# Tender Response Studio — Python Edition

## What changed
The original pure-JS workflow has been converted to a **Python/Flask backend**. All logic that was previously running in the browser (NLP classification, risk assessment, tender extraction) now runs server-side via **Python + Anthropic Claude API**.

## Architecture

```
Browser (HTML/CSS/JS — identical UI)
        │
        │  HTTP fetch calls
        ▼
Flask Backend (app.py)
        │
        │  Anthropic Claude API
        ▼
Claude Sonnet (NLP + analysis)
```

## Python API Endpoints

| Endpoint | Method | Description |
|---|---|---|
| `/api/agents` | GET | Returns agent definitions and confidence scores |
| `/api/extract-tender` | POST | PDF upload → Claude extracts ITT fields |
| `/api/assess-risk` | POST | Extracted data → Claude risk assessment |
| `/api/classify-feedback` | POST | NLP feedback → action classification (LLM) |
| `/api/classify-rda-intent` | POST | RDA feedback intent classification (LLM) |
| `/api/detect-action` | POST | Fast regex-based action detection (no LLM) |

## Files

```
tender_studio/
├── app.py                          ← Flask app + all Python logic
├── requirements.txt
├── templates/
│   └── index.html                  ← Original HTML (unchanged visually)
└── static/
    ├── css/
    │   └── tender-response-studio.css   ← your existing CSS file
    └── js/
        ├── tender-response-studio.js    ← original animation/UI JS
        ├── tenderstudio-wiring.js       ← NEW: Python API bridge
        └── sentinel-api.js              ← stub (replaced by Python)
```

## Setup

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Set your Anthropic API key
export ANTHROPIC_API_KEY=sk-ant-...

# 3. Copy your existing CSS file
cp tender-response-studio.css static/css/

# 4. Run the server
python app.py
# → http://localhost:5000
```

## What's Python-powered

| Feature | Before | After |
|---|---|---|
| ITT PDF extraction | JS/browser | Python + PyMuPDF + Claude |
| Risk assessment | JS hardcoded | Python + Claude (dynamic) |
| CP1/CP2 NLP feedback | JS regex | Python + Claude (semantic) |
| RDA intent classification | JS regex | Python + Claude (enriched) |
| Live intent detection | JS regex | Python regex (fast, no LLM) |
| Agent data | JS constants | Python constants (served via API) |

## Notes
- The CSS file (`tender-response-studio.css`) is not included — copy it from your existing setup.
- The UI is 100% identical to the original — all HTML/CSS/animation JS is preserved.
- The Python backend gracefully falls back to local regex classification if the Anthropic API is unavailable.
