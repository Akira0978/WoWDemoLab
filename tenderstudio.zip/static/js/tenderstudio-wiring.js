/**
 * tenderstudio-wiring.js
 * ─────────────────────────────────────────────────────────────────
 * Python-powered wiring layer.
 * All agent logic, NLP classification, risk assessment, and tender
 * extraction are delegated to the Flask backend (/api/*).
 *
 * This file replaces sentinel-api.js and tenderstudio-wiring.js.
 * The original tender-response-studio.js handles all DOM animation
 * and UI state — this file only intercepts the API calls.
 * ─────────────────────────────────────────────────────────────────
 */

/* ── Python API helpers ──────────────────────────────────────── */

async function pyPost(endpoint, body) {
  const opts = {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  };
  const resp = await fetch(endpoint, opts);
  if (!resp.ok) throw new Error(`${endpoint} → ${resp.status}`);
  return resp.json();
}

async function pyGet(endpoint) {
  const resp = await fetch(endpoint);
  if (!resp.ok) throw new Error(`${endpoint} → ${resp.status}`);
  return resp.json();
}

/* ── Override: PDF extraction ────────────────────────────────── */
/**
 * Replaces trsExtractFile().
 * Sends the PDF to /api/extract-tender (Python/Claude extracts fields).
 */
window.trsExtractFile = function(file) {
  if (!file || !file.name.toLowerCase().endsWith('.pdf')) return;
  const fd = new FormData();
  fd.append('file', file);
  fetch('/api/extract-tender', { method: 'POST', body: fd })
    .then(r => r.json())
    .then(data => {
      if (data && !data.error) {
        window.trsExtractedData = data;
        console.log('[TRS-PY] Extraction complete:', data);
      }
    })
    .catch(e => console.warn('[TRS-PY] Extraction failed (non-blocking):', e));
};

/* ── Override: Risk engine ───────────────────────────────────── */
/**
 * Replaces the runRiskEngine() internal fetch call.
 * Calls /api/assess-risk with extracted tender data.
 * Result shape is identical to what the original JS expects.
 */
window._pyAssessRisk = async function() {
  const payload = window.trsExtractedData || {};
  const resp = await fetch('/api/assess-risk', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  if (!resp.ok) throw new Error('/api/assess-risk → ' + resp.status);
  return resp.json();
};

/* Monkey-patch runRiskEngine to use Python backend */
const _origRunRiskEngine = window.runRiskEngine;
window.runRiskEngine = async function() {
  /* Swap internal fetch for Python API call */
  const consolEl = document.getElementById('riskConsole');
  if (!consolEl) return;

  consolEl.classList.add('show');

  /* Reset UI state */
  for (let i = 0; i < 6; i++) {
    const step = document.getElementById('rcStep' + i);
    const icon = document.getElementById('rcStepIcon' + i);
    if (step) step.classList.remove('visible');
    if (icon) { icon.className = 'rc-step-icon'; icon.textContent = ''; }
  }

  const grid      = document.getElementById('rcGrid');
  const scoreWrap = document.getElementById('rcScoreWrap');
  const flagsEl   = document.getElementById('rcFlags');
  const toggle    = document.getElementById('rcToggle');
  if (grid)      grid.style.display      = 'none';
  if (scoreWrap) scoreWrap.style.display = 'none';
  if (flagsEl)   { flagsEl.style.display = 'none'; flagsEl.innerHTML = ''; }
  if (toggle)    toggle.style.display    = 'none';

  const gonogo      = document.getElementById('rcGoNogo');
  const gonogoLabel = document.getElementById('rcGoNogoLabel');
  if (gonogo)      gonogo.className  = 'rc-gonogo scanning';
  if (gonogoLabel) gonogoLabel.textContent = 'Scanning\u2026';

  const sub     = document.getElementById('rcHeaderSub');
  const stepsEl = document.getElementById('rcSteps');
  if (sub)     sub.textContent  = 'Python agent analysing uploaded ITT document\u2026';
  if (stepsEl) stepsEl.style.display = 'block';

  /* Animate steps while Python API call is in flight */
  const stepDelays = [0, 400, 850, 1300, 1750, 2200];
  const riskPromise = window._pyAssessRisk().catch(e => {
    console.warn('[Risk Engine] Python API failed:', e);
    return null;
  });

  for (let i = 0; i < 6; i++) {
    await sleep(stepDelays[i]);
    const step = document.getElementById('rcStep' + i);
    const icon = document.getElementById('rcStepIcon' + i);
    if (step) step.classList.add('visible');
    if (icon) icon.className = 'rc-step-icon processing';
    await sleep(350);
    if (icon) { icon.className = 'rc-step-icon done'; icon.textContent = '\u2713'; }
  }

  const riskData = await riskPromise;
  if (!riskData || riskData.error) {
    if (sub) sub.textContent = 'Risk assessment unavailable — using defaults.';
    return;
  }

  /* ── Render dimension grid ── */
  if (grid) {
    grid.style.display = 'grid';
    const dimMap = {
      commercial:   { score: 'rcScoreCommercial', bar: 'rcBarCommercial', tag: 'rcTagCommercial' },
      technical:    { score: 'rcScoreTechnical',  bar: 'rcBarTechnical',  tag: 'rcTagTechnical'  },
      programme:    { score: 'rcScoreProgramme',  bar: 'rcBarProgramme',  tag: 'rcTagProgramme'  },
      supply_chain: { score: 'rcScoreSupply',     bar: 'rcBarSupply',     tag: 'rcTagSupply'     },
      strategic:    { score: 'rcScoreStrategic',  bar: 'rcBarStrategic',  tag: 'rcTagStrategic'  },
    };
    const dims = riskData.dimensions || {};
    Object.keys(dimMap).forEach(key => {
      const d = dims[key] || {};
      const ids = dimMap[key];
      const scoreEl = document.getElementById(ids.score);
      const barEl   = document.getElementById(ids.bar);
      const tagEl   = document.getElementById(ids.tag);
      const score = d.score || 0;
      const label = d.label || 'low';
      if (scoreEl) { scoreEl.textContent = score; scoreEl.className = 'rc-cell-score ' + label; }
      if (barEl)   { barEl.className = 'rc-cell-bar ' + label; requestAnimationFrame(() => requestAnimationFrame(() => { barEl.style.width = Math.min(score, 100) + '%'; })); }
      if (tagEl)   tagEl.textContent = label.charAt(0).toUpperCase() + label.slice(1) + ' risk';
    });
  }

  /* ── Overall score ring ── */
  const overall      = riskData.overall_score || 0;
  const overallLabel = riskData.overall_label || 'low';
  if (scoreWrap) {
    scoreWrap.style.display = 'flex';
    const valEl   = document.getElementById('rcOverallScore');
    const fillEl  = document.getElementById('rcRingFill');
    const titleEl = document.getElementById('rcScoreTitle');
    const descEl  = document.getElementById('rcScoreDesc');
    if (valEl)   valEl.textContent   = overall;
    if (titleEl) titleEl.textContent = riskData.decision_label || 'Risk Assessment Complete';
    if (descEl)  descEl.textContent  = riskData.decision_desc  || '';
    const ringColors = { low: '#00a886', medium: '#d97706', high: '#EC1B2E' };
    const ringColor  = ringColors[overallLabel] || '#d97706';
    const circ   = 163;
    const offset = circ - (overall / 100) * circ;
    if (fillEl) {
      fillEl.style.stroke = ringColor;
      fillEl.style.strokeDashoffset = circ;
      requestAnimationFrame(() => requestAnimationFrame(() => {
        fillEl.style.transition = 'stroke-dashoffset .9s cubic-bezier(.22,1,.36,1),stroke .3s ease';
        fillEl.style.strokeDashoffset = offset;
      }));
    }
  }

  /* ── Go/No-Go badge ── */
  const decision = riskData.decision || 'conditional';
  if (gonogo)      gonogo.className            = 'rc-gonogo ' + decision;
  if (gonogoLabel) gonogoLabel.textContent     = riskData.decision_label || decision.toUpperCase();

  /* ── Risk flags ── */
  const flags = riskData.flags || [];
  if (flagsEl && flags.length) {
    flagsEl.style.display = 'flex';
    flagsEl.innerHTML = flags.slice(0, 8).map((f, fi) => {
      const level = f.level || 'medium';
      const steps = (f.mitigation_steps || []).map((s, si) => `
        <div class="rc-mit-step">
          <div class="rc-mit-num">${si + 1}</div>
          <span>${s}</span>
        </div>`).join('');
      const urgencyColor = f.urgency && f.urgency.toLowerCase().includes('critical') ? '#EC1B2E'
        : f.urgency && f.urgency.toLowerCase().includes('cp1') ? '#d97706' : '#607080';
      return `
      <div class="rc-flag ${level}" id="rcFlag${fi}">
        <div class="rc-flag-header" onclick="rcToggleFlag(${fi})">
          <span class="rc-flag-badge">${level.toUpperCase()}</span>
          <div class="rc-flag-text">
            <div class="rc-flag-title">${f.title || ''}</div>
            <div class="rc-flag-detail">${f.detail || ''}</div>
          </div>
          <div class="rc-flag-meta">
            ${f.owner ? `<span class="rc-flag-owner"><svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>${f.owner}</span>` : ''}
            ${f.urgency ? `<span class="rc-flag-urgency" style="color:${urgencyColor}">⏰ ${f.urgency}</span>` : ''}
          </div>
          <div class="rc-flag-chevron" id="rcFlagChevron${fi}">
            <svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg>
          </div>
        </div>
        <div class="rc-flag-body" id="rcFlagBody${fi}">
          ${steps ? `<div class="rc-mit-section">
            <div class="rc-mit-label">
              <svg viewBox="0 0 24 24"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
              Mitigation Steps
            </div>
            <div class="rc-mit-steps">${steps}</div>
          </div>` : ''}
          ${f.forecast ? `<div class="rc-forecast">
            <div class="rc-forecast-label">
              <svg viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
              Risk Forecast
            </div>
            <div class="rc-forecast-text">${f.forecast}</div>
          </div>` : ''}
        </div>
      </div>`;
    }).join('');
  }

  if (sub) {
    const tenderTitle = riskData.tender_title || 'ITT Document';
    const clientName  = riskData.client_name  || '';
    sub.textContent = `${tenderTitle}${clientName ? ' · ' + clientName : ''} · ${flags.length} risk flag${flags.length !== 1 ? 's' : ''} identified`;
  }
  if (toggle) toggle.style.display = 'flex';
  await sleep(600);
  if (stepsEl) stepsEl.style.display = 'none';
};

/* ── Override: CP1 NLP feedback dispatch ─────────────────────── */
/**
 * Replaces cp1DispatchNlpAction().
 * Sends feedback to /api/classify-feedback (Python/Claude classifies it).
 */
window.cp1DispatchNlpAction = async function(text) {
  if (!text) return;

  /* Fast local detection for the intent strip (no API needed) */
  const action  = _pyClassifyAction(text);
  const section = _pyDetectSection(text);
  let container = document.getElementById('cp1NlpActionsContainer');
  if (!container) {
    container = document.createElement('div');
    container.id = 'cp1NlpActionsContainer';
    container.className = 'cp-nlp-actions-container';
    const notesWrap = document.getElementById('cp1NotesWrap');
    if (notesWrap) notesWrap.insertAdjacentElement('afterend', container);
  }

  /* Show loading card */
  const loadId = 'cp1NlpLoad_' + Date.now();
  const loadDiv = document.createElement('div');
  loadDiv.id = loadId;
  loadDiv.className = 'cp-nlp-card';
  loadDiv.style.cssText = 'border-left-color:#1976d2;opacity:.6;';
  loadDiv.innerHTML = '<div style="padding:12px 14px;font-size:12px;color:#607080;">Python NLP engine classifying feedback\u2026</div>';
  container.appendChild(loadDiv);

  try {
    const result = await pyPost('/api/classify-feedback', { feedback: text, checkpoint: 'CP1' });
    loadDiv.remove();

    const wrapper = document.createElement('div');
    wrapper.innerHTML = cp_buildNotificationCard(
      result.action || action,
      result.section_key ? { key: result.section_key, lead: result.lead_name, role: result.lead_role, email: result.lead_email, color: result.lead_color, initials: result.lead_initials } : section,
      text, 'CP1', 'Bid Manager'
    );
    const card = wrapper.firstElementChild;
    card.style.cssText += 'opacity:0;transform:translateY(6px);transition:opacity .35s ease,transform .35s ease;';
    container.appendChild(card);
    requestAnimationFrame(() => requestAnimationFrame(() => { card.style.opacity = '1'; card.style.transform = 'translateY(0)'; }));

    cp_logToTrace('CP1', result.action || action, section, text, 'Bid Manager');

    if ((result.action || action) === 'rereview' || (result.action || action) === 'notify') {
      await cp_showDispatchSequence('cp1NlpActionsContainer', section, text, result.action || action);
    }
  } catch (e) {
    console.warn('[TRS-PY] cp1 NLP fallback to local:', e);
    loadDiv.remove();
    /* Fallback to local classification */
    const wrapper = document.createElement('div');
    wrapper.innerHTML = cp_buildNotificationCard(action, section, text, 'CP1', 'Bid Manager');
    const card = wrapper.firstElementChild;
    container.appendChild(card);
    cp_logToTrace('CP1', action, section, text, 'Bid Manager');
  }
};

/* ── Override: CP2 NLP feedback dispatch ─────────────────────── */
window.cp2DispatchDirectorFeedback = async function(directorIdx, text) {
  if (!text) return;
  const dirNames = ['D. Patel (BU Director)', 'C. Wright (Commercial Director)'];
  const approver = dirNames[directorIdx] || 'Director';
  const action   = _pyClassifyAction(text);
  const section  = _pyDetectSection(text);
  const cid = 'cp2NlpContainer' + directorIdx;
  let container = document.getElementById(cid);
  if (!container) {
    container = document.createElement('div');
    container.id = cid;
    container.className = 'cp-nlp-actions-container';
    const apCard = document.getElementById('apCard' + directorIdx);
    if (apCard) apCard.insertAdjacentElement('afterend', container);
    else {
      const cp2Inner = document.querySelector('#cp2Row .hitl-inner');
      if (cp2Inner) cp2Inner.appendChild(container);
    }
  }

  try {
    const result = await pyPost('/api/classify-feedback', { feedback: text, checkpoint: 'CP2' });
    const sectionData = result.section_key
      ? { key: result.section_key, lead: result.lead_name, role: result.lead_role, email: result.lead_email, color: result.lead_color, initials: result.lead_initials }
      : section;

    const wrapper = document.createElement('div');
    wrapper.innerHTML = cp_buildNotificationCard(result.action || action, sectionData, text, 'CP2', approver);
    const card = wrapper.firstElementChild;
    card.style.cssText += 'opacity:0;transform:translateY(6px);transition:opacity .35s ease,transform .35s ease;';
    container.appendChild(card);
    requestAnimationFrame(() => requestAnimationFrame(() => { card.style.opacity = '1'; card.style.transform = 'translateY(0)'; }));
    cp_logToTrace('CP2', result.action || action, sectionData, text, approver);
    if (['rereview', 'notify', 'flag'].includes(result.action || action)) {
      await cp_showDispatchSequence(cid, sectionData, text, result.action || action);
    }
  } catch (e) {
    console.warn('[TRS-PY] cp2 NLP fallback to local:', e);
    const wrapper = document.createElement('div');
    wrapper.innerHTML = cp_buildNotificationCard(action, section, text, 'CP2', approver);
    container.appendChild(wrapper.firstElementChild);
    cp_logToTrace('CP2', action, section, text, approver);
  }
};

/* ── Override: Live NLP intent detection (uses Python endpoint) ─ */
/**
 * Intercepts cp1OnNotesInput / cp2OnNotesInput for live intent strips.
 * Uses /api/detect-action (fast, regex-only, no LLM) for real-time hints.
 */
let _detectActionTimer = null;

function _pyLiveDetect(text, hintEl, stripEl, dispatchBtnEl) {
  if (dispatchBtnEl) dispatchBtnEl.disabled = !text;
  if (!text) {
    if (hintEl)  hintEl.textContent = '';
    if (stripEl) stripEl.innerHTML  = '';
    return;
  }
  /* Debounce — fire 200ms after user stops typing */
  clearTimeout(_detectActionTimer);
  _detectActionTimer = setTimeout(async () => {
    try {
      const result = await pyPost('/api/detect-action', { text });
      const meta = result.meta || {};
      const section = result.section;
      const secLabel = section ? ' — ' + section.key.charAt(0).toUpperCase() + section.key.slice(1) : '';
      const leadLabel = section ? ' → ' + section.lead : '';
      if (stripEl) {
        stripEl.innerHTML = `<span style="display:inline-flex;align-items:center;gap:4px;padding:1px 8px;border-radius:999px;font-size:10px;font-weight:700;background:${meta.bg || 'rgba(96,112,128,.1)'};color:${meta.color || '#607080'};">${meta.icon || '💬'} ${meta.label || 'Feedback Logged'}${secLabel}${leadLabel}</span>`;
      }
    } catch (_) {
      /* Fallback: use local classify */
      const action = _pyClassifyAction(text);
      const meta   = CP_ACTION_META[action] || CP_ACTION_META.general;
      if (stripEl) stripEl.innerHTML = `<span style="display:inline-flex;align-items:center;gap:4px;padding:1px 8px;border-radius:999px;font-size:10px;font-weight:700;background:${meta.bg};color:${meta.color};">${meta.icon} ${meta.label}</span>`;
    }
  }, 200);
}

/* Patch cp1OnNotesInput */
window.cp1OnNotesInput = function(ta) {
  const val = ta.value.trim();
  _pyLiveDetect(val, document.getElementById('cp1NlpHint'), document.getElementById('cp1IntentStrip'), document.getElementById('cp1DispatchBtn'));
};

/* Patch cp2OnNotesInput */
window.cp2OnNotesInput = function(directorIdx, ta) {
  const val = ta.value.trim();
  _pyLiveDetect(val, null, document.getElementById('cp2IntentStrip' + directorIdx), document.getElementById('cp2DispatchBtn' + directorIdx));
};

/* ── Override: RDA intent classification ─────────────────────── */
/**
 * Wraps rdaClassifyIntent so that classification goes through Python.
 * For live typing hints we keep the fast local regex (rdaOnInput).
 * For actual submission (rdaSubmitFeedback) we enrich with Python.
 */
window.rdaOnInput = function(ta) {
  const val = ta.value.trim();
  const cc  = document.getElementById('rdaCharCount'); if (cc) cc.textContent = ta.value.length;
  const btn = document.getElementById('rdaRetriggerBtn'); if (btn) btn.disabled = val.length < 5;
  const strip  = document.getElementById('rdaIntentStrip');
  const hint   = document.getElementById('rdaIntentHint');
  const status = document.getElementById('rdaFeedbackStatus');
  if (!val) {
    if (strip)  strip.innerHTML   = '';
    if (hint)   hint.textContent  = '';
    if (status) status.textContent = 'Enter feedback to enable re-trigger';
    return;
  }
  /* Fast local classify for responsive UI */
  const intent = rdaClassifyIntent(val);
  if (strip)  strip.innerHTML  = `<span class="rda-intent-chip ${intent.chipClass} active">${intent.icon} ${intent.label}</span><span style="font-size:11px;color:#607080;align-self:center;">Intent detected</span>`;
  if (hint)   hint.textContent = intent.type.toUpperCase();
  if (status) status.textContent = 'Intent: ' + intent.label + ' — click Re-trigger to apply';

  /* Async enrich from Python */
  clearTimeout(_detectActionTimer);
  _detectActionTimer = setTimeout(async () => {
    try {
      const result = await pyPost('/api/classify-rda-intent', { text: val });
      if (result && result.label) {
        if (strip)  strip.innerHTML  = `<span class="rda-intent-chip ${result.chipClass || intent.chipClass} active">${result.icon || intent.icon} ${result.label}</span><span style="font-size:11px;color:#607080;align-self:center;">Python NLP detected</span>`;
        if (hint)   hint.textContent = result.type.toUpperCase();
        if (status) status.textContent = 'Intent: ' + result.label + ' — click Re-trigger to apply';
      }
    } catch (_) { /* keep local result */ }
  }, 250);
};

/* ── Local Python-mirroring helpers (fast, no API) ──────────── */
/** Mirror of Python classify_action() */
function _pyClassifyAction(text) {
  const t = text.toLowerCase();
  if (/re.?review|review.*section|check.*section|look.*at|revisit/.test(t))  return 'rereview';
  if (/notify|send.*to|alert|inform|contact|request.*review/.test(t))         return 'notify';
  if (/escalate|raise|flag.*director|escalation/.test(t))                      return 'escalate';
  if (/flag|highlight|mark|note|attention/.test(t))                            return 'flag';
  if (/remove|delete|drop|exclude/.test(t))                                    return 'remove';
  if (/rephrase|rewrite|update|revise|amend/.test(t))                          return 'rephrase';
  if (/add|include|insert/.test(t))                                            return 'add';
  return 'general';
}

const _CP1_SECTION_LEADS = {
  'health':        { lead: 'S. Patel',           role: 'H&S Lead',           email: 's.patel@gallifordtry.com',     color: '#EC1B2E', initials: 'SP' },
  'safety':        { lead: 'S. Patel',           role: 'H&S Lead',           email: 's.patel@gallifordtry.com',     color: '#EC1B2E', initials: 'SP' },
  'sustainability':{ lead: 'L. Ahmed',           role: 'Sustainability Lead', email: 'l.ahmed@gallifordtry.com',     color: '#00a886', initials: 'LA' },
  'carbon':        { lead: 'L. Ahmed',           role: 'Sustainability Lead', email: 'l.ahmed@gallifordtry.com',     color: '#00a886', initials: 'LA' },
  'supply chain':  { lead: 'R. Chen',            role: 'Supply Chain Lead',  email: 'r.chen@gallifordtry.com',      color: '#7c5cfc', initials: 'RC' },
  'technical':     { lead: 'J. Harrison',        role: 'Technical Lead',     email: 'j.harrison@gallifordtry.com',  color: '#1976d2', initials: 'JH' },
  'commercial':    { lead: 'Commercial Manager', role: 'Commercial Lead',    email: 'commercial@gallifordtry.com',  color: '#f5a623', initials: 'CM' },
  'quality':       { lead: 'Quality Manager',    role: 'Quality Lead',       email: 'quality@gallifordtry.com',     color: '#00c2e0', initials: 'QM' },
  'social value':  { lead: 'L. Ahmed',           role: 'Sustainability Lead', email: 'l.ahmed@gallifordtry.com',   color: '#00a886', initials: 'LA' },
};

/** Mirror of Python detect_section() */
function _pyDetectSection(text) {
  const t = text.toLowerCase();
  for (const key of Object.keys(_CP1_SECTION_LEADS)) {
    if (t.includes(key)) return { key, ..._CP1_SECTION_LEADS[key] };
  }
  const m = t.match(/section\s+([\d]+(?:\.\d+)?)/);
  if (m) {
    const n = parseFloat(m[1]);
    const map = { 4: 'health', 5: 'sustainability', 6: 'supply chain', 7: 'commercial', 8: 'quality', 9: 'social value' };
    const k = map[Math.floor(n)] || 'technical';
    return { key: 'Section ' + m[1], ..._CP1_SECTION_LEADS[k] };
  }
  return null;
}

/* ── Expose Python backend status in console ─────────────────── */
window.addEventListener('DOMContentLoaded', () => {
  pyGet('/api/agents')
    .then(data => {
      console.log('[TRS-PY] Backend connected. Agents loaded:', data.agents.length);
    })
    .catch(() => {
      console.warn('[TRS-PY] Backend not reachable — running in offline mode.');
    });
});
