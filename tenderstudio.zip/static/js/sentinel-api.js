/**
 * sentinel-api.js — stub
 * Original sentinel API replaced by Python Flask backend.
 * All real logic lives in app.py and tenderstudio-wiring.js.
 */
console.log('[Sentinel] Python backend active — sentinel-api.js is a no-op stub.');
