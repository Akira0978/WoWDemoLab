"""
Tender Response Studio — Python/Flask Backend
All agent logic, NLP classification, risk assessment, and tender extraction
are handled server-side in Python via Anthropic API.
"""

import os
import re
import json
import time
import tempfile
from datetime import datetime
from flask import Flask, request, jsonify, render_template, send_from_directory

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 50 * 1024 * 1024  # 50MB

# ─── Anthropic client (lazy-loaded so server starts without key) ───
_anthropic = None

def get_anthropic():
    global _anthropic
    if _anthropic is None:
        import anthropic
        _anthropic = anthropic.Anthropic(api_key=os.environ.get("ANTHROPIC_API_KEY", ""))
    return _anthropic


# ═══════════════════════════════════════════════════════════════════
#  AGENT DATA — mirrors JS AGENTS / CONFIDENCE / META arrays
# ═══════════════════════════════════════════════════════════════════

AGENTS = [
    {
        "AGENT_NAME": "Orchestrator agent",
        "AGENT_DESCRIPTION": "Coordinates the end-to-end agentic workflow, actively managing timing, sequencing, dependencies, and alerts throughout the tender window.",
        "TASKS": [
            "Ensuring every workstream starts at the right moment",
            "Keeping your bid on schedule by continuously monitoring the tender clock and flagging any timeline risks before they become critical",
            "Maximising team productivity by running independent workstreams simultaneously, compressing the overall bid preparation timeline",
            "Proactively surfacing deadline and dependency risks so bid managers can intervene early rather than react under pressure",
            "Guaranteeing governance integrity by enforcing mandatory human approval checkpoints",
        ],
        "TOOLS_USED": ["Workflow state management", "Task sequencing and dependency tracking", "Alerting and notification mechanisms"],
        "BUSINESS_OUTCOMES": [
            "Faster bid turnaround — parallel workstreams reduce end-to-end preparation time by up to 40%, freeing your team to focus on bid quality",
            "Zero missed deadlines — real-time milestone tracking and proactive alerts ensure your submission is always on track",
            "Full governance assurance — mandatory human checkpoints mean no response leaves without the right approvals in place",
        ],
    },
    {
        "AGENT_NAME": "ITT intake & analysis agent",
        "AGENT_DESCRIPTION": "Ingests ITT documentation and produces a structured understanding of the tender along with early commercial and delivery risk flags.",
        "TASKS": [
            "Instantly processing your received Invitation to Tender",
            "Translating complex ITT instructions into a clear, structured requirements map so entire bid team works from a shared, accurate understanding",
            "Delivering a ready-to-use Tender Summary Brief to all contributors",
            "Identifying commercial, contractual, and delivery risks early",
            "Surfacing clarification questions and risk flags immediately",
        ],
        "TOOLS_USED": ["Document ingestion and parsing", "Requirement and risk extraction logic"],
        "BUSINESS_OUTCOMES": [
            "Day-one clarity — Tender Summary successfully created for Bid Manager review",
            "Risk-aware bidding — Risks have been flagged and summary has been created for Commercial Manager review",
        ],
    },
    {
        "AGENT_NAME": "Content retrieval agent",
        "AGENT_DESCRIPTION": "Searches the bid content library to find and rank the most relevant prior material aligned to the current ITT.",
        "TASKS": [
            "Instantly searching your entire bid content library against this tender's specific requirements — delivering the best available evidence in seconds",
            "Surfacing the most relevant winning submissions, method statements, and case references, giving your drafters a head start with proven, high-quality content",
            "Scoring and ranking all retrieved content by relevance and past performance",
            "Structuring the retrieved content into ready-to-use inputs for the drafting agent — ensuring nothing is lost in translation between research and writing",
        ],
        "TOOLS_USED": ["Content library search", "Relevance ranking mechanism"],
        "BUSINESS_OUTCOMES": [
            "Higher-quality responses — bids are built on your most relevant, proven content rather than starting from a blank page, raising the standard of every submission",
            "Significant time saving — automated content retrieval eliminates manual library searches, reclaiming hours of bid team capacity per tender",
            "Institutional knowledge captured — past successes are systematically re-applied, ensuring your organisation's expertise informs every new bid",
        ],
    },
    {
        "AGENT_NAME": "Governance pack agent",
        "AGENT_DESCRIPTION": "Assembles the governance pack in parallel with drafting, ensuring decision-makers receive a complete and structured overview.",
        "TASKS": [
            "Continuously assembling your governance pack as the bid develops — so directors always have an up-to-date view",
            "Consolidating risk flags, bid confidence scores, and key summaries into a single decision-ready document",
            "Maintaining a live, always-current governance overview throughout the bid — eliminating the last-minute scramble to prepare director briefing packs",
            "Preparing a structured, professionally formatted governance pack ahead of Checkpoint 2 — ensuring executive sign-off is informed, efficient, and audit-ready",
        ],
        "TOOLS_USED": ["Automated document assembly", "Structured summary generation"],
        "BUSINESS_OUTCOMES": [
            "Faster director decisions — structured governance packs enable informed sign-off in minutes rather than requiring lengthy briefing sessions",
            "Reduced governance overhead — automated assembly eliminates the manual effort of consolidating bid data for leadership review",
            "Stronger audit trail — every governance decision is backed by a complete, timestamped pack, supporting compliance and post-bid review",
        ],
    },
    {
        "AGENT_NAME": "Response drafting agent",
        "AGENT_DESCRIPTION": "Produces a full compliant draft response aligned to ITT criteria and performs self-checks against those criteria.",
        "TASKS": [
            "Producing a complete, structured draft response precisely aligned to each ITT question and scoring criterion",
            "Seamlessly weaving your strongest existing content into compliant, coherent narratives",
            "Continuously validating the draft against evaluation criteria as it writing",
            "Rapidly incorporating reviewer feedback and requested amendments",
            "Maintaining a complete, submission-ready draft available for Checkpoint 1 review at any time",
        ],
        "TOOLS_USED": ["Draft generation engine", "Criteria-alignment and self-check logic"],
        "BUSINESS_OUTCOMES": [
            "Submission-ready quality from the first draft — AI-generated responses aligned to scoring criteria reduce the revision burden on your bid team by up to 60%",
            "Higher win probability — criterion-by-criterion alignment ensures your response directly addresses what evaluators are scoring, maximising your competitive score",
            "Faster review cycles — a structured, pre-validated draft means bid managers spend time refining and approving, not correcting and rebuilding",
        ],
    },
    {
        "AGENT_NAME": "Governance & compliance agent",
        "AGENT_DESCRIPTION": "Performs final compliance checks and confirms submission readiness before handoff to the bid manager.",
        "TASKS": [
            "Conducting a thorough compliance review across every section of your submission",
            "Verifying that all mandatory attachments, declarations, and format requirements are present and correctly structured",
            "Providing a complete audit trail of agent activities and human decisions",
            "Generating a definitive Submission Readiness Report",
        ],
        "TOOLS_USED": ["Compliance checking mechanisms", "Submission readiness evaluation"],
        "BUSINESS_OUTCOMES": [
            "Zero disqualification risk — automated compliance verification ensures every submission meets mandatory requirements before it leaves your organisation",
            "Confident, evidence-backed submission — the Readiness Report gives leadership a clear green light, replacing gut-feel with verified assurance",
            "Continuous improvement culture — full audit trails enable post-bid analysis, helping Galliford Try refine its approach and strengthen future submissions",
        ],
    },
]

CONFIDENCE = [
    {"score": 100, "note": None},
    {"score": 97,  "note": "Minor ambiguity detected in two ITT evaluation sub-criteria — bid team review recommended before drafting begins."},
    {"score": 94,  "note": "Three content library matches scored below the relevance threshold — supplementary evidence may strengthen the response."},
    {"score": 100, "note": None},
    {"score": 96,  "note": "One response section flagged for potential word-count variance against ITT guidance — reviewer attention advised at CP1."},
    {"score": 91,  "note": "Mandatory attachment cross-check identified one declaration requiring manual countersignature before submission is complete."},
]

CP1_SECTION_LEADS = {
    "health":        {"lead": "S. Patel",           "role": "H&S Lead",           "email": "s.patel@gallifordtry.com",     "color": "#EC1B2E", "initials": "SP"},
    "safety":        {"lead": "S. Patel",           "role": "H&S Lead",           "email": "s.patel@gallifordtry.com",     "color": "#EC1B2E", "initials": "SP"},
    "h&s":           {"lead": "S. Patel",           "role": "H&S Lead",           "email": "s.patel@gallifordtry.com",     "color": "#EC1B2E", "initials": "SP"},
    "sustainability": {"lead": "L. Ahmed",           "role": "Sustainability Lead", "email": "l.ahmed@gallifordtry.com",    "color": "#00a886", "initials": "LA"},
    "carbon":        {"lead": "L. Ahmed",           "role": "Sustainability Lead", "email": "l.ahmed@gallifordtry.com",    "color": "#00a886", "initials": "LA"},
    "supply chain":  {"lead": "R. Chen",            "role": "Supply Chain Lead",  "email": "r.chen@gallifordtry.com",     "color": "#7c5cfc", "initials": "RC"},
    "subcontract":   {"lead": "R. Chen",            "role": "Supply Chain Lead",  "email": "r.chen@gallifordtry.com",     "color": "#7c5cfc", "initials": "RC"},
    "technical":     {"lead": "J. Harrison",        "role": "Technical Lead",     "email": "j.harrison@gallifordtry.com", "color": "#1976d2", "initials": "JH"},
    "methodology":   {"lead": "J. Harrison",        "role": "Technical Lead",     "email": "j.harrison@gallifordtry.com", "color": "#1976d2", "initials": "JH"},
    "programme":     {"lead": "J. Harrison",        "role": "Technical Lead",     "email": "j.harrison@gallifordtry.com", "color": "#1976d2", "initials": "JH"},
    "commercial":    {"lead": "Commercial Manager", "role": "Commercial Lead",    "email": "commercial@gallifordtry.com",  "color": "#f5a623", "initials": "CM"},
    "pricing":       {"lead": "Commercial Manager", "role": "Commercial Lead",    "email": "commercial@gallifordtry.com",  "color": "#f5a623", "initials": "CM"},
    "quality":       {"lead": "Quality Manager",    "role": "Quality Lead",       "email": "quality@gallifordtry.com",     "color": "#00c2e0", "initials": "QM"},
    "social value":  {"lead": "L. Ahmed",           "role": "Sustainability Lead", "email": "l.ahmed@gallifordtry.com",   "color": "#00a886", "initials": "LA"},
}

CP_ACTION_META = {
    "rereview": {"label": "Re-review Requested",     "color": "#1976d2", "bg": "rgba(25,118,210,.1)",  "icon": "🔄"},
    "notify":   {"label": "Notification Dispatched", "color": "#00a886", "bg": "rgba(0,168,134,.1)",   "icon": "🔔"},
    "escalate": {"label": "Escalation Raised",       "color": "#EC1B2E", "bg": "rgba(236,27,46,.1)",   "icon": "▲"},
    "flag":     {"label": "Section Flagged",         "color": "#d97706", "bg": "rgba(245,166,35,.1)",  "icon": "🚩"},
    "remove":   {"label": "Removal Requested",       "color": "#EC1B2E", "bg": "rgba(236,27,46,.1)",   "icon": "✕"},
    "rephrase": {"label": "Revision Requested",      "color": "#7c5cfc", "bg": "rgba(124,92,252,.1)",  "icon": "✎"},
    "add":      {"label": "Addition Requested",      "color": "#00a886", "bg": "rgba(0,168,134,.1)",   "icon": "+"},
    "general":  {"label": "Feedback Logged",         "color": "#607080", "bg": "rgba(96,112,128,.1)",  "icon": "💬"},
}

RDA_INTENT_PATTERNS = {
    "remove":  r"remove|delete|drop|exclude|take out|get rid",
    "rephrase": r"rephrase|rewrite|update|revise|amend|improve|change|refine|shorten|concise|simplify",
    "add":     r"add|include|insert|append|expand|extend|incorporate",
    "reorder": r"reorder|restructure|reorganise|reorganize|move|swap|shift|rearrange",
}


# ═══════════════════════════════════════════════════════════════════
#  PYTHON NLP CLASSIFICATION ENGINES
# ═══════════════════════════════════════════════════════════════════

def classify_action(text: str) -> str:
    """Classify the action type from free-text feedback (mirrors cp_classifyAction)."""
    t = text.lower()
    if re.search(r"re.?review|review.*section|check.*section|look.*at|revisit", t):
        return "rereview"
    if re.search(r"notify|send.*to|alert|inform|contact|request.*review", t):
        return "notify"
    if re.search(r"escalate|raise|flag.*director|escalation", t):
        return "escalate"
    if re.search(r"flag|highlight|mark|note|attention", t):
        return "flag"
    if re.search(r"remove|delete|drop|exclude", t):
        return "remove"
    if re.search(r"rephrase|rewrite|update|revise|amend", t):
        return "rephrase"
    if re.search(r"add|include|insert", t):
        return "add"
    return "general"


def detect_section(text: str) -> dict | None:
    """Detect which bid section is mentioned in text (mirrors cp_detectSection)."""
    t = text.lower()
    for key, lead_info in CP1_SECTION_LEADS.items():
        if key in t:
            return {"key": key, **lead_info}
    m = re.search(r"section\s+([\d]+(?:\.\d+)?)", t)
    if m:
        n = float(m.group(1))
        section_map = {
            4: "health", 5: "sustainability", 6: "supply chain",
            7: "commercial", 8: "quality", 9: "social value",
        }
        lead_key = section_map.get(int(n), "technical")
        return {"key": f"Section {m.group(1)}", **CP1_SECTION_LEADS[lead_key]}
    return None


def classify_rda_intent(text: str) -> dict:
    """Classify RDA feedback intent (mirrors rdaClassifyIntent)."""
    t = text.lower()
    for intent_type, pattern in RDA_INTENT_PATTERNS.items():
        if re.search(pattern, t):
            labels = {
                "remove":  {"label": "Remove Content",    "icon": "✕", "chipClass": "chip-remove"},
                "rephrase": {"label": "Rephrase/Refine",  "icon": "✎", "chipClass": "chip-rephrase"},
                "add":     {"label": "Add Content",       "icon": "+", "chipClass": "chip-add"},
                "reorder": {"label": "Reorder Structure", "icon": "⇅", "chipClass": "chip-reorder"},
            }
            return {"type": intent_type, **labels[intent_type]}
    return {"type": "custom", "label": "Custom Edit", "icon": "⚙", "chipClass": "chip-custom"}


def get_rda_nlp_steps(intent_type: str) -> list[str]:
    """Return NLP processing step labels per intent type."""
    steps = {
        "remove": [
            "Parsing instruction: section removal detected…",
            "Locating target section in current draft…",
            "Validating removal against ITT mandatory requirements…",
            "Regenerating document without target section…",
            "Updating cross-references and section numbering…",
            "Revised draft ready — section removed cleanly",
        ],
        "rephrase": [
            "Parsing instruction: rephrase/refine detected…",
            "Loading target passage into NLP refinement engine…",
            "Applying tone, conciseness and emphasis constraints…",
            "Validating revised passage against evaluation criteria…",
            "Integrating refined content into document…",
            "Revised draft ready — passage updated",
        ],
        "add": [
            "Parsing instruction: content addition detected…",
            "Identifying insertion point and section context…",
            "Retrieving relevant content from bid library…",
            "Generating and aligning new content to ITT criteria…",
            "Inserting content and updating cross-references…",
            "Revised draft ready — new content integrated",
        ],
        "reorder": [
            "Parsing instruction: structural reorder detected…",
            "Mapping current document section sequence…",
            "Computing coherent reorder sequence…",
            "Validating narrative flow after restructure…",
            "Updating all section numbering and references…",
            "Revised draft ready — structure updated",
        ],
    }
    return steps.get(intent_type, [
        "Parsing natural language instruction…",
        "Decomposing into discrete edit operations…",
        "Applying instruction with context-aware NLP engine…",
        "Re-running full criteria alignment pass…",
        "Validating document coherence…",
        "Revised draft ready — changes applied",
    ])


# ═══════════════════════════════════════════════════════════════════
#  ANTHROPIC API CALLS
# ═══════════════════════════════════════════════════════════════════

def extract_tender_fields(text: str) -> dict:
    """
    Use Claude to extract key fields from ITT document text.
    Returns structured JSON with client_name, tender_ref, bid_deadline,
    project_value, tender_title, project_description.
    """
    client = get_anthropic()
    prompt = f"""You are a bid management assistant. Extract the following fields from this ITT document text.
Return ONLY a valid JSON object with these exact keys. If a field is not found, use null.

Keys to extract:
- client_name: The name of the client/contracting authority issuing the tender
- tender_ref: The tender reference or ITT number
- bid_deadline: The submission deadline (date and time if available)
- project_value: The estimated project/contract value
- tender_title: The title/name of the project being tendered
- project_description: A one or two sentence description of the project scope

For each field also include an "extraction_source" sibling object with the same keys,
where the value is either "extracted" (found in text) or "default" (not found).

Document text (first 4000 chars):
{text[:4000]}

Return only the JSON, no markdown, no explanation."""

    try:
        msg = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=800,
            messages=[{"role": "user", "content": prompt}],
        )
        raw = msg.content[0].text.strip()
        raw = re.sub(r"^```json\s*|^```\s*|```$", "", raw, flags=re.MULTILINE).strip()
        return json.loads(raw)
    except Exception as e:
        print(f"[extract_tender_fields] Error: {e}")
        return {
            "client_name": None, "tender_ref": None, "bid_deadline": None,
            "project_value": None, "tender_title": None, "project_description": None,
            "extraction_source": {
                "client_name": "default", "tender_ref": "default", "bid_deadline": "default",
                "project_value": "default", "tender_title": "default", "project_description": "default",
            },
            "error": str(e),
        }


def assess_risk(extracted_data: dict) -> dict:
    """
    Use Claude to produce a structured risk assessment from extracted tender data.
    Returns overall score, dimension scores, go/no-go decision, and flags.
    """
    client = get_anthropic()
    context = json.dumps(extracted_data, indent=2) if extracted_data else "{}"

    prompt = f"""You are a senior bid risk analyst. Based on this tender data, produce a structured risk assessment.

Tender data:
{context}

Return ONLY a valid JSON object with this exact structure (no markdown, no explanation):

{{
  "overall_score": <integer 0-100, higher = higher risk>,
  "overall_label": "<low|medium|high>",
  "decision": "<go|conditional|nogo>",
  "decision_label": "<short label e.g. 'Conditional Go'>",
  "decision_desc": "<one sentence explanation>",
  "tender_title": "<tender title or 'ITT Document'>",
  "client_name": "<client name or ''>",
  "dimensions": {{
    "commercial":   {{"score": <0-100>, "label": "<low|medium|high>"}},
    "technical":    {{"score": <0-100>, "label": "<low|medium|high>"}},
    "programme":    {{"score": <0-100>, "label": "<low|medium|high>"}},
    "supply_chain": {{"score": <0-100>, "label": "<low|medium|high>"}},
    "strategic":    {{"score": <0-100>, "label": "<low|medium|high>"}}
  }},
  "flags": [
    {{
      "level": "<high|medium|low>",
      "title": "<short risk title>",
      "detail": "<one sentence detail>",
      "owner": "<role responsible>",
      "urgency": "<when action needed>",
      "mitigation_steps": ["<step 1>", "<step 2>", "<step 3>"],
      "forecast": "<brief risk forecast>"
    }}
  ]
}}

Generate 3-6 realistic flags relevant to the tender context. If data is sparse, use sensible construction/infrastructure defaults."""

    try:
        msg = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=1500,
            messages=[{"role": "user", "content": prompt}],
        )
        raw = msg.content[0].text.strip()
        raw = re.sub(r"^```json\s*|^```\s*|```$", "", raw, flags=re.MULTILINE).strip()
        return json.loads(raw)
    except Exception as e:
        print(f"[assess_risk] Error: {e}")
        # Sensible fallback
        return {
            "overall_score": 42,
            "overall_label": "medium",
            "decision": "conditional",
            "decision_label": "Conditional Go",
            "decision_desc": "Bid is viable but key risk items require resolution before submission.",
            "tender_title": extracted_data.get("tender_title", "ITT Document"),
            "client_name": extracted_data.get("client_name", ""),
            "dimensions": {
                "commercial":   {"score": 45, "label": "medium"},
                "technical":    {"score": 35, "label": "low"},
                "programme":    {"score": 40, "label": "medium"},
                "supply_chain": {"score": 30, "label": "low"},
                "strategic":    {"score": 50, "label": "medium"},
            },
            "flags": [
                {
                    "level": "medium",
                    "title": "Single-source supplier dependency",
                    "detail": "Primary equipment supplier identified as sole-source — no qualified alternative confirmed.",
                    "owner": "Procurement Lead",
                    "urgency": "Resolve before CP1",
                    "mitigation_steps": ["Identify alternative qualified suppliers", "Request confirmation of supply chain resilience", "Build contractual protections"],
                    "forecast": "Risk reduces to Low once second supplier is qualified.",
                },
                {
                    "level": "high",
                    "title": "Tight submission deadline",
                    "detail": "Insufficient time buffer identified between final draft and submission deadline.",
                    "owner": "Bid Manager",
                    "urgency": "Critical — immediate action",
                    "mitigation_steps": ["Compress review cycle", "Assign dedicated resource to compliance check", "Pre-populate standard appendices now"],
                    "forecast": "Risk escalates to Critical if CP2 is delayed beyond planned date.",
                },
            ],
            "error": str(e),
        }


def classify_feedback_nlp(feedback: str, checkpoint: str) -> dict:
    """
    Use Claude to classify feedback text from a checkpoint and generate a structured response.
    This powers the NLP action cards shown in CP1/CP2 panels.
    """
    client = get_anthropic()
    prompt = f"""You are a bid workflow NLP engine. Classify this reviewer feedback from {checkpoint}.

Feedback: "{feedback}"

Return ONLY a valid JSON object:
{{
  "action": "<rereview|notify|escalate|flag|remove|rephrase|add|general>",
  "section_key": "<detected section topic or null e.g. 'health', 'technical', 'sustainability'>",
  "summary": "<one sentence summary of what action was requested>",
  "lead_name": "<lead name to notify or null>",
  "lead_role": "<lead role or null>",
  "lead_email": "<lead email or null>",
  "lead_color": "<hex color or null>",
  "lead_initials": "<initials or null>",
  "dispatch_steps": ["<step 1>", "<step 2>", "<step 3>", "<step 4>", "<step 5>"]
}}

Use these section leads if detected:
- health/safety/h&s → S. Patel, H&S Lead, s.patel@gallifordtry.com, #EC1B2E, SP
- sustainability/carbon/social value → L. Ahmed, Sustainability Lead, l.ahmed@gallifordtry.com, #00a886, LA
- supply chain/subcontract → R. Chen, Supply Chain Lead, r.chen@gallifordtry.com, #7c5cfc, RC
- technical/methodology/programme → J. Harrison, Technical Lead, j.harrison@gallifordtry.com, #1976d2, JH
- commercial/pricing → Commercial Manager, Commercial Lead, commercial@gallifordtry.com, #f5a623, CM
- quality → Quality Manager, Quality Lead, quality@gallifordtry.com, #00c2e0, QM"""

    try:
        msg = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=600,
            messages=[{"role": "user", "content": prompt}],
        )
        raw = msg.content[0].text.strip()
        raw = re.sub(r"^```json\s*|^```\s*|```$", "", raw, flags=re.MULTILINE).strip()
        return json.loads(raw)
    except Exception as e:
        print(f"[classify_feedback_nlp] Error: {e}")
        action = classify_action(feedback)
        section = detect_section(feedback)
        return {
            "action": action,
            "section_key": section["key"] if section else None,
            "summary": f"Feedback classified as {action}",
            "lead_name": section.get("lead") if section else None,
            "lead_role": section.get("role") if section else None,
            "lead_email": section.get("email") if section else None,
            "lead_color": section.get("color") if section else None,
            "lead_initials": section.get("initials") if section else None,
            "dispatch_steps": [
                f"Parsing instruction: {action} request detected...",
                f"Identifying responsible lead...",
                "Composing notification...",
                "Dispatching review request via workflow orchestrator...",
                "Notification delivered ✓",
            ],
        }


# ═══════════════════════════════════════════════════════════════════
#  ROUTES
# ═══════════════════════════════════════════════════════════════════

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/static/<path:path>")
def static_files(path):
    return send_from_directory("static", path)


# ── Agent data endpoint ──────────────────────────────────────────
@app.route("/api/agents", methods=["GET"])
def api_agents():
    """Return full agent definitions + confidence scores."""
    return jsonify({"agents": AGENTS, "confidence": CONFIDENCE})


# ── Tender PDF extraction ────────────────────────────────────────
@app.route("/api/extract-tender", methods=["POST"])
def api_extract_tender():
    """
    Accepts a PDF upload. Extracts text via PyMuPDF, then calls Claude
    to extract structured ITT fields.
    """
    file = request.files.get("file")
    if not file:
        return jsonify({"error": "No file provided"}), 400

    try:
        import fitz  # PyMuPDF

        pdf_bytes = file.read()
        doc = fitz.open(stream=pdf_bytes, filetype="pdf")
        text = ""
        for page in doc:
            text += page.get_text()
        doc.close()

        if not text.strip():
            return jsonify({"error": "No text extracted from PDF"}), 422

        result = extract_tender_fields(text)
        return jsonify(result)

    except Exception as e:
        print(f"[extract-tender] Error: {e}")
        return jsonify({"error": str(e)}), 500


# ── Risk assessment ──────────────────────────────────────────────
@app.route("/api/assess-risk", methods=["POST"])
def api_assess_risk():
    """
    Accepts extracted tender data (or empty body) and returns a structured
    risk assessment produced by Claude.
    """
    data = request.get_json(silent=True) or {}
    result = assess_risk(data)
    return jsonify(result)


# ── NLP feedback classification ──────────────────────────────────
@app.route("/api/classify-feedback", methods=["POST"])
def api_classify_feedback():
    """
    Classifies a reviewer's natural-language feedback into a structured
    action card. Used for CP1 and CP2 feedback panels.
    """
    body = request.get_json(silent=True) or {}
    feedback = body.get("feedback", "").strip()
    checkpoint = body.get("checkpoint", "CP1")

    if not feedback:
        return jsonify({"error": "No feedback provided"}), 400

    result = classify_feedback_nlp(feedback, checkpoint)
    return jsonify(result)


# ── RDA intent classification ────────────────────────────────────
@app.route("/api/classify-rda-intent", methods=["POST"])
def api_classify_rda_intent():
    """
    Classifies drafting agent feedback intent (remove/rephrase/add/reorder/custom).
    Returns intent type + NLP step labels for the animated sequence.
    """
    body = request.get_json(silent=True) or {}
    text = body.get("text", "").strip()

    if not text:
        return jsonify({"error": "No text provided"}), 400

    intent = classify_rda_intent(text)
    intent["steps"] = get_rda_nlp_steps(intent["type"])
    return jsonify(intent)


# ── Action + section detection (lightweight, no LLM) ────────────
@app.route("/api/detect-action", methods=["POST"])
def api_detect_action():
    """
    Fast Python-only action + section detection for live NLP hint strips.
    No LLM call — uses regex patterns same as original JS.
    """
    body = request.get_json(silent=True) or {}
    text = body.get("text", "").strip()

    if not text:
        return jsonify({"action": "general", "section": None, "meta": CP_ACTION_META["general"]})

    action = classify_action(text)
    section = detect_section(text)
    meta = CP_ACTION_META.get(action, CP_ACTION_META["general"])

    return jsonify({
        "action": action,
        "section": section,
        "meta": meta,
    })


if __name__ == "__main__":
    print("Tender Response Studio — Python Backend")
    print("Starting on http://localhost:5000")
    app.run(debug=True, port=5000)
