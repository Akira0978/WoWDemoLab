"""
Sentinel ingest utilities (demo-grade)
- Extract text from PDF or DOCX
- Deterministic and dependency-light
"""
from __future__ import annotations
from pathlib import Path
from typing import Tuple
import pdfplumber
from docx import document


def detect_type(filename: str) -> str:
    ext = Path(filename).suffix.lower()
    if ext == ".pdf": return "pdf"
    if ext == ".docx": return "docx"
    if ext == ".txt": return "txt"
    if ext == ".doc": return "doc"
    return "unknown"

def extract_text_from_pdf(path: str) -> str:
   
    parts = []
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            t = page.extract_text() or ""
            if t.strip():
                parts.append(t)
    return "\n\n".join(parts).strip()

def extract_text_from_docx(path: str) -> str:
    from docx import Document
    doc = Document(path)
    parts = [p.text for p in doc.paragraphs if p.text and p.text.strip()]
    return "\n".join(parts).strip()

def extract_text(path: str, original_filename: str) -> Tuple[str, str]:
    doc_type = detect_type(original_filename)
    if doc_type == "pdf":
        return doc_type, extract_text_from_pdf(path)
    if doc_type == "docx":
        return doc_type, extract_text_from_docx(path)
    if doc_type == "txt":
        return doc_type, Path(path).read_text(encoding="utf-8", errors="ignore").strip()
    if doc_type == "doc":
        raise ValueError("Legacy .doc not supported. Upload .pdf or .docx.")
    raise ValueError(f"Unsupported file type: {original_filename}")
