#!/usr/bin/env python
"""
Quick API endpoint test
"""
from app import create_app
from models import db
from models.claim_case import ClaimCase
from datetime import datetime, timedelta

app = create_app('development')

with app.app_context():
    # Create test claim if none exists
    test_case = ClaimCase.query.first()
    if not test_case:
        print("[INFO] Creating test case...")
        test_case = ClaimCase(
            case_id="TEST-001",
            policy_id="POL-12345",
            claimant_id="CLM-67890",
            claim_type="Motor",
            loss_date=datetime.utcnow() - timedelta(days=5),
            reported_date=datetime.utcnow(),
            status="INTAKE",
            fraud_score=45.0,
            fraud_band="REVIEW",
            fraud_confidence=0.62,
            jurisdiction="GB"
        )
        db.session.add(test_case)
        db.session.commit()
        print(f"[OK] Created test case: {test_case.case_id}")
    else:
        print(f"[OK] Found existing test case: {test_case.case_id}")

    # Test endpoints
    with app.test_client() as client:
        print("\n=== Testing Endpoints ===\n")

        # Test /api/claims
        print("[TEST] GET /api/claims")
        resp = client.get("/api/claims?limit=5&offset=0")
        print(f"  Status: {resp.status_code}")
        if resp.status_code == 200:
            data = resp.get_json()
            print(f"  Items: {data.get('total', '?')}")
            print("[OK]\n")
        else:
            print(f"  Error: {resp.data}\n")

        # Test /api/kpis
        print("[TEST] GET /api/kpis")
        resp = client.get("/api/kpis")
        print(f"  Status: {resp.status_code}")
        if resp.status_code == 200:
            data = resp.get_json()
            print(f"  Total: {data.get('total', '?')}")
            print("[OK]\n")
        else:
            print(f"  Error: {resp.data}\n")

        # Test /api/audit/<case_id>
        print("[TEST] GET /api/audit/TEST-001")
        resp = client.get("/api/audit/TEST-001?limit=10")
        print(f"  Status: {resp.status_code}")
        if resp.status_code == 200:
            data = resp.get_json()
            print(f"  Events: {data.get('count', '?')}")
            print("[OK]\n")
        else:
            print(f"  Error: {resp.data}\n")

        # Test /api/agents/run-batch
        print("[TEST] POST /api/agents/run-batch")
        resp = client.post("/api/agents/run-batch?limit=5")
        print(f"  Status: {resp.status_code}")
        if resp.status_code == 200:
            data = resp.get_json()
            print(f"  Updated: {data.get('updated', '?')}")
            print(f"  Errors: {len(data.get('errors', []))}")
            print("[OK]\n")
        else:
            print(f"  Error: {resp.data}\n")

print("\n=== All tests complete ===")
