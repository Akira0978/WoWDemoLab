"""
Sentinel Fraud Intelligence Engine
===================================
Scores claim cases across 5 fraud-risk dimensions.
Produces explainable intelligence indicators.

CRITICAL RESPONSIBILITY LOCK:
This engine computes fraud intelligence ONLY.
It does NOT:
  - update database
  - make decisions
  - trigger actions
  - call external systems

Output is fed to orchestrator for human review & decision.
"""

from typing import Optional

# ─────────────────────────────────────────────────────────────────────────────
# FRAUD INTELLIGENCE CONFIG
# ─────────────────────────────────────────────────────────────────────────────

FRAUD_THRESHOLDS = {
    'low':    30,
    'review': 60,
    # 60+ is HIGH
}

DIMENSION_WEIGHTS = {
    'behavioural': 0.25,
    'historical':  0.20,
    'network':     0.25,
    'document':    0.15,
    'contextual':  0.15,
}

SCORE_LABELS = {
    'LOW':    (0,  30),
    'REVIEW': (31, 60),
    'HIGH':   (61, 100),
}


def _score_label(score: int) -> str:
    """Map numeric score to fraud band."""
    if score <= 30:
        return 'LOW'
    if score <= 60:
        return 'REVIEW'
    return 'HIGH'


def _indicator(dimension: str, severity: str, explanation: str, recommended_action: str, confidence: float, indicator_id: str = None):
    """
    Build a fraud indicator dict.
    
    Args:
        dimension: Which dimension triggered (behavioural, historical, network, document, contextual)
        severity: LOW, REVIEW, HIGH
        explanation: Why this indicator fired
        recommended_action: What to do about it
        confidence: 0.0-1.0 how confident is this indicator
        indicator_id: Optional unique ID for tracking
    
    Returns:
        Structured indicator dict
    """
    return {
        'indicator_id': indicator_id or f"{dimension}_{severity}",
        'dimension': dimension,
        'severity': severity,
        'explanation': explanation,
        'recommended_action': recommended_action,
        'confidence': round(confidence, 2),
    }


# ─────────────────────────────────────────────────────────────────────────────
# DIMENSION SCORERS
# ─────────────────────────────────────────────────────────────────────────────

def score_behavioural(case_data: dict) -> dict:
    """
    Behavioural dimension: claimant actions and patterns.
    
    Detects:
      - Late claim reporting (delays after loss)
      - Multiple submissions (unusual filing patterns)
      - Suspicious timing (clustered claims)
    """
    score = 0
    indicators = []
    confidence = 0.0

    loss_date = case_data.get('loss_date')
    reported_date = case_data.get('reported_date')
    
    # Late reporting flag
    if loss_date and reported_date:
        from datetime import datetime, timedelta
        if isinstance(loss_date, str):
            try:
                loss_date = datetime.fromisoformat(loss_date)
            except:
                loss_date = None
        if isinstance(reported_date, str):
            try:
                reported_date = datetime.fromisoformat(reported_date)
            except:
                reported_date = None
        
        if loss_date and reported_date:
            days_to_report = (reported_date - loss_date).days
            
            if days_to_report > 90:
                score += 25
                indicators.append(_indicator(
                    'behavioural',
                    'HIGH',
                    f'Claim reported {days_to_report} days after loss date — unusual delay suggests possible staging.',
                    'Request detailed explanation for reporting delay. Cross-reference against loss documentation timestamps.',
                    0.75,
                    'behavioural_late_report'
                ))
            elif days_to_report > 30:
                score += 12
                indicators.append(_indicator(
                    'behavioural',
                    'REVIEW',
                    f'Claim reported {days_to_report} days after loss — note delay for consistency check.',
                    'Review explanation for reporting delay against loss timeline in documentation.',
                    0.60,
                    'behavioural_moderate_delay'
                ))

    # Multiple submissions in short window
    prior_claims = case_data.get('prior_claims_count', 0)
    if prior_claims and prior_claims >= 3:
        score += 20
        indicators.append(_indicator(
            'behavioural',
            'REVIEW',
            f'Claimant has {prior_claims} claims in file history — elevated frequency pattern.',
            'Review prior claims for common characteristics. Check for staged patterns or frequency deviation.',
            0.65,
            'behavioural_high_frequency'
        ))
    elif prior_claims and prior_claims >= 1:
        score += 8
        indicators.append(_indicator(
            'behavioural',
            'LOW',
            f'Claimant has {prior_claims} prior claim(s) — standard history profile.',
            'Reference prior claims in context. Confirm consistency with current claim profile.',
            0.55,
            'behavioural_repeat_claimant'
        ))

    # Suspicious timing (clustered claims)
    claim_frequency = case_data.get('claim_frequency_days', None)
    if claim_frequency and claim_frequency < 30 and prior_claims and prior_claims > 0:
        score += 18
        indicators.append(_indicator(
            'behavioural',
            'REVIEW',
            f'Claims clustered within {claim_frequency} days — potential staging pattern.',
            'Analyse temporal pattern against loss causation. Interview claimant re: loss causation timing.',
            0.70,
            'behavioural_clustering'
        ))

    return {
        'score': min(100, max(0, score)),
        'indicators': indicators,
        'confidence': round(min(0.95, 0.4 + 0.15 * len(indicators)), 2),
    }


def score_historical(case_data: dict) -> dict:
    """
    Historical dimension: claimant's past claim record.
    
    Detects:
      - Prior fraud findings
      - Similar loss patterns
      - Escalated claims history
    """
    score = 0
    indicators = []
    confidence = 0.0

    # Prior fraud indicator
    prior_fraud = case_data.get('prior_fraud_finding', False)
    if prior_fraud:
        score += 50
        indicators.append(_indicator(
            'historical',
            'HIGH',
            'Claimant has prior fraud finding on record — immediate escalation required.',
            'Refer to SIU immediately. Do not proceed with settlement without fraud unit clearance.',
            0.95,
            'historical_prior_fraud'
        ))

    # Similar loss pattern
    similar_losses = case_data.get('similar_loss_count', 0)
    if similar_losses and similar_losses >= 2:
        score += 25
        indicators.append(_indicator(
            'historical',
            'HIGH',
            f'Claimant has {similar_losses} similar claims — pattern recognition flag.',
            'Cross-reference loss types, causation, and amounts. Flag for staged loss analysis.',
            0.80,
            'historical_similar_pattern'
        ))
    elif similar_losses and similar_losses >= 1:
        score += 12
        indicators.append(_indicator(
            'historical',
            'REVIEW',
            f'Claimant has {similar_losses} similar prior claim — note for consistency.',
            'Compare claim details against prior similar claim. Validate causation differences.',
            0.65,
            'historical_similar_once'
        ))

    # Escalated / declined claims
    prior_declined = case_data.get('prior_declined_claims', 0)
    if prior_declined and prior_declined > 0:
        score += 15
        indicators.append(_indicator(
            'historical',
            'REVIEW',
            f'{prior_declined} prior claim(s) declined by underwriting — review causation.',
            'Understand why prior claims were declined. Verify current claim is materially different.',
            0.70,
            'historical_declined'
        ))

    return {
        'score': min(100, max(0, score)),
        'indicators': indicators,
        'confidence': round(min(0.95, 0.3 + 0.20 * len(indicators)), 2),
    }


def score_network(case_data: dict) -> dict:
    """
    Network dimension: connections to other cases.
    
    Detects:
      - Shared identifiers (address, phone, bank)
      - Ring-fence indicators (cross-policy networks)
      - Repeated connections to known fraud networks
    """
    score = 0
    indicators = []
    confidence = 0.0

    # Shared address flag
    shared_address_count = case_data.get('shared_address_cases', 0)
    if shared_address_count and shared_address_count >= 5:
        score += 30
        indicators.append(_indicator(
            'network',
            'HIGH',
            f'{shared_address_count} other claims share reported address — ring-fence risk.',
            'Refer to fraud network team. Flag as potential organized fraud network.',
            0.85,
            'network_shared_address_high'
        ))
    elif shared_address_count and shared_address_count >= 2:
        score += 15
        indicators.append(_indicator(
            'network',
            'REVIEW',
            f'{shared_address_count} other claims from same address — cross-reference.',
            'Analyse other claims from address. Verify legitimacy of separate claimants.',
            0.70,
            'network_shared_address_moderate'
        ))

    # Shared phone number
    shared_phone_count = case_data.get('shared_phone_cases', 0)
    if shared_phone_count and shared_phone_count >= 3:
        score += 25
        indicators.append(_indicator(
            'network',
            'HIGH',
            f'{shared_phone_count} other claims share phone number — network indicator.',
            'Cross-check claimant legitimacy. Refer for SIU network analysis.',
            0.80,
            'network_shared_phone'
        ))

    # Shared bank account
    shared_bank_count = case_data.get('shared_bank_cases', 0)
    if shared_bank_count and shared_bank_count >= 2:
        score += 35
        indicators.append(_indicator(
            'network',
            'HIGH',
            f'Payment account shared with {shared_bank_count} other claimants — suspicious network.',
            'Freeze payment. Refer to SIU and financial crimes unit immediately.',
            0.90,
            'network_shared_bank'
        ))

    # Ring-fence indicators
    ring_fence_flag = case_data.get('ring_fence_indicator')
    if ring_fence_flag:
        score += 20
        severity = 'HIGH' if ring_fence_flag in ['STAGED_CLAIMS', 'ORGANIZED_RING'] else 'REVIEW'
        indicators.append(_indicator(
            'network',
            severity,
            f'Network ring-fence indicator: {ring_fence_flag}',
            'Escalate to organized fraud task force. Coordinate with other policy holders.',
            0.75,
            'network_ring_fence'
        ))

    return {
        'score': min(100, max(0, score)),
        'indicators': indicators,
        'confidence': round(min(0.95, 0.35 + 0.25 * len(indicators)), 2),
    }


def score_document(case_data: dict) -> dict:
    """
    Document dimension: supporting evidence completeness and consistency.
    
    Detects:
      - Missing required documents
      - Inconsistencies between documents
      - Document quality red flags
    """
    score = 0
    indicators = []
    confidence = 0.0

    # Missing documents
    missing_doc_count = case_data.get('missing_documents_count', 0)
    if missing_doc_count and missing_doc_count >= 3:
        score += 20
        indicators.append(_indicator(
            'document',
            'REVIEW',
            f'{missing_doc_count} key documents missing from submission — delays assessment.',
            'Issue formal document request. Set deadline for receipt (10 business days).',
            0.65,
            'document_missing_critical'
        ))
    elif missing_doc_count and missing_doc_count >= 1:
        score += 8
        indicators.append(_indicator(
            'document',
            'LOW',
            f'{missing_doc_count} document(s) outstanding — routine follow-up.',
            'Request missing documents as part of normal claim development.',
            0.55,
            'document_missing_minor'
        ))

    # Document inconsistencies
    inconsistency_flags = case_data.get('document_inconsistencies', [])
    if inconsistency_flags and len(inconsistency_flags) > 0:
        score += 15 * min(3, len(inconsistency_flags))
        for incon in inconsistency_flags[:2]:  # top 2 only
            indicators.append(_indicator(
                'document',
                'REVIEW',
                f'Document inconsistency: {incon}',
                'Request clarification from claimant. Compare statements with supporting evidence.',
                0.60,
                'document_inconsistency'
            ))

    return {
        'score': min(100, max(0, score)),
        'indicators': indicators,
        'confidence': round(min(0.95, 0.4 + 0.10 * len(indicators)), 2),
    }


def score_contextual(case_data: dict) -> dict:
    """
    Contextual dimension: external factors and deviations.
    
    Detects:
      - Geographic anomalies
      - Claim frequency deviations
      - Seasonal/temporal anomalies
    """
    score = 0
    indicators = []
    confidence = 0.0

    # Geographic anomaly
    jurisdiction = case_data.get('jurisdiction', 'GB')
    claim_type = case_data.get('claim_type', '')
    
    if jurisdiction and jurisdiction not in ['GB', 'UK']:
        if claim_type == 'Motor':
            score += 10
            indicators.append(_indicator(
                'contextual',
                'REVIEW',
                f'Claim jurisdiction is {jurisdiction} — international processing required.',
                'Confirm claimant location and policy coverage for this jurisdiction.',
                0.60,
                'contextual_international'
            ))

    # Claim frequency deviation
    claim_freq_pct = case_data.get('claim_frequency_percentile', 50)
    if claim_freq_pct and claim_freq_pct > 85:
        score += 12
        indicators.append(_indicator(
            'contextual',
            'REVIEW',
            f'Claimant frequency is {claim_freq_pct}th percentile — above normal distribution.',
            'Verify claimant demographics and risk profile match loss frequency.',
            0.65,
            'contextual_high_frequency'
        ))

    # Seasonal anomaly
    loss_month = case_data.get('loss_month')
    if loss_month:
        seasonal_flag = case_data.get('seasonal_anomaly')
        if seasonal_flag:
            score += 8
            indicators.append(_indicator(
                'contextual',
                'LOW',
                f'Loss date unusual for claim type during {loss_month} — note for pattern analysis.',
                'Cross-check loss causation against seasonal expectations for claim type.',
                0.55,
                'contextual_seasonal'
            ))

    return {
        'score': min(100, max(0, score)),
        'indicators': indicators,
        'confidence': round(min(0.95, 0.35 + 0.10 * len(indicators)), 2),
    }


# ─────────────────────────────────────────────────────────────────────────────
# MAIN FRAUD ASSESSMENT
# ─────────────────────────────────────────────────────────────────────────────

def assess_fraud(case_data: dict) -> dict:
    """
    Compute fraud intelligence across 5 dimensions.
    
    Args:
        case_data: Dictionary with claim facts:
          - identity: case_id, policy_id, claim_type
          - temporal: loss_date, reported_date
          - history: prior_claims_count, prior_fraud_finding
          - network: shared_address_cases, shared_phone_cases, shared_bank_cases
          - documents: missing_documents_count, document_inconsistencies
          - contextual: jurisdiction, claim_frequency_percentile
    
    Returns:
        Dictionary with:
          - fraud_score (0-100)
          - fraud_band (LOW, REVIEW, HIGH)
          - fraud_confidence (0.0-1.0)
          - indicators (list)
          - dimension_scores (dict)
    """
    
    # Score all dimensions
    dimensions = {
        'behavioural': score_behavioural(case_data),
        'historical':  score_historical(case_data),
        'network':     score_network(case_data),
        'document':    score_document(case_data),
        'contextual':  score_contextual(case_data),
    }

    # Compute weighted overall score
    overall_score = sum(
        dimensions[d]['score'] * DIMENSION_WEIGHTS[d]
        for d in DIMENSION_WEIGHTS
    )
    overall_score = round(overall_score)

    # Assign fraud band
    fraud_band = _score_label(overall_score)
    
    # Aggregate all indicators, sorted by severity
    severity_order = {'HIGH': 0, 'REVIEW': 1, 'LOW': 2}
    all_indicators = []
    for d_name, d_data in dimensions.items():
        all_indicators.extend(d_data['indicators'])
    all_indicators.sort(key=lambda i: severity_order.get(i['severity'], 3))

    # Compute overall confidence (aggregate from all dimensions)
    overall_confidence = sum(
        dimensions[d]['confidence'] * DIMENSION_WEIGHTS[d]
        for d in DIMENSION_WEIGHTS
    )
    overall_confidence = round(overall_confidence, 2)

    return {
        'fraud_score': overall_score,
        'fraud_band': fraud_band,
        'fraud_confidence': overall_confidence,
        'indicators': all_indicators[:10],  # top 10 indicators only
        'dimension_scores': {
            d: {
                'score': dimensions[d]['score'],
                'band': _score_label(dimensions[d]['score']),
                'confidence': dimensions[d]['confidence'],
            }
            for d in dimensions
        },
        'case_id': case_data.get('case_id', 'N/A'),
        'claim_type': case_data.get('claim_type', 'N/A'),
        'policy_id': case_data.get('policy_id', 'N/A'),
    }


if __name__ == '__main__':
    # Demo: assess sample case
    import json
    
    sample_case = {
        'case_id': 'CASE-001',
        'policy_id': 'POL-12345',
        'claim_type': 'Motor',
        'loss_date': '2026-04-01',
        'reported_date': '2026-05-15',
        'prior_claims_count': 2,
        'shared_address_cases': 1,
        'missing_documents_count': 0,
        'prior_fraud_finding': False,
    }
    
    result = assess_fraud(sample_case)
    print(json.dumps(result, indent=2))
