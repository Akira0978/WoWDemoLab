#!/usr/bin/env python
"""Test API endpoints."""

from app import create_app
import json

app = create_app('testing')
client = app.test_client()

# Test the /api/sim/start endpoint
print('Testing /api/sim/start endpoint...')
response = client.post('/api/sim/start?interval=2&count=2')
print(f'Status: {response.status_code}')
print(json.dumps(response.get_json(), indent=2))

# Test the /api/ingest/upload endpoint exists
print('\nTesting /api/ingest/upload endpoint...')
response = client.post('/api/ingest/upload')
print(f'Status: {response.status_code}')
data = response.get_json()
if 'error' in data:
    print(f'✓ Ingest endpoint registered - got expected error')

# Test claims endpoint
print('\nTesting /api/claims endpoint...')
response = client.get('/api/claims')
print(f'Status: {response.status_code}')
data = response.get_json()
print(f'✓ Claims endpoint OK - {data.get("total", 0)} claims available')
