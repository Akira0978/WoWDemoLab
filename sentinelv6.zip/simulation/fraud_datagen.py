"""
Fraud Simulation Engine (Live Demo Runtime)

Responsibilities:
- Generate synthetic fraud claims
- Persist ClaimCase records
- Run orchestration/fraud pipeline
- Continuously simulate live intake traffic
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import List, Dict, Any

import random
import uuid
import json
import time

from models import db
from models.claim_case import ClaimCase
from simulation.pdf_generator import generate_claim_pdf
from ingest.document_utils import extract_text
from ingest.claim_parser import parse_claim_text
from orchestration.runner import run_case


# =========================================================
# DATA MODEL
# =========================================================

@dataclass
class DemoCase:
    policy_id: str
    claimant_id: str
    claimant_name: str
    claim_type: str
    jurisdiction: str
    amount: float
    scenario: str
    expected_band: str
    expected_score: int
    source_filename: str
    source_text: str


# =========================================================
# SCENARIOS
# =========================================================

SCENARIOS = [

    dict(
        scenario="FRAUD_RING",
        jurisdiction="DE",
        claim_type="Motor",
        amount_range=(2500, 6000),
        score=87,
        band="HIGH",
        template=(
            "Claimant: {name}\n"
            "Policy: {policy}\n"
            "Repairer: AutoFix GmbH\n"
            "Location: Frankfurt, Germany\n"
            "Narrative: Rear-end collision on A3 autobahn with "
            "whiplash injury. Shared solicitor appears across "
            "6 linked claims.\n"
            "Amount: €{amount}\n"
        )
    ),

    dict(
        scenario="SUSPICIOUS_CLUSTER",
        jurisdiction="FR",
        claim_type="Property",
        amount_range=(9000, 16000),
        score=64,
        band="REVIEW",
        template=(
            "Claimant: {name}\n"
            "Policy: {policy}\n"
            "Contractor: RénoPlus SARL\n"
            "Location: Lyon, France\n"
            "Narrative: Burst pipe water damage. "
            "3rd claim in 18 months from same address.\n"
            "Amount: €{amount}\n"
        )
    ),

    dict(
        scenario="CLEAR_FASTTRACK",
        jurisdiction="UK",
        claim_type="Travel",
        amount_range=(200, 1200),
        score=8,
        band="LOW",
        template=(
            "Claimant: {name}\n"
            "Policy: {policy}\n"
            "Location: London, United Kingdom\n"
            "Narrative: Baggage loss claim after flight. "
            "Police report and airline letter attached.\n"
            "Amount: £{amount}\n"
        )
    ),
]


NAMES = [
    "H. Müller",
    "M. Dubois",
    "J. Whitfield",
    "P. Hoffmann",
    "L. Weber",
    "J. Schröder",
    "A. Singh",
    "S. Patel"
]


# =========================================================
# CASE GENERATION
# =========================================================

def generate_cases(
    n: int = 30,
    seed: int | None = None
) -> List[DemoCase]:

    rng = random.Random(seed)

    out: List[DemoCase] = []

    for i in range(n):

        sc = rng.choice(SCENARIOS)

        policy = f"POL-{rng.randint(100000,999999)}"

        claimant_id = f"CLM-{rng.randint(10000,99999)}"

        name = rng.choice(NAMES)

        amount = rng.randint(*sc["amount_range"])

        text = sc["template"].format(
            name=name,
            policy=policy,
            amount=amount
        )

        filename = (
            f"{sc['scenario']}_"
            f"{sc['jurisdiction']}_"
            f"{i+1}.pdf"
        )

        out.append(
            DemoCase(
                policy_id=policy,
                claimant_id=claimant_id,
                claimant_name=name,
                claim_type=sc["claim_type"],
                jurisdiction=sc["jurisdiction"],
                amount=float(amount),
                scenario=sc["scenario"],
                expected_band=sc["band"],
                expected_score=int(sc["score"]),
                source_filename=filename,
                source_text=text
            )
        )

    return out


# =========================================================
# PAYLOAD TRANSFORM
# =========================================================

def to_payload(dc: DemoCase) -> Dict[str, Any]:

    now = datetime.utcnow()

    return {

        "policy_id": dc.policy_id,

        "claimant_id": dc.claimant_id,

        "claim_type": dc.claim_type,

        "coverage_type": dc.claim_type,

        "loss_date":
            (now - timedelta(days=random.randint(1, 60))).date(),

        "reported_date":
            now.date(),

        "jurisdiction":
            dc.jurisdiction,

        "source_filename":
            dc.source_filename,

        "source_text":
            dc.source_text,

        "expected": {
            "scenario": dc.scenario,
            "fraud_band": dc.expected_band,
            "fraud_score": dc.expected_score
        }
    }


# =========================================================
# DB INSERTION + ORCHESTRATION
# =========================================================

def generate_and_insert_claim():

    dc = generate_cases(1)[0]

    payload = to_payload(dc)

    case_id = f"CASE-{uuid.uuid4().hex[:8].upper()}"

    case = ClaimCase(

        case_id=case_id,

        policy_id=payload["policy_id"],

        claimant_id=payload["claimant_id"],

        claim_type=payload["claim_type"],

        coverage_type=payload["coverage_type"],

        loss_date=payload["loss_date"],

        reported_date=payload["reported_date"],

        jurisdiction=payload["jurisdiction"],

        status="INTAKE",

        current_stage="fraud_analysis",

        source_filename=payload["source_filename"],

        source_text=payload["source_text"],

        ingestion=json.dumps({
            "expected": payload["expected"]
        }),

        created_at=datetime.utcnow(),

        updated_at=datetime.utcnow(),
    )

    db.session.add(case)
    db.session.commit()

    # -----------------------------------------
    # FRAUD ORCHESTRATION PIPELINE
    # -----------------------------------------

    case = run_case(case)
    pdf_path = generate_claim_pdf(case)

    case.source_filename = pdf_path

    doc_type, extracted = extract_text(
    pdf_path,
    case.source_filename
)
    parsed = parse_claim_text(extracted)

    case.source_text = extracted
    # -----------------------------------
# extract_text may return tuple
# -----------------------------------

    if isinstance(extracted, tuple):

        extracted = extracted[0]


    # Fix unsupported SQLite structures
    if isinstance(case.triggered_indicators, list):

        case.triggered_indicators = json.dumps(
            case.triggered_indicators
        )

    if isinstance(case.evidence_refs, list):

        case.evidence_refs = json.dumps(
            case.evidence_refs
        )

    case.updated_at = datetime.utcnow()

    db.session.commit()

    return case


# =========================================================
# LIVE SIMULATION ENGINE
# =========================================================

def start_live_simulation(
    app,
    stop_event,
    interval=12
):

    generated = 0

    with app.app_context():

        print("[SIM] Live fraud simulation engine started")

        while not stop_event.is_set():

            try:

                case = generate_and_insert_claim()

                generated += 1

                print(
                    f"[SIM] "
                    f"#{generated} | "
                    f"{case.case_id} | "
                    f"{case.claim_type} | "
                    f"{case.fraud_band} | "
                    f"{case.status}"
                )

            except Exception as e:

                print(f"[SIM ERROR] {e}")

                db.session.rollback()

            time.sleep(interval)