"""
Sentinel Control Plane
======================
Minimal Flask entrypoint. Bootstraps app, loads config, registers blueprints.

Does NOT contain:
- Business logic
- Domain rules
- Scoring/simulation
- Report generation
- Agent behavior
"""

from flask import Flask, render_template, Blueprint, jsonify, request, current_app, send_from_directory
import os, tempfile, uuid
from threading import Thread, Event
import time
from pathlib import Path
from api import claims_bp, agents_bp, reports_bp, ui_bp
from datetime import datetime

from models import db
from models.claim_case import ClaimCase
from ingest.document_utils import extract_text
from ingest.claim_parser import parse_claim_text, parsed_to_dict
from orchestration.runner import run_case
from simulation.fraud_datagen import generate_cases, to_payload
from simulation.fraud_datagen import start_live_simulation

sim_bp = Blueprint("sim", __name__, url_prefix="/api/sim")

_stop = Event()
_thread = None
            
@sim_bp.route("/start", methods=["POST"])
def start():
    global _thread
    if _thread and _thread.is_alive():
        return jsonify({"ok": True, "running": True}), 200

    interval = int(request.args.get("interval", 12))  # 10–15 sec range
    count = int(request.args.get("count", 30))

    _stop.clear()
    _thread = Thread(
    target=start_live_simulation,
    args=(current_app._get_current_object(),_stop, interval),
    daemon=True)
    _thread.start()
    return jsonify({"ok": True, "running": True, "interval": interval, "count": count}), 200

@sim_bp.route("/stop", methods=["POST"])
def stop():
    _stop.set()
    return jsonify({"ok": True, "stopped": True}), 200


ingest_bp = Blueprint("ingest", __name__, url_prefix="/api/ingest")

@ingest_bp.route("/upload", methods=["POST"])
def upload_and_ingest():
    case_id = request.form.get("case_id")  # optional (update-if-exists)

    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "Empty filename"}), 400

    suffix = os.path.splitext(f.filename)[1].lower()
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        f.save(tmp.name)
        tmp_path = tmp.name

    try:
        doc_type, text = extract_text(tmp_path, f.filename)
        parsed = parse_claim_text(text)
        parsed_dict = parsed_to_dict(parsed)

        # Create or update
        if not case_id:
            case_id = f"CASE-{uuid.uuid4().hex[:10].upper()}"

        case = ClaimCase.query.filter_by(case_id=case_id).first()
        if not case:
            case = ClaimCase(
                case_id=case_id,
                policy_id=request.form.get("policy_id"),
                claimant_id=request.form.get("claimant_id"),
                claim_type=parsed.claim_type,
                coverage_type=parsed.claim_type,
                jurisdiction=parsed.jurisdiction,
                loss_date=parsed.loss_date,
                reported_date=parsed.reported_date,
                status="INTAKE",
                created_at=datetime.utcnow(),
            )
            db.session.add(case)

        case.source_filename = f.filename
        case.source_text = text
        case.ingestion = parsed_dict
        case.ingested_at = datetime.utcnow()

        db.session.commit()

        # ✅ Run analysis via same code-path as /api/agents/run
        run_analysis_for_case(case)
        db.session.commit()

        return jsonify({
            "case_id": case.case_id,
            "status": case.status,
            "case": case.to_dict()
        }), 200

    finally:
        try: os.unlink(tmp_path)
        except: pass

@ingest_bp.route("/reparse/<case_id>", methods=["POST"])
def reparse_from_stored_text(case_id):
    case = ClaimCase.query.filter_by(case_id=case_id).first()
    if not case:
        return jsonify({"error": "Case not found"}), 404
    if not case.source_text:
        return jsonify({"error": "No source_text to parse"}), 400

    parsed = parse_claim_text(case.source_text)
    case.ingestion = parsed_to_dict(parsed)
    case.claim_type = parsed.claim_type
    case.jurisdiction = parsed.jurisdiction
    case.loss_date = parsed.loss_date
    case.reported_date = parsed.reported_date
    case.ingested_at = datetime.utcnow()

    db.session.commit()

    run_analysis_for_case(case)
    db.session.commit()

    return jsonify({"case_id": case.case_id, "case": case.to_dict()}), 200

def create_app(config_name: str = "development") -> Flask:
    """
    Factory function: create and configure Flask app.
    
    Args:
        config_name: 'development', 'testing', or 'production'
    
    Returns:
        Configured Flask app instance
    """
    app = Flask(
        __name__,
        template_folder='templates',
        static_folder='static'
    )
    
    # ─────────────────────────────────────────────────────────────────
    # LOAD CONFIGURATION
    # ─────────────────────────────────────────────────────────────────
    _load_config(app, config_name)
    
    # ─────────────────────────────────────────────────────────────────
    # DATABASE INITIALIZATION
    # ─────────────────────────────────────────────────────────────────
    _init_db(app)
    
    # ─────────────────────────────────────────────────────────────────
    # ERROR HANDLERS
    # ─────────────────────────────────────────────────────────────────
    _register_error_handlers(app)
    
    # ─────────────────────────────────────────────────────────────────
    # BLUEPRINT REGISTRATION
    # ─────────────────────────────────────────────────────────────────
    _register_blueprints(app)
    
    # ─────────────────────────────────────────────────────────────────
    # AUTO-SEED TEST DATA ON STARTUP
    # ─────────────────────────────────────────────────────────────────
    # _auto_seed_on_startup(app)
    _start_background_simulation(app)
    
    # ─────────────────────────────────────────────────────────────────
    # UI ROUTES (minimal)
    # ─────────────────────────────────────────────────────────────────
    
    
    
    @app.route('/')
    def home():
        """Landing page: RCGCC dashboard (AllianzF4 adapted)"""
        return render_template('Manager/RCGCC.html')
    
    @app.route('/case/<case_id>')
    def case_view(case_id):
        """Case detail dashboard: TenderResponseStudio adapted"""
        return render_template('Manager/TenderResponseStudio.html', case_id=case_id)

    @app.route('/tender-response-studio')
    def tender_response_studio():
        """Direct access to TenderResponseStudio."""
        return render_template('Manager/TenderResponseStudio.html')

    @app.route('/debug/seed')
    def seed_cases():
        from models import db
        from models.claim_case import ClaimCase
        from datetime import datetime

        for i in range(1, 11):
            case_id = f"CASE-{i}"
            if ClaimCase.query.filter_by(case_id=case_id).first():
                continue
            c = ClaimCase(
                case_id=case_id,
                policy_id=f"P-{i}",
                claimant_id=f"C-{i}",
                claim_type="Motor",
                jurisdiction="DE",
                status="INTAKE",
                loss_date=datetime.utcnow(),
                reported_date=datetime.utcnow(),
            )
            db.session.add(c)
        db.session.commit()
        return {"status": "seeded"}

    @app.route('/favicon.ico')
    def favicon():
        """Serve favicon"""
        from flask import send_from_directory
        return send_from_directory('static', 'favicon.ico', mimetype='image/vnd.microsoft.icon')
    
    return app

    @app.route("/uploads/<path:filename>")
    def uploaded_file(filename):
        return send_from_directory(
        "uploads",
        filename
    )
def _load_config(app: Flask, config_name: str) -> None:
    """Load config from environment or defaults."""
    app.config['ENV'] = config_name
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'sentinel-dev-key')
    app.config['SESSION_TYPE'] = 'filesystem'
    
    # Database
    base_dir = os.path.dirname(os.path.abspath(__file__))
    db_path = os.getenv('DATABASE_URL') or f'sqlite:///{base_dir}/sentinel.db'
    app.config['SQLALCHEMY_DATABASE_URI'] = db_path
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    
    # Reports output
    reports_dir = os.path.join(base_dir, 'reports')
    os.makedirs(reports_dir, exist_ok=True)
    app.config['REPORTS_DIR'] = reports_dir


def _init_db(app: Flask) -> None:
    """Initialize database (one-time on app startup)."""
    try:
        from models import db
        from models.claim_case import ClaimCase
        
        db.init_app(app)
        
        # Create tables on startup
        with app.app_context():
            db.create_all()
    except ImportError as e:
        # models not yet ready; fail fast
        app.logger.error(f"Failed to import models: {e}. Database initialization skipped.")
    except Exception as e:
        app.logger.error(f"Database initialization error: {e}")


def _register_error_handlers(app: Flask) -> None:
    """Register global error handlers."""
    
    @app.errorhandler(400)
    def bad_request(e):
        return {'error': 'Bad request', 'details': str(e)}, 400
    
    @app.errorhandler(404)
    def not_found(e):
        return {'error': 'Not found', 'details': str(e)}, 404
    
    @app.errorhandler(500)
    def internal_error(e):
        return {'error': 'Internal server error', 'details': str(e)}, 500


def _register_blueprints(app: Flask) -> None:
    """Register all domain blueprints."""
    
    # Claims lifecycle
    try:
        from api.claims import claims_bp
        app.register_blueprint(claims_bp)
    except ImportError:
        app.logger.warning("claims_bp not available")
    
    # Agent execution
    try:
        from api.agents import agents_bp
        app.register_blueprint(agents_bp)
    except ImportError:
        app.logger.warning("agents_bp not available")
    
    # Decision pack & reports
    try:
        from api.reports import reports_bp
        app.register_blueprint(reports_bp)
    except ImportError:
        app.logger.warning("reports_bp not available")
    
    # UI support (KPIs, audit, claims list)
    try:
        from api.ui import ui_bp
        app.register_blueprint(ui_bp)
    except ImportError:
        app.logger.warning("ui_bp not available")
    
    # Checkpoints (Phase 4)
    try:
        from api.checkpoints import checkpoints_bp
        app.register_blueprint(checkpoints_bp)
    except ImportError:
        app.logger.warning("checkpoints_bp not available")
    
    # Evidence (Phase 4)
    try:
        from api.evidence import evidence_bp
        app.register_blueprint(evidence_bp)
    except ImportError:
        app.logger.warning("evidence_bp not available")
    
    # Simulation & Data Generation (Phase 5)
    try:
        app.register_blueprint(sim_bp)
        app.logger.info("sim_bp registered")
    except Exception as e:
        app.logger.warning(f"sim_bp registration failed: {e}")
    
    # Document Ingestion (Phase 5)
    try:
        app.register_blueprint(ingest_bp)
        app.logger.info("ingest_bp registered")
    except Exception as e:
        app.logger.warning(f"ingest_bp registration failed: {e}")



def _start_background_simulation(app: Flask) -> None:
    """
    Start continuous live fraud claim generation.
    Runs only once per Flask process.
    """
    global _thread

    try:
        # Prevent duplicate threads
        if _thread and _thread.is_alive():
            app.logger.info("Simulation already running")
            return

        _stop.clear()

        # Infinite continuous feed
        _thread = Thread(
            target=start_live_simulation,
            args=(app, 12, 999999),
            daemon=True
        )

        _thread.start()

        app.logger.info("✓ Background fraud simulation started")

    except Exception as e:
        app.logger.error(f"Simulation startup failed: {e}")

def run_analysis_for_case(case: ClaimCase) -> ClaimCase:
    """
    Single source of truth for analysis.
    This is what /api/agents/run uses, and ingestion uses too.
    """
    updated = run_case(case)   # updates fraud_score/band/confidence/status + audit events
    return updated


if __name__ == '__main__':
    # Local development only
    app = create_app('development')
    app.run(debug=True, host='0.0.0.0', port=7003, use_reloader=False)
