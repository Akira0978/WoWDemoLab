# Quick Start - Phase 3/4 + Batch Ready

## Start the App

```bash
cd c:\Python\Allianz\SENTINEL
python app.py
```

Server runs on: **http://localhost:7003**

## Test URLs

- **Home (RCGCC):** http://localhost:7003/
- **Case Detail:** http://localhost:7003/case/TEST-001

## API Endpoints (All Tested ✓)

### Phase 3 (Read/View)
- `GET /api/claims?limit=50&offset=0&status=INTAKE` - List cases
- `GET /api/kpis` - Dashboard stats
- `GET /api/audit/<case_id>?limit=200` - Audit trail

### Phase 4 (Checkpoints & Evidence)
- `POST /api/checkpoints/<case_id>/<cp_id>` - Store gate decision
- `GET /api/evidence/<case_id>` - List evidence refs
- `POST /api/reports/decision-pack/<case_id>` - Export pack

### Batch (Agent Wave)
- `POST /api/agents/run-batch?limit=10` - Run analysis on N cases
- `POST /api/agents/run/<case_id>` - Run analysis on 1 case

## Button Wiring

**RCGCC "Run Agent Wave" button** → calls `SentinelAPI.runBatch(10)` → `POST /api/agents/run-batch?limit=10`

## Error Fixes Applied

❌ **FIXED:** `/api/messages/demo` (old AMIS endpoint) - now disabled in rcgcc-wiring.js
❌ **FIXED:** 500 errors on `/api/claims` and `/api/kpis` - added error logging
❌ **FIXED:** Database schema mismatch - recreated with new checkpoint fields

## Database

Test case auto-created: `TEST-001` (Motor claim, INTAKE status)

## Next: Try This Flow

1. Open http://localhost:7003
2. See claim list from real database
3. Click "Run Agent Wave" button - runs batch fraud analysis
4. Table auto-refreshes with updated fraud_score/fraud_band
5. Click a row → navigate to case detail
6. Case detail shows fraud indicators, trace modal with audit events
7. Click decision button → submits to backend, updates case
