/**
 * Phase 5: RCGCC Case Hub Wiring (LIVE FRAUD FEED VERSION)
 * -------------------------------------------------------
 * - Uses /api/claims (real DB)
 * - Keeps RCGCC HTML/CSS untouched
 * - Disables old AMIS agentCycle
 * - Enables live fraud feed polling
 * - Enables KPI synchronization
 * - Enables row click → case hydration
 * - Fully wired for Sentinel fraud workflow
 */

(function () {

  if (typeof SentinelAPI === "undefined") {
    console.error("SentinelAPI not loaded.");
    return;
  }

  // // Disable old Tender/AMIS cycle system
  // window.cycleRunning = true;
  // window.nextTimer = null;
  // window.scheduleNextCycle = function () {};

  // DOM refs
  const tbody = document.getElementById("dataBody");
  const searchInput = document.getElementById("tableSearch");
  const statusFilter = document.getElementById("statusFilter");
  const rowsPerPageSelect = document.getElementById("rowsPerPage");
  const pageInfo = document.getElementById("pageInfo");
  const pagination = document.getElementById("pagination");
  const btnRefresh = document.getElementById("btnRefresh");

  let limit = Number(rowsPerPageSelect?.value || 10);
  let offset = 0;
  let total = 0;

  // Global live cache
  window._rcgccRows = [];
  window.rowsData = [];

  // ─────────────────────────────────────────────
  // Helpers
  // ─────────────────────────────────────────────

  function fmtLocal(iso) {
    try {
      return new Date(iso).toLocaleString();
    } catch {
      return iso || "—";
    }
  }

  function badgeClassConfidence(v) {
    v = Number(v || 0);

    if (v >= 0.80) return "badge-chip chip-red";
    if (v >= 0.60) return "badge-chip chip-yellow";

    return "badge-chip chip-green";
  }

  function badgeClassStatus(s) {
    s = (s || "").toUpperCase();

    if (s === "CLOSED") return "badge-chip chip-green";
    if (s === "HUMAN_REVIEW") return "badge-chip chip-yellow";
    if (s === "ESCALATED") return "badge-chip chip-red";

    return "badge-chip chip-grey";
  }

  function fraudEventLabel(score) {

    score = Number(score || 0);

    if (score >= 80) return "Potential Fraud Ring";
    if (score >= 60) return "High Risk Claim";
    if (score >= 40) return "Suspicious Pattern";

    return "Standard Claim";
  }

  // ─────────────────────────────────────────────
  // Render Table
  // ─────────────────────────────────────────────

  function renderRows(rows) {

    if (!tbody) return;

    tbody.innerHTML = rows.map((r, i) => `

      <tr class="rcgcc-live-row"
          style="cursor:pointer"
          onclick="rcgccRowClick(${i})">

        <td>${fmtLocal(r.received_at)}</td>

        <td>
          <span class="${badgeClassConfidence(r.triage_confidence)}">
            ${Number(r.triage_confidence).toFixed(2)}
          </span>
        </td>

        <td>${fmtLocal(r.sla_due_at)}</td>

        <td>
          <span class="${badgeClassStatus(r.status)}">
            ${r.status}
          </span>
        </td>

        <td>
          <span class="badge-chip chip-grey">
            ${r.event_type}
          </span>
        </td>

        <td class="text-truncate" style="max-width:420px">
          ${r.subject}
        </td>

      </tr>

    `).join("");
  }

  // ─────────────────────────────────────────────
  // Pagination
  // ─────────────────────────────────────────────

  function renderPagination() {

    if (!pagination) return;

    const pages = Math.max(1, Math.ceil(total / limit));
    const currentPage = Math.floor(offset / limit) + 1;

    pagination.innerHTML = `

      <li class="page-item ${currentPage === 1 ? "disabled" : ""}">
        <a class="page-link" href="#" data-page="${currentPage - 1}">
          Prev
        </a>
      </li>

      <li class="page-item disabled">
        <span class="page-link">
          ${currentPage} / ${pages}
        </span>
      </li>

      <li class="page-item ${currentPage === pages ? "disabled" : ""}">
        <a class="page-link" href="#" data-page="${currentPage + 1}">
          Next
        </a>
      </li>

    `;

    pagination.querySelectorAll("a[data-page]").forEach(a => {

      a.addEventListener("click", (e) => {

        e.preventDefault();

        const p = Number(a.dataset.page);

        if (p < 1) return;

        offset = (p - 1) * limit;

        load();

      });

    });

  }

  // ─────────────────────────────────────────────
  // Main Load Function
  // ─────────────────────────────────────────────

  window.load = async function () {

    const q = (searchInput?.value || "").trim();
    const status = (statusFilter?.value || "").trim();

    try {

      const resp = await SentinelAPI.listClaims({
        limit,
        offset,
        status: status || null,
        q: q || null
      });

      const items = resp.items || [];

      total = resp.total || items.length;

      const rows = items.map(c => {

        const confidence =
          c.fraud_confidence != null
            ? Number(c.fraud_confidence)
            : (
                c.fraud_score != null
                  ? Math.min(0.99, Number(c.fraud_score) / 100)
                  : 0.50
              );

        return {

    // ---------------------------------
    // CORE
    // ---------------------------------

    case_id:
        c.case_id,

    received_at:
        c.created_at ||
        new Date().toISOString(),

    status:
        c.status || "INTAKE",

    // ---------------------------------
    // FRAUD
    // ---------------------------------

    fraud_score:
        c.fraud_score || 0,

    fraud_band:
        c.fraud_band || "LOW",

    triage_confidence:
        confidence,

    triggered_indicators:
        c.triggered_indicators || [],

    reasoning_summary:
        c.reasoning_summary || "",

    // ---------------------------------
    // DOCUMENTS
    // ---------------------------------

    source_filename:
        c.source_filename,

    source_text:
        c.source_text,

    pdf_url:
        c.pdf_url,

    ingestion:
        c.ingestion || {},

    // ---------------------------------
    // SLA
    // ---------------------------------

    sla_due_at:
        c.sla_due_ts ||
        c.created_at ||
        new Date().toISOString(),

    // ---------------------------------
    // UI
    // ---------------------------------

    event_type:
        fraudEventLabel(c.fraud_score),

    subject:
        c.subject ||
        `${c.case_id} · ${c.claim_type || "—"}`
};

      });

      // Global sync for KPIs + row hydration
      window.rowsData = rows;
      window._rcgccRows = rows;
// -----------------------------------------
// AUTO ACTIVATE LATEST LIVE CLAIM
// -----------------------------------------

if (rows.length > 0) {

    const latest = rows[0];

    if (
        !window.activeCase ||
        window.activeCase.case_id !== latest.case_id
    ) {

        if (
            typeof window.activateTenderStudioCase ===
            "function"
        ) {

            window.activateTenderStudioCase(latest);
        }
    }
}
      // Render UI
      renderRows(rows);

      // KPI recompute
      if (typeof window.recomputeKpis === "function") {

        try {
          window.recomputeKpis();
        } catch (err) {
          console.error("[RCGCC] KPI recompute failed:", err);
        }

      }

      // Page info
      if (pageInfo) {

        const shownTo = Math.min(offset + limit, total);

        pageInfo.textContent =
          total === 0
            ? "Showing 0 records"
            : `Showing ${offset + 1} to ${shownTo} of ${total}`;

      }

      renderPagination();

      console.log(
        `[RCGCC] Loaded ${rows.length} claims (total=${total})`
      );

    } catch (e) {

      console.error("[RCGCC] Load failed:", e);

      if (typeof showError === "function") {
        showError("Load failed: " + e.message);
      }

    }

  };

  // ─────────────────────────────────────────────
  // Auto-Generate Claim PDF & Upload to TRS
  // ─────────────────────────────────────────────

  window.autoUploadCasePdf = async function(claimRow) {
    if (!claimRow || !claimRow.case_id) {
      console.warn("[RCGCC] No claim data for PDF generation");
      return false;
    }

    try {
      /* Generate a claim summary PDF using html2pdf or simple blob creation */
      const pdfContent = generateClaimPdfContent(claimRow);
      
      /* Convert to blob */
      const blob = new Blob([pdfContent], { type: "application/pdf" });
      
      /* Create a simple PDF-like representation (for demo, this can be a receipt-like format) */
      const filename = `claim-${claimRow.case_id || claimRow.id}.pdf`;
      
      /* If TenderResponseStudio is available (same window), directly call its auto-upload */
      if (typeof window.trsAutoUploadPdf === "function") {
        /* Convert blob to base64 for transfer */
        const reader = new FileReader();
        reader.onload = function() {
          const base64 = reader.result.split(",")[1]; /* Remove data:application/pdf;base64, prefix */
          window.trsAutoUploadPdf(base64, filename, {
            claimId: claimRow.case_id,
            caseId: claimRow.id,
            source: "rcgcc"
          });
        };
        reader.readAsDataURL(blob);
        console.log("[RCGCC] Claim PDF queued for auto-upload:", filename);
      } else {
        /* Fallback: Store in sessionStorage for later pickup by TRS */
        const reader = new FileReader();
        reader.onload = function() {
          const base64 = reader.result.split(",")[1];
          sessionStorage.setItem("pendingClaimPdf", JSON.stringify({
            pdfBase64: base64,
            filename: filename,
            claimId: claimRow.case_id,
            caseId: claimRow.id,
            timestamp: new Date().toISOString()
          }));
          console.log("[RCGCC] Claim PDF stored in sessionStorage:", filename);
        };
        reader.readAsDataURL(blob);
      }
      
      return true;
    } catch (e) {
      console.error("[RCGCC] Failed to generate/upload claim PDF:", e);
      return false;
    }
  };

  /* Generate claim summary content (simple text-based PDF representation) */
  function generateClaimPdfContent(claimRow) {
    const caseSummary = `
CLAIM CASE SUMMARY
==================

Case ID: ${claimRow.case_id || "N/A"}
Claim Type: ${claimRow.claim_type || "N/A"}
Status: ${claimRow.status || "N/A"}
Fraud Score: ${claimRow.fraud_score || "N/A"}
Fraud Band: ${claimRow.fraud_band || "N/A"}
Confidence: ${(claimRow.fraud_confidence || 0).toFixed(2)}

Policy: ${claimRow.policy_id || "N/A"}
Jurisdiction: ${claimRow.jurisdiction || "N/A"}
Amount: ${claimRow.amount || "N/A"}

Loss Date: ${claimRow.loss_date || "N/A"}
Reported Date: ${claimRow.reported_date || "N/A"}

Received: ${fmtLocal(claimRow.received_at) || "N/A"}
SLA Due: ${fmtLocal(claimRow.sla_due_at) || "N/A"}

---
Document Generated: ${new Date().toLocaleString()}
Source: RCGCC Fraud Intelligence Platform
    `;
    return caseSummary;
  }

  // ─────────────────────────────────────────────
  // Row Click → Open Fraud Studio
  // ─────────────────────────────────────────────

  window.rcgccRowClick = async function (idx) {
    const row = (window._rcgccRows || [])[idx];

    if (!row || !row.case_id) {
        console.warn("[RCGCC] Missing case_id");
        return;
    }

    console.log("[RCGCC] Opening case:", row.case_id);

    // -----------------------------------------
    // AUTO UPLOAD GENERATED PDF TO TENDER STUDIO
    // -----------------------------------------
    if (typeof window.autoUploadCasePdf === "function") {
        await window.autoUploadCasePdf(row);
    }

    // -----------------------------------------
    // STORE ACTIVE CASE
    // -----------------------------------------
    sessionStorage.setItem("sentinel_case_id", row.case_id);

    // -----------------------------------------
    // HYDRATE TENDERSTUDIO RUNTIME
    // -----------------------------------------
    if (typeof window.activateTenderStudioCase === "function") {
        await window.activateTenderStudioCase(row);
    }

    // -----------------------------------------
    // SOFT DELAY FOR EVENT PROPAGATION
    // -----------------------------------------
    setTimeout(() => {
        window.location.href = `/case/${row.case_id}`;
    }, 250);
  };

  // ─────────────────────────────────────────────
  // Search + Filters
  // ─────────────────────────────────────────────

  searchInput?.addEventListener("input", () => {
    offset = 0;
    load();
  });

  statusFilter?.addEventListener("change", () => {
    offset = 0;
    load();
  });

  rowsPerPageSelect?.addEventListener("change", () => {

    limit = Number(rowsPerPageSelect.value || 10);

    offset = 0;

    load();

  });

  // ─────────────────────────────────────────────
  // Manual Agent Wave
  // ─────────────────────────────────────────────

  btnRefresh?.addEventListener("click", async () => {

    try {

      if (typeof showSuccess === "function") {
        showSuccess("Running fraud analysis wave...");
      }

      await SentinelAPI.runBatch(10);

      offset = 0;

      await load();

      if (typeof showSuccess === "function") {
        showSuccess("Fraud analysis completed");
      }

    } catch (e) {

      console.error("[RCGCC] Batch run failed:", e);

      if (typeof showError === "function") {
        showError("Fraud analysis failed: " + e.message);
      }

    }

  });

  // ─────────────────────────────────────────────
  // Initialize
  // ─────────────────────────────────────────────

  async function initializeRCGCC() {

    console.log("[RCGCC] Initializing live fraud dashboard...");

    // Initial table load
    await load();

    // Start backend simulation automatically
    try {

      await fetch("/api/sim/start?interval=12&count=999999", {
        method: "POST"
      });

      console.log("[RCGCC] Live fraud simulation started");

    } catch (err) {

      console.warn(
        "[RCGCC] Simulation startup failed:",
        err
      );

    }

  }

  if (document.readyState === "loading") {

    document.addEventListener(
      "DOMContentLoaded",
      initializeRCGCC
    );

  } else {

    initializeRCGCC();

  }

  // ─────────────────────────────────────────────
  // Continuous Live Polling
  // ─────────────────────────────────────────────

  setInterval(async () => {

    try {

      console.log("[RCGCC] Polling latest fraud claims...");

      await load();

    } catch (err) {

      console.error(
        "[RCGCC] Live refresh failed:",
        err
      );

    }

  }, 10000);

  console.log("[RCGCC] Phase 5 LIVE fraud wiring active");

})();


window.activateTenderStudioCase = async function(caseRow) {

    console.log(
        "[RCGCC] Activating TenderStudio case:",
        caseRow.case_id
    );

    // -----------------------------------------
    // GLOBAL ACTIVE CASE
    // -----------------------------------------

    window.activeCase = caseRow;

    // -----------------------------------------
    // OPEN SIDE PANELS
    // -----------------------------------------

    if (typeof window.openCasePanel === "function") {

        window.openCasePanel(caseRow);
    }

    // -----------------------------------------
    // HYDRATE DOCUMENT VIEWER
    // -----------------------------------------

    window.dispatchEvent(
        new CustomEvent(
            "claim-document-ready",
            {
                detail: caseRow
            }
        )
    );

    // -----------------------------------------
    // HYDRATE AGENT MESH
    // -----------------------------------------

    window.dispatchEvent(
        new CustomEvent(
            "agent-mesh-update",
            {
                detail: {
                    caseId: caseRow.case_id,
                    fraudBand: caseRow.fraud_band,
                    score: caseRow.fraud_score
                }
            }
        )
    );

    // -----------------------------------------
    // UPDATE WORKSTREAMS
    // -----------------------------------------

    window.dispatchEvent(
        new CustomEvent(
            "workstream-update",
            {
                detail: caseRow
            }
        )
    );
};
