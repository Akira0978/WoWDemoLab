"""
Sentinel Models
===============
Database models for insurance claim case management.
"""

from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

from .claim_case import ClaimCase

__all__ = ['db', 'ClaimCase']
