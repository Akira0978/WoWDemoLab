import json
from datetime import datetime
import os


AUDIT_FILE = "audit_log.jsonl"  # newline-delimited JSON


def log_event(event_type: str, case_id: str, payload: dict):
    entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "event_type": event_type,
        "case_id": case_id,
        "payload": payload,
    }

    with open(AUDIT_FILE, "a", encoding="utf-8") as f:
        f.write(json.dumps(entry) + "\n")


def read_events(case_id: str, limit: int = 200):
    """
    Read audit events for a specific case from JSONL audit log.
    Returns list of last 'limit' events for the case.
    """
    events = []
    try:
        with open(AUDIT_FILE, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    evt = json.loads(line)
                    if evt.get("case_id") == case_id:
                        events.append(evt)
                except (json.JSONDecodeError, ValueError):
                    continue
        return events[-limit:] if events else []
    except FileNotFoundError:
        return []