from enum import Enum


class CaseState(str, Enum):
    INTAKE = "INTAKE"
    INVESTIGATING = "INVESTIGATING"
    HUMAN_REVIEW = "HUMAN_REVIEW"
    ESCALATED = "ESCALATED"
    CLOSED = "CLOSED"


# Allowed transitions
VALID_TRANSITIONS = {
    CaseState.INTAKE: [CaseState.INVESTIGATING],
    CaseState.INVESTIGATING: [CaseState.HUMAN_REVIEW],
    CaseState.HUMAN_REVIEW: [CaseState.ESCALATED, CaseState.CLOSED],
    CaseState.ESCALATED: [CaseState.CLOSED],
    CaseState.CLOSED: [],
}


def is_valid_transition(current_state: str, next_state: str) -> bool:
    try:
        current = CaseState(current_state)
        next_s = CaseState(next_state)
    except ValueError:
        return False

    return next_s in VALID_TRANSITIONS.get(current, [])


def enforce_transition(current_state: str, next_state: str):
    if not is_valid_transition(current_state, next_state):
        raise Exception(
            f"Invalid state transition: {current_state} → {next_state}"
        )


def get_next_state(current_state: str) -> str | None:
    transitions = VALID_TRANSITIONS.get(CaseState(current_state), [])
    return transitions[0].value if transitions else None
