/**
 * Sentinel API Adapter (FINAL - Phase 3/4)
 * Robust wrapper around backend endpoints.
 */
const SentinelAPI = {
  async _json(url, opts = {}) {
    const res = await fetch(url, opts);
    const text = await res.text();
    let data = null;
    try { data = text ? JSON.parse(text) : null; } catch { data = { raw: text }; }
    if (!res.ok) {
      const msg = (data && (data.error || data.message)) ? (data.error || data.message) : `HTTP ${res.status}`;
      throw new Error(`${opts.method || "GET"} ${url} failed: ${msg}`);
    }
    return data;
  },

  async getCase(caseId) {
    return this._json(`/api/claims/${encodeURIComponent(caseId)}`);
  },

  async listClaims({ limit = 50, offset = 0, status = null, q = null } = {}) {
    let url = `/api/claims?limit=${encodeURIComponent(limit)}&offset=${encodeURIComponent(offset)}`;
    if (status) url += `&status=${encodeURIComponent(status)}`;
    if (q) url += `&q=${encodeURIComponent(q)}`;
    return this._json(url);
  },

  async getKPIs() {
    return this._json(`/api/kpis`);
  },

  async runAnalysis(caseId) {
    return this._json(`/api/agents/run/${encodeURIComponent(caseId)}`, { method: "POST" });
  },

  async runBatch(limit = 10) {
    return this._json(`/api/agents/run-batch?limit=${encodeURIComponent(limit)}`, { method: "POST" });
  },

  async submitDecision(caseId, decision, notes = "", decidedBy = "") {
    const payloadA = { decision, notes };
    const payloadB = { handler_decision: decision, handler_notes: notes, decided_by: decidedBy };
    try {
      return await this._json(`/api/decisions/${encodeURIComponent(caseId)}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payloadA)
      });
    } catch (e1) {
      return await this._json(`/api/reports/decide/${encodeURIComponent(caseId)}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payloadB)
      });
    }
  },

  async getAudit(caseId, limit = 200) {
    return this._json(`/api/audit/${encodeURIComponent(caseId)}?limit=${encodeURIComponent(limit)}`);
  },

  async submitCheckpoint(caseId, checkpointId, payload) {
    return this._json(`/api/checkpoints/${encodeURIComponent(caseId)}/${encodeURIComponent(checkpointId)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload || {})
    });
  },

  async ingestUpload(file, caseId = null) {
    const form = new FormData();
    if (caseId) form.append("case_id", caseId);
    form.append("file", file);
    const res = await fetch("/api/ingest/upload", { method: "POST", body: form });
    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Ingestion failed: ${res.status} ${text}`);
    }
    return res.json();
  },
 
  async reparseCase(caseId) {
    return this._json(`/api/ingest/reparse/${encodeURIComponent(caseId)}`, { method: "POST" });
  },

  async listEvidence(caseId) {
    return this._json(`/api/evidence/${encodeURIComponent(caseId)}`);
  },

  async startFeeder(interval = 12, count = 30) {
    return this._json(`/api/sim/start?interval=${interval}&count=${count}`, { method: "POST" });
  },

  async generateDecisionPack(caseId) {
    return this._json(`/api/reports/decision-pack/${encodeURIComponent(caseId)}`, { method: "POST" });
  }
};


function getCaseIdFromContext() {
  const ss = sessionStorage.getItem("sentinel_case_id");
  if (ss) return ss;

  const params = new URLSearchParams(window.location.search);
  const qp = params.get("case_id");
  if (qp) return qp;

  const hidden = document.getElementById("caseId");
  if (hidden && hidden.value) return hidden.value;

  return null;
}

function showError(message) {
  console.error(message);
  const alert = document.createElement("div");
  alert.className = "alert alert-danger alert-dismissible fade show";
  alert.style.position = "fixed";
  alert.style.top = "20px";
  alert.style.right = "20px";
  alert.style.zIndex = "9999";
  alert.innerHTML = `<strong>Error:</strong> ${String(message)} <button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
  document.body.appendChild(alert);
  setTimeout(() => alert.remove(), 5000);
}

function showSuccess(message) {
  const alert = document.createElement("div");
  alert.className = "alert alert-success alert-dismissible fade show";
  alert.style.position = "fixed";
  alert.style.top = "20px";
  alert.style.right = "20px";
  alert.style.zIndex = "9999";
  alert.innerHTML = `<strong>Success:</strong> ${String(message)} <button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
  document.body.appendChild(alert);
  setTimeout(() => alert.remove(), 4000);
}
