/**
 * Phase 5: RCGCC Case Hub Wiring (LIVE FRAUD FEED VERSION)
 * -------------------------------------------------------
 * - Uses /api/claims (real DB)
 * - Keeps RCGCC HTML/CSS untouched
 * - Disables old AMIS agentCycle
 * - Enables live fraud feed polling
 * - Enables KPI synchronization
 * - Enables row click → case hydration
 * - Fully wired for Sentinel fraud workflow
 */

(function () {

  if (typeof SentinelAPI === "undefined") {
    console.error("SentinelAPI not loaded.");
    return;
  }

  // // Disable old Tender/AMIS cycle system
  // window.cycleRunning = true;
  // window.nextTimer = null;
  // window.scheduleNextCycle = function () {};

  // DOM refs
  const tbody = document.getElementById("dataBody");
  const searchInput = document.getElementById("tableSearch");
  const statusFilter = document.getElementById("statusFilter");
  const rowsPerPageSelect = document.getElementById("rowsPerPage");
  const pageInfo = document.getElementById("pageInfo");
  const pagination = document.getElementById("pagination");
  const btnRefresh = document.getElementById("btnRefresh");

  let limit = Number(rowsPerPageSelect?.value || 10);
  let offset = 0;
  let total = 0;

  // Global live cache
  window._rcgccRows = [];
  window.rowsData = [];
  let lastMeshCaseId = null; // Track which case triggered mesh animation
  
  // ─────────────────────────────────────────────
  // PHASE 3: AGENT MESH DEMO ENGINE
  // ─────────────────────────────────────────────
  let meshBusy = false;
  
  function fakeNetworkInsight(row) {
    if ((row.fraud_score || 0) > 80) {
      return "Pattern match: shared solicitor across 4 claims";
    }
    if ((row.fraud_score || 0) > 60) {
      return "Cluster detected: repeat repairer linkage";
    }
    return "No significant network anomalies detected";
  }
  
  function getDecision(row) {
    const score = row.fraud_score || 0;
    if (score >= 80) return "Escalated → SIU Investigation";
    if (score >= 60) return "Conditional → Manual Review";
    return "Auto-approved → Fast-track settlement";
  }
  
  function formatSLA(sla) {
    try {
      return new Date(sla).toLocaleTimeString();
    } catch {
      return "—";
    }
  }
  
  async function printStep(s) {
    const agentStepsEl = document.getElementById('agentSteps');
    const agentProgress = document.getElementById('agentProgress');
    const line = document.createElement('div');
    line.className = 'agent-line';
    line.innerHTML = `<span class="agent-tag tag-tool">${s.tag}</span><span class="kw">${s.label}</span> — `;
    if (agentStepsEl) agentStepsEl.appendChild(line);
    
    const msgSpan = document.createElement('span');
    line.appendChild(msgSpan);
    
    const text = s.msg;
    const slowTyping = document.getElementById('slowTypingToggle');
    const speed = (slowTyping && slowTyping.checked) ? 25 : 10;
    
    for (let i = 0; i < text.length; i++) {
      msgSpan.textContent += text[i];
      if (agentStepsEl) agentStepsEl.scrollTop = agentStepsEl.scrollHeight;
      await new Promise(r => setTimeout(r, speed));
    }
    
    if (agentProgress) agentProgress.style.width = s.pct + '%';
    await new Promise(r => setTimeout(r, 300));
  }
  
  async function runAgentMeshDemo(row) {
    if (meshBusy || !row) return;
    meshBusy = true;
    
    const agentStepsEl = document.getElementById('agentSteps');
    const agentProgress = document.getElementById('agentProgress');
    const agentHint = document.getElementById('agentHint');
    
    if (agentStepsEl) agentStepsEl.innerHTML = '';
    if (agentProgress) agentProgress.style.width = '0%';
    if (agentHint) agentHint.textContent = 'Agents executing…';
    
    const steps = [
      { tag: "Controller", label: "Wave Trigger", msg: `Starting orchestration for ${row.case_id}`, pct: 5 },
      { tag: "Ingestion", label: "Claim Intake", msg: `Received ${row.subject}`, pct: 15 },
      { tag: "Parser", label: "Entity Extraction", msg: `Extracting claimant, policy, location, loss details`, pct: 30 },
      { tag: "Network", label: "Graph Intelligence", msg: fakeNetworkInsight(row), pct: 50 },
      { tag: "Risk Engine", label: "Fraud Scoring", msg: `Score computed: ${row.fraud_score} (${row.fraud_band || '—'})`, pct: 70 },
      { tag: "Compliance", label: "SLA Check", msg: `Deadline ${formatSLA(row.sla_due_at)}`, pct: 85 },
      { tag: "Decision", label: "Routing", msg: getDecision(row), pct: 95 },
      { tag: "Pack Builder", label: "Investigation Pack", msg: `Evidence checklist + audit trace generated`, pct: 100 }
    ];
    
    for (const s of steps) {
      await printStep(s);
    }
    
    if (agentHint) agentHint.textContent = 'Idle';
    meshBusy = false;
  }
  
// 🔥 Force chart update after real data arrives
setTimeout(() => {
  if (typeof seedChartFromData === "function") {
    seedChartFromData();
  }
}, 200);
  // ─────────────────────────────────────────────
  // Helpers
  // ─────────────────────────────────────────────

  function fmtLocal(iso) {
    try {
      return new Date(iso).toLocaleString();
    } catch {
      return iso || "—";
    }
  }

  function badgeClassConfidence(v) {
    v = Number(v || 0);

    if (v >= 0.80) return "badge-chip chip-red";
    if (v >= 0.60) return "badge-chip chip-yellow";

    return "badge-chip chip-green";
  }

  function severityColorFromScore(score) {
    score = Number(score || 0);
    if (score >= 80) return '#EC1B2E';
    if (score >= 60) return '#f5a623';
    return '#00c9a0';
  }

  function severityLabel(score) {
    score = Number(score || 0);
    if (score >= 80) return 'HIGH';
    if (score >= 60) return 'MEDIUM';
    return 'LOW';
  }

  // ─────────────────────────────────────────────
  // DATA PRESERVATION & PARTIAL UPDATES
  // ─────────────────────────────────────────────

  /**
   * Preserve original values from API response
   * Prevents animation from wiping real data
   */
  function preserveOriginalValues(rows) {
    return rows.map(r => ({
      ...r,
      _original_summary: r.report_summary,
      _original_confidence: r.triage_confidence,
      _original_subject: r.subject
    }));
  }

  /**
   * Update single row UI element without full table re-render
   * Used during animation to avoid wiping state
   */
  function updateRowUI(index, updates) {
    const rowEl = document.querySelectorAll('.rcgcc-live-row')[index];
    if (!rowEl) return;

    // Update subject/summary cell (6th column)
    if (updates.tempSummary !== undefined) {
      const subjectCell = rowEl.children[5];
      if (subjectCell) subjectCell.textContent = updates.tempSummary;
    }

    // Update confidence cell (2nd column)
    if (updates.confidence !== undefined) {
      const confCell = rowEl.children[1];
      if (confCell) {
        const badgeSpan = confCell.querySelector('span') || confCell;
        badgeSpan.textContent = updates.confidence;
      }
    }
  }

  /**
   * Populate CP0 review metadata from actual case data
   * NOT from hardcoded HTML defaults
   */
  function populateCp0Meta(caseData) {
  const meta = {
    claimant: caseData.claimant_name || caseData.insured_name || caseData.customer_name || "—",
    case_ref: caseData.case_id || "—",
    claim_type: caseData.claim_type || caseData.event_type || "—",
    loss_date: caseData.loss_date || caseData.incident_date || caseData.received_at || "—",
    pack_version: caseData.pack_version || "v1.0 — Pre-CP0"
  };

  const container = document.querySelector('.cp0-review-meta');
  if (!container) return;

  container.innerHTML = `
    <div class="cp0-review-meta-item">
      <div class="cp0-review-meta-label">Claimant</div>
      <div class="cp0-review-meta-val">${meta.claimant}</div>
    </div>

    <div class="cp0-review-meta-item">
      <div class="cp0-review-meta-label">Case Reference</div>
      <div class="cp0-review-meta-val">${meta.case_ref}</div>
    </div>

    <div class="cp0-review-meta-item">
      <div class="cp0-review-meta-label">Claim Type</div>
      <div class="cp0-review-meta-val">${meta.claim_type}</div>
    </div>

    <div class="cp0-review-meta-item">
      <div class="cp0-review-meta-label">Loss Date</div>
      <div class="cp0-review-meta-val" style="color:#d97706;">
        ${meta.loss_date}
      </div>
    </div>

    <div class="cp0-review-meta-item">
      <div class="cp0-review-meta-label">Pack Version</div>
      <div class="cp0-review-meta-val">${meta.pack_version}</div>
    </div>
  `;
}

  function esc(s) {
    return (s || '').toString().replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  }

  function badgeClassStatus(s) {
    s = (s || "").toUpperCase();

    if (s === "CLOSED") return "badge-chip chip-green";
    if (s === "HUMAN_REVIEW") return "badge-chip chip-yellow";
    if (s === "ESCALATED") return "badge-chip chip-red";

    return "badge-chip chip-grey";
  }

  function fraudEventLabel(score) {

    score = Number(score || 0);

    if (score >= 80) return "Potential Fraud Ring";
    if (score >= 60) return "High Risk Claim";
    if (score >= 40) return "Suspicious Pattern";

    return "Standard Claim";
  }

  // ─────────────────────────────────────────────
  // Render Table
  // ─────────────────────────────────────────────

  function renderRows(rows) {
    if (!tbody) return;

    tbody.innerHTML = rows.map((r, i) => {
      const severityColor = severityColorFromScore(r.fraud_score);
      
      // Fallback chain: use original if available, then current, then computed
    const subject =
  r.report_summary ||
  r._original_summary ||
  r.subject ||
  `${r.case_id} · ${r.event_type || '—'}`;
      
      // Precise confidence logic: only fallback to 0.50 for NEW records
      let confidence;
      if (r.triage_confidence != null && r.triage_confidence !== undefined) {
        confidence = Number(r.triage_confidence).toFixed(2);
      } else if (r._original_confidence != null && r._original_confidence !== undefined) {
        confidence = Number(r._original_confidence).toFixed(2);
      } else if (r.status === 'NEW') {
        confidence = '0.50'; // Only for new incoming records
      } else {
        confidence = '—'; // Missing data shown as dash
      }
      
      return `<tr class="rcgcc-live-row" style="cursor:pointer;border-left:5px solid ${severityColor}" onclick="rcgccRowClick(${i})"><td>${fmtLocal(r.received_at)}</td><td><span class="${badgeClassConfidence(r.triage_confidence)}">${confidence}</span></td><td>${fmtLocal(r.sla_due_at)}</td><td><span class="${badgeClassStatus(r.status)}">${r.status}</span></td><td><span class="badge-chip" style="background:rgba(${severityColor.slice(1).match(/.{1,2}/g).map(x=>parseInt(x,16)).join(',')},0.15);border-color:${severityColor};color:${severityColor};font-weight:600;border:1px solid ${severityColor}">${severityLabel(r.fraud_score)}</span></td><td class="text-truncate" style="max-width:420px">${subject}</td></tr>`;
    }).join("");
  }

  // ─────────────────────────────────────────────
  // Pagination
  // ─────────────────────────────────────────────

  function renderPagination() {

    if (!pagination) return;

    const pages = Math.max(1, Math.ceil(total / limit));
    const currentPage = Math.floor(offset / limit) + 1;

    pagination.innerHTML = `

      <li class="page-item ${currentPage === 1 ? "disabled" : ""}">
        <a class="page-link" href="#" data-page="${currentPage - 1}">
          Prev
        </a>
      </li>

      <li class="page-item disabled">
        <span class="page-link">
          ${currentPage} / ${pages}
        </span>
      </li>

      <li class="page-item ${currentPage === pages ? "disabled" : ""}">
        <a class="page-link" href="#" data-page="${currentPage + 1}">
          Next
        </a>
      </li>

    `;

    pagination.querySelectorAll("a[data-page]").forEach(a => {

      a.addEventListener("click", (e) => {

        e.preventDefault();

        const p = Number(a.dataset.page);

        if (p < 1) return;

        offset = (p - 1) * limit;

        load();

      });

    });

  }

  // ─────────────────────────────────────────────
  // Main Load Function
  // ─────────────────────────────────────────────

  window.load = async function () {

    const q = (searchInput?.value || "").trim();
    const status = (statusFilter?.value || "").trim();

    try {

      const resp = await SentinelAPI.listClaims({
        limit,
        offset,
        status: status || null,
        q: q || null
      });

      const items = resp.items || [];

      total = resp.total || items.length;

      const rows = items.map(c => {

        const confidence =
  r.triage_confidence != null
    ? Number(r.triage_confidence).toFixed(2)
    : (r._original_confidence != null
        ? Number(r._original_confidence).toFixed(2)
        : "—");


        return {
        
    // ---------------------------------
    // CORE
    // ---------------------------------

    case_id:
        c.case_id,

    received_at:
        c.created_at ||
        new Date().toISOString(),

    status:
        c.status || "INTAKE",

    // ---------------------------------
    // FRAUD
    // ---------------------------------

    fraud_score:
        c.fraud_score || 0,

    fraud_band:
        c.fraud_band || "LOW",

    triage_confidence:
        confidence,

    triggered_indicators:
        c.triggered_indicators || [],

    reasoning_summary:
        c.reasoning_summary || "",

    // ---------------------------------
    // DOCUMENTS
    // ---------------------------------

    source_filename:
        c.source_filename,

    source_text:
        c.source_text,

    pdf_url:
        c.pdf_url,

    ingestion:
        c.ingestion || {},

    // ---------------------------------
    // SLA
    // ---------------------------------

    sla_due_at:
        c.sla_due_ts ||
        c.created_at ||
        new Date().toISOString(),

    // ---------------------------------
    // UI
    // ---------------------------------

    event_type:
        fraudEventLabel(c.fraud_score),

    subject:
        c.subject ||
        `${c.case_id} · ${c.claim_type || "—"}`
};

      });

      // CRITICAL: Preserve original values before any mutations
      rows = preserveOriginalValues(rows);
      window.rowsData = rows;
      window._rcgccRows = rows;

      window._rcgccRows = rows;

if (typeof recomputeKpis === "function") {
  recomputeKpis();
}
if (typeof seedChartFromData === "function") {
  seedChartFromData();
}
// -----------------------------------------
// AUTO ACTIVATE LATEST LIVE CLAIM
// -----------------------------------------

if (rows.length > 0) {

    const latest = rows[0];
    
    // Only trigger mesh animation for NEW cases (not on every refresh)
    const isNewCase = (lastMeshCaseId !== latest.case_id);
    if (isNewCase) {
      lastMeshCaseId = latest.case_id;
    }

    if (
        !window.activeCase ||
        window.activeCase.case_id !== latest.case_id
    ) {

        if (
            typeof window.activateTenderStudioCase ===
            "function"
        ) {

            window.activateTenderStudioCase(latest);
        }
    }
    
    // PHASE 3: Trigger Agent Mesh Demo animation ONLY for new cases
    if (isNewCase && typeof runAgentMeshDemo === 'function') {
      runAgentMeshDemo(latest);
    }
}
      // Render UI
      renderRows(rows);

      // KPI recompute
      if (typeof window.recomputeKpis === "function") {

        try {
          window.recomputeKpis();
        } catch (err) {
          console.error("[RCGCC] KPI recompute failed:", err);
        }

      }

      // Page info
      if (pageInfo) {

        const shownTo = Math.min(offset + limit, total);

        pageInfo.textContent =
          total === 0
            ? "Showing 0 records"
            : `Showing ${offset + 1} to ${shownTo} of ${total}`;

      }

      renderPagination();

      console.log(
        `[RCGCC] Loaded ${rows.length} claims (total=${total})`
      );

    } catch (e) {

      console.error("[RCGCC] Load failed:", e);

      if (typeof showError === "function") {
        showError("Load failed: " + e.message);
      }

    }

  };

  // ─────────────────────────────────────────────
  // Auto-Generate Claim PDF & Upload to TRS
  // ─────────────────────────────────────────────

  window.autoUploadCasePdf = async function(claimRow) {
    if (!claimRow || !claimRow.case_id) {
      console.warn("[RCGCC] No claim data for PDF generation");
      return false;
    }

    try {
      /* Generate a claim summary PDF using html2pdf or simple blob creation */
      const pdfContent = generateClaimPdfContent(claimRow);
      
      /* Convert to blob */
      const blob = new Blob([pdfContent], { type: "application/pdf" });
      
      /* Create a simple PDF-like representation (for demo, this can be a receipt-like format) */
      const filename = `claim-${claimRow.case_id || claimRow.id}.pdf`;
      
      /* If TenderResponseStudio is available (same window), directly call its auto-upload */
      if (typeof window.trsAutoUploadPdf === "function") {
        /* Convert blob to base64 for transfer */
        const reader = new FileReader();
        reader.onload = function() {
          const base64 = reader.result.split(",")[1]; /* Remove data:application/pdf;base64, prefix */
          window.trsAutoUploadPdf(base64, filename, {
            claimId: claimRow.case_id,
            caseId: claimRow.id,
            source: "rcgcc"
          });
        };
        reader.readAsDataURL(blob);
        console.log("[RCGCC] Claim PDF queued for auto-upload:", filename);
      } else {
        /* Fallback: Store in sessionStorage for later pickup by TRS */
        const reader = new FileReader();
        reader.onload = function() {
          const base64 = reader.result.split(",")[1];
          sessionStorage.setItem("pendingClaimPdf", JSON.stringify({
            pdfBase64: base64,
            filename: filename,
            claimId: claimRow.case_id,
            caseId: claimRow.id,
            timestamp: new Date().toISOString()
          }));
          console.log("[RCGCC] Claim PDF stored in sessionStorage:", filename);
        };
        reader.readAsDataURL(blob);
      }
      
      return true;
    } catch (e) {
      console.error("[RCGCC] Failed to generate/upload claim PDF:", e);
      return false;
    }
  };

  /* Generate claim summary content (simple text-based PDF representation) */
  function generateClaimPdfContent(claimRow) {
    const caseSummary = `
CLAIM CASE SUMMARY
==================

Case ID: ${claimRow.case_id || "N/A"}
Claim Type: ${claimRow.claim_type || "N/A"}
Status: ${claimRow.status || "N/A"}
Fraud Score: ${claimRow.fraud_score || "N/A"}
Fraud Band: ${claimRow.fraud_band || "N/A"}
Confidence: ${(claimRow.fraud_confidence || 0).toFixed(2)}

Policy: ${claimRow.policy_id || "N/A"}
Jurisdiction: ${claimRow.jurisdiction || "N/A"}
Amount: ${claimRow.amount || "N/A"}

Loss Date: ${claimRow.loss_date || "N/A"}
Reported Date: ${claimRow.reported_date || "N/A"}

Received: ${fmtLocal(claimRow.received_at) || "N/A"}
SLA Due: ${fmtLocal(claimRow.sla_due_at) || "N/A"}

---
Document Generated: ${new Date().toLocaleString()}
Source: RCGCC Fraud Intelligence Platform
    `;
    return caseSummary;
  }

  // ─────────────────────────────────────────────
  // Row Click → Open Fraud Studio
  // ─────────────────────────────────────────────

  window.rcgccRowClick = async function (idx) {
  const row = (window._rcgccRows || [])[idx];
  if (!row) return;

  // ✅ This is the missing wiring
  populateCp0Meta(row);
};


    console.log("[RCGCC] Opening case:", row.case_id);

    // -----------------------------------------
    // AUTO UPLOAD GENERATED PDF TO TENDER STUDIO
    // -----------------------------------------
    if (typeof window.autoUploadCasePdf === "function") {
        await window.autoUploadCasePdf(row);
    }

    // -----------------------------------------
    // STORE ACTIVE CASE
    // -----------------------------------------
    sessionStorage.setItem("sentinel_case_id", row.case_id);

    // -----------------------------------------
    // HYDRATE TENDERSTUDIO RUNTIME
    // -----------------------------------------
    if (typeof window.activateTenderStudioCase === "function") {
        await window.activateTenderStudioCase(row);
    }

    // -----------------------------------------
    // SOFT DELAY FOR EVENT PROPAGATION
    // -----------------------------------------
    setTimeout(() => {
        window.location.href = `/case/${row.case_id}`;
    }, 250);
  };

  // ─────────────────────────────────────────────
  // Search + Filters
  // ─────────────────────────────────────────────

  searchInput?.addEventListener("input", () => {
    offset = 0;
    load();
  });

  statusFilter?.addEventListener("change", () => {
    offset = 0;
    load();
  });

  rowsPerPageSelect?.addEventListener("change", () => {

    limit = Number(rowsPerPageSelect.value || 10);

    offset = 0;

    load();

  });

  // ─────────────────────────────────────────────
  // Manual Agent Wave
  // ─────────────────────────────────────────────

  btnRefresh?.addEventListener("click", async () => {

    try {

      if (typeof showSuccess === "function") {
        showSuccess("Running fraud analysis wave...");
      }

      await SentinelAPI.runBatch(10);

      offset = 0;

      await load();

      if (typeof showSuccess === "function") {
        showSuccess("Fraud analysis completed");
      }

    } catch (e) {

      console.error("[RCGCC] Batch run failed:", e);

      if (typeof showError === "function") {
        showError("Fraud analysis failed: " + e.message);
      }

    }

  });

  // ─────────────────────────────────────────────
  // Initialize
  // ─────────────────────────────────────────────

  async function initializeRCGCC() {

    console.log("[RCGCC] Initializing live fraud dashboard...");

    // Initial table load
    await load();

    // Start backend simulation automatically
    try {

      await fetch("/api/sim/start?interval=12&count=999999", {
        method: "POST"
      });

      console.log("[RCGCC] Live fraud simulation started");

    } catch (err) {

      console.warn(
        "[RCGCC] Simulation startup failed:",
        err
      );

    }

  }

  if (document.readyState === "loading") {

    document.addEventListener(
      "DOMContentLoaded",
      initializeRCGCC
    );

  } else {

    initializeRCGCC();

  }

  // ─────────────────────────────────────────────
  // Continuous Live Polling
  // ─────────────────────────────────────────────

  setInterval(async () => {

    try {

      console.log("[RCGCC] Polling latest fraud claims...");

      await load();

    } catch (err) {

      console.error(
        "[RCGCC] Live refresh failed:",
        err
      );

    }

  }, 10000);

  console.log("[RCGCC] Phase 5 LIVE fraud wiring active");

})();


window.activateTenderStudioCase = async function(caseRow) {

    console.log(
        "[RCGCC] Activating TenderStudio case:",
        caseRow.case_id
    );

    // -----------------------------------------
    // GLOBAL ACTIVE CASE
    // -----------------------------------------

    window.activeCase = caseRow;

    // -----------------------------------------
    // OPEN SIDE PANELS
    // -----------------------------------------

    if (typeof window.openCasePanel === "function") {

        window.openCasePanel(caseRow);
    }

    // -----------------------------------------
    // HYDRATE DOCUMENT VIEWER
    // -----------------------------------------

    window.dispatchEvent(
        new CustomEvent(
            "claim-document-ready",
            {
                detail: caseRow
            }
        )
    );

    // -----------------------------------------
    // HYDRATE AGENT MESH
    // -----------------------------------------

    window.dispatchEvent(
        new CustomEvent(
            "agent-mesh-update",
            {
                detail: {
                    caseId: caseRow.case_id,
                    fraudBand: caseRow.fraud_band,
                    score: caseRow.fraud_score
                }
            }
        )
    );

    // -----------------------------------------
    // UPDATE WORKSTREAMS
    // -----------------------------------------

    window.dispatchEvent(
        new CustomEvent(
            "workstream-update",
            {
                detail: caseRow
            }
        )
    );
};
