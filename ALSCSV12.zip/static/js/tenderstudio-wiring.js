/**
 * TenderResponseStudio → FINAL Sentinel Wiring
 */

(function () {
  if (typeof SentinelAPI === "undefined") {
    console.error("SentinelAPI not loaded.");
    return;
  }

  const caseId = getCaseIdFromContext();

  function pick(c, dotted, fallback = null) {
    try {
      return dotted.split(".").reduce((a, k) => (a && a[k] !== undefined ? a[k] : undefined), c) ?? fallback;
    } catch {
      return fallback;
    }
  }

  function setText(id, val) {
    const el = document.getElementById(id);
    if (el) el.textContent = (val == null) ? "—" : String(val);
  }

  function renderIndicators(c) {
    const indicators =
      c.triggered_indicators ||
      (c.ingestion && c.ingestion.signals) ||
      [];

    const flags = document.getElementById("rcFlags");
    if (!flags) return;

    flags.style.display = "block";
    flags.innerHTML = indicators.length
      ? indicators.map(x => `
        <div class="rc-flag rc-flag-${(x.severity || "medium").toLowerCase()}">
          <div class="rc-flag-title">${x.title || x.indicator_id}</div>
          <div class="rc-flag-detail">${x.explanation || ""}</div>
        </div>
      `).join("")
      : `<div class="rc-flag rc-flag-low"><div class="rc-flag-title">No indicators</div></div>`;
  }

  function applyAuditToTraceUI(events) {
    const el = document.getElementById("traceAgentLog");
    if (!el) return;

    el.innerHTML = (events || []).slice(-20).map(e =>
      `<div class="agent-line">${e.timestamp} - ${e.event_type}</div>`
    ).join("");
  }

  // ✅ MAIN LOADER
  async function loadCase() {
    if (!caseId) {
      showError("No case selected. Open from RCGCC.");
      return;
    }

    try {
      const c = await SentinelAPI.getCase(caseId);

      const pageTitle = document.querySelector(".page-title");
      if (pageTitle) pageTitle.textContent = `Case: ${c.case_id}`;

      const score = c.fraud_score ?? pick(c, "intelligence.fraud_score");
      const band = c.fraud_band ?? pick(c, "intelligence.fraud_band") ?? c.status;

      setText("rcOverallScore", score);
      setText("rcGoNogoLabel", band);

      renderIndicators(c);

      const audit = await SentinelAPI.getAudit(caseId, 200);
      applyAuditToTraceUI(audit.events);

      window.__SENTINEL_CASE = c;

      // ✅ ✅ AUTO INGEST LOGIC (FINAL VERSION)
      const hasSource = (c.source_text || (c.ingestion && c.ingestion.narrative));
      const needsParse = !c.ingestion || !c.ingestion.signals;

      if (hasSource && needsParse) {
        try {
          showSuccess("Processing attached document...");

          await SentinelAPI.reparseCase(caseId);

          showSuccess("Parsing complete. Running analysis...");

          const refreshed = await SentinelAPI.getCase(caseId);

          setText("rcOverallScore", refreshed.fraud_score ?? pick(refreshed, "intelligence.fraud_score"));
          setText("rcGoNogoLabel", refreshed.fraud_band ?? pick(refreshed, "intelligence.fraud_band") ?? refreshed.status);

          renderIndicators(refreshed);

          const audit2 = await SentinelAPI.getAudit(caseId, 200);
          applyAuditToTraceUI(audit2.events);

          window.__SENTINEL_CASE = refreshed;

          showSuccess("Document processed successfully");

        } catch (err) {
          console.error(err);
          showError("Auto-ingestion failed: " + err.message);
        }
      }

    } catch (e) {
      console.error(e);
      showError("Load failed: " + e.message);
    }
  }

  // ✅ UPLOAD HANDLER (HOOKS INTO EXISTING HTML)
  window.uploadFileSelected = async function (event) {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      showSuccess("Uploading & parsing document...");

      const resp = await SentinelAPI.ingestUpload(file, caseId);

      sessionStorage.setItem("sentinel_case_id", resp.case_id);

      showSuccess("Analysis running...");

      await loadCase();

    } catch (err) {
      console.error(err);
      showError(err.message);
    }
  };

  // INIT
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", loadCase);
  } else {
    loadCase();
  }

  console.log("[TenderResponseStudio] ✅ FINAL wiring active");
})();

// ─────────────────────────────────────────────────────────────
// AUTO-UPLOAD PDF FROM UPLOADS FOLDER (Phase 2B)
// ─────────────────────────────────────────────────────────────
async function autoUploadCasePdfFromUploads() {
  const caseId = sessionStorage.getItem('sentinel_case_id');
  if (!caseId) return;

  const url = `/uploads/${encodeURIComponent(caseId)}.pdf`;
  try {
    const r = await fetch(url);
    if (!r.ok) {
      console.log('[Studio] No PDF found for case:', caseId);
      return;
    }
    const blob = await r.blob();
    const filename = `${caseId}.pdf`;
    
    // Call the auto-upload engine (exists in tender-response-studio.js)
    if (typeof window.uploadPdfBlob === 'function') {
      await window.uploadPdfBlob(blob, filename);
      console.log('[Studio] ✅ Auto-uploaded PDF for case:', caseId);
    }
  } catch (err) {
    console.warn('[Studio] Auto-upload failed:', err);
  }
}

window.addEventListener('DOMContentLoaded', autoUploadCasePdfFromUploads);
