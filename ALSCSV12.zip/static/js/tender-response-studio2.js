/* ======================================================
   SENTINEL — ANTI-FRAUD AGENT DEFINITIONS (4 AGENTS)
   Domain: Insurance Fraud Detection & Claims Intelligence
   ====================================================== */

/* -----------------------------
   AGENT DEFINITIONS
----------------------------- */
const AGENTS = [
  {
    AGENT_NAME: "Intake & Signal",
    AGENT_DESCRIPTION:
      "Performs intelligent claim intake by parsing submitted documents, extracting entities, validating inputs, and generating initial fraud risk signals.",
    TASKS: [
      "Parsing claim forms, attachments, and supporting documents",
      "Extracting claimant identity, policy references, and incident details",
      "Validating document completeness and consistency",
      "Detecting early anomaly signals during intake",
      "Normalising claim data for downstream agent processing"
    ],
    TOOLS_USED: [
      "Document parsing & OCR engine",
      "Entity extraction & validation logic",
      "Rule-free anomaly detection"
    ],
    BUSINESS_OUTCOMES: [
      "Faster claim intake — claims are structured and validated within seconds rather than manual review cycles",
      "Early risk awareness — potential fraud indicators are flagged before any human handling begins",
      "Improved data quality — downstream fraud analysis operates on consistent, enriched claim data"
    ]
  },

  {
    AGENT_NAME: "Network Intelligence",
    AGENT_DESCRIPTION:
      "Performs cross-claim and cross-market entity resolution to uncover hidden relationships, organised fraud rings, and repeat abuse patterns.",
    TASKS: [
      "Resolving claimant, repairer, solicitor, and address entities across markets",
      "Building relationship graphs linking claims, entities, and events",
      "Identifying shared attributes across historical claims",
      "Detecting organised fraud patterns and networks",
      "Calculating network-level fraud confidence scores"
    ],
    TOOLS_USED: [
      "Entity resolution engine",
      "Graph construction & network analysis",
      "Cross-market fraud intelligence datasets"
    ],
    BUSINESS_OUTCOMES: [
      "Organised fraud exposed — hidden networks across regions are surfaced automatically",
      "Reduced leakage — repeat and professional fraud attempts are intercepted early",
      "Stronger investigator signal — cases are prioritised using network-backed risk evidence"
    ]
  },

  {
    AGENT_NAME: "Decisioning & Action",
    AGENT_DESCRIPTION:
      "Evaluates combined signals and determines the optimal handling path, balancing risk, automation, investigation routing, and customer outcome.",
    TASKS: [
      "Aggregating risk signals from upstream agents",
      "Scoring overall fraud risk with explainable factors",
      "Determining routing: fast-track, review, or fraud investigation",
      "Triggering automated actions for low-risk claims",
      "Generating investigator briefings for high-risk cases"
    ],
    TOOLS_USED: [
      "Risk scoring & classification engine",
      "Workflow routing logic",
      "Automated decision execution"
    ],
    BUSINESS_OUTCOMES: [
      "Faster settlements — low-risk claims are auto-approved without human delay",
      "Focused investigations — fraud teams receive only high-confidence cases",
      "Consistent decisions — risk thresholds are applied uniformly across markets"
    ]
  },

  {
    AGENT_NAME: "Learning & Adaptation",
    AGENT_DESCRIPTION:
      "Continuously improves fraud detection by learning from confirmed outcomes and propagating new fraud patterns across the platform.",
    TASKS: [
      "Recording confirmed fraud and cleared claim outcomes",
      "Updating fraud pattern libraries and signal weights",
      "Identifying early signals emerging across markets",
      "Alerting regional teams to new fraud trends",
      "Improving model performance over time"
    ],
    TOOLS_USED: [
      "Pattern learning & feedback loops",
      "Cross-market intelligence propagation",
      "Continuous model calibration"
    ],
    BUSINESS_OUTCOMES: [
      "Adaptive protection — the fraud system improves with every resolved claim",
      "Early trend detection — emerging fraud tactics are identified before scaling",
      "Enterprise intelligence — insights are shared across regions and lines of business"
    ]
  }
];

/* -----------------------------
   CONFIDENCE SCORES PER AGENT
----------------------------- */
const CONFIDENCE = [
  { score: 98, note: "Minor document inconsistencies detected — no impact on downstream analysis." },
  { score: 87, note: "Strong network overlap detected across related claims — organised fraud likely." },
  { score: 100, note: null },
  { score: 96, note: "New fraud pattern confirmed and propagated to monitoring rules." }
];

/* -----------------------------
   VISUAL META FOR AGENTS
----------------------------- */
const META = [
  { color: "#3B82F6", bg: "rgba(59,130,246,.15)", icon: "intake" },
  { color: "#8B5CF6", bg: "rgba(139,92,246,.15)", icon: "network" },
  { color: "#F59E0B", bg: "rgba(245,158,11,.15)", icon: "decision" },
  { color: "#10B981", bg: "rgba(16,185,129,.15)", icon: "learning" }
];

/* -----------------------------
   ICON DEFINITIONS
----------------------------- */
const ICONS = {
  intake: `<svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
    <polyline points="14 2 14 8 20 8"/>
  </svg>`,

  network: `<svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
    <circle cx="12" cy="12" r="3"/>
    <circle cx="19" cy="5" r="2"/>
    <circle cx="5" cy="19" r="2"/>
    <line x1="17.5" y1="6.5" x2="13.5" y2="10.5"/>
    <line x1="6.5" y1="17.5" x2="10.5" y2="13.5"/>
  </svg>`,

  decision: `<svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
    <path d="M12 2l7 4v6c0 5-3.5 9-7 10-3.5-1-7-5-7-10V6z"/>
  </svg>`,

  learning: `<svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
    <circle cx="12" cy="12" r="10"/>
    <path d="M12 6v6l4 2"/>
  </svg>`
};

/* -----------------------------
   TASK / TOOL / OUTCOME ICONS
----------------------------- */
const TASK_SVG = `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <polyline points="9 11 12 14 22 4"/>
  <path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/>
</svg>`;

const TOOL_SVG = `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <circle cx="12" cy="12" r="3"/>
  <path d="M19.4 15a7.96 7.96 0 0 0 .6-3 7.96 7.96 0 0 0-.6-3"/>
</svg>`;

const OUTCOME_SVG = `<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <rect x="2" y="7" width="20" height="14" rx="2"/>
  <path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/>
</svg>`;

/* ======================================================
   END OF SENTINEL AGENT CONFIGURATION
   ====================================================== */
