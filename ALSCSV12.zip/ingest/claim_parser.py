"""
Lightweight claim parser (demo-grade)
- Regex + heuristic signals
- Produces structured fields + indicators
"""
from __future__ import annotations
import re
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, Any, List

@dataclass
class ParsedClaim:
    claim_type: str
    jurisdiction: str
    claim_amount: float | None
    loss_date: str | None
    reported_date: str
    claimant_name: str | None
    repairer_name: str | None
    narrative: str
    signals: List[Dict[str, Any]]

_CLAIM_TYPE_KEYS = {
    "motor": ["collision","rear-end","whiplash","autobahn","garage","repairer"],
    "property": ["property","water damage","burst pipe","contractor","building management"],
    "travel": ["travel","baggage","flight","airline","police report"],
}

def _guess_claim_type(text: str) -> str:
    tl = text.lower()
    best = ("motor", 0)
    for k, keys in _CLAIM_TYPE_KEYS.items():
        s = sum(1 for w in keys if w in tl)
        if s > best[1]:
            best = (k, s)
    return best[0].capitalize()

def _guess_jurisdiction(text: str) -> str:
    tl = text.lower()
    if "frankfurt" in tl or "germany" in tl or " de" in tl: return "DE"
    if "lyon" in tl or "france" in tl or " fr" in tl: return "FR"
    if "london" in tl or "united kingdom" in tl or " uk" in tl: return "UK"
    return "DE"

def _extract_amount(text: str) -> float | None:
    m = re.search(r"(€|£|\\bEUR\\b|\\bGBP\\b)\\s*([0-9]{1,3}(?:,[0-9]{3})*(?:\\.[0-9]{2})?|[0-9]+(?:\\.[0-9]{2})?)", text, re.I)
    if not m: return None
    try: return float(m.group(2).replace(",", ""))
    except: return None

def _extract_date(text: str) -> str | None:
    for pat in [r"(\\d{4}-\\d{2}-\\d{2})", r"(\\d{1,2}/\\d{1,2}/\\d{4})"]:
        m = re.search(pat, text)
        if m: return m.group(1)
    return None

def parse_claim_text(text: str) -> ParsedClaim:
    text = (text or "").strip()
    claim_type = _guess_claim_type(text)
    jurisdiction = _guess_jurisdiction(text)
    amount = _extract_amount(text)
    loss_date = _extract_date(text)

    claimant = None
    m = re.search(r"Claimant\\s*:\\s*(.+)", text, re.I)
    if m: claimant = m.group(1).strip()[:80]

    repairer = None
    m = re.search(r"(Repairer|Garage|Contractor)\\s*:\\s*(.+)", text, re.I)
    if m: repairer = m.group(2).strip()[:80]

    signals: List[Dict[str, Any]] = []
    tl = text.lower()

    if "first-time claimant" in tl:
        signals.append({"indicator_id":"first_time_claimant","severity":"low","explanation":"First-time claimant stated","confidence":0.6})
    if "third claim" in tl or "3rd claim" in tl:
        signals.append({"indicator_id":"high_claim_frequency","severity":"medium","explanation":"Repeated claims pattern","confidence":0.75})
    if "shared solicitor" in tl:
        signals.append({"indicator_id":"shared_intermediary","severity":"high","explanation":"Shared solicitor across linked claims","confidence":0.85})
    if repairer and ("autofix" in repairer.lower() or "renoplus" in repairer.lower()):
        signals.append({"indicator_id":"known_repairer_node","severity":"high","explanation":"Repairer matches suspicious node (demo)","confidence":0.9})
    if amount and amount > 10000:
        signals.append({"indicator_id":"high_claim_amount","severity":"medium","explanation":"High claim amount","confidence":0.65})

    return ParsedClaim(
        claim_type=claim_type,
        jurisdiction=jurisdiction,
        claim_amount=amount,
        loss_date=loss_date,
        reported_date=datetime.utcnow().isoformat(),
        claimant_name=claimant,
        repairer_name=repairer,
        narrative=text[:2000],
        signals=signals
    )

def parsed_to_dict(p: ParsedClaim) -> Dict[str, Any]:
    return {
        "claim_type": p.claim_type,
        "jurisdiction": p.jurisdiction,
        "claim_amount": p.claim_amount,
        "loss_date": p.loss_date,
        "reported_date": p.reported_date,
        "claimant_name": p.claimant_name,
        "repairer_name": p.repairer_name,
        "narrative": p.narrative,
        "signals": p.signals
    }
