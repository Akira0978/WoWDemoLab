"""
UI Support Endpoints (Phase 3 FINAL)
Read-only endpoints used by RCGCC + TenderResponseStudio wiring.
"""
from flask import Blueprint, jsonify, request
from datetime import datetime
from models import db
from models.claim_case import ClaimCase



ui_bp = Blueprint("ui", __name__, url_prefix="/api")


@ui_bp.route("/claims", methods=["GET"])
def list_claims():
    """
    GET /api/claims?limit=50&offset=0&status=INTAKE
    Returns list of ClaimCase objects for RCGCC.
    """
    try:
        limit = int(request.args.get("limit", 25))
        offset = int(request.args.get("offset", 0))
        status = request.args.get("status")
        q = request.args.get("q")

        limit = max(1, min(limit, 200))
        offset = max(0, offset)

        query = ClaimCase.query

        if status:
            query = query.filter(ClaimCase.status == status)

        if q:
            like = f"%{q}%"
            query = query.filter(
                (ClaimCase.case_id.ilike(like)) |
                (ClaimCase.policy_id.ilike(like)) |
                (ClaimCase.claimant_id.ilike(like)) |
                (ClaimCase.claim_type.ilike(like)) |
                (ClaimCase.jurisdiction.ilike(like))
            )

        total = query.count()

        cases = (query
                 .order_by(ClaimCase.created_at.desc())
                 .offset(offset)
                 .limit(limit)
                 .all())

        return jsonify({
            "items": [c.to_dict() for c in cases],
            "total": total,
            "limit": limit,
            "offset": offset
        }), 200

    except Exception as e:
        import traceback
        print(f"[ERROR] list_claims: {e}\n{traceback.format_exc()}")
        return jsonify({"error": str(e)}), 500



@ui_bp.route("/kpis", methods=["GET"])
def get_kpis():
    """
    GET /api/kpis
    Returns KPI aggregates for RCGCC dashboard.
    """
    try:
        total = ClaimCase.query.count()

        by_status = {}
        status_counts = db.session.query(
            ClaimCase.status,
            db.func.count(ClaimCase.id)
        ).group_by(ClaimCase.status).all()

        for st, cnt in status_counts:
            by_status[st or "UNKNOWN"] = int(cnt)

        avg_score = db.session.query(db.func.avg(ClaimCase.fraud_score)).scalar()
        avg_score = round(float(avg_score), 2) if avg_score is not None else None

        return jsonify({
            "total": total,
            "by_status": by_status,
            "avg_fraud_score": avg_score
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@ui_bp.route("/audit/<case_id>", methods=["GET"])
def get_audit(case_id):
    """
    GET /api/audit/<case_id>?limit=200
    Reads audit events for case (from audit log file).
    """
    try:
        limit = int(request.args.get("limit", 200))
        limit = max(1, min(limit, 1000))

        # Import here to avoid circular imports
        from orchestration.audit_log import read_events

        events = read_events(case_id, limit=limit)
        return jsonify({"events": events, "count": len(events)}), 200

    except ImportError:
        # Fallback if audit_log doesn't exist yet
        return jsonify({"events": [], "count": 0}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500
