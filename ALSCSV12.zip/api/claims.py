from flask import Blueprint, request, jsonify
from datetime import datetime
import uuid

from models import db, ClaimCase

claims_bp = Blueprint("claims", __name__, url_prefix="/api/claims")


# -----------------------------
# Create new claim case
# -----------------------------
@claims_bp.route("", methods=["POST"])
def create_case():
    data = request.get_json()

    if not data:
        return jsonify({"error": "Invalid payload"}), 400

    try:
        # Parse dates safely
        loss_date = data.get("loss_date")
        reported_date = data.get("reported_date")
        
        if isinstance(loss_date, str):
            try:
                loss_date = datetime.fromisoformat(loss_date.replace('Z', '+00:00'))
            except:
                loss_date = datetime.utcnow()
        
        if isinstance(reported_date, str):
            try:
                reported_date = datetime.fromisoformat(reported_date.replace('Z', '+00:00'))
            except:
                reported_date = datetime.utcnow()

        case = ClaimCase(
            case_id=str(uuid.uuid4()),
            policy_id=data.get("policy_id"),
            claimant_id=data.get("claimant_id"),
            claim_type=data.get("claim_type"),
            coverage_type=data.get("coverage_type"),
            loss_date=loss_date or datetime.utcnow(),
            reported_date=reported_date or datetime.utcnow(),
            jurisdiction=data.get("jurisdiction", "GB"),
            status="INTAKE",
            created_at=datetime.utcnow()
        )

        db.session.add(case)
        db.session.commit()

        return jsonify({
            "message": "Case created",
            "case_id": case.case_id
        }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500


# -----------------------------
# List cases with pagination & filters
# -----------------------------
@claims_bp.route("", methods=["GET"])
def list_cases():
    try:
        limit = int(request.args.get("limit", 50))
        offset = int(request.args.get("offset", 0))
        status = request.args.get("status", None)
        q = request.args.get("q", None)  # search query
        
        query = ClaimCase.query
        
        # Filter by status if provided
        if status:
            query = query.filter_by(status=status)
        
        # Filter by search query (case_id, claim_type, jurisdiction)
        if q:
            search_term = f"%{q.lower()}%"
            from sqlalchemy import or_
            query = query.filter(
                or_(
                    ClaimCase.case_id.ilike(search_term),
                    ClaimCase.claim_type.ilike(search_term),
                    ClaimCase.jurisdiction.ilike(search_term)
                )
            )
        
        # Get total count before pagination
        total = query.count()
        
        # Apply pagination
        items = query.order_by(ClaimCase.created_at.desc()).limit(limit).offset(offset).all()
        
        # Flatten response for UI (extract from nested structure)
        def flatten_case(case_obj):
           
            return {

        # -----------------------------------
        # CORE
        # -----------------------------------

        "case_id":
            case_obj.case_id,

        "created_at":
            case_obj.created_at.isoformat()
            if case_obj.created_at else None,

        "status":
            str(case_obj.status),

        "claim_type":
            case_obj.claim_type,

        "jurisdiction":
            case_obj.jurisdiction,

        # -----------------------------------
        # FRAUD
        # -----------------------------------

        "fraud_score":
            case_obj.fraud_score,

        "fraud_confidence":
            case_obj.fraud_confidence,

        "fraud_band":
            case_obj.fraud_band,

        "triggered_indicators":
            case_obj.triggered_indicators or [],

        "reasoning_summary":
            case_obj.reasoning_summary,

        # -----------------------------------
        # SLA
        # -----------------------------------

        "sla_due_ts":
            case_obj.sla_due_ts.isoformat()
            if case_obj.sla_due_ts else None,

        # -----------------------------------
        # DOCUMENTS
        # -----------------------------------

        "source_filename":
            case_obj.source_filename,

        "source_text":
            case_obj.source_text,

        "pdf_url":
            f"/uploads/{case_obj.case_id}.pdf",

        # -----------------------------------
        # INGESTION
        # -----------------------------------

        "ingestion":
            case_obj.ingestion or {},

        # -----------------------------------
        # UI SUBJECT
        # -----------------------------------

        "subject":
            (
                f"{case_obj.case_id} · "
                f"{case_obj.claim_type or '—'} · "
                f"{case_obj.jurisdiction or '—'}"
            )
    }
        
        return jsonify({
            "total": total,
            "limit": limit,
            "offset": offset,
            "items": [flatten_case(case) for case in items]
        }), 200
        
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# -----------------------------
# Get case by ID
# -----------------------------
@claims_bp.route("/<case_id>", methods=["GET"])
def get_case(case_id):
    case = ClaimCase.query.filter_by(case_id=case_id).first()

    if not case:
        return jsonify({"error": "Case not found"}), 404

    return jsonify(case.to_dict()), 200