from flask import Blueprint, jsonify, request
from datetime import datetime

from models import db, ClaimCase

agents_bp = Blueprint("agents", __name__, url_prefix="/api/agents")


# Stub for orchestrator (will be created next)
def run_case(case):
    """
    Placeholder orchestrator runner.
    Will invoke fraud_engine and update case with intelligence.
    """
    from intelligence.fraud_engine import assess_fraud
    
    # Prepare case data for fraud engine
    case_data = {
        'case_id': case.case_id,
        'policy_id': case.policy_id,
        'claim_type': case.claim_type,
        'loss_date': case.loss_date.isoformat() if case.loss_date else None,
        'reported_date': case.reported_date.isoformat() if case.reported_date else None,
        'prior_claims_count': 0,  # placeholder
        'missing_documents_count': 0,  # placeholder
        'prior_fraud_finding': False,  # placeholder
    }
    
    # Run fraud assessment
    intelligence = assess_fraud(case_data)
    
    # Update case with intelligence
    case.fraud_score = intelligence['fraud_score']
    case.fraud_band = intelligence['fraud_band']
    case.fraud_confidence = intelligence['fraud_confidence']
    case.status = 'HUMAN_REVIEW'
    case.last_agent_run = datetime.utcnow()
    
    # Store indicators as JSON string
    import json
    case.triggered_indicators = json.dumps(intelligence.get('indicators', []))
    
    return case


# -----------------------------
# Run Sentinel pipeline
# -----------------------------
@agents_bp.route("/run/<case_id>", methods=["POST"])
def run_case_pipeline(case_id):
    case = ClaimCase.query.filter_by(case_id=case_id).first()

    if not case:
        return jsonify({"error": "Case not found"}), 404

    try:
        updated_case = run_case(case)

        db.session.commit()

        return jsonify({
            "message": "Pipeline executed",
            "case_id": case_id,
            "status": updated_case.status,
            "fraud_score": updated_case.fraud_score,
            "fraud_band": updated_case.fraud_band,
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500

@agents_bp.route("/run-batch", methods=["POST"])
def run_batch():
    """
    POST /api/agents/run-batch?limit=10
    Run analysis on batch of INTAKE cases.
    Used by RCGCC "Run Agent Wave" button.
    """
    try:
        limit = int(request.args.get("limit", 10))
        limit = max(1, min(limit, 50))

        cases = (
            ClaimCase.query
            .filter(ClaimCase.status == "INTAKE")
            .order_by(ClaimCase.created_at.desc())
            .limit(limit)
            .all()
        )

        updated = 0
        errors = []

        for c in cases:
            try:
                run_case(c)
                updated += 1
            except Exception as e:
                errors.append({"case_id": c.case_id, "error": str(e)})

        db.session.commit()

        return jsonify({
            "updated": updated,
            "errors": errors,
            "total_processed": len(cases)
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500