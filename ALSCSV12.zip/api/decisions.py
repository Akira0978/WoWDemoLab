from flask import Blueprint, request, jsonify

from models.claim_case import ClaimCase
from models import db
from orchestration.runner import apply_human_decision

decisions_bp = Blueprint("decisions", __name__, url_prefix="/api/decisions")


# -----------------------------
# Apply human decision
# -----------------------------
@decisions_bp.route("/<case_id>", methods=["POST"])
def decide(case_id):
    case = ClaimCase.query.filter_by(case_id=case_id).first()

    if not case:
        return jsonify({"error": "Case not found"}), 404

    data = request.get_json()

    decision = data.get("decision")
    notes = data.get("notes", "")

    try:
        updated_case = apply_human_decision(case, decision, notes)

        db.session.commit()

        return jsonify({
            "message": "Decision applied",
            "status": updated_case.status,
            "decision": updated_case.handler_decision
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500