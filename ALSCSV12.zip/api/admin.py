# api/admin.py
from __future__ import annotations
import os
from flask import Blueprint, jsonify, current_app
from models import db
from models.claim_case import ClaimCase

admin_bp = Blueprint("admin", __name__, url_prefix="/api/admin")

@admin_bp.route("/reset", methods=["POST"])
def reset_demo_session():
    """
    Clears DB rows (does not delete DB file) and clears uploads folder.
    """
    # 1) Clear DB rows
    deleted_cases = db.session.query(ClaimCase).delete(synchronize_session=False)
    db.session.commit()

    # 2) Clear uploads folder
    upload_dir = current_app.config.get("UPLOAD_FOLDER", os.path.join(current_app.root_path, "uploads"))
    removed_files = 0
    errors = []

    if os.path.isdir(upload_dir):
        for name in os.listdir(upload_dir):
            path = os.path.join(upload_dir, name)
            try:
                # keep folder, remove files only
                if os.path.isfile(path):
                    os.remove(path)
                    removed_files += 1
            except Exception as e:
                errors.append(f"{name}: {str(e)}")

    return jsonify({
        "ok": True,
        "db_deleted_cases": deleted_cases,
        "uploads_removed_files": removed_files,
        "upload_dir": upload_dir,
        "errors": errors
    }), 200
