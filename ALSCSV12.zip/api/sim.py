# api/sim.py

from flask import Blueprint, jsonify
from threading import Thread
import time
import uuid
from datetime import datetime

from models import db
from models.claim_case import ClaimCase

sim_bp = Blueprint("sim", __name__, url_prefix="/api/sim")


def feeder():
    while True:
        c = ClaimCase(
            case_id=f"CASE-{uuid.uuid4().hex[:6].upper()}",
            claim_type="Motor",
            jurisdiction="DE",
            status="INTAKE",
            created_at=datetime.utcnow()
        )
        db.session.add(c)
        db.session.commit()
        time.sleep(10)


@sim_bp.route("/start", methods=["POST"])
def start():
    Thread(target=feeder, daemon=True).start()
    return jsonify({"ok": True})
