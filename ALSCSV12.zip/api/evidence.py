"""
Evidence API (Phase 4)
Read evidence references for cases.
"""
from flask import Blueprint, jsonify
from models.claim_case import ClaimCase

evidence_bp = Blueprint("evidence", __name__, url_prefix="/api/evidence")


@evidence_bp.route("/<case_id>", methods=["GET"])
def list_evidence(case_id):
    """
    GET /api/evidence/<case_id>
    Returns list of evidence references for case.
    """
    try:
        case = ClaimCase.query.filter_by(case_id=case_id).first()
        if not case:
            return jsonify({"error": "Case not found"}), 404

        refs = case.evidence_refs or []
        # If stored as string, convert to list
        if isinstance(refs, str):
            refs = [r.strip() for r in refs.split(",") if r.strip()]

        return jsonify({"items": refs, "count": len(refs)}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500
