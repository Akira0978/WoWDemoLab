"""
Decisions and Reports Blueprint
================================
Human decision recording and case resolution.
"""

from flask import Blueprint, request, jsonify
from datetime import datetime

from models import db, ClaimCase

reports_bp = Blueprint("reports", __name__, url_prefix="/api/reports")


# ─────────────────────────────────────────────────────────────────────────────
# Record human decision (critical checkpoint)
# ─────────────────────────────────────────────────────────────────────────────

@reports_bp.route("/decide/<case_id>", methods=["POST"])
def record_decision(case_id):
    """
    Record human handler decision.
    
    This is where human authority takes over from agent intelligence.
    """
    case = ClaimCase.query.filter_by(case_id=case_id).first()

    if not case:
        return jsonify({"error": "Case not found"}), 404

    data = request.get_json()

    if not data:
        return jsonify({"error": "Invalid payload"}), 400

    try:
        # Parse decision
        handler_decision = data.get("handler_decision")  # CLEAR, HOLD, REFER, REJECT
        if handler_decision not in ["CLEAR", "HOLD", "REFER", "REJECT"]:
            return jsonify({"error": f"Invalid decision: {handler_decision}"}), 400

        # Update case with human decision
        case.handler_decision = handler_decision
        case.referred_unit = data.get("referred_unit")
        case.handler_notes = data.get("handler_notes", "")
        case.decision_ts = datetime.utcnow()
        case.decided_by = data.get("decided_by", "unknown")
        case.decision_version = (case.decision_version or 0) + 1

        # Update status based on decision
        if handler_decision == "CLEAR":
            case.status = "CLOSED"
        elif handler_decision == "REFER":
            case.status = "ESCALATED"
        elif handler_decision in ["HOLD", "REJECT"]:
            case.status = "INVESTIGATING"

        db.session.commit()

        return jsonify({
            "message": "Decision recorded",
            "case_id": case_id,
            "handler_decision": handler_decision,
            "status": case.status,
        }), 200

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500


# ─────────────────────────────────────────────────────────────────────────────
# Get full case report (for UI display)
# ─────────────────────────────────────────────────────────────────────────────

@reports_bp.route("/<case_id>", methods=["GET"])
def get_report(case_id):
    """Get full case report with all intelligence and decisions."""
    case = ClaimCase.query.filter_by(case_id=case_id).first()

    if not case:
        return jsonify({"error": "Case not found"}), 404

    return jsonify(case.to_dict()), 200

@reports_bp.route("/decision-pack/<case_id>", methods=["POST"])
def decision_pack(case_id):
    """
    POST /api/reports/decision-pack/<case_id>
    Generate decision pack export (PDF/DOCX stub).
    Returns download URL.
    """
    try:
        case = ClaimCase.query.filter_by(case_id=case_id).first()
        if not case:
            return jsonify({"error": "Case not found"}), 404

        # TODO: Implement PDF/DOCX generation using your report generator
        # For now, return a predictable download URL placeholder
        url = f"/reports/Decision_Pack_{case_id}.pdf"
        return jsonify({"download_url": url}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500