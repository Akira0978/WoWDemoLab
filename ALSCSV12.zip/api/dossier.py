# api/dossier.py
from __future__ import annotations

import json
import re
import time
import uuid
from dataclasses import dataclass
from typing import Any, Dict, Optional, Tuple

import tempfile
import os
from flask import Blueprint, jsonify, request, current_app

from ingest.document_utils import extract_text
from ingest.claim_parser import parse_claim_text, parsed_to_dict


dossier_bp = Blueprint("dossier", __name__, url_prefix="/api/dossier")


# ════════════════════════════════════════════════════════════════════
# PHASE 2: DETERMINISTIC DOSSIER PARSING
# ════════════════════════════════════════════════════════════════════

_KEY_LINE_RE = {
    "case_id": re.compile(r"^\s*Case Reference\s*:\s*(?P<v>.+?)\s*$", re.I | re.M),
    "policy_number": re.compile(r"^\s*Policy Number\s*:\s*(?P<v>.+?)\s*$", re.I | re.M),
    "claimant_id": re.compile(r"^\s*Claimant ID\s*:\s*(?P<v>.+?)\s*$", re.I | re.M),
    "claim_type": re.compile(r"^\s*Claim Type\s*:\s*(?P<v>.+?)\s*$", re.I | re.M),
    "coverage_type": re.compile(r"^\s*Coverage Type\s*:\s*(?P<v>.+?)\s*$", re.I | re.M),
    "jurisdiction": re.compile(r"^\s*Jurisdiction\s*:\s*(?P<v>[A-Z]{2})\s*$", re.I | re.M),
    "fraud_band": re.compile(r"^\s*Fraud Band\s*:\s*(?P<v>LOW|REVIEW|HIGH)\s*$", re.I | re.M),
    "fraud_score": re.compile(r"^\s*Fraud Score\s*:\s*(?P<v>\d+(?:\.\d+)?)\s*$", re.I | re.M),
    "fraud_confidence": re.compile(r"^\s*Fraud Confidence\s*:\s*(?P<v>\d+(?:\.\d+)?)\s*$", re.I | re.M),
    "status": re.compile(r"^\s*Status\s*:\s*(?P<v>.+?)\s*$", re.I | re.M),
    "current_stage": re.compile(r"^\s*Current Stage\s*:\s*(?P<v>.+?)\s*$", re.I | re.M),
    "loss_date": re.compile(r"^\s*Loss Date\s*:\s*(?P<v>.+?)\s*$", re.I | re.M),
    "reported_date": re.compile(r"^\s*Reported Date\s*:\s*(?P<v>.+?)\s*$", re.I | re.M),
    "reasoning_summary": re.compile(r"^\s*Reasoning Summary\s*:\s*(?P<v>.+?)\s*$", re.I | re.M),
    "generated_at": re.compile(r"^\s*Generated Timestamp\s*:\s*(?P<v>.+?)\s*$", re.I | re.M),
}

_AMOUNT_RE = re.compile(r"(€|£|\bEUR\b|\bGBP\b)\s*(\d{1,3}(?:,\d{3})*(?:\.\d+)?|\d+(?:\.\d+)?)", re.I)
_NARRATIVE_LINE_RE = re.compile(r"^\s*Narrative\s*:\s*(?P<v>.+?)\s*$", re.I | re.M)
_LOCATION_LINE_RE = re.compile(r"^\s*Location\s*:\s*(?P<v>.+?)\s*$", re.I | re.M)
_REPAIRER_LINE_RE = re.compile(r"^\s*Repairer\s*:\s*(?P<v>.+?)\s*$", re.I | re.M)
_CLAIMANT_LINE_RE = re.compile(r"^\s*Claimant\s*:\s*(?P<v>.+?)\s*$", re.I | re.M)


def _get_value(text: str, key: str) -> Optional[str]:
    rx = _KEY_LINE_RE.get(key)
    if not rx:
        return None
    m = rx.search(text or "")
    return m.group("v").strip() if m else None


def _extract_json_array_after_label(text: str, label: str) -> Tuple[Optional[list], Optional[str]]:
    """Finds JSON array after label like 'Triggered Indicators:' with bracket matching."""
    if not text:
        return (None, None)
    idx = text.lower().find(label.lower())
    if idx < 0:
        return (None, None)
    start = text.find("[", idx)
    if start < 0:
        return (None, None)
    depth = 0
    end = None
    for i in range(start, len(text)):
        ch = text[i]
        if ch == "[":
            depth += 1
        elif ch == "]":
            depth -= 1
            if depth == 0:
                end = i + 1
                break
    if end is None:
        return (None, None)
    raw = text[start:end].strip()
    try:
        parsed = json.loads(raw)
        if isinstance(parsed, list):
            return (parsed, raw)
    except Exception:
        return (None, raw)
    return (None, raw)


def _extract_amount(text: str) -> Optional[float]:
    m = _AMOUNT_RE.search(text or "")
    if not m:
        return None
    try:
        return float(m.group(2).replace(",", ""))
    except Exception:
        return None


def parse_text_to_dossier_json(raw_text: str, filename: str = "") -> Dict[str, Any]:
    """
    Deterministic parser for 'CLAIM INVESTIGATION DOSSIER' format.
    Extracts key fields via regex + safe JSON parsing for Triggered Indicators.
    Falls back to claim_parser.parse_claim_text when template fields missing.
    """
    text = (raw_text or "").strip()
    case_id = _get_value(text, "case_id")
    claim_type = _get_value(text, "claim_type")
    jurisdiction = _get_value(text, "jurisdiction")
    template_present = bool(case_id and claim_type and jurisdiction)

    indicators, indicators_raw = _extract_json_array_after_label(text, "Triggered Indicators:")
    fraud_band = _get_value(text, "fraud_band")
    fraud_score = _get_value(text, "fraud_score")
    fraud_conf = _get_value(text, "fraud_confidence")

    try:
        fraud_score_n = float(fraud_score) if fraud_score is not None else None
    except Exception:
        fraud_score_n = None
    try:
        fraud_conf_n = float(fraud_conf) if fraud_conf is not None else None
    except Exception:
        fraud_conf_n = None

    narr = None
    nm = _NARRATIVE_LINE_RE.search(text)
    if nm:
        narr = nm.group("v").strip()

    amount = _extract_amount(text)

    # Fallback if template not present
    if not template_present:
        parsed_obj = parse_claim_text(text)
        parsed = parsed_to_dict(parsed_obj)
        return {
            "case_id": f"DOSSIER-{uuid.uuid4().hex[:8].upper()}",
            "source_filename": filename,
            "parsed": parsed,
            "narrative": parsed.get("narrative") or text[:2000],
            "fraud_band": "REVIEW",
            "fraud_score": 50,
            "fraud_confidence": 0.6,
            "triggered_indicators": parsed.get("signals") or [],
            "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "_parser": "fallback_claim_parser",
        }

    # Template present → build structured dossier_json
    parsed_block = {
        "policy_number": _get_value(text, "policy_number"),
        "claimant_id": _get_value(text, "claimant_id"),
        "claim_type": claim_type,
        "coverage_type": _get_value(text, "coverage_type"),
        "jurisdiction": jurisdiction,
        "loss_date": _get_value(text, "loss_date"),
        "reported_date": _get_value(text, "reported_date"),
        "claimant_name": (_CLAIMANT_LINE_RE.search(text).group("v").strip() if _CLAIMANT_LINE_RE.search(text) else None),
        "repairer_name": (_REPAIRER_LINE_RE.search(text).group("v").strip() if _REPAIRER_LINE_RE.search(text) else None),
        "location": (_LOCATION_LINE_RE.search(text).group("v").strip() if _LOCATION_LINE_RE.search(text) else None),
        "claim_amount": amount,
        "narrative": narr or text[:2000],
        "signals": [],
    }

    dossier_json = {
        "case_id": case_id,
        "source_filename": filename,
        "parsed": parsed_block,
        "narrative": parsed_block["narrative"],
        "fraud_band": (fraud_band or "REVIEW").upper(),
        "fraud_score": int(fraud_score_n) if fraud_score_n is not None else 50,
        "fraud_confidence": float(fraud_conf_n) if fraud_conf_n is not None else 0.6,
        "triggered_indicators": indicators or [],
        "status": _get_value(text, "status"),
        "current_stage": _get_value(text, "current_stage"),
        "reasoning_summary": _get_value(text, "reasoning_summary"),
        "generated_at": _get_value(text, "generated_at") or time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "_parser": "deterministic_regex",
        "_indicators_raw": indicators_raw,
    }

    return dossier_json
@dataclass
class _TTLItem:
    exp_ts: float
    payload: Dict[str, Any]


class DossierTTLStore:
    """
    In-memory TTL store for ephemeral dossier sessions.
    No DB persistence. Keys are opaque tokens.
    """
    def __init__(self, ttl_seconds: int = 30 * 60):
        self.ttl_seconds = int(ttl_seconds)
        self._data: Dict[str, _TTLItem] = {}

    def _now(self) -> float:
        return time.time()

    def cleanup(self) -> None:
        now = self._now()
        expired = [k for k, v in self._data.items() if v.exp_ts <= now]
        for k in expired:
            self._data.pop(k, None)

    def put(self, payload: Dict[str, Any]) -> str:
        self.cleanup()
        token = uuid.uuid4().hex
        self._data[token] = _TTLItem(exp_ts=self._now() + self.ttl_seconds, payload=payload)
        return token

    def get(self, token: str) -> Optional[Dict[str, Any]]:
        self.cleanup()
        item = self._data.get(token)
        if not item:
            return None
        if item.exp_ts <= self._now():
            self._data.pop(token, None)
            return None
        return item.payload


def _get_store() -> DossierTTLStore:
    # One store per Flask process
    store: DossierTTLStore = current_app.extensions.get("dossier_store")  # type: ignore
    if not store:
        ttl = int(current_app.config.get("DOSSIER_TTL_SECONDS", 30 * 60))
        store = DossierTTLStore(ttl_seconds=ttl)
        current_app.extensions["dossier_store"] = store
    return store


def _simple_fraud_enrich(parsed: Dict[str, Any], raw_text: str) -> Dict[str, Any]:
    """
    Demo-grade enrichment: derive fraud_score/band/confidence + indicators.
    Keeps things deterministic and safe for demo. No DB needed.
    """
    text_l = (raw_text or "").lower()
    indicators = []

    # Keyword-based indicators
    def add(indicator_id: str, severity: str, explanation: str, confidence: float):
        indicators.append({
            "indicator_id": indicator_id,
            "severity": severity,
            "explanation": explanation,
            "confidence": confidence
        })

    if "shared solicitor" in text_l or "same solicitor" in text_l:
        add("shared_intermediary", "HIGH", "Shared solicitor pattern detected across claims", 0.85)
    if "repairer" in text_l and ("known" in text_l or "autofix" in text_l):
        add("repairer_node_match", "HIGH", "Repairer matches a suspicious network node", 0.80)
    if "third claim" in text_l or "3rd claim" in text_l:
        add("repeat_claim_frequency", "MED", "Repeat claim frequency signal detected", 0.70)
    if "late reporting" in text_l or "reported 60 days" in text_l:
        add("late_reporting", "MED", "Loss-to-reporting delay indicates higher risk", 0.65)

    amount = parsed.get("claim_amount") or 0
    try:
        amount = float(amount) if amount is not None else 0.0
    except Exception:
        amount = 0.0

    # Deterministic scoring
    score = 5
    score += 30 if any(i["severity"] == "HIGH" for i in indicators) else 0
    score += 20 if any(i["severity"] == "MED" for i in indicators) else 0
    if amount >= 10000:
        score += 15
        add("high_amount", "MED", "Claim amount exceeds normal threshold", 0.60)

    score = max(0, min(100, int(score)))

    if score >= 80:
        band = "HIGH"
    elif score >= 60:
        band = "REVIEW"
    else:
        band = "LOW"

    confidence = round(min(0.95, 0.45 + 0.08 * len(indicators)), 2)

    return {
        "fraud_score": score,
        "fraud_band": band,
        "fraud_confidence": confidence,
        "triggered_indicators": indicators,
    }


@dossier_bp.route("/parse", methods=["POST"])
def parse_dossier():
    """
    POST /api/dossier/parse
    multipart/form-data: file=<PDF>
    Returns: { token, dossier_json }
    """

    # ✅ Validate file
    if "file" not in request.files:
        return jsonify({"error": "Missing file"}), 400

    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "Empty filename"}), 400

    filename = f.filename

    import tempfile
    import os

    # ✅ Save uploaded file temporarily
    suffix = os.path.splitext(filename)[1] or ".pdf"
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        f.save(tmp.name)
        temp_path = tmp.name

    try:
        # ✅ extract_text returns (doc_type, text)
        doc_type, raw_text = extract_text(temp_path, filename)
        raw_text = (raw_text or "").strip()
    finally:
        # ✅ cleanup temp file
        try:
            os.remove(temp_path)
        except Exception:
            pass

    # ✅ Deterministic parser
    dossier_json = parse_text_to_dossier_json(raw_text, filename=filename)

    store = _get_store()
    token = store.put(dossier_json)

    return jsonify({
        "token": token,
        "dossier_json": dossier_json
    }), 200
