"""
Checkpoints API (Phase 4)
Human gate decision persistence.
"""
from flask import Blueprint, jsonify, request
from models import db
from models.claim_case import ClaimCase
from orchestration.audit_log import log_event

checkpoints_bp = Blueprint("checkpoints", __name__, url_prefix="/api/checkpoints")


@checkpoints_bp.route("/<case_id>/<cp_id>", methods=["POST"])
def set_checkpoint(case_id, cp_id):
    """
    POST /api/checkpoints/<case_id>/cp0
    Store checkpoint decision (CP0, CP1, CP2).
    """
    try:
        case = ClaimCase.query.filter_by(case_id=case_id).first()
        if not case:
            return jsonify({"error": "Case not found"}), 404

        payload = request.get_json(silent=True) or {}
        field = f"{cp_id.lower()}_state"
        if field not in ("cp0_state", "cp1_state", "cp2_state"):
            return jsonify({"error": "Invalid checkpoint"}), 400

        setattr(case, field, payload)
        db.session.commit()

        log_event("GATE_ACTION", case_id, {"checkpoint": cp_id.upper(), **payload})
        return jsonify({"ok": True, "checkpoint": cp_id.upper(), "state": payload}), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500
