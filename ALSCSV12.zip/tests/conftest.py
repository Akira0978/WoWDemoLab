import pytest
from app import create_app
from models import db
from models.claim_case import ClaimCase

@pytest.fixture()
def app():
    app = create_app({
        "TESTING": True,
        "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
        "SQLALCHEMY_TRACK_MODIFICATIONS": False,
    })
    with app.app_context():
        db.create_all()
    yield app

@pytest.fixture()
def client(app):
    return app.test_client()

@pytest.fixture()
def seed_cases(app):
    with app.app_context():
        for i in range(5):
            c = ClaimCase(
                case_id=f"CASE-{i}",
                policy_id=f"POL-{i}",
                claimant_id=f"CLM-{i}",
                claim_type="Motor",
                jurisdiction="DE",
                status="INTAKE",
                fraud_score=None,
                fraud_confidence=None,
            )
            db.session.add(c)
        db.session.commit()