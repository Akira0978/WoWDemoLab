﻿"""
Sentinel Control Plane
======================
Minimal Flask entrypoint. Bootstraps app, loads config, registers blueprints.

Does NOT contain:
- Business logic
- Domain rules
- Scoring/simulation
- Report generation
- Agent behavior
"""


from flask import Flask, render_template, Blueprint, jsonify, request, current_app, send_from_directory
import os, tempfile, uuid
from threading import Thread, Event
import time
from pathlib import Path
from api import claims_bp, agents_bp, reports_bp, ui_bp
from datetime import datetime

from models import db
from models.claim_case import ClaimCase
from ingest.document_utils import extract_text
from ingest.claim_parser import parse_claim_text, parsed_to_dict
from orchestration.runner import run_case
from simulation.fraud_datagen import generate_cases, to_payload
from simulation.fraud_datagen import start_live_simulation
from api.admin import admin_bp

from api.dossier import dossier_bp


sim_bp = Blueprint("sim", __name__, url_prefix="/api/sim")

_stop = Event()
_thread = None

@sim_bp.route("/start", methods=["POST"])
def start():
    global _thread
    if _thread and _thread.is_alive():
        return jsonify({"ok": True, "running": True}), 200

    interval = int(request.args.get("interval", 12))
    count = int(request.args.get("count", 30))

    _stop.clear()
    _thread = Thread(
        target=start_live_simulation,
        args=(current_app._get_current_object(), _stop, interval),
        daemon=True)
    _thread.start()
    return jsonify({"ok": True, "running": True, "interval": interval, "count": count}), 200

@sim_bp.route("/stop", methods=["POST"])
def stop():
    _stop.set()
    return jsonify({"ok": True, "stopped": True}), 200


ingest_bp = Blueprint("ingest", __name__, url_prefix="/api/ingest")

@ingest_bp.route("/upload", methods=["POST"])
def upload_and_ingest():
    case_id = request.form.get("case_id")

    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "Empty filename"}), 400

    suffix = os.path.splitext(f.filename)[1].lower()
    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        f.save(tmp.name)
        tmp_path = tmp.name

    try:
        doc_type, text = extract_text(tmp_path, f.filename)
        parsed = parse_claim_text(text)
        parsed_dict = parsed_to_dict(parsed)

        if not case_id:
            case_id = f"CASE-{uuid.uuid4().hex[:10].upper()}"

        case = ClaimCase.query.filter_by(case_id=case_id).first()
        if not case:
            case = ClaimCase(
                case_id=case_id,
                policy_id=request.form.get("policy_id"),
                claimant_id=request.form.get("claimant_id"),
                claim_type=parsed.claim_type,
                coverage_type=parsed.claim_type,
                jurisdiction=parsed.jurisdiction,
                loss_date=parsed.loss_date,
                reported_date=parsed.reported_date,
                status="INTAKE",
                created_at=datetime.utcnow(),
            )
            db.session.add(case)

        case.source_filename = f.filename
        case.source_text = text
        case.ingestion = parsed_dict
        case.ingested_at = datetime.utcnow()

        db.session.commit()

        run_analysis_for_case(case)
        db.session.commit()

        return jsonify({
            "case_id": case.case_id,
            "status": case.status,
            "case": case.to_dict()
        }), 200

    finally:
        try:
            os.unlink(tmp_path)
        except:
            pass

@ingest_bp.route("/reparse/<case_id>", methods=["POST"])
def reparse_from_stored_text(case_id):
    case = ClaimCase.query.filter_by(case_id=case_id).first()
    if not case:
        return jsonify({"error": "Case not found"}), 404
    if not case.source_text:
        return jsonify({"error": "No source_text to parse"}), 400

    parsed = parse_claim_text(case.source_text)
    case.ingestion = parsed_to_dict(parsed)
    case.claim_type = parsed.claim_type
    case.jurisdiction = parsed.jurisdiction
    case.loss_date = parsed.loss_date
    case.reported_date = parsed.reported_date
    case.ingested_at = datetime.utcnow()

    db.session.commit()

    run_analysis_for_case(case)
    db.session.commit()

    return jsonify({"case_id": case.case_id, "case": case.to_dict()}), 200


def create_app(config_name: str = "development") -> Flask:
    """
    Factory function: create and configure Flask app.

    Args:
        config_name: 'development', 'testing', or 'production'

    Returns:
        Configured Flask app instance
    """
    app = Flask(
        __name__,
        template_folder='templates',
        static_folder='static'
    )

    _load_config(app, config_name)
    _init_db(app)
    _register_error_handlers(app)
    _register_blueprints(app)
    _start_background_simulation(app)

    @app.route('/')
    def home():
        return render_template('Manager/RCGCC.html')

    @app.route('/case/<case_id>')
    def case_view(case_id):
        return render_template('Manager/TenderResponseStudio.html', case_id=case_id)

    @app.route('/tender-response-studio')
    def tender_response_studio():
        return render_template('Manager/TenderResponseStudio.html')

    @app.route('/debug/seed')
    def seed_cases():
        from models import db
        from models.claim_case import ClaimCase
        from datetime import datetime
        for i in range(1, 11):
            case_id = f"CASE-{i}"
            if ClaimCase.query.filter_by(case_id=case_id).first():
                continue
            c = ClaimCase(
                case_id=case_id,
                policy_id=f"P-{i}",
                claimant_id=f"C-{i}",
                claim_type="Motor",
                jurisdiction="DE",
                status="INTAKE",
                loss_date=datetime.utcnow(),
                reported_date=datetime.utcnow(),
            )
            db.session.add(c)
        db.session.commit()
        return {"status": "seeded"}

    @app.route('/favicon.ico')
    def favicon():
        return send_from_directory('static', 'favicon.ico', mimetype='image/vnd.microsoft.icon')

    @app.route("/uploads/<path:filename>")
    def uploaded_file(filename):
        return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

    @app.route("/api/admin/reset", methods=["POST"])
    def reset_session():
        """Reset the demo session: clear uploads folder and reset database."""
        import shutil
        try:
            uploads_dir = app.config['UPLOAD_FOLDER']
            if os.path.exists(uploads_dir):
                shutil.rmtree(uploads_dir)
            os.makedirs(uploads_dir, exist_ok=True)
            # Reset DossierTTLStore
            from api.dossier import _store_instance
            if _store_instance:
                _store_instance._data.clear()
            return jsonify({"ok": True, "message": "Session reset: uploads folder cleared"}), 200
        except Exception as e:
            return jsonify({"ok": False, "error": str(e)}), 500

    # ------------------------------------------------------------------
    # TENDER RESPONSE STUDIO — /api/claims/tender-response-studio
    # Fixed: was defined AFTER return app (dead code → 404).
    # Now correctly placed BEFORE return app.
    # Returns last parsed dossier from DossierTTLStore so JS gets
    # real PDF-extracted data, not hardcoded placeholders.
    # ------------------------------------------------------------------
    @app.route("/api/claims/tender-response-studio", methods=["GET"])
    def get_tender_studio_claims():
        from api.dossier import _get_store
        dossier = None
        try:
            store = _get_store()
            if store._data:
                latest = max(store._data.values(), key=lambda item: item.exp_ts)
                dossier = latest.payload
        except Exception:
            dossier = None

        if dossier:
            parsed = dossier.get("parsed") or {}
            indicators = dossier.get("triggered_indicators") or []
            return jsonify({
                "case_id":               dossier.get("case_id") or parsed.get("case_id") or "N/A",
                "category":         dossier.get("claim_type") or parsed.get("claim_type") or "N/A",
                "risk":             dossier.get("fraud_band") or "REVIEW",
                "status":           dossier.get("status") or "HUMAN_REVIEW",
                "score":            dossier.get("fraud_score") or 0,
                "confidence":       dossier.get("fraud_confidence") or 0.6,
                "indicators":       indicators,
                "fraud_dimensions": dossier.get("fraud_dimensions") or {},
                "narrative":        dossier.get("narrative") or "",
                "jurisdiction":     dossier.get("jurisdiction") or parsed.get("jurisdiction") or "",
                "source_filename":  dossier.get("source_filename") or "",
                "dossier":          dossier,
            }), 200

        return jsonify({
            "id":               "N/A",
            "category":         "N/A",
            "risk":             "REVIEW",
            "status":           "PENDING",
            "score":            0,
            "confidence":       0.6,
            "indicators":       [],
            "fraud_dimensions": {},
            "narrative":        "",
            "jurisdiction":     "",
            "source_filename":  "",
            "dossier":          None,
        }), 200

    # ------------------------------------------------------------------
    # ASSESS RISK — /api/assess-risk
    # Fixed: was a hardcoded placeholder returning {"risk":"LOW"}.
    # Now pulls last parsed dossier from DossierTTLStore and returns
    # a structured risk payload that the JS Risk Mitigation Console
    # renders (dimensions, flags, Go/No-Go badge, score ring).
    # Called by runRiskEngine() in tender-response-studio.js.
    # ------------------------------------------------------------------
    @app.route("/api/assess-risk", methods=["POST"])
    def assess_risk_studio():
        from api.dossier import _get_store
        request.get_json(force=True, silent=True)

        dossier = None
        try:
            store = _get_store()
            if store._data:
                latest = max(store._data.values(), key=lambda item: item.exp_ts)
                dossier = latest.payload
        except Exception:
            dossier = None

        if dossier:
            parsed     = dossier.get("parsed") or {}
            indicators = dossier.get("triggered_indicators") or []
            overall    = int(dossier.get("fraud_score") or 0)
            band       = (dossier.get("fraud_band") or "REVIEW").upper()

            band_to_decision = {"HIGH": "nogo", "MEDIUM": "conditional", "LOW": "go"}
            decision = band_to_decision.get(band, "conditional")

            label_map = {
                "go":          "\u2713 GO",
                "conditional": "\u26a0 CONDITIONAL GO",
                "nogo":        "\u2715 NO-GO",
            }
            desc_map = {
                "go":          "Risk profile is within acceptable parameters. Recommend proceeding.",
                "conditional": "Moderate risk identified. Proceed subject to mitigation actions below.",
                "nogo":        "High risk profile. Recommend escalation before committing resources.",
            }

            flags = []
            for ind in indicators[:8]:
                sev = (ind.get("severity") or "medium").lower()
                flags.append({
                    "level":            sev,
                    "title":            ind.get("indicator_id") or ind.get("dimension") or "Indicator",
                    "detail":           ind.get("explanation") or "",
                    "mitigation_steps": ([ind["recommended_action"]]
                                         if ind.get("recommended_action") else []),
                    "forecast":         "",
                    "owner":            "",
                    "urgency":          "",
                    "dimension":        ind.get("dimension") or "behavioural",
                })

            fd  = dossier.get("fraud_dimensions") or {}
            lbl = band.lower()
            dimensions = {
                "commercial":   {"score": fd.get("behavioural") or overall, "label": lbl},
                "technical":    {"score": fd.get("historical")  or overall, "label": lbl},
                "programme":    {"score": fd.get("network")     or overall, "label": lbl},
                "supply_chain": {"score": fd.get("document")    or overall, "label": lbl},
                "strategic":    {"score": fd.get("contextual")  or overall, "label": lbl},
            }

            return jsonify({
                "overall_score":  overall,
                "overall_label":  lbl,
                "decision":       decision,
                "decision_label": label_map[decision],
                "decision_desc":  desc_map[decision],
                "dimensions":     dimensions,
                "flags":          flags,
                "tender_ref":     dossier.get("case_id") or "N/A",
                "tender_title":   parsed.get("claim_type") or "N/A",
                "client_name":    parsed.get("claimant_name") or "N/A",
            }), 200

        return jsonify({
            "overall_score":  0,
            "overall_label":  "low",
            "decision":       "conditional",
            "decision_label": "\u26a0 CONDITIONAL GO",
            "decision_desc":  "No dossier uploaded yet. Upload a PDF to run a full risk assessment.",
            "dimensions": {
                "commercial":   {"score": 0, "label": "low"},
                "technical":    {"score": 0, "label": "low"},
                "programme":    {"score": 0, "label": "low"},
                "supply_chain": {"score": 0, "label": "low"},
                "strategic":    {"score": 0, "label": "low"},
            },
            "flags":          [],
            "tender_ref":     "N/A",
            "tender_title":   "N/A",
            "client_name":    "N/A",
        }), 200

    return app


def _load_config(app: Flask, config_name: str) -> None:
    """Load config from environment or defaults."""
    app.config['ENV'] = config_name
    app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'sentinel-dev-key')
    app.config['SESSION_TYPE'] = 'filesystem'
    app.config['DOSSIER_TTL_SECONDS'] = int(os.getenv("DOSSIER_TTL_SECONDS", "1800"))
    base_dir = os.path.dirname(os.path.abspath(__file__))
    db_path = os.getenv('DATABASE_URL') or f'sqlite:///{base_dir}/sentinel.db'
    app.config['SQLALCHEMY_DATABASE_URI'] = db_path
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    reports_dir = os.path.join(base_dir, 'reports')
    os.makedirs(reports_dir, exist_ok=True)
    app.config['REPORTS_DIR'] = reports_dir
    uploads_dir = os.path.join(base_dir, 'uploads')
    os.makedirs(uploads_dir, exist_ok=True)
    app.config['UPLOAD_FOLDER'] = uploads_dir


def _init_db(app: Flask) -> None:
    """Initialize database (one-time on app startup)."""
    try:
        from models import db
        from models.claim_case import ClaimCase
        db.init_app(app)
        with app.app_context():
            db.create_all()
    except ImportError as e:
        app.logger.error(f"Failed to import models: {e}. Database initialization skipped.")
    except Exception as e:
        app.logger.error(f"Database initialization error: {e}")


def _register_error_handlers(app: Flask) -> None:
    """Register global error handlers."""

    @app.errorhandler(400)
    def bad_request(e):
        return {'error': 'Bad request', 'details': str(e)}, 400

    @app.errorhandler(404)
    def not_found(e):
        return {'error': 'Not found', 'details': str(e)}, 404

    @app.errorhandler(500)
    def internal_error(e):
        return {'error': 'Internal server error', 'details': str(e)}, 500


def _register_blueprints(app: Flask) -> None:
    app.register_blueprint(ui_bp)
    app.register_blueprint(claims_bp)
    app.register_blueprint(agents_bp)
    app.register_blueprint(reports_bp)
    app.register_blueprint(dossier_bp)
    app.register_blueprint(sim_bp)
    app.register_blueprint(ingest_bp)
    app.register_blueprint(admin_bp)


def _start_background_simulation(app: Flask) -> None:
    """Start continuous live fraud claim generation. Runs only once per Flask process."""
    global _thread
    try:
        if _thread and _thread.is_alive():
            app.logger.info("Simulation already running")
            return
        _stop.clear()
        _thread = Thread(
            target=start_live_simulation,
            args=(app, _stop, 12),
            daemon=True
        )
        _thread.start()
        app.logger.info("✓ Background fraud simulation started")
    except Exception as e:
        app.logger.error(f"Simulation startup failed: {e}")


def run_analysis_for_case(case: ClaimCase) -> ClaimCase:
    """Single source of truth for analysis."""
    updated = run_case(case)
    return updated


# Create app instance for gunicorn (startup.txt: gunicorn app:app)
app = create_app('production')

if __name__ == '__main__':
    app = create_app('development')
    app.run(debug=True, host='0.0.0.0', port=7003, use_reloader=False)