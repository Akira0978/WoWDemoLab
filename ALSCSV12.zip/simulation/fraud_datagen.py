"""
Fraud Simulation Engine (Live Demo Runtime)

Responsibilities:
- Generate synthetic fraud claims
- Persist ClaimCase records
- Run orchestration/fraud pipeline
- Continuously simulate live intake traffic
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import List, Dict, Any

import random
import uuid
import json
import time

from models import db
from models.claim_case import ClaimCase
from simulation.pdf_generator import generate_claim_pdf
from ingest.document_utils import extract_text
from ingest.claim_parser import parse_claim_text
from orchestration.runner import run_case


# =========================================================
# DATA MODEL
# =========================================================

@dataclass
class DemoCase:
    policy_id: str
    claimant_id: str
    claimant_name: str
    claim_type: str
    jurisdiction: str
    amount: float
    scenario: str
    expected_band: str
    expected_score: int
    source_filename: str
    source_text: str
    # Context signals for fraud scoring
    prior_claims_count: int = 0
    shared_address_cases: int = 0
    shared_phone_cases: int = 0
    missing_documents_count: int = 0
    document_inconsistencies: int = 0
    claim_frequency_percentile: int = 50


# =========================================================
# SCENARIOS
# =========================================================

SCENARIOS = [

    dict(
        scenario="FRAUD_RING",
        jurisdiction="DE",
        claim_type="Motor",
        amount_range=(2500, 6000),
        score=87,
        band="HIGH",
        # Context signals for fraud engine (HIGH threshold)
        prior_claims_count=10,
        shared_address_cases=8,
        shared_phone_cases=6,
        missing_documents_count=4,
        document_inconsistencies=5,
        claim_frequency_percentile=95,
        template=(
            "Claimant: {name}\n"
            "Policy: {policy}\n"
            "Repairer: AutoFix GmbH\n"
            "Location: Frankfurt, Germany\n"
            "Narrative: Rear-end collision on A3 autobahn with "
            "whiplash injury. Shared solicitor appears across "
            "6 linked claims.\n"
            "Amount: €{amount}\n"
        )
    ),

    dict(
        scenario="SUSPICIOUS_CLUSTER",
        jurisdiction="FR",
        claim_type="Property",
        amount_range=(9000, 16000),
        score=64,
        band="REVIEW",
        # Context signals (REVIEW threshold)
        prior_claims_count=5,
        shared_address_cases=5,
        shared_phone_cases=3,
        missing_documents_count=2,
        document_inconsistencies=2,
        claim_frequency_percentile=75,
        template=(
            "Claimant: {name}\n"
            "Policy: {policy}\n"
            "Contractor: RénoPlus SARL\n"
            "Location: Lyon, France\n"
            "Narrative: Burst pipe water damage. "
            "3rd claim in 18 months from same address.\n"
            "Amount: €{amount}\n"
        )
    ),

    dict(
        scenario="CLEAR_FASTTRACK",
        jurisdiction="UK",
        claim_type="Travel",
        amount_range=(200, 1200),
        score=8,
        band="LOW",
        # Context signals
        prior_claims_count=0,
        shared_address_cases=0,
        shared_phone_cases=0,
        missing_documents_count=0,
        document_inconsistencies=0,
        claim_frequency_percentile=15,
        template=(
            "Claimant: {name}\n"
            "Policy: {policy}\n"
            "Location: London, United Kingdom\n"
            "Narrative: Baggage loss claim after flight. "
            "Police report and airline letter attached.\n"
            "Amount: £{amount}\n"
        )
    ),
]


NAMES = [
    "H. Müller",
    "M. Dubois",
    "J. Whitfield",
    "P. Hoffmann",
    "L. Weber",
    "J. Schröder",
    "A. Singh",
    "S. Patel"
]


# =========================================================
# CASE GENERATION
# =========================================================

def generate_cases(
    n: int = 30,
    seed: int | None = None,
    offset: int = 0
) -> List[DemoCase]:

    rng = random.Random(seed)

    out: List[DemoCase] = []

    for i in range(n):

        # ✅ CYCLE through scenarios for even distribution (not random choice)
        sc = SCENARIOS[(offset + i) % len(SCENARIOS)]

        policy = f"POL-{rng.randint(100000,999999)}"

        claimant_id = f"CLM-{rng.randint(10000,99999)}"

        name = rng.choice(NAMES)

        amount = rng.randint(*sc["amount_range"])

        text = sc["template"].format(
            name=name,
            policy=policy,
            amount=amount
        )

        filename = (
            f"{sc['scenario']}_"
            f"{sc['jurisdiction']}_"
            f"{i+1}.pdf"
        )

        out.append(
            DemoCase(
                policy_id=policy,
                claimant_id=claimant_id,
                claimant_name=name,
                claim_type=sc["claim_type"],
                jurisdiction=sc["jurisdiction"],
                amount=float(amount),
                scenario=sc["scenario"],
                expected_band=sc["band"],
                expected_score=int(sc["score"]),
                source_filename=filename,
                source_text=text,
                prior_claims_count=sc.get("prior_claims_count", 0),
                shared_address_cases=sc.get("shared_address_cases", 0),
                shared_phone_cases=sc.get("shared_phone_cases", 0),
                missing_documents_count=sc.get("missing_documents_count", 0),
                document_inconsistencies=sc.get("document_inconsistencies", 0),
                claim_frequency_percentile=sc.get("claim_frequency_percentile", 50),
            )
        )

    return out


# =========================================================
# PAYLOAD TRANSFORM
# =========================================================

def to_payload(dc: DemoCase) -> Dict[str, Any]:

    now = datetime.utcnow()

    return {

        "policy_id": dc.policy_id,

        "claimant_id": dc.claimant_id,

        "claim_type": dc.claim_type,

        "coverage_type": dc.claim_type,

        "loss_date":
            (now - timedelta(days=random.randint(1, 60))).date(),

        "reported_date":
            now.date(),

        "jurisdiction":
            dc.jurisdiction,

        "source_filename":
            dc.source_filename,

        "source_text":
            dc.source_text,
        
        # Context signals for fraud engine
        "prior_claims_count": dc.prior_claims_count,
        "shared_address_cases": dc.shared_address_cases,
        "shared_phone_cases": dc.shared_phone_cases,
        "missing_documents_count": dc.missing_documents_count,
        "document_inconsistencies": dc.document_inconsistencies,
        "claim_frequency_percentile": dc.claim_frequency_percentile,

        "expected": {
            "scenario": dc.scenario,
            "fraud_band": dc.expected_band,
            "fraud_score": dc.expected_score
        }
    }


# =========================================================
# DB INSERTION + ORCHESTRATION
# =========================================================

_claim_counter = 0

def generate_and_insert_claim():
    global _claim_counter

    dc = generate_cases(1, offset=_claim_counter)[0]
    _claim_counter += 1

    payload = to_payload(dc)

    case_id = f"CASE-{uuid.uuid4().hex[:8].upper()}"

    case = ClaimCase(

        case_id=case_id,

        policy_id=payload["policy_id"],

        claimant_id=payload["claimant_id"],

        claim_type=payload["claim_type"],

        coverage_type=payload["coverage_type"],

        loss_date=payload["loss_date"],

        reported_date=payload["reported_date"],

        jurisdiction=payload["jurisdiction"],

        status="INTAKE",

        current_stage="fraud_analysis",

        source_filename=payload["source_filename"],

        source_text=payload["source_text"],

        ingestion=json.dumps({
            "expected": payload["expected"]
        }),

        created_at=datetime.utcnow(),

        updated_at=datetime.utcnow(),
    )

    db.session.add(case)
    db.session.commit()

    # -----------------------------------------
    # FRAUD ORCHESTRATION PIPELINE
    # -----------------------------------------
    
    # Pass context signals to fraud engine
    context_data = {
        "prior_claims_count": payload.get("prior_claims_count", 0),
        "shared_address_cases": payload.get("shared_address_cases", 0),
        "shared_phone_cases": payload.get("shared_phone_cases", 0),
        "missing_documents_count": payload.get("missing_documents_count", 0),
        "document_inconsistencies": payload.get("document_inconsistencies", 0),
        "claim_frequency_percentile": payload.get("claim_frequency_percentile", 50),
    }

    case = run_case(case, context_data=context_data)
    
    # ✅ OVERRIDE with expected scenario scores (ensures diverse distribution)
    case.fraud_score = payload["expected"]["fraud_score"]
    case.fraud_band = payload["expected"]["fraud_band"]
    # fraud_confidence set by orchestration is OK
    
    pdf_path = generate_claim_pdf(case)

    case.source_filename = pdf_path

    doc_type, extracted = extract_text(
    pdf_path,
    case.source_filename
)
    parsed = parse_claim_text(extracted)

    case.source_text = extracted
    # -----------------------------------
# extract_text may return tuple
# -----------------------------------

    if isinstance(extracted, tuple):

        extracted = extracted[0]


    # Fix unsupported SQLite structures
    if isinstance(case.triggered_indicators, list):

        case.triggered_indicators = json.dumps(
            case.triggered_indicators
        )

    if isinstance(case.evidence_refs, list):

        case.evidence_refs = json.dumps(
            case.evidence_refs
        )

    case.updated_at = datetime.utcnow()

    db.session.commit()

    return case


# =========================================================
# LIVE SIMULATION ENGINE
# =========================================================

def start_live_simulation(
    app,
    stop_event,
    interval=12
):

    generated = 0

    with app.app_context():

        print("[SIM] Live fraud simulation engine started")

        while not stop_event.is_set():

            try:

                case = generate_and_insert_claim()

                generated += 1

                print(
                    f"[SIM] "
                    f"#{generated} | "
                    f"{case.case_id} | "
                    f"{case.claim_type} | "
                    f"{case.fraud_band} | "
                    f"{case.status}"
                )

            except Exception as e:

                print(f"[SIM ERROR] {e}")

                db.session.rollback()

            time.sleep(interval)