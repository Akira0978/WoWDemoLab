from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer
)

from reportlab.lib.styles import getSampleStyleSheet

from reportlab.lib.pagesizes import letter

from pathlib import Path

from datetime import datetime


UPLOAD_DIR = Path("uploads")

UPLOAD_DIR.mkdir(exist_ok=True)


def generate_claim_pdf(case):

    pdf_path = UPLOAD_DIR / f"{case.case_id}.pdf"

    doc = SimpleDocTemplate(
        str(pdf_path),
        pagesize=letter
    )

    styles = getSampleStyleSheet()

    story = []

    def add(title, value):

        story.append(
            Paragraph(
                f"<b>{title}</b>: {value}",
                styles["BodyText"]
            )
        )

        story.append(Spacer(1, 10))

    # =====================================================
    # HEADER
    # =====================================================

    story.append(
        Paragraph(
            "<b>CLAIM INVESTIGATION DOSSIER</b>",
            styles["Title"]
        )
    )

    story.append(Spacer(1, 20))

    # =====================================================
    # CORE DETAILS
    # =====================================================

    add("Case Reference", case.case_id)

    add("Policy Number", case.policy_id)

    add("Claimant ID", case.claimant_id)

    add("Claim Type", case.claim_type)

    add("Coverage Type", case.coverage_type)

    add("Jurisdiction", case.jurisdiction)

    add("Fraud Band", case.fraud_band)

    add("Fraud Score", case.fraud_score)

    add("Fraud Confidence", case.fraud_confidence)

    add("Status", case.status)

    add("Current Stage", case.current_stage)

    add("Loss Date", case.loss_date)

    add("Reported Date", case.reported_date)

    # =====================================================
    # NARRATIVE
    # =====================================================

    story.append(
        Paragraph(
            "<b>Claim Narrative</b>",
            styles["Heading2"]
        )
    )

    story.append(Spacer(1, 10))

    story.append(
        Paragraph(
            case.source_text.replace("\n", "<br/>"),
            styles["BodyText"]
        )
    )

    story.append(Spacer(1, 20))

    # =====================================================
    # ENGINE OUTPUT
    # =====================================================

    story.append(
        Paragraph(
            "<b>Fraud Engine Analysis</b>",
            styles["Heading2"]
        )
    )

    story.append(Spacer(1, 10))

    add(
        "Triggered Indicators",
        case.triggered_indicators
    )

    add(
        "Reasoning Summary",
        case.reasoning_summary
    )

    add(
        "Generated Timestamp",
        datetime.utcnow().isoformat()
    )

    doc.build(story)

    return str(pdf_path)