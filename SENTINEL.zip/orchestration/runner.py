from datetime import datetime

from orchestration.state_machine import (
    enforce_transition,
    CaseState,
)
from orchestration.audit_log import log_event
from intelligence.fraud_engine import assess_fraud


def run_case(case):
    """
    Runs orchestration pipeline for a ClaimCase.

    IMPORTANT:
    - Stops at HUMAN_REVIEW
    - Does NOT finalize decisions
    """

    # -------------------
    # INTAKE → INVESTIGATING
    # -------------------
    if case.status == CaseState.INTAKE:
        enforce_transition(case.status, CaseState.INVESTIGATING)

        case.status = CaseState.INVESTIGATING
        case.current_stage = "fraud_analysis"
        case.last_agent_run = datetime.utcnow()

        log_event("STATE_CHANGE", case.case_id, {
            "from": "INTAKE",
            "to": "INVESTIGATING"
        })

    # -------------------
    # FRAUD ENGINE EXECUTION
    # -------------------
    if case.status == CaseState.INVESTIGATING:

        result = assess_fraud(case.to_dict())

        case.fraud_score = result.get("fraud_score")
        case.fraud_band = result.get("fraud_band")
        case.fraud_confidence = result.get("fraud_confidence")

        case.triggered_indicators = result.get("indicators")
        case.reasoning_summary = f"{len(result.get('indicators', []))} indicators triggered"

        case.last_agent_run = datetime.utcnow()

        log_event("ENGINE_RUN", case.case_id, result)

        # -------------------
        # MOVE TO HUMAN REVIEW
        # -------------------
        enforce_transition(case.status, CaseState.HUMAN_REVIEW)

        case.status = CaseState.HUMAN_REVIEW
        case.current_stage = "awaiting_human_decision"

        log_event("STATE_CHANGE", case.case_id, {
            "from": "INVESTIGATING",
            "to": "HUMAN_REVIEW"
        })

    return case


def apply_human_decision(case, decision: str, notes: str = ""):
    """
    Applies handler decision.

    VALID decisions:
    - CLEAR → CLOSED
    - REFER → ESCALATED
    - HOLD → stays HUMAN_REVIEW
    """

    if case.status != CaseState.HUMAN_REVIEW:
        raise Exception("Human decision allowed only in HUMAN_REVIEW state")

    case.handler_decision = decision
    case.handler_notes = notes
    case.decision_ts = datetime.utcnow()

    if decision == "CLEAR":
        enforce_transition(case.status, CaseState.CLOSED)
        case.status = CaseState.CLOSED

    elif decision == "REFER":
        enforce_transition(case.status, CaseState.ESCALATED)
        case.status = CaseState.ESCALATED

    elif decision == "HOLD":
        pass  # no state change

    else:
        raise Exception("Invalid decision")

    log_event("HUMAN_DECISION", case.case_id, {
        "decision": decision,
        "notes": notes
    })

    return case