from flask import Blueprint, request, jsonify
from datetime import datetime
import uuid

from models import db, ClaimCase

claims_bp = Blueprint("claims", __name__, url_prefix="/api/claims")


# -----------------------------
# Create new claim case
# -----------------------------
@claims_bp.route("", methods=["POST"])
def create_case():
    data = request.get_json()

    if not data:
        return jsonify({"error": "Invalid payload"}), 400

    try:
        # Parse dates safely
        loss_date = data.get("loss_date")
        reported_date = data.get("reported_date")
        
        if isinstance(loss_date, str):
            try:
                loss_date = datetime.fromisoformat(loss_date.replace('Z', '+00:00'))
            except:
                loss_date = datetime.utcnow()
        
        if isinstance(reported_date, str):
            try:
                reported_date = datetime.fromisoformat(reported_date.replace('Z', '+00:00'))
            except:
                reported_date = datetime.utcnow()

        case = ClaimCase(
            case_id=str(uuid.uuid4()),
            policy_id=data.get("policy_id"),
            claimant_id=data.get("claimant_id"),
            claim_type=data.get("claim_type"),
            coverage_type=data.get("coverage_type"),
            loss_date=loss_date or datetime.utcnow(),
            reported_date=reported_date or datetime.utcnow(),
            jurisdiction=data.get("jurisdiction", "GB"),
            status="INTAKE",
            created_at=datetime.utcnow()
        )

        db.session.add(case)
        db.session.commit()

        return jsonify({
            "message": "Case created",
            "case_id": case.case_id
        }), 201

    except Exception as e:
        db.session.rollback()
        return jsonify({"error": str(e)}), 500


# -----------------------------
# Get case by ID
# -----------------------------
@claims_bp.route("/<case_id>", methods=["GET"])
def get_case(case_id):
    case = ClaimCase.query.filter_by(case_id=case_id).first()

    if not case:
        return jsonify({"error": "Case not found"}), 404

    return jsonify(case.to_dict()), 200