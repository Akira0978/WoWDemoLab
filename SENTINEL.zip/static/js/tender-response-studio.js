const AGENTS=[
  {
    AGENT_NAME:"Orchestrator agent",
    AGENT_DESCRIPTION:"Coordinates the end-to-end agentic workflow, actively managing timing, sequencing, dependencies, and alerts throughout the tender window.",
    TASKS:[
      "Ensuring every workstream starts at the right moment",
      "Keeping your bid on schedule by continuously monitoring the tender clock and flagging any timeline risks before they become critical",
      "Maximising team productivity by running independent workstreams simultaneously, compressing the overall bid preparation timeline",
      "Proactively surfacing deadline and dependency risks so bid managers can intervene early rather than react under pressure",
      "Guaranteeing governance integrity by enforcing mandatory human approval checkpoints"
    ],
    TOOLS_USED:["Workflow state management","Task sequencing and dependency tracking","Alerting and notification mechanisms"],
    BUSINESS_OUTCOMES:[
      "Faster bid turnaround — parallel workstreams reduce end-to-end preparation time by up to 40%, freeing your team to focus on bid quality",
      "Zero missed deadlines — real-time milestone tracking and proactive alerts ensure your submission is always on track",
      "Full governance assurance — mandatory human checkpoints mean no response leaves without the right approvals in place"
    ]
  },
  {
    AGENT_NAME:"ITT intake & analysis agent",
    AGENT_DESCRIPTION:"Ingests ITT documentation and produces a structured understanding of the tender along with early commercial and delivery risk flags.",
    TASKS:[
      "Instantly processing your received Invitation to Tender",
      "Translating complex ITT instructions into a clear, structured requirements map so entire bid team works from a shared, accurate understanding",
      "Delivering a ready-to-use Tender Summary Brief to all contributors",
      "Identifying commercial, contractual, and delivery risks early",
      "Surfacing clarification questions and risk flags immediately"
    ],
    TOOLS_USED:["Document ingestion and parsing","Requirement and risk extraction logic"],
    BUSINESS_OUTCOMES:[
      "Day-one clarity — Tender Summary successfully created for Bid Manager review",
      "Risk-aware bidding — Risks have been flagged and summary has been created for Commercial Manager review"
    ]
  },
  {
    AGENT_NAME:"Content retrieval agent",
    AGENT_DESCRIPTION:"Searches the bid content library to find and rank the most relevant prior material aligned to the current ITT.",
    TASKS:[
      "Instantly searching your entire bid content library against this tender's specific requirements — delivering the best available evidence in seconds",
      "Surfacing the most relevant winning submissions, method statements, and case references, giving your drafters a head start with proven, high-quality content",
      "Scoring and ranking all retrieved content by relevance and past performance",
      "Structuring the retrieved content into ready-to-use inputs for the drafting agent — ensuring nothing is lost in translation between research and writing"
    ],
    TOOLS_USED:["Content library search","Relevance ranking mechanism"],
    BUSINESS_OUTCOMES:[
      "Higher-quality responses — bids are built on your most relevant, proven content rather than starting from a blank page, raising the standard of every submission",
      "Significant time saving — automated content retrieval eliminates manual library searches, reclaiming hours of bid team capacity per tender",
      "Institutional knowledge captured — past successes are systematically re-applied, ensuring your organisation's expertise informs every new bid"
    ]
  },
  {
    AGENT_NAME:"Governance pack agent",
    AGENT_DESCRIPTION:"Assembles the governance pack in parallel with drafting, ensuring decision-makers receive a complete and structured overview.",
    TASKS:[
      "Continuously assembling your governance pack as the bid develops — so directors always have an up-to-date view",
      "Consolidating risk flags, bid confidence scores, and key summaries into a single decision-ready document",
      "Maintaining a live, always-current governance overview throughout the bid — eliminating the last-minute scramble to prepare director briefing packs",
      "Preparing a structured, professionally formatted governance pack ahead of Checkpoint 2 — ensuring executive sign-off is informed, efficient, and audit-ready"
    ],
    TOOLS_USED:["Automated document assembly","Structured summary generation"],
    BUSINESS_OUTCOMES:[
      "Faster director decisions — structured governance packs enable informed sign-off in minutes rather than requiring lengthy briefing sessions",
      "Reduced governance overhead — automated assembly eliminates the manual effort of consolidating bid data for leadership review",
      "Stronger audit trail — every governance decision is backed by a complete, timestamped pack, supporting compliance and post-bid review"
    ]
  },
  {
    AGENT_NAME:"Response drafting agent",
    AGENT_DESCRIPTION:"Produces a full compliant draft response aligned to ITT criteria and performs self-checks against those criteria.",
    TASKS:[
      "Producing a complete, structured draft response precisely aligned to each ITT question and scoring criterion",
      "Seamlessly weaving your strongest existing content into compliant, coherent narratives",
      "Continuously validating the draft against evaluation criteria as it writing",
      "Rapidly incorporating reviewer feedback and requested amendments",
      "Maintaining a complete, submission-ready draft available for Checkpoint 1 review at any time"
    ],
    TOOLS_USED:["Draft generation engine","Criteria-alignment and self-check logic"],
    BUSINESS_OUTCOMES:[
      "Submission-ready quality from the first draft — AI-generated responses aligned to scoring criteria reduce the revision burden on your bid team by up to 60%",
      "Higher win probability — criterion-by-criterion alignment ensures your response directly addresses what evaluators are scoring, maximising your competitive score",
      "Faster review cycles — a structured, pre-validated draft means bid managers spend time refining and approving, not correcting and rebuilding"
    ]
  },
  {
    AGENT_NAME:"Governance & compliance agent",
    AGENT_DESCRIPTION:"Performs final compliance checks and confirms submission readiness before handoff to the bid manager.",
    TASKS:[
      "Conducting a thorough compliance review across every section of your submission",
      "Verifying that all mandatory attachments, declarations, and format requirements are present and correctly structured",
      "Providing a complete audit trail of agent activities and human decisions",
      "Generating a definitive Submission Readiness Report"
    ],
    TOOLS_USED:["Compliance checking mechanisms","Submission readiness evaluation"],
    BUSINESS_OUTCOMES:[
      "Zero disqualification risk — automated compliance verification ensures every submission meets mandatory requirements before it leaves your organisation",
      "Confident, evidence-backed submission — the Readiness Report gives leadership a clear green light, replacing gut-feel with verified assurance",
      "Continuous improvement culture — full audit trails enable post-bid analysis, helping Galliford Try refine its approach and strengthen future submissions"
    ]
  }
];
/* Confidence scores per agent — 100% shows affirmation, <100% shows actionable note */
const CONFIDENCE=[
  {score:100, note:null},
  {score:97,  note:"Minor ambiguity detected in two ITT evaluation sub-criteria — bid team review recommended before drafting begins."},
  {score:94,  note:"Three content library matches scored below the relevance threshold — supplementary evidence may strengthen the response."},
  {score:100, note:null},
  {score:96,  note:"One response section flagged for potential word-count variance against ITT guidance — reviewer attention advised at CP1."},
  {score:91,  note:"Mandatory attachment cross-check identified one declaration requiring manual countersignature before submission is complete."}
];

const META=[
  {color:'#1976d2',bg:'rgba(25,118,210,.15)',icon:'orchestrator'},
  {color:'#7c5cfc',bg:'rgba(124,92,252,.15)',icon:'intake'},
  {color:'#00a886',bg:'rgba(0,168,134,.15)',icon:'retrieval'},
  {color:'#f5a623',bg:'rgba(245,166,35,.15)',icon:'governance'},
  {color:'#00c2e0',bg:'rgba(0,194,224,.15)',icon:'drafting'},
  {color:'#EC1B2E',bg:'rgba(236,27,46,.15)',icon:'compliance'}
];

const ICONS={
  orchestrator:`<svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M3 9h18M9 21V9"/></svg>`,
  intake:`<svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/></svg>`,
  retrieval:`<svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>`,
  governance:`<svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>`,
  drafting:`<svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><line x1="17" y1="10" x2="3" y2="10"/><line x1="21" y1="6" x2="3" y2="6"/><line x1="21" y1="14" x2="3" y2="14"/><line x1="17" y1="18" x2="3" y2="18"/></svg>`,
  compliance:`<svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>`
};

const TASK_SVG=`<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>`;
const TOOL_SVG=`<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>`;
const OUTCOME_SVG=`<svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 7V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v2"/><line x1="12" y1="12" x2="12" y2="12"/></svg>`;

const CHECK_SVG=`<svg viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`;
const WARN_SVG=`<svg viewBox="0 0 24 24"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`;

/* Show transition bridge row between agents during the 5s gap */
function showTransitionIndicator(nextAgentName){
  const existing=document.getElementById('agentTransitionRow');
  if(existing)existing.remove();
  const tr=document.createElement('tr');
  tr.className='agent-transition-row';
  tr.id='agentTransitionRow';
  tr.innerHTML=`<td colspan="3">
    <div class="agent-transition-inner">
      <div class="agent-transition-spinner"></div>
      <div class="agent-transition-text">
        <div class="agent-transition-label">Workflow orchestrating next step</div>
        <div class="agent-transition-name">Next agent executing: <span>${nextAgentName}</span> is starting&hellip;</div>
        <div class="agent-transition-dots"><span></span><span></span><span></span></div>
      </div>
    </div>
  </td>`;
  $('workflowBody').appendChild(tr);
  tr.scrollIntoView({behavior:'smooth',block:'nearest'});
  return tr;
}

function removeTransitionIndicator(){
  const el=document.getElementById('agentTransitionRow');
  if(el){el.style.transition='opacity .3s ease';el.style.opacity='0';setTimeout(()=>el.remove(),320);}
}

/* Render confidence score badge below the Complete badge */
function showConfidenceBadge(agentIndex){
  const conf=CONFIDENCE[agentIndex];
  if(!conf)return;
  const badge=document.getElementById('ab'+agentIndex);
  if(!badge)return;
  const score=conf.score;
  const isHigh=score===100;
  const isMed=score>=90&&score<100;
  const cls=isHigh?'confidence-high':isMed?'confidence-med':'confidence-low';
  const icon=isHigh?CHECK_SVG:WARN_SVG;
  const label=isHigh?`Confidence: ${score}%`:`Confidence: ${score}% &mdash;`;
  const noteHtml=conf.note?`<div class="confidence-note">&#9432; ${conf.note}</div>`:'';
  const wrap=document.createElement('div');
  wrap.className=`confidence-wrap ${cls}`;
  wrap.innerHTML=`<div class="confidence-icon">${icon}</div><div class="confidence-score-val">${label}</div>${noteHtml}`;
  badge.insertAdjacentElement('afterend',wrap);
  requestAnimationFrame(()=>requestAnimationFrame(()=>wrap.classList.add('show')));
}

const PT_STEPS=[
  {id:'pt0',label:'Orchestrator',type:'agent'},
  {id:'pt1',label:'ITT Intake',type:'agent'},
  {id:'pt2',label:'Content\nRetrieval',type:'agent'},
  {id:'pt3',label:'Gov Pack',type:'agent'},
  {id:'pt4',label:'Response\nDraft',type:'agent'},
  {id:'ptCP0',label:'CP0\nLead Reviews',type:'hitl'},
  {id:'ptCP1',label:'CP1\nDraft Review',type:'hitl'},
  {id:'ptCP2',label:'CP2\nGov Gate',type:'hitl'},
  {id:'pt5',label:'Compliance\nAgent',type:'agent'}
];

let isRunning=false,timerH=null,taskCount=0,doneCount=0;
let cp0Resolver=null,cp1Resolver=null,cp2Resolver=null,cp2BUApproved=false,cp2CommApproved=false;
let cp0Approvals={tech:false,hs:false,sustain:false,supplychain:false};
let cp0Rejections={tech:false,hs:false,sustain:false,supplychain:false};
let cp0FeedbackStore={tech:'',hs:'',sustain:'',supplychain:''};
let cp0RevisedContent={tech:null,hs:null,sustain:null,supplychain:null};
let cp0RetriggerCount={tech:0,hs:0,sustain:0,supplychain:0};
let cp0CurrentLeadIdx=null;
let workflowStartTime=null;
const approvalTimestamps={};

/* ═══════════════════════════════════════════
   CHECKPOINT 0 — LEAD SECTION REVIEW DATA
═══════════════════════════════════════════ */
const CP0_LEADS=[
  {
    id:'tech',
    name:'J. Harrison',
    initials:'JH',
    role:'Technical Lead',
    email:'j.harrison@gallifordtry.com',
    color:'#1976d2',
    gradient:'linear-gradient(135deg,#1976d2,#00c2e0)',
    sectionBadge:'Method Statement',
    sectionBadgeIcon:"<svg viewBox='0 0 24 24'><path d='M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z'/></svg>",
    previewText:'Technical methodology, UV system design approach, and commissioning sequence.',
    modalTitle:'Technical Method Statement — Section 3',
    modalContent:`
      <div class="cp0-review-section-title">
        <svg viewBox="0 0 24 24"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>
        Section 3 — Technical Methodology & Method Statement
      </div>
      <div class="cp0-review-body">
        <h4>3.1 Design Approach</h4>
        <p>Our proposed UV disinfection system is designed around the Trojan Technologies UV3000 Plus, selected for its validated performance at Grafham WTW's flow rates (up to 270 Ml/day). The system comprises four duty UV channels with one standby, providing N+1 redundancy throughout the disinfection process.</p>
        <h4>3.2 Installation Methodology</h4>
        <ul>
          <li>Phased installation sequenced to maintain continuous treated water output — no planned service interruption</li>
          <li>UV skid pre-commissioned off-site prior to delivery — reducing on-site programme risk</li>
          <li>Temporary bypass arrangement installed in Week 1, validated by flow modelling</li>
          <li>Sequential channel handover: Channels 1&amp;2 operational before Channels 3&amp;4 are isolated</li>
        </ul>
        <h4>3.3 Commissioning Sequence</h4>
        <ul>
          <li>Factory Acceptance Test (FAT): Week 6 &mdash; Trojan Technologies facility</li>
          <li>Site Acceptance Test (SAT): Week 14 &mdash; full flow validation at Grafham</li>
          <li>72-hour continuous performance test prior to handover</li>
          <li>Anglian Water operational team shadowing throughout commissioning</li>
        </ul>
        <h4>3.4 Technical Risk Mitigation</h4>
        <p>Primary technical risk identified: single-source UV supplier. Mitigation: Xylem (Wedeco) UV identified as qualified alternative with equivalent hydraulic performance. Detailed comparison provided in Appendix B.</p>
      </div>
    `
  },
  {
    id:'hs',
    name:'S. Patel',
    initials:'SP',
    role:'H&S Lead',
    email:'s.patel@gallifordtry.com',
    color:'#EC1B2E',
    gradient:'linear-gradient(135deg,#EC1B2E,#f5a623)',
    sectionBadge:'H&S Sections',
    sectionBadgeIcon:"<svg viewBox='0 0 24 24'><path d='M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z'/></svg>",
    previewText:'Health & Safety plan, risk assessments, and CDM compliance evidence.',
    modalTitle:'Health & Safety Plan — Section 5',
    modalContent:`
      <div class="cp0-review-section-title">
        <svg viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>
        Section 5 — Health &amp; Safety
      </div>
      <div class="cp0-review-body">
        <h4>5.1 H&S Management Framework</h4>
        <p>Galliford Try operates a certified ISO 45001:2018 Occupational Health &amp; Safety Management System (Cert. No. GB-45001-2024-GT). All works at Grafham WTW will be delivered under our established Project H&amp;S Plan, reviewed and approved by the Principal Designer at RIBA Stage 3.</p>
        <h4>5.2 Key Site Hazards &amp; Controls</h4>
        <ul>
          <li><strong>Working over/near water:</strong> Rescue plan, throw lines, and PPE in place at all times. Induction mandatory for all personnel</li>
          <li><strong>Confined space entry (UV channels):</strong> Permit-to-work system with gas monitoring, trained rescue team on standby</li>
          <li><strong>Electrical isolation (HV works):</strong> Approved isolation procedure, LOTO regime, Authorised Person appointed</li>
          <li><strong>Chemical handling (chlorine dosing):</strong> COSHH assessment completed, spill kit, PPE &amp; emergency shower provision</li>
        </ul>
        <h4>5.3 CDM 2015 Compliance</h4>
        <ul>
          <li>Principal Contractor duties accepted &mdash; Construction Phase Plan issued</li>
          <li>Pre-Construction Information received and reviewed</li>
          <li>Health &amp; Safety File to be maintained and handed over on completion</li>
        </ul>
        <h4>5.4 Performance Record</h4>
        <p>GT Water sector RIDDOR incidence rate: 0.08 per 100,000 hours worked (3-year rolling average). Zero RIDDOR reportable incidents on AMP7 Anglian Water framework to date.</p>
      </div>
    `
  },
  {
    id:'sustain',
    name:'L. Ahmed',
    initials:'LA',
    role:'Sustainability Lead',
    email:'l.ahmed@gallifordtry.com',
    color:'#00a886',
    gradient:'linear-gradient(135deg,#00a886,#00c2e0)',
    sectionBadge:'ESG Sections',
    sectionBadgeIcon:"<svg viewBox='0 0 24 24'><path d='M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2z'/><path d='M12 8v4l3 3'/></svg>",
    previewText:'Sustainability commitments, carbon reduction plan, and social value evidence.',
    modalTitle:'Sustainability & ESG — Section 6',
    modalContent:`
      <div class="cp0-review-section-title">
        <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>
        Section 6 — Sustainability &amp; ESG
      </div>
      <div class="cp0-review-body">
        <h4>6.1 Carbon Reduction Plan</h4>
        <p>This project is aligned to Galliford Try's Net Zero by 2030 pathway (Science Based Target initiative approved). Specific commitments for Grafham WTW UV Upgrade:</p>
        <ul>
          <li>Scope 1 &amp; 2 construction carbon: &lt;45 tCO₂e (vs. industry benchmark 78 tCO₂e)</li>
          <li>100% renewable electricity on site from Week 1 via REGOs-backed supply</li>
          <li>Electric plant for all small plant; HVO fuel for generators and large plant</li>
          <li>Embodied carbon of UV system: 12.4 tCO₂e — lowest of three options assessed</li>
        </ul>
        <h4>6.2 Social Value Commitments</h4>
        <ul>
          <li>2 apprenticeships created within Anglian Water's supply region</li>
          <li>Local supply chain spend: minimum 40% within 50-mile radius of Grafham</li>
          <li>100 STEM education volunteer hours via Cambridgeshire schools programme</li>
          <li>Social Value return: £0.38 per £1 contract value (measured via TOMS framework)</li>
        </ul>
        <h4>6.3 Biodiversity Net Gain</h4>
        <p>Site surveys confirmed no protected species or habitats within works zone. Biodiversity Net Gain: +2% (baseline maintained). Wildflower verge seeding proposed along access road as enhancement measure.</p>
        <h4>6.4 Waste &amp; Circular Economy</h4>
        <p>Existing UV equipment: 100% diverted from landfill. Steel components recycled via certified UK smelter. Target: &lt;2% waste to landfill for entire project.</p>
      </div>
    `
  },
  {
    id:'supplychain',
    name:'R. Chen',
    initials:'RC',
    role:'Supply Chain Lead',
    email:'r.chen@gallifordtry.com',
    color:'#7c5cfc',
    gradient:'linear-gradient(135deg,#7c5cfc,#EC1B2E)',
    sectionBadge:'Subcontractors',
    sectionBadgeIcon:"<svg viewBox='0 0 24 24'><path d='M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2'/><circle cx='9' cy='7' r='4'/><path d='M23 21v-2a4 4 0 0 0-3-3.87'/><path d='M16 3.13a4 4 0 0 1 0 7.75'/></svg>",
    previewText:'Subcontractor appointments, supply chain resilience, and procurement schedule.',
    modalTitle:'Supply Chain & Subcontractors — Section 4',
    modalContent:`
      <div class="cp0-review-section-title">
        <svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
        Section 4 — Supply Chain &amp; Subcontractor Details
      </div>
      <div class="cp0-review-body">
        <h4>4.1 Proposed Subcontractor Schedule</h4>
        <ul>
          <li><strong>UV Equipment Supply:</strong> Trojan Technologies (primary) | Xylem Wedeco (approved alternative)</li>
          <li><strong>Electrical &amp; Instrumentation:</strong> Clarkson Controls Ltd &mdash; AMP7 preferred supplier, ISO 9001 certified</li>
          <li><strong>Civil Works:</strong> Cambuilt Ltd &mdash; local Cambridgeshire contractor, Anglian Water approved</li>
          <li><strong>Mechanical Installation:</strong> Meridian Process Engineering &mdash; UV skid specialists</li>
        </ul>
        <h4>4.2 Supply Chain Resilience</h4>
        <p>Key risk: single-source UV supplier (Trojan Technologies). Mitigation actions:</p>
        <ul>
          <li>Xylem (Wedeco) UV confirmed as technically equivalent alternative &mdash; hydraulic model validated</li>
          <li>Lead time for Xylem equipment: 8 weeks vs. Trojan 6 weeks &mdash; programme impact assessed as manageable</li>
          <li>Formal back-to-back contracts with 12-week delivery guarantee from both suppliers</li>
        </ul>
        <h4>4.3 Procurement Programme</h4>
        <ul>
          <li>Week 1: UV supplier order placed (subject to CP0 approval)</li>
          <li>Week 2: E&amp;I and civil subcontracts executed</li>
          <li>Week 4: All long-lead items ordered and delivery confirmed</li>
          <li>Week 6: All subcontractors mobilised to site</li>
        </ul>
        <h4>4.4 Modern Slavery &amp; Compliance</h4>
        <p>All subcontractors vetted against GT Supply Chain Code of Conduct. Modern Slavery Act compliance confirmed. CHAS &amp; Constructionline Gold certification required as minimum for all appointed subcontractors.</p>
      </div>
    `
  }
];

/* ═══════════════════════════════════════════
   CHECKPOINT 0 — RENDER & LOGIC
═══════════════════════════════════════════ */

function renderCP0(){
  return new Promise(resolve=>{
    cp0Resolver=resolve;
    cp0Approvals={tech:false,hs:false,sustain:false,supplychain:false};
    const ptS=$('ptCP0');if(ptS)ptS.className='pt-step hitl-active';
    const cpRow=document.createElement('tr');
    cpRow.className='cp0-row hitl-row';
    cpRow.id='cp0Row';
        const leadCardsHtml=CP0_LEADS.map((lead,idx)=>`
      <div class="cp0-lead-card" id="cp0Card${idx}" style="--cp0-lead-color:${lead.color}">
        <div class="cp0-lead-hdr">
          <div class="cp0-lead-avatar" style="background:${lead.gradient}">${lead.initials}</div>
          <div>
            <div class="cp0-lead-name">${lead.name}</div>
            <div class="cp0-lead-role">${lead.role}</div>
          </div>
        </div>
        <div class="cp0-section-badge">${lead.sectionBadgeIcon}${lead.sectionBadge}</div>
        <div class="cp0-section-preview" id="cp0Preview${idx}">${lead.previewText}</div>
        <div class="cp0-lead-status status-pending" id="cp0Stat${idx}">
          <span style="width:6px;height:6px;border-radius:50%;background:currentColor;display:inline-block;"></span>&nbsp;Awaiting Review
        </div>
        <!-- Inline feedback note — shown after rejection -->
        <div class="cp0-feedback-note" id="cp0FeedbackNote${idx}"></div>
        <div class="cp0-lead-actions" id="cp0Actions${idx}">
          <button class="cp0-btn-review" id="cp0RevBtn${idx}" onclick="cp0OpenReview(${idx})">
            <svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>Review
          </button>
          <button class="cp0-btn-approve" id="cp0ApprBtn${idx}" onclick="cp0ApproveLead(${idx})">
            <svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>Approve
          </button>
          <button class="cp0-btn-reject" style="display:none;" id="cp0RejBtn${idx}" onclick="cp0OpenReview(${idx})">
            <svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>Reject
          </button>
        </div>
        <!-- Re-open review after rejection -->
        <button class="cp0-btn-reopen" id="cp0ReopenBtn${idx}" onclick="cp0OpenReview(${idx})">
          <svg viewBox="0 0 24 24"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-3.76"/></svg>Re-open &amp; Revise
        </button>
      </div>
    `).join('');
    cpRow.innerHTML=`<td colspan="3">
      <div class="cp0-inner">
        <div class="hitl-header">
          <div class="hitl-icon" style="background:rgba(0,194,224,.12)">
            <svg viewBox="0 0 24 24" stroke="#00c2e0"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
          </div>
          <div class="hitl-title-block">
            <div class="cp0-eyebrow">&#9654; Human-in-the-Loop &mdash; Multi-Lead Section Review</div>
            <div class="cp0-title">Checkpoint 0: Lead Approval Gate &mdash; Draft Section Sign-Off</div>
          </div>
          <div class="cp0-badge" id="cp0Badge"><span style="width:6px;height:6px;border-radius:50%;background:#00c2e0;display:inline-block;"></span>&nbsp;0 / 4 Leads Approved</div>
        </div>        
        <div class="hitl-desc cp0-desc">
          <div><strong>✔ Draft complete</strong> — The Response Drafting Agent has finalised the initial tender draft.</div>
          <div style="margin-top:6px;"><strong>⏳ Action required</strong> — Each specialist lead must review and approve their assigned section below.</div>
          <div style="margin-top:6px;"><strong>▶ Next step</strong> — Once all four approvals are recorded, the workflow will automatically progress to <strong>Checkpoint 1: Bid Manager Review</strong>.</div>
        </div>
        <div class="cp0-lead-grid">${leadCardsHtml}</div>
        <div class="cp0-allclear-banner" id="cp0AllClear">
          <svg viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
          All four leads have approved their sections &mdash; workflow is resuming to Checkpoint 1&hellip;
        </div>
      </div>
    </td>`;
    $('workflowBody').appendChild(cpRow);
    cpRow.scrollIntoView({behavior:'smooth',block:'center'});
  });
}

function cp0OpenReview(leadIdx){
    cp0CurrentLeadIdx=leadIdx;
  const lead=CP0_LEADS[leadIdx];
  /* Resolve revised content and retrigger count FIRST — used below */
  const revisedContent=cp0RevisedContent[lead.id];
  const retriggerCount=cp0RetriggerCount[lead.id]||0;

  $('cp0ReviewTitle').textContent=lead.modalTitle;
  /* Show revision badge in sub-header if agent has re-processed this section */
  if(retriggerCount>0){
    const sub=$('cp0ReviewSub');
    if(sub)sub.innerHTML='Checkpoint 0 &nbsp;&middot;&nbsp; '+lead.role+' Review &nbsp;&middot;&nbsp; AW-2025-IT-047 &nbsp;&middot;&nbsp; <span style="background:rgba(0,194,224,.1);color:#0c4a6e;border:1px solid rgba(0,194,224,.25);border-radius:999px;padding:1px 8px;font-size:10px;font-weight:700;">&#9654; Revision '+retriggerCount+'</span>';
  } else {
    $('cp0ReviewSub').textContent='Checkpoint 0 \u00b7 '+lead.role+' Review \u00b7 AW-2025-IT-047';
  }
  $('cp0ReviewIcon').style.background=`rgba(${hexToRgb(lead.color)},.15)`;
  $('cp0ReviewIcon').querySelector('svg').setAttribute('stroke',lead.color);
  /* Use revised content if agent has processed feedback, otherwise original */
  $('cp0ReviewBody').innerHTML=revisedContent||lead.modalContent;

  /* Reset feedback area for this opening */
  const feedbackText=$('cp0FeedbackText');
  const feedbackSubmitted=$('cp0FeedbackSubmitted');
  const charCount=$('cp0CharCount');
  if(feedbackText)feedbackText.value='';
  if(charCount)charCount.textContent='0';
  if(feedbackSubmitted)feedbackSubmitted.classList.remove('show');

  /* Pre-fill feedback if lead previously rejected with notes */
  const prevFeedback=cp0FeedbackStore[lead.id];
  if(prevFeedback&&feedbackText){feedbackText.value=prevFeedback;if(charCount)charCount.textContent=prevFeedback.length;}

  const alreadyApproved=cp0Approvals[lead.id];
  const alreadyRejected=cp0Rejections[lead.id];

  /* Approve button */
  const apprBtn=$('cp0ReviewApproveBtn');
  if(apprBtn)apprBtn.style.display=alreadyApproved?'none':'inline-flex';

  /* Reject button */
  const rejBtn=$('cp0ReviewRejectBtn');
  if(rejBtn)rejBtn.style.display=alreadyApproved?'none':'inline-flex';

  /* Footer note */
  const note=$('cp0ReviewFooterNote');
  if(note){
    if(alreadyApproved)note.textContent='\u2713 This section has already been approved by '+lead.name;
    else if(alreadyRejected)note.textContent='\u26A0 Previously rejected by '+lead.name+' \u2014 revise and re-submit or approve to clear.';
    else note.textContent='Review the section above, then approve or provide feedback.';
  }

  /* Feedback area — disable if already approved */
  const feedbackArea=$('cp0FeedbackArea');
  if(feedbackArea)feedbackArea.style.opacity=alreadyApproved?'.5':'';
  if(feedbackText)feedbackText.disabled=!!alreadyApproved;

  /* Toggle preview on card */
  const card=$('cp0Card'+leadIdx);
  if(card&&!card.classList.contains('preview-open'))card.classList.add('preview-open');
  openModal('cp0ReviewModal');
}

function cp0UpdateCharCount(){
  const ta=$('cp0FeedbackText');
  const cc=$('cp0CharCount');
  if(ta&&cc)cc.textContent=ta.value.length;
}

function cp0ReviewAndApprove(){
  if(cp0CurrentLeadIdx===null)return;
  /* Capture any feedback even on approval */
  const feedbackText=$('cp0FeedbackText');
  const feedback=feedbackText?feedbackText.value.trim():'';
  if(feedback){
    cp0FeedbackStore[CP0_LEADS[cp0CurrentLeadIdx].id]=feedback;
    /* Show submitted confirmation briefly */
    const submitted=$('cp0FeedbackSubmitted');
    const submittedText=$('cp0FeedbackSubmittedText');
    if(submitted&&submittedText){
      submittedText.textContent='Feedback noted and logged \u2014 approving section.';
      submitted.classList.add('show');
    }
  }
  closeModal('cp0ReviewModal');
  cp0ApproveLead(cp0CurrentLeadIdx,feedback);
}

function cp0ReviewAndReject(){
  if(cp0CurrentLeadIdx===null)return;
  const feedbackText=$('cp0FeedbackText');
  const feedback=feedbackText?feedbackText.value.trim():'';
  if(!feedback){
    /* Highlight textarea to prompt feedback */
    if(feedbackText){
      feedbackText.style.borderColor='var(--brand-red)';
      feedbackText.focus();
      feedbackText.placeholder='Please describe the required changes before rejecting...';
      setTimeout(()=>{if(feedbackText)feedbackText.style.borderColor='';},2000);
    }
    const note=$('cp0ReviewFooterNote');
    if(note){note.textContent='\u26A0 Please add feedback describing the required changes before rejecting.';note.style.color='var(--brand-red)';setTimeout(()=>{note.style.color='';},3000);}
    return;
  }
  /* Store feedback */
  cp0FeedbackStore[CP0_LEADS[cp0CurrentLeadIdx].id]=feedback;
  /* Show submitted confirmation */
  const submitted=$('cp0FeedbackSubmitted');
  const submittedText=$('cp0FeedbackSubmittedText');
  if(submitted&&submittedText){
    submittedText.textContent='\u26A0 Changes requested \u2014 flagged to bid team and logged to Agent Trace.';
    submitted.classList.add('show');
  }
  const leadIdx=cp0CurrentLeadIdx;
  setTimeout(()=>{
    closeModal('cp0ReviewModal');
    cp0RejectLead(leadIdx,feedback);
  },900);
}

function cp0ApproveLead(leadIdx,feedbackNote=''){
  const lead=CP0_LEADS[leadIdx];
  if(cp0Approvals[lead.id])return;
  const t=ts();
  /* Clear any previous rejection */
  cp0Rejections[lead.id]=false;
  cp0Approvals[lead.id]=true;
  approvalTimestamps['cp0_'+lead.id]=t;
  /* Update card UI */
  const card=$('cp0Card'+leadIdx);
  if(card){card.classList.remove('cp0-rejected');card.classList.add('cp0-approved');}
  const stat=$('cp0Stat'+leadIdx);
  if(stat){
    stat.className='cp0-lead-status status-approved';
    stat.innerHTML=`<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>&nbsp;Approved &mdash; ${t}`;
  }
  /* Show feedback note on card if feedback was provided */
  if(feedbackNote){
    const noteEl=$('cp0FeedbackNote'+leadIdx);
    if(noteEl){noteEl.innerHTML=`<strong>Note:</strong> ${feedbackNote}`;noteEl.classList.add('show');}
  }
  /* Disable action buttons */
  const revBtn=$('cp0RevBtn'+leadIdx);if(revBtn)revBtn.disabled=true;
  const apprBtn=$('cp0ApprBtn'+leadIdx);if(apprBtn)apprBtn.disabled=true;
  const rejBtn=$('cp0RejBtn'+leadIdx);if(rejBtn)rejBtn.disabled=true;
  const reopenBtn=$('cp0ReopenBtn'+leadIdx);if(reopenBtn)reopenBtn.classList.remove('show');
  /* Log to Agent Trace */
  updateTraceCP0(lead,t,'Approved',feedbackNote);
  /* Update progress */
  const approved=Object.values(cp0Approvals).filter(Boolean).length;
  const pct=(approved/4)*100;
  const fill=$('cp0ProgressFill');if(fill)fill.style.width=pct+'%';
  const lbl=$('cp0ProgressLabel');if(lbl)lbl.textContent=approved+' of 4 approved';
  const badge=$('cp0Badge');
  if(badge){
    badge.innerHTML=`<span style="width:6px;height:6px;border-radius:50%;background:${approved===4?'#00a886':'#00c2e0'};display:inline-block;"></span>&nbsp;${approved} / 4 Leads Approved`;
    if(approved===4){
      badge.style.background='rgba(0,168,134,.12)';
      badge.style.color='#155724';
      badge.style.borderColor='rgba(0,168,134,.28)';
    }
  }
  if(approved===4)cp0AllApproved();
}

function cp0RejectLead(leadIdx,feedback){
  const lead=CP0_LEADS[leadIdx];
  if(cp0Approvals[lead.id])return;
  const t=ts();
  cp0Rejections[lead.id]=true;
  cp0RetriggerCount[lead.id]=(cp0RetriggerCount[lead.id]||0)+1;
  approvalTimestamps['cp0_rej_'+lead.id]=t;
  /* Update card UI to rejected state */
  const card=$('cp0Card'+leadIdx);
  if(card){card.classList.remove('cp0-approved','cp0-awaiting-recheck');card.classList.add('cp0-rejected');}
  const stat=$('cp0Stat'+leadIdx);
  if(stat){
    stat.className='cp0-lead-status status-rejected';
    stat.innerHTML=`<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>&nbsp;Changes Requested &mdash; Drafting Agent retriggered`;
  }
  /* Show feedback note */
  const noteEl=$('cp0FeedbackNote'+leadIdx);
  if(noteEl){noteEl.innerHTML=`<strong>\u26A0 Retriggering agent:</strong> &ldquo;${feedback}&rdquo;`;noteEl.classList.add('show');}
  /* Disable all buttons while agent processes */
  [$('cp0RevBtn'+leadIdx),$('cp0ApprBtn'+leadIdx),$('cp0RejBtn'+leadIdx),$('cp0ReopenBtn'+leadIdx)].forEach(b=>{if(b){b.disabled=true;b.classList.remove('show');}});
  /* Log rejection to Agent Trace */
  updateTraceCP0(lead,t,'Changes Requested',feedback);
  /* Update CP0 badge */
  const badge=$('cp0Badge');
  if(badge){
    const approvedCount=Object.values(cp0Approvals).filter(Boolean).length;
    const rejectedCount=Object.values(cp0Rejections).filter(Boolean).length;
    badge.innerHTML=`<span style="width:6px;height:6px;border-radius:50%;background:#f5a623;display:inline-block;animation:pulseDot 1s ease-in-out infinite;"></span>&nbsp;${approvedCount} Approved &nbsp;|&nbsp; Agent Retriggered`;
    badge.style.background='rgba(245,166,35,.1)';
    badge.style.color='#856404';
    badge.style.borderColor='rgba(245,166,35,.28)';
  }
  /* FIRE THE RDA RETRIGGER — async, non-blocking */
  cp0TriggerRdaRetrigger(leadIdx,feedback);
}

/* ═══════════════════════════════════════════════════════════
   CP0 → RDA FEEDBACK RETRIGGER ENGINE
   Called from cp0RejectLead — runs inline inside CP0 row
═══════════════════════════════════════════════════════════ */

/* NLP steps tailored per intent for CP0 retrigger display */
const CP0_RDA_STEPS={
  remove:[
    'Parsing instruction: section removal detected…',
    'Locating target section in current draft…',
    'Validating removal against ITT mandatory requirements…',
    'Regenerating document without target section…',
    'Updating cross-references and section numbering…',
    'Revised draft ready — section removed cleanly'
  ],
  rephrase:[
    'Parsing instruction: rephrase/refine detected…',
    'Loading target passage into NLP refinement engine…',
    'Applying tone, conciseness and emphasis constraints…',
    'Validating revised passage against evaluation criteria…',
    'Integrating refined content into document…',
    'Revised draft ready — passage updated'
  ],
  add:[
    'Parsing instruction: content addition detected…',
    'Identifying insertion point and section context…',
    'Retrieving relevant content from bid library…',
    'Generating and aligning new content to ITT criteria…',
    'Inserting content and updating cross-references…',
    'Revised draft ready — new content integrated'
  ],
  reorder:[
    'Parsing instruction: structural reorder detected…',
    'Mapping current document section sequence…',
    'Computing coherent reorder sequence…',
    'Validating narrative flow after restructure…',
    'Updating all section numbering and references…',
    'Revised draft ready — structure updated'
  ],
  custom:[
    'Parsing natural language instruction…',
    'Decomposing into discrete edit operations…',
    'Applying instruction with context-aware NLP engine…',
    'Re-running full criteria alignment pass…',
    'Validating document coherence…',
    'Revised draft ready — changes applied'
  ]
};

/* Generate revised section content using DOM parsing — reliable section targeting */
function cp0ApplyFeedbackToContent(originalContent, intent, feedback, lead){
  /* Parse original HTML into a real DOM for reliable manipulation */
  const parser=new DOMParser();
  const doc=parser.parseFromString('<div id="root">'+originalContent+'</div>','text/html');
  const root=doc.getElementById('root');

  /* Revised badge always prepended */
  const badge=doc.createElement('div');
  badge.className='cp0-revised-badge';

  /* Extract section number from feedback e.g. "3.3", "3", "5.2" */
  const secMatch=feedback.match(/(?:section|sec)[\s.]+([\d]+(?:\.[\d]+)?)/i)
    || feedback.match(/([\d]+\.[\d]+)/)
    || feedback.match(/([\d]+)/i);
  const secRef=secMatch?secMatch[1].trim():null;

  /* ── REMOVE ── */
  if(intent.type==='remove'){
    badge.innerHTML=`<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' style='width:12px;height:12px;'><polyline points='20 6 9 17 4 12'/></svg>Revised by Response Drafting Agent &mdash; Section ${secRef||'specified'} removed per ${lead.role} feedback`;
    if(secRef){
      /* Find all h4 elements whose text starts with the section number */
      const allH4=root.querySelectorAll('h4');
      allH4.forEach(h4=>{
        const h4Text=h4.textContent.trim();
        /* Match e.g. "3.3" at start of h4 text */
        if(h4Text.startsWith(secRef)){
          /* Collect this h4 + all following siblings until next h4 */
          const toRemove=[h4];
          let sib=h4.nextElementSibling;
          while(sib&&sib.tagName!=='H4'){
            toRemove.push(sib);
            sib=sib.nextElementSibling;
          }
          /* Replace with visual diff marker */
          const diffWrap=doc.createElement('div');
          diffWrap.className='cp0-diff-removed';
          diffWrap.innerHTML=`&#9660; Section ${secRef}: ${h4Text.replace(secRef,'').trim()} &mdash; <em>removed as instructed by ${lead.role}</em>`;
          const addedWrap=doc.createElement('div');
          addedWrap.className='cp0-diff-added';
          addedWrap.innerHTML=`&#9656; Section ${secRef} has been removed from this draft. Remaining sections have been renumbered accordingly.`;
          h4.parentNode.insertBefore(diffWrap,h4);
          h4.parentNode.insertBefore(addedWrap,h4);
          toRemove.forEach(el=>el.remove());
        }
      });
    }
    root.insertBefore(badge,root.firstChild);
    return root.innerHTML;
  }

  /* ── REPHRASE ── */
  if(intent.type==='rephrase'){
    badge.innerHTML=`<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' style='width:12px;height:12px;'><polyline points='20 6 9 17 4 12'/></svg>Revised by Response Drafting Agent &mdash; Content rephrased per ${lead.role} feedback`;
    /* Find first <p> in .cp0-review-body and mark as modified */
    const body=root.querySelector('.cp0-review-body');
    if(body){
      const firstP=body.querySelector('p');
      if(firstP){
        const original=firstP.textContent;
        const removedSpan=doc.createElement('span');
        removedSpan.className='cp0-diff-removed';
        removedSpan.textContent=original;
        const addedSpan=doc.createElement('div');
        addedSpan.className='cp0-diff-modified';
        addedSpan.innerHTML=`&#9656; [Rephrased] ${rdaGetRephrasedText(feedback,original,lead)}`;
        firstP.parentNode.insertBefore(removedSpan,firstP);
        firstP.parentNode.insertBefore(addedSpan,firstP);
        firstP.remove();
      }
    }
    root.insertBefore(badge,root.firstChild);
    return root.innerHTML;
  }

  /* ── ADD ── */
  if(intent.type==='add'){
    badge.innerHTML=`<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' style='width:12px;height:12px;'><polyline points='20 6 9 17 4 12'/></svg>Revised by Response Drafting Agent &mdash; New content added per ${lead.role} feedback`;
    const body=root.querySelector('.cp0-review-body');
    if(body&&secRef){
      const allH4=body.querySelectorAll('h4');
      let insertAfter=null;
      allH4.forEach(h4=>{
        if(h4.textContent.trim().startsWith(secRef))insertAfter=h4;
      });
      /* Find last sibling of that h4 (the list or paragraph) */
      if(insertAfter){
        let lastSib=insertAfter.nextElementSibling;
        while(lastSib&&lastSib.nextElementSibling&&lastSib.nextElementSibling.tagName!=='H4'){
          lastSib=lastSib.nextElementSibling;
        }
        const addedDiv=doc.createElement('div');
        addedDiv.className='cp0-diff-added';
        addedDiv.innerHTML=`&#9656; [Added by Agent] ${rdaGetAddedParagraph(feedback,lead)}`;
        const ref=lastSib?lastSib.nextSibling:insertAfter.nextSibling;
        body.insertBefore(addedDiv,ref);
      } else {
        /* Append at end of body */
        const addedDiv=doc.createElement('div');
        addedDiv.className='cp0-diff-added';
        addedDiv.innerHTML=`&#9656; [Added by Agent] ${rdaGetAddedParagraph(feedback,lead)}`;
        body.appendChild(addedDiv);
      }
    }
    root.insertBefore(badge,root.firstChild);
    return root.innerHTML;
  }

  /* ── DEFAULT / CUSTOM ── */
  badge.innerHTML=`<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2' stroke-linecap='round' stroke-linejoin='round' style='width:12px;height:12px;'><polyline points='20 6 9 17 4 12'/></svg>Revised by Response Drafting Agent &mdash; Custom edits applied per ${lead.role} feedback`;
  const customNote=doc.createElement('div');
  customNote.className='cp0-diff-modified';
  customNote.style.marginBottom='10px';
  customNote.innerHTML=`&#9656; Agent processed instruction: &ldquo;${feedback}&rdquo; &mdash; changes applied to this section.`;
  root.insertBefore(customNote,root.firstChild);
  root.insertBefore(badge,root.firstChild);
  return root.innerHTML;
}

function rdaGetRephrasedText(feedback,original,lead){
  if(/concise|shorten|brief/i.test(feedback))
    return 'Updated version — refined for conciseness and clarity by the drafting agent. Key points retained; verbose phrasing removed as instructed by '+lead.role+'.';
  if(/cost|saving|value/i.test(feedback))
    return 'Updated version — cost savings and value delivery emphasised upfront as instructed by '+lead.role+'. Original technical detail preserved in subsequent paragraphs.';
  if(/formal|professional/i.test(feedback))
    return 'Updated version — tone elevated to formal register as instructed by '+lead.role+'. Content aligned to evaluation criteria.';
  return 'Updated version — rephrased by drafting agent per '+lead.role+' instruction. Narrative improved while maintaining full ITT alignment.';
}

function rdaGetAddedParagraph(feedback, lead){
  if(/sustain/i.test(feedback)||/esg/i.test(feedback))
    return 'Galliford Try is committed to delivering net-zero construction for this project. Our sustainability framework includes 100% renewable electricity on site, HVO fuel for all plant, and a minimum 40% local supply chain spend — delivering £0.38 social value per £1 of contract value.';
  if(/health|safety|h.?s/i.test(feedback))
    return 'All works will be delivered under our ISO 45001:2018 certified H&S Management System. A dedicated Safety Officer will be present on site throughout the programme, with weekly safety walks and mandatory near-miss reporting.';
  if(/commerc|cost|price|financ/i.test(feedback))
    return 'Our commercial model delivers a fixed-price solution with CPI-linked annual adjustments capped at 3%. Payment milestones are tied to verified delivery stage-gates, eliminating client exposure to cost overruns.';
  return 'This section has been updated to reflect the latest project requirements and stakeholder feedback, ensuring full alignment with the ITT evaluation criteria.';
}

/* Main CP0 RDA retrigger — called after cp0RejectLead */
async function cp0TriggerRdaRetrigger(leadIdx, feedback){
  const lead=CP0_LEADS[leadIdx];
  const intent=rdaClassifyIntent(feedback);

  /* Remove any existing retrigger row */
  const existingRtRow=document.getElementById('cp0RdaRetriggerRow');
  if(existingRtRow){existingRtRow.style.opacity='0';await sleep(250);existingRtRow.remove();}

  /* Build and inject retrigger row inside CP0 inner div */
  const steps=CP0_RDA_STEPS[intent.type]||CP0_RDA_STEPS.custom;
  const stepsHtml=steps.map((_,i)=>
    `<div class="cp0-rda-step" id="cp0RdaStep${leadIdx}_${i}">`+
    `<div class="cp0-rda-step-icon" id="cp0RdaStepIcon${leadIdx}_${i}"></div>`+
    `<span>${_}</span></div>`
  ).join('');

  const intentColors={remove:'background:#fee2e2;color:#7f1d1d;',rephrase:'background:#ede9fe;color:#5b21b6;',add:'background:#d4edda;color:#155724;',reorder:'background:#dbeafe;color:#0c4a6e;',custom:'background:var(--surface-3);color:#37474f;'};
  const intentStyle=intentColors[intent.type]||intentColors.custom;

  const rtDiv=document.createElement('div');
  rtDiv.className='cp0-rda-retrigger-row';
  rtDiv.id='cp0RdaRetriggerRow';
  rtDiv.innerHTML=`<div class="cp0-rda-retrigger-inner">
    <div class="cp0-rda-retrigger-hdr">
      <div class="cp0-rda-spinner"></div>
      <div>
        <div class="cp0-rda-retrigger-title">Response Drafting Agent &mdash; Re-triggered by ${lead.role}</div>
        <div class="cp0-rda-retrigger-sub">Processing: &ldquo;${feedback}&rdquo;</div>
      </div>
      <span class="cp0-rda-intent-badge" style="${intentStyle}">${intent.icon} ${intent.label}</span>
    </div>
    <div class="cp0-rda-steps">${stepsHtml}</div>
    <div class="cp0-rda-done-banner" id="cp0RdaDoneBanner">
      <svg viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
      <span id="cp0RdaDoneText">Revised draft ready &mdash; re-presenting to ${lead.role} for review</span>
    </div>
  </div>`;

  /* Append inside the CP0 inner div (after lead grid) */
  const cp0Inner=document.querySelector('#cp0Row .cp0-inner');
  if(cp0Inner) cp0Inner.appendChild(rtDiv);
  rtDiv.scrollIntoView({behavior:'smooth',block:'nearest'});

  /* Animate NLP steps */
  for(let s=0;s<steps.length;s++){
    const stepEl=document.getElementById(`cp0RdaStep${leadIdx}_${s}`);
    const iconEl=document.getElementById(`cp0RdaStepIcon${leadIdx}_${s}`);
    if(stepEl){stepEl.classList.add('visible','processing');}
    if(iconEl)iconEl.classList.add('processing');
    await sleep(600);
    if(stepEl){stepEl.classList.remove('processing');stepEl.classList.add('done');}
    if(iconEl){iconEl.classList.remove('processing');iconEl.classList.add('done');iconEl.textContent='✓';}
  }

  /* Stop spinner */
  const spinner=rtDiv.querySelector('.cp0-rda-spinner');
  if(spinner){spinner.style.animation='none';spinner.style.borderColor='rgba(0,168,134,.3)';spinner.style.borderTopColor='#00a886';}

  /* Show done banner */
  await sleep(300);
  const doneBanner=document.getElementById('cp0RdaDoneBanner');
  if(doneBanner)doneBanner.classList.add('show');
  await sleep(600);

  /* Apply NLP diff to section content in cp0FeedbackStore for this lead */
  cp0RevisedContent[lead.id]=cp0ApplyFeedbackToContent(lead.modalContent, intent, feedback, lead);
  cp0Rejections[lead.id]=false; /* Reset rejection so lead can re-review */

  /* Update lead card to "awaiting re-check" */
  const card=$('cp0Card'+leadIdx);
  if(card){card.classList.remove('cp0-rejected');card.classList.add('cp0-awaiting-recheck');}
  const stat=$('cp0Stat'+leadIdx);
  if(stat){
    stat.className='cp0-lead-status status-revised';
    stat.innerHTML=`<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-3.76"/></svg>&nbsp;Revised &mdash; Re-review Required`;
  }

  /* Re-enable approve/reject buttons for this lead */
  const apprBtn=$('cp0ApprBtn'+leadIdx);if(apprBtn)apprBtn.disabled=false;
  const rejBtn=$('cp0RejBtn'+leadIdx);if(rejBtn)rejBtn.disabled=false;
  const reopenBtn=$('cp0ReopenBtn'+leadIdx);if(reopenBtn)reopenBtn.classList.remove('show');

  /* Update feedback note on card */
  const noteEl=$('cp0FeedbackNote'+leadIdx);
  if(noteEl){
    noteEl.innerHTML=`<strong>&#9654; Revised:</strong> Agent processed &ldquo;${feedback}&rdquo; &mdash; please re-review`;
  }

  /* Pulse the review button to draw attention */
  const revBtn=$('cp0RevBtn'+leadIdx);
  if(revBtn){
    revBtn.style.borderColor='var(--cyan)';
    revBtn.style.background='rgba(0,194,224,.1)';
    revBtn.style.color='#0c4a6e';
    revBtn.innerHTML=`<svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>Re-review &#9656;`;
    revBtn.disabled=false;
  }

  /* Log retrigger to trace */
  rdaLogToTrace(feedback,intent);
}

function cp0AllApproved(){
  const t=ts();
  approvalTimestamps.cp0All=t;
  const banner=$('cp0AllClear');if(banner)banner.classList.add('show');
  const ptS=$('ptCP0');if(ptS)ptS.className='pt-step hitl-done';
  const inner=document.querySelector('#cp0Row .cp0-inner');
  if(inner)inner.style.borderLeftColor='var(--emerald)';
  /* Update trace HitL badge counter */
  const approved=parseInt(($('traceApprovals').textContent||'0/2').split('/')[0])+1;
  // CP0 counts separately — update summary KPI
  const kpiEl=$('traceApprovals');
  if(kpiEl)kpiEl.textContent=approved+'/2';
  setTimeout(()=>{cp0Resolver&&cp0Resolver();},1800);
}

function updateTraceCP0(lead,time,action,feedback){
  /* Add/update a row in the traceHitlLog hidden table */
  const tbody=$('traceHitlLog');
  if(tbody){
    /* Remove existing row for this lead if present (e.g. reject then approve) */
    const existingRow=document.getElementById('trace-cp0-row-'+lead.id);
    if(existingRow)existingRow.remove();
    const isApproved=(action==='Approved');
    const tr=document.createElement('tr');
    tr.id='trace-cp0-row-'+lead.id;
    const pillClass=isApproved?'trace-pill-green':'trace-pill-amber';
    const noteCell=feedback?feedback:'\u2014';
    tr.innerHTML=`<td>CP0 &mdash; Lead Review</td><td>${lead.role}</td><td>${lead.email}</td><td><span class="trace-pill ${pillClass}">${action}</span></td><td>${time}</td><td>${lead.name} &mdash; ${lead.sectionBadge}${feedback?' | '+feedback:''}</td>`;
    tbody.appendChild(tr);
  }
  /* Update / add visible gate card in trace modal Human Gates tab */
  const gateList=document.querySelector('.hitl-gate-list');
  if(gateList){
    const existingId='hgc-cp0-'+lead.id;
    const existing=document.getElementById(existingId);
    const isApproved=(action==='Approved');
    const cardClass=isApproved?'hgc-approved':'hgc-awaiting';
    const pillClass=isApproved?'trace-pill-green':'trace-pill-amber';
    const html=`<div class="hitl-gate-header">
      <div class="hgc-gate-label" style="background:rgba(0,194,224,.1);color:#0c4a6e;border-color:rgba(0,194,224,.25);">CP0 &mdash; Lead Review</div>
      <div class="hgc-info">
        <div class="hgc-name">${lead.name} &mdash; ${lead.role}</div>
        <div class="hgc-role">Section: ${lead.sectionBadge}${feedback?' &nbsp;&middot;&nbsp; <em>'+feedback+'</em>':''}</div>
      </div>
      <span class="hgc-action-pill trace-pill ${pillClass}">${action}</span>
      <span style="font-size:11px;color:#9eadba;">${time}</span>
    </div>`;
    if(existing){
      existing.className='hitl-gate-card '+cardClass;
      existing.innerHTML=html;
    } else {
      const div=document.createElement('div');
      div.className='hitl-gate-card '+cardClass;
      div.id=existingId;
      div.innerHTML=html;
      gateList.insertBefore(div,gateList.firstChild);
    }
  }
}

/* Utility: hex colour to rgb for rgba() */
function hexToRgb(hex){
  const r=parseInt(hex.slice(1,3),16);
  const g=parseInt(hex.slice(3,5),16);
  const b=parseInt(hex.slice(5,7),16);
  return `${r},${g},${b}`;
}

const $=id=>document.getElementById(id);
const kT=$('kpiTasks'),kD=$('kpiDone'),kTime=$('kpiTime');
function sleep(ms){return new Promise(r=>setTimeout(r,ms));}

window.addEventListener('scroll',()=>{$('trsHeader').classList.toggle('elevated',window.scrollY>8);},{passive:true});

function countUp(el,to,ms=500){
  const from=parseInt(el.textContent)||0,t0=performance.now();
  (function tick(now){const p=Math.min((now-t0)/ms,1);el.textContent=Math.round(from+(to-from)*(1-Math.pow(1-p,3)));if(p<1)requestAnimationFrame(tick);})(performance.now());
}

function startClock(){
  workflowStartTime=Date.now();
  timerH=setInterval(()=>{const s=Math.floor((Date.now()-workflowStartTime)/1000);kTime.textContent=s<60?s+'s':Math.floor(s/60)+'m '+(s%60)+'s';},1000);
}
function stopClock(){clearInterval(timerH);}
function ts(){return new Date().toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit',second:'2-digit'});}

function buildHeroCard(){
  $('hcRows').innerHTML=AGENTS.map((a,i)=>{
    const m=META[i];
    return `<div class="hc-row" id="hcRow${i}"><div class="hc-dot" id="hcDot${i}" style="background:${m.color};opacity:.28"></div><div class="hc-agent-name">${a.AGENT_NAME.replace(/ agent$/i,'')}</div><div class="hc-stat" id="hcSt${i}" style="color:${m.color};opacity:.35">&#8212;</div></div>`;
  }).join('');
}

function buildTimeline(){
  $('ptInner').innerHTML=PT_STEPS.map(s=>{
    const isHitl=s.type==='hitl';
    const badge=isHitl?'<div class="pt-hitl-badge">&#9654; HitL</div>':'';
    const label=s.label.replace('\n','<br>');
    return `<div class="pt-step" id="${s.id}"><div class="pt-dot-wrap"><div class="pt-dot" style="${isHitl?'border-color:rgba(245,166,35,.3)':''}"><svg viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,.2)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg></div></div><div class="pt-label">${label}</div>${badge}</div>`;
  }).join('');
}

async function renderAgent(i){
  const ag=AGENTS[i],m=META[i];
  const ptS=$('pt'+i);if(ptS)ptS.className='pt-step active';
  const hcD=$('hcDot'+i),hcS=$('hcSt'+i);
  if(hcD){hcD.style.opacity='1';hcD.classList.add('live');}
  if(hcS){hcS.textContent='Active';hcS.style.opacity='1';}
  const row=document.createElement('tr');row.className='wf-row is-active';
  const iconSvg=(ICONS[m.icon]||ICONS.orchestrator).replace('<svg',`<svg stroke="${m.color}"`);
  row.innerHTML=`<td class="agent-col"><div class="agent-hdr"><div class="agent-icon-wrap" style="background:${m.bg}">${iconSvg}</div><div class="agent-name-t">${ag.AGENT_NAME}</div></div><div class="agent-desc-t" id="ad${i}" style="opacity:0;transition:opacity .45s ease"></div><div class="agent-badge badge-live" id="ab${i}"><span class="badge-dot"></span> Processing</div></td><td class="tasks-col"><ul class="col-list" id="tl${i}"></ul></td><td class="tools-col"><ul class="col-list" id="ol${i}"></ul></td>`;
  $('workflowBody').appendChild(row);await sleep(400);
  const descEl=$('ad'+i);if(descEl){descEl.textContent=ag.AGENT_DESCRIPTION;requestAnimationFrame(()=>requestAnimationFrame(()=>{descEl.style.opacity='1';}));}
  await sleep(300);
  const taskUl=$('tl'+i);
  for(const t of ag.TASKS){const li=document.createElement('li');li.className='col-item';li.innerHTML=`<div class="item-icon ti">${TASK_SVG}</div><span>${t}</span>`;taskUl.appendChild(li);await sleep(20);requestAnimationFrame(()=>li.classList.add('on'));taskCount++;countUp(kT,taskCount,280);await sleep(900);}
  const toolUl=$('ol'+i);
  for(const tool of ag.TOOLS_USED){const li=document.createElement('li');li.className='col-item';li.innerHTML=`<div class="item-icon oi">${TOOL_SVG}</div><span>${tool}</span>`;toolUl.appendChild(li);await sleep(20);requestAnimationFrame(()=>li.classList.add('on'));await sleep(300);}
  if(ag.BUSINESS_OUTCOMES&&ag.BUSINESS_OUTCOMES.length){
    const outcomeWrap=document.createElement('div');
    outcomeWrap.className='biz-outcome-wrap';
    outcomeWrap.style.opacity='0';
    outcomeWrap.style.transition='opacity .55s ease';
    /* Build outcome items — agent 1 gets clickable items linked to specific tabs */
    const outcomeItems=ag.BUSINESS_OUTCOMES.map((o,oi)=>{
      if(i===1){
        const tabTarget=oi===0?'brief':'risk';
        return `<li class="biz-outcome-item clickable" onclick="openAgentInspectTab(${i},'${tabTarget}')" title="Click to view ${oi===0?'Tender Summary Brief':'Risk & Clarification Log'}">`+
          `<div class="biz-outcome-dot"></div>`+
          `<span>${o}</span>`+
          `<span class="biz-outcome-launch"><svg viewBox="0 0 24 24"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/></svg>View</span>`+
          `</li>`;
      }
      return `<li class="biz-outcome-item"><div class="biz-outcome-dot"></div><span>${o}</span></li>`;
    }).join('');
    outcomeWrap.innerHTML=`<div class="biz-outcome-hdr"><div class="biz-outcome-icon">${OUTCOME_SVG}</div><span class="biz-outcome-title">Business Outcomes</span></div><ul class="biz-outcome-list">${outcomeItems}</ul>`;
    toolUl.closest('td').appendChild(outcomeWrap);
    await sleep(300);
    requestAnimationFrame(()=>requestAnimationFrame(()=>{outcomeWrap.style.opacity='1';}));
  }
  await sleep(800);
  row.classList.replace('is-active','is-done');
  const badge=$('ab'+i);if(badge){badge.className='agent-badge badge-done';badge.innerHTML=`<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="#00c9a0" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg> Complete`;}
  if(ptS)ptS.className='pt-step done';
  if(hcD)hcD.classList.remove('live');
  if(hcS)hcS.textContent='\u2713 Done';
  doneCount++;countUp(kD,doneCount,350);
  /* Update agent execution card pill in enhanced trace modal */
  const aecPill=document.getElementById('aec-pill-'+i);
  if(aecPill){aecPill.className='trace-pill trace-pill-green';aecPill.textContent='Complete';}
}

function renderCP1(){
  return new Promise(resolve=>{
    cp1Resolver=resolve;
    const ptS=$('ptCP1');if(ptS)ptS.className='pt-step hitl-active';
    const cpRow=document.createElement('tr');cpRow.className='hitl-row';cpRow.id='cp1Row';
    cpRow.innerHTML=`<td colspan="3"><div class="hitl-inner"><div class="hitl-header"><div class="hitl-icon"><svg viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg></div><div class="hitl-title-block"><div class="hitl-eyebrow">&#9654; Human-in-the-Loop &mdash; Mandatory Pause</div><div class="hitl-title">Checkpoint 1: Draft Review Gate</div></div><div class="hitl-badge"><span style="width:6px;height:6px;border-radius:50%;background:#f5a623;display:inline-block;"></span>&nbsp;Awaiting Bid Manager Approval</div></div><div class="hitl-desc">
  <div><strong>✔ Draft ready</strong> — The Response Drafting Agent has completed Draft v1.0 and prepared the submission for review.</div>
  <div style="margin-top:6px;"><strong>⏸ Workflow paused</strong> — This is a mandatory decision checkpoint requiring Bid Manager sign-off.</div>
  <div style="margin-top:6px;"><strong>⏳ Action required</strong> — Review the full draft, record any feedback, then approve or request revisions below.</div>
  <div style="margin-top:6px;"><strong>▶ Next step</strong> — Upon approval, the workflow will automatically advance to the <strong>CheckPoint 2</strong>.</div>
</div><div class="hitl-grid"><div class="hitl-info-card"><div class="hitl-info-label">Required Approver</div><div class="hitl-info-val">Bid Manager &mdash; bm.jones@company.com</div></div><div class="hitl-info-card"><div class="hitl-info-label">Document Ready</div><div class="hitl-info-val">Draft v1.0 &mdash; AW-2025-IT-047</div></div><div class="hitl-info-card"><div class="hitl-info-label">Triggered At</div><div class="hitl-info-val" id="cp1Time"></div></div><div class="hitl-info-card"><div class="hitl-info-label">Next Step on Approval</div><div class="hitl-info-val">Governance & Compliance Agent activates</div></div></div><div class="hitl-actions"><button class="hitl-btn hitl-btn-view" onclick="openTenderModal()"><svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>Review Draft</button><button class="hitl-btn hitl-btn-retrigger" style="display:none"onclick="cp1Retrigger()"><svg viewBox="0 0 24 24"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-3.76"/></svg>Re-trigger Drafting</button><button class="hitl-btn" style="background:rgba(245,166,35,.1);color:#856404;border:1px solid rgba(245,166,35,.3);" onclick="cp1OpenGovPackAndApprove()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>Review Governance Pack</button><button class="hitl-btn hitl-btn-approve" id="cp1ApproveBtn" onclick="cp1Approve()"><svg viewBox="0 0 24 24"><polyline points="20 6 9 17 4 12"/></svg>Approve & Proceed</button><button class="hitl-btn hitl-btn-reject" style="display:none;" id="cp1RejectBtn" onclick="cp1Reject()"><svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>Reject & Revise</button></div><div class="hitl-notes-wrap open" id="cp1NotesWrap"><div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:5px;margin-top:10px;"><span style="font-size:11px;font-weight:600;color:var(--text-muted);text-transform:uppercase;letter-spacing:.4px;">Reviewer Notes &amp; Feedback (logged to Agent Trace)</span><span style="font-size:10px;color:#9eadba;" id="cp1NlpHint"></span></div><textarea class="hitl-notes" id="cp1Notes" placeholder="Enter review comments, required changes, or approval rationale... e.g. Remove Section 3.3 &bull; Rephrase the introduction &bull; Add sustainability detail" oninput="cp1OnNotesInput(this)" maxlength="600"></textarea><div style="display:flex;align-items:center;justify-content:space-between;margin-top:6px;gap:8px;"><span style="font-size:10px;color:#9eadba;flex:1;" id="cp1IntentStrip"></span><span style="font-size:10px;color:#9eadba;"><span id="cp1CharCount">0</span>/600</span><button class="cp-dispatch-btn" id="cp1DispatchBtn" onclick="cp1HandleDispatch()" disabled>Send Feedback</button></div></div><div class="hitl-approved-banner" id="cp1Banner"><svg viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg><span>Draft approved by Bid Manager at <strong id="cp1ApproveTime"></strong> &mdash; workflow resuming&hellip;</span></div></div></td>`;
    $('workflowBody').appendChild(cpRow);
    $('cp1Time').textContent=ts();
    cpRow.scrollIntoView({behavior:'smooth',block:'center'});
  });
}

function cp1Approve(){
  const t=ts();approvalTimestamps.cp1=t;
  /* Capture any reviewer notes on approval */
  const notes=$('cp1Notes')?$('cp1Notes').value.trim():'';
  $('cp1ApproveBtn').disabled=true;
  /* Also disable reject and retrigger once approved */
  const rejBtn=$('cp1Row').querySelector('.hitl-btn-reject');if(rejBtn)rejBtn.disabled=true;
  const rtBtn=$('cp1Row').querySelector('.hitl-btn-retrigger');if(rtBtn)rtBtn.disabled=true;
  $('cp1ApproveTime').textContent=t;
  $('cp1Banner').classList.add('show');
  $('cp1Row').querySelector('.hitl-badge').textContent='\u2713 Approved';
  $('cp1Row').querySelector('.hitl-badge').style.cssText='background:rgba(0,201,160,.12);color:#00c9a0;border:1px solid rgba(0,201,160,.25);border-radius:10px;padding:3px 10px;font-size:11px;font-weight:700;';
  $('cp1Row').querySelector('.hitl-inner').style.borderLeftColor='var(--emerald)';
  const ptS=$('ptCP1');if(ptS)ptS.className='pt-step hitl-done';
  /* Log notes to trace if provided */
  updateTraceHitl(0,'Approved',t,notes||'Bid Manager approved — no revision notes');
  setTimeout(()=>{cp1Resolver&&cp1Resolver();},1400);
}

function cp1Reject(){
  const notes=$('cp1Notes')?$('cp1Notes').value.trim():'';
  if(!notes){
    /* Highlight notes textarea — feedback required before reject */
    const ta=$('cp1Notes');
    if(ta){ta.style.borderColor='var(--brand-red)';ta.focus();ta.placeholder='Please enter revision notes before rejecting...';setTimeout(()=>{ta.style.borderColor='';},2200);}
    const badge=$('cp1Row').querySelector('.hitl-badge');
    if(badge){const orig=badge.textContent;badge.textContent='\u26A0 Please enter reviewer notes first';badge.style.cssText='background:rgba(236,27,46,.1);color:#EC1B2E;border:1px solid rgba(236,27,46,.25);border-radius:10px;padding:3px 10px;font-size:11px;font-weight:700;';setTimeout(()=>{badge.textContent=orig;badge.style.cssText='background:rgba(245,166,35,.1);color:#856404;border:1px solid rgba(245,166,35,.28);border-radius:10px;padding:3px 10px;font-size:11px;font-weight:700;';},2200);}
    return;
  }
  /* Log rejection with notes to trace */
  updateTraceHitl(0,'Rejected',ts(),notes);
  const badge=$('cp1Row').querySelector('.hitl-badge');
  if(badge){badge.textContent='\u26A0 Rejected \u2014 Revisions Required';badge.style.cssText='background:rgba(240,84,115,.12);color:#f8778e;border:1px solid rgba(240,84,115,.25);border-radius:10px;padding:3px 10px;font-size:11px;font-weight:700;';}
  /* Disable approve until retrigger completes */
  const apprBtn=$('cp1ApproveBtn');if(apprBtn)apprBtn.disabled=true;
  /* Show reject button as active, show retrigger prompt */
  const rejectBtn=$('cp1Row').querySelector('.hitl-btn-reject');if(rejectBtn)rejectBtn.disabled=true;
  /* Auto-trigger the RDA retrigger with the notes as feedback */
  setTimeout(()=>cp1TriggerRda(notes),400);
}

async function cp1TriggerRda(feedback){
  const intent=rdaClassifyIntent(feedback);
  /* Remove any previous CP1 retrigger row */
  const prev=document.getElementById('cp1RdaRetriggerRow');
  if(prev){prev.style.opacity='0';await sleep(280);prev.remove();}

  const steps=CP0_RDA_STEPS[intent.type]||CP0_RDA_STEPS.custom;
  const intentColors={remove:'background:#fee2e2;color:#7f1d1d;',rephrase:'background:#ede9fe;color:#5b21b6;',add:'background:#d4edda;color:#155724;',reorder:'background:#dbeafe;color:#0c4a6e;',custom:'background:var(--surface-3);color:#37474f;'};
  const intentStyle=intentColors[intent.type]||intentColors.custom;

  const stepsHtml=steps.map((_,i)=>
    `<div class="rda-nlp-step" id="cp1RdaStep${i}"><div class="rda-nlp-step-icon" id="cp1RdaStepIcon${i}"></div><span>${_}</span></div>`
  ).join('');

  const rtRow=document.createElement('tr');
  rtRow.className='rda-retrigger-row';
  rtRow.id='cp1RdaRetriggerRow';
  rtRow.innerHTML=`<td colspan="3">
    <div class="rda-retrigger-inner">
      <div class="rda-retrigger-hdr">
        <div class="rda-retrigger-spinner"></div>
        <div>
          <div class="rda-retrigger-label">Response Drafting Agent &mdash; Re-triggered by Bid Manager</div>
          <div class="rda-retrigger-sub">Processing: &ldquo;${feedback}&rdquo;</div>
        </div>
        <span class="rda-intent-chip ${intent.chipClass}" style="margin-left:auto;">${intent.icon} ${intent.label}</span>
      </div>
      <div class="rda-nlp-steps">${stepsHtml}</div>
    </div>
  </td>`;

  /* Insert after cp1Row */
  const cp1Row=$('cp1Row');
  if(cp1Row&&cp1Row.nextSibling){
    cp1Row.parentNode.insertBefore(rtRow,cp1Row.nextSibling);
  } else if(cp1Row){
    cp1Row.parentNode.appendChild(rtRow);
  }
  rtRow.scrollIntoView({behavior:'smooth',block:'nearest'});

  /* Animate NLP steps */
  for(let s=0;s<steps.length;s++){
    const stepEl=document.getElementById('cp1RdaStep'+s);
    const iconEl=document.getElementById('cp1RdaStepIcon'+s);
    if(stepEl){stepEl.classList.add('visible','processing');}
    if(iconEl)iconEl.classList.add('processing');
    await sleep(620);
    if(stepEl){stepEl.classList.remove('processing');stepEl.classList.add('done');}
    if(iconEl){iconEl.classList.remove('processing');iconEl.classList.add('done');iconEl.textContent='\u2713';}
  }

  /* Stop spinner, show complete */
  const spinner=rtRow.querySelector('.rda-retrigger-spinner');
  if(spinner){spinner.style.animation='none';spinner.style.borderColor='rgba(0,168,134,.3)';spinner.style.borderTopColor='#00a886';}
  const lbl=rtRow.querySelector('.rda-retrigger-label');
  if(lbl)lbl.textContent='Response Drafting Agent \u2014 Revised Draft Ready';
  const sub=rtRow.querySelector('.rda-retrigger-sub');
  if(sub)sub.innerHTML='Draft updated &mdash; <strong style="color:#155724;">'+rdaGetChangeDescription(intent,feedback)+'</strong>. Ready for Bid Manager re-review.';

  /* Show complete banner */
  const completeBanner=document.createElement('div');
  completeBanner.className='rda-complete-banner';
  completeBanner.innerHTML=`<svg viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>Revised draft ready &mdash; ${rdaGetChangeDescription(intent,feedback)}. Bid Manager can now approve.`;
  rtRow.querySelector('.rda-retrigger-inner').appendChild(completeBanner);

  /* Update CP1 badge */
  await sleep(400);
  const badge=$('cp1Row').querySelector('.hitl-badge');
  if(badge){badge.textContent='\u25BA Revised Draft Ready \u2014 Re-review Required';badge.style.cssText='background:rgba(0,194,224,.1);color:#0c4a6e;border:1px solid rgba(0,194,224,.25);border-radius:10px;padding:3px 10px;font-size:11px;font-weight:700;';}

  /* Log retrigger to trace */
  updateTraceHitl(0,'Retrigger',ts(),feedback);
  rdaLogToTrace(feedback,intent);

  /* Re-enable approve button and reject button */
  const apprBtn=$('cp1ApproveBtn');if(apprBtn){apprBtn.disabled=false;}
  const rejBtn=$('cp1Row').querySelector('.hitl-btn-reject');if(rejBtn){rejBtn.disabled=false;rejBtn.style.display='';}

  /* Update Document Ready info card to show new version */
  const infoCells=$('cp1Row').querySelectorAll('.hitl-info-val');
  if(infoCells[1])infoCells[1].textContent='Draft v1.1 \u2014 Revised \u2014 AW-2025-IT-047';

  /* Clear notes textarea ready for next round */
  const ta=$('cp1Notes');if(ta)ta.value='';
}

function cp1Retrigger(){
  /* Use notes as feedback if present, else show prompt */
  const notes=$('cp1Notes')?$('cp1Notes').value.trim():'';
  if(!notes){
    const ta=$('cp1Notes');
    if(ta){ta.style.borderColor='var(--cyan)';ta.focus();ta.placeholder='Enter your feedback or change request, then click Re-trigger...';setTimeout(()=>{ta.style.borderColor='';},2200);}
    const badge=$('cp1Row').querySelector('.hitl-badge');
    if(badge){const orig=badge.textContent;badge.textContent='\u2139 Enter reviewer notes above to re-trigger';badge.style.cssText='background:rgba(0,194,224,.1);color:#0c4a6e;border:1px solid rgba(0,194,224,.25);border-radius:10px;padding:3px 10px;font-size:11px;font-weight:700;';setTimeout(()=>{badge.textContent=orig;badge.style.cssText='';},2200);}
    return;
  }
  /* Disable retrigger button during processing */
  const rtBtn=$('cp1Row').querySelector('.hitl-btn-retrigger');if(rtBtn)rtBtn.disabled=true;
  cp1TriggerRda(notes);
}

function renderCP2(){
  return new Promise(resolve=>{
    cp2Resolver=resolve;
    const ptS=$('ptCP2');if(ptS)ptS.className='pt-step hitl-active';
    cp2BUApproved=false;cp2CommApproved=false;
    const cpRow=document.createElement('tr');cpRow.className='hitl-row';cpRow.id='cp2Row';
    cpRow.innerHTML=`<td colspan="3"><div class="hitl-inner" style="border-left-color:var(--violet);"><div class="hitl-header"><div class="hitl-icon" style="background:rgba(124,92,252,.12)"><svg viewBox="0 0 24 24" stroke="#c4b5fd"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg></div><div class="hitl-title-block"><div class="hitl-eyebrow" style="color:#c4b5fd;">&#9654; Human-in-the-Loop &mdash; Dual Director Sign-Off Required</div><div class="hitl-title">Checkpoint 2: Governance Gate &mdash; Executive Approval</div></div><div class="hitl-badge" style="background:rgba(124,92,252,.12);color:#c4b5fd;border-color:rgba(124,92,252,.28);" id="cp2Badge"><span style="width:6px;height:6px;border-radius:50%;background:#c4b5fd;display:inline-block;"></span>&nbsp;Awaiting Dual Director Approval</div></div><div class="hitl-desc">
  <div><strong>✔ Governance pack ready</strong> — The complete submission package has been assembled and issued for executive review.</div>
  <div style="margin-top:6px;"><strong>⏸ Workflow paused</strong> — This is a mandatory governance checkpoint requiring dual director approval.</div>
  <div style="margin-top:6px;"><strong>⏳ Action required</strong> — Both the <strong>BU Director</strong> and <strong>Commercial Director</strong> must review and approve independently. Approval from one does not release the workflow.</div>
  <div style="margin-top:6px;"><strong>▶ Next step</strong> — When both approvals are received, the workflow will proceed to <strong>Governance and Compliance agent</strong>.</div>
</div><div class="hitl-grid"><div class="hitl-info-card"><div class="hitl-info-label">Governance Pack</div><div class="hitl-info-val">AW-2025-IT-047-GOV-v1.pdf &mdash; Auto-assembled</div></div><div class="hitl-info-card"><div class="hitl-info-label">Contents</div><div class="hitl-info-val">Full draft &bull; Commercial terms &bull; Risk register &bull; Legal disclaimers</div></div><div class="hitl-info-card"><div class="hitl-info-label">Gate Triggered At</div><div class="hitl-info-val" id="cp2Time"></div></div><div class="hitl-info-card"><div class="hitl-info-label">Approval Threshold</div><div class="hitl-info-val">Both directors must approve before workflow proceeds</div></div></div><div class="gov-gate-grid"><div class="approver-card" id="apCard0"><div class="approver-hdr"><div class="approver-avatar" style="background:linear-gradient(135deg,#1976d2,#00c2e0)">DP</div><div><div class="approver-name">D. Patel</div><div class="approver-role">BU Director &mdash; d.patel@company.com</div></div></div><div class="approver-status pending" id="apStat0"><span style="width:5px;height:5px;border-radius:50%;background:currentColor;display:inline-block;"></span>&nbsp;Awaiting Review</div><div class="cp2-director-notes-wrap"><textarea class="cp2-director-notes" id="cp2DirectorNotes0" placeholder="e.g. Re-review Health &amp; Safety section &bull; Flag commercial terms &bull; Highlight programme risk" oninput="cp2OnNotesInput(0,this)" maxlength="400"></textarea><div style="display:flex;align-items:center;justify-content:space-between;margin-top:4px;"><span class="cp2-intent-strip" id="cp2IntentStrip0"></span><button class="cp-dispatch-btn" id="cp2DispatchBtn0" onclick="cp2HandleDirectorDispatch(0)" disabled>Send Feedback</button></div></div><div class="approver-btns"><button class="approver-btn approver-btn-ok" id="apOk0" onclick="directorApprove(0,'D. Patel','BU Director','d.patel@company.com')">&#10003; Approve</button><button class="approver-btn approver-btn-no" style="display:none;" id="apNo0" onclick="directorReject(0)">&#10007; Reject</button></div></div><div class="approver-card" id="apCard1"><div class="approver-hdr"><div class="approver-avatar" style="background:linear-gradient(135deg,#7c5cfc,#EC1B2E)">CW</div><div><div class="approver-name">C. Wright</div><div class="approver-role">Commercial Director &mdash; c.wright@company.com</div></div></div><div class="approver-status pending" id="apStat1"><span style="width:5px;height:5px;border-radius:50%;background:currentColor;display:inline-block;"></span>&nbsp;Awaiting Review</div><div class="cp2-director-notes-wrap"><textarea class="cp2-director-notes" id="cp2DirectorNotes1" placeholder="e.g. Escalate commercial pricing &bull; Re-review supply chain section &bull; Flag sustainability targets" oninput="cp2OnNotesInput(1,this)" maxlength="400"></textarea><div style="display:flex;align-items:center;justify-content:space-between;margin-top:4px;"><span class="cp2-intent-strip" id="cp2IntentStrip1"></span><button class="cp-dispatch-btn" id="cp2DispatchBtn1" onclick="cp2HandleDirectorDispatch(1)" disabled>Send Feedback</button></div></div><div class="approver-btns"><button class="approver-btn approver-btn-ok" id="apOk1" onclick="directorApprove(1,'C. Wright','Commercial Director','c.wright@company.com')">&#10003; Approve</button><button class="approver-btn approver-btn-no" style="display:none;" id="apNo1" onclick="directorReject(1)">&#10007; Reject</button></div></div></div><div class="hitl-actions" style="margin-top:4px;"><button class="hitl-btn hitl-btn-view" onclick="openTenderModal()"><svg viewBox="0 0 24 24"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>View Full Draft</button><button class="hitl-btn" style="background:rgba(245,166,35,.1);color:#856404;border:1px solid rgba(245,166,35,.3);" onclick="openGovPackModal()"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>Review Governance Pack</button><button class="hitl-btn hitl-btn-retrigger" style="display:none;" onclick="cp2Retrigger()"><svg viewBox="0 0 24 24"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-3.76"/></svg>Re-trigger & Revise</button></div><div class="hitl-approved-banner" id="cp2Banner"><svg viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg><span>Both directors approved at <strong id="cp2ApproveTime"></strong> &mdash; proceeding to final submission&hellip;</span></div></div></td>`;
    $('workflowBody').appendChild(cpRow);
    $('cp2Time').textContent=ts();
    cpRow.scrollIntoView({behavior:'smooth',block:'center'});
  });
}

function directorApprove(idx,name,role,email){
  const t=ts();
  $('apOk'+idx).disabled=true;$('apNo'+idx).disabled=true;
  $('apCard'+idx).classList.add('approved');
  $('apStat'+idx).className='approver-status approved';
  $('apStat'+idx).innerHTML=`<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>&nbsp;Approved at ${t}`;
  if(idx===0){cp2BUApproved=true;approvalTimestamps.cp2BU=t;updateTraceHitl(1,'Approved',t,name+' (BU Director)');}
  else{cp2CommApproved=true;approvalTimestamps.cp2Comm=t;updateTraceHitl(2,'Approved',t,name+' (Commercial Director)');}
  checkCP2Complete();
}

function directorReject(idx){
  $('apOk'+idx).disabled=true;$('apNo'+idx).disabled=true;
  $('apCard'+idx).classList.add('rejected');
  $('apStat'+idx).className='approver-status rejected';
  $('apStat'+idx).innerHTML=`&#10007; Rejected &mdash; ${ts()}`;
  updateTraceHitl(idx+1,'Rejected',ts(),(idx===0?'BU':'Commercial')+' Director &mdash; revisions required');
}

function cp2Retrigger(){
  $('cp2Badge').textContent='\u21BB Re-triggering workflow...';
  setTimeout(()=>{$('cp2Badge').textContent='\u25BA Awaiting Re-review';},1500);
}

function checkCP2Complete(){
  if(cp2BUApproved&&cp2CommApproved){
    const t=ts();approvalTimestamps.cp2Both=t;
    $('cp2ApproveTime').textContent=t;
    $('cp2Banner').classList.add('show');
    $('cp2Badge').textContent='\u2713 Dual Approval Complete';
    $('cp2Badge').style.cssText='background:rgba(0,201,160,.12);color:#00c9a0;border:1px solid rgba(0,201,160,.25);border-radius:10px;padding:3px 10px;font-size:11px;font-weight:700;';
    const ptS=$('ptCP2');if(ptS)ptS.className='pt-step hitl-done';
    $('cp2Row').querySelector('.hitl-inner').style.borderLeftColor='var(--emerald)';
    $('traceApprovals').textContent='2/2';
    setTimeout(()=>{cp2Resolver&&cp2Resolver();},1800);
  }
}

function updateTraceHitl(rowIdx,action,time,notes){
  const rows=$('traceHitlLog').querySelectorAll('tr');
  if(rows[rowIdx]){
    const cells=rows[rowIdx].querySelectorAll('td');
    const pill=cells[3].querySelector('.trace-pill');
    if(pill){
      if(action==='Approved'){pill.className='trace-pill trace-pill-green';pill.textContent='Approved';}
      else if(action==='Rejected'){pill.className='trace-pill trace-pill-rose';pill.textContent='Rejected';}
      else{pill.className='trace-pill trace-pill-amber';pill.textContent='Retrigger';}
    }
    if(cells[4])cells[4].textContent=time;
    if(cells[5]&&notes)cells[5].textContent=notes;
  }
}

function setBtnLabel(text){
  const lbl=document.getElementById('startBtnLabel');
  if(lbl)lbl.textContent=text;
}

async function runFlow(){
  if(isRunning)return;
  const btn=document.getElementById('startBtn');
  if(!btn)return;
  btn.disabled=true;
  btn.classList.add('running');
  setBtnLabel(' Parsing\u2026');
  const uploadOk=await uploadStartIllusion();
  if(!uploadOk){
    btn.disabled=false;
    btn.classList.remove('running');
    setBtnLabel(' Initiate Process');
    return;
  }
  setBtnLabel(' Running\u2026');
  /* Apply any extracted tender data to override hardcoded defaults */
  trsApplyExtractedData();
  isRunning=true;taskCount=0;doneCount=0;cp2BUApproved=false;cp2CommApproved=false;
  $('board').style.display='block';
  $('progressTimeline').style.display='block';
  $('completionBanner').style.display='none';
  buildTimeline();buildHeroCard();$('workflowBody').innerHTML='';
  startClock();
  const genTime = $('traceGenTime');
  if (genTime) {
    genTime.textContent = new Date().toLocaleString('en-GB');
  }

  const v10Time = $('traceV10Time');
  if (v10Time) {
    v10Time.textContent = new Date().toLocaleString('en-GB');
  }
  await sleep(180);
  $('board').scrollIntoView({behavior:'smooth',block:'start'});
    for(let i=0;i<5;i++){
      await renderAgent(i);
      showConfidenceBadge(i);
      injectInspectButton(i);
      if(i<4){
        showTransitionIndicator(AGENTS[i+1].AGENT_NAME);
        await sleep(5000);
        removeTransitionIndicator();
        await sleep(320);
      }
    }
  /* ── Checkpoint 0: Lead Section Review Gate ── */
  await sleep(800);
  await renderCP0();
  await sleep(800);
  await renderCP1();
    await sleep(800);
  await renderCP2();
  await sleep(800);
  await renderAgent(5);
  showConfidenceBadge(5);
  injectInspectButton(5);
  await sleep(1000);
  stopClock();
  isRunning=false;
  btn.disabled=false;btn.classList.remove('running');setBtnLabel(' Run Again');
  $('traceElapsed').textContent=kTime.textContent;
  ['hdrTenderBtn','heroTenderBtn','secTenderBtn'].forEach(id=>{
    const el=$(id);if(!el)return;
    el.style.display='inline-flex';el.style.opacity='0';el.style.transition='opacity .6s ease';
    requestAnimationFrame(()=>requestAnimationFrame(()=>{el.style.opacity='1';}));
  });
  const banner=$('completionBanner');
  banner.style.display='block';
  banner.scrollIntoView({behavior:'smooth',block:'nearest'});
}

function resetWorkflow(){
  isRunning=false;taskCount=0;doneCount=0;cp2BUApproved=false;cp2CommApproved=false;
  cp0Resolver=null;cp1Resolver=null;cp2Resolver=null;
  resetRdaState();
  /* Reset upload zone */
  uploadRemove();
  const proc=$('uploadProcessing');
  if(proc){proc.classList.remove('show');proc.style.background='';proc.style.borderColor='';}
  const bar=$('uploadProcessingBar');if(bar)bar.style.width='0%';
  const label=$('uploadProcessingLabel');
  if(label){label.textContent='Parsing ITT document\u2026';label.style.color='';}
  const msg=$('uploadRequiredMsg');if(msg)msg.classList.remove('show');
  /* Remove CP1 RDA retrigger row if present */
  const cp1Rt=document.getElementById('cp1RdaRetriggerRow');if(cp1Rt)cp1Rt.remove();
  /* Reset CP1 char count and intent strip */
  const cp1cc=$('cp1CharCount');if(cp1cc)cp1cc.textContent='0';
  const cp1is=$('cp1IntentStrip');if(cp1is)cp1is.textContent='';
  const cp1nh=$('cp1NlpHint');if(cp1nh)cp1nh.textContent='';

  cp0Approvals={tech:false,hs:false,sustain:false,supplychain:false};
    cp0Rejections={tech:false,hs:false,sustain:false,supplychain:false};
  cp0FeedbackStore={tech:'',hs:'',sustain:'',supplychain:''};
  cp0RevisedContent={tech:null,hs:null,sustain:null,supplychain:null};
  cp0RetriggerCount={tech:0,hs:0,sustain:0,supplychain:0};
  cp0CurrentLeadIdx=null;
  /* Remove dynamically-added CP0 gate cards, trace rows, retrigger rows */
  document.querySelectorAll('[id^="hgc-cp0-"]').forEach(el=>el.remove());
  document.querySelectorAll('[id^="trace-cp0-row-"]').forEach(el=>el.remove());
  const rdaRtRow=document.getElementById('cp0RdaRetriggerRow');if(rdaRtRow)rdaRtRow.remove();
  stopClock();
  kT.textContent='0';kD.textContent='0';kTime.textContent='\u2014';
  $('workflowBody').innerHTML='';
  $('board').style.display='none';
  $('progressTimeline').style.display='none';
  $('completionBanner').style.display='none';
  $('traceApprovals').textContent='0/2';
  $('traceElapsed').textContent='\u2014';
  const btn=$('startBtn');
  btn.disabled=false;btn.classList.remove('running');setBtnLabel(' Initiate Process');
  ['hdrTenderBtn','heroTenderBtn','secTenderBtn'].forEach(id=>{const el=$(id);if(el){el.style.display='none';el.style.opacity='0';}});
  buildHeroCard();
  /* Reset enhanced trace modal agent cards */
  document.querySelectorAll('.agent-exec-card').forEach(c=>{c.classList.remove('aec-complete','aec-active','expanded');c.classList.add('aec-pending');});
  for(let r=0;r<6;r++){const p=document.getElementById('aec-pill-'+r);if(p){p.className='trace-pill trace-pill-blue';p.textContent='Pending';}const sp=document.getElementById('sum-pill-'+r);if(sp){sp.className='trace-pill trace-pill-blue';sp.textContent='Pending';}const d=document.getElementById('aec-dur-'+r);if(d)d.innerHTML='&#8212;';}
  /* Reset HitL gate cards */
  document.querySelectorAll('.hitl-gate-card').forEach(c=>{c.classList.remove('hgc-approved');c.classList.add('hgc-awaiting');});
  for(let r=0;r<3;r++){const a=document.getElementById('hgc-action-'+r);if(a){a.className='hgc-action-pill trace-pill trace-pill-blue';a.textContent='Awaiting';}const t=document.getElementById('hgc-ts-'+r);if(t)t.innerHTML='&#8212;';}
  /* Reset tab badges */
  const tb=document.getElementById('tabBadgeAgents');if(tb)tb.textContent='0/6';
  const th=document.getElementById('tabBadgeHitl');if(th)th.textContent='0/2';
  /* Reset hidden tbody for legacy JS */
  $('traceHitlLog').querySelectorAll('.trace-pill').forEach(p=>{p.className='trace-pill trace-pill-blue';p.textContent='Awaiting';});
  /* Reset perf bars */
  document.querySelectorAll('.perf-metric-row').forEach(r=>r.classList.remove('in-view'));
  document.querySelectorAll('.pmr-bar-fill').forEach(b=>b.style.width='0');
  window.scrollTo({top:0,behavior:'smooth'});
}

function openModal(id){$(id).classList.add('open');document.body.style.overflow='hidden';}
function closeModal(id){$(id).classList.remove('open');document.body.style.overflow='';}

/* ===============================================
   DOWNLOAD / EXPORT ENGINE
   Safe insertion — no existing code modified
=============================================== */



/* =================================================
   WYSIWYG PDF EXPORT ENGINE
   Clones exact modal content into #printRoot
   then triggers window.print() — no new tab,
   PDF looks identical to what user sees in app
================================================= */


function setBtnDownloadFeedback(btn, label){
  if(!btn)return;
  const orig = btn.innerHTML;
  btn.innerHTML = '<svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:4px;"><polyline points="20 6 9 17 4 12"/></svg>' + label;
  btn.style.background = '#00a886';
  btn.style.borderColor = '#00a886';
  btn.style.color = '#fff';
  setTimeout(()=>{ btn.innerHTML=orig; btn.style.background=''; btn.style.borderColor=''; btn.style.color=''; }, 3000);
}

async function exportToPdf(el, filename, btn) {
  if (!el) { alert('Content not available. Please open the panel first.'); return; }
  if (btn) setBtnDownloadFeedback(btn, 'Generating PDF...');

  // Temporarily make element visible and positioned for capture
  const prevDisplay = el.style.display;
  const prevPosition = el.style.position;
  const prevLeft = el.style.left;
  const prevTop = el.style.top;
  const prevZIndex = el.style.zIndex;
  const prevOpacity = el.style.opacity;
  const prevMaxH = el.style.maxHeight;
  const prevOverflow = el.style.overflow;

  el.style.display = 'block';
  el.style.position = 'fixed';
  el.style.left = '-9999px';
  el.style.top = '0';
  el.style.zIndex = '-1';
  el.style.opacity = '1';
  el.style.maxHeight = 'none';
  el.style.overflow = 'visible';

  // Wait for layout
  await new Promise(r => setTimeout(r, 150));

  try {
    const canvas = await html2canvas(el, {
      scale: 2,
      useCORS: true,
      allowTaint: true,
      backgroundColor: '#ffffff',
      logging: false,
      width: el.scrollWidth,
      height: el.scrollHeight,
      windowWidth: el.scrollWidth
    });

    const { jsPDF } = window.jspdf;
    const imgData = canvas.toDataURL('image/png');
    const pdfW = 210; // A4 width mm
    const pdfH = (canvas.height * pdfW) / canvas.width;
    const pdf = new jsPDF({ orientation: pdfH > 297 ? 'p' : 'p', unit: 'mm', format: 'a4' });

    let yOffset = 0;
    const pageH = 297; // A4 height mm
    let remaining = pdfH;
    let page = 0;

    while (remaining > 0) {
      if (page > 0) pdf.addPage();
      const sliceH = Math.min(pageH, remaining);
      const srcY = (page * pageH * canvas.width) / pdfW;
      const srcH = (sliceH * canvas.width) / pdfW;
      // Add image slice
      pdf.addImage(imgData, 'PNG', 0, 0, pdfW, pdfH, '', 'FAST');
      if (remaining > pageH) {
        // Clip by adding white rectangle over next page overflow
      }
      remaining -= pageH;
      page++;
      if (page > 20) break; // safety
    }

    pdf.save(filename);
  } catch(err) {
    console.error('PDF export error:', err);
    alert('PDF export failed. Please try again.');
  }

  // Restore element
  el.style.display = prevDisplay;
  el.style.position = prevPosition;
  el.style.left = prevLeft;
  el.style.top = prevTop;
  el.style.zIndex = prevZIndex;
  el.style.opacity = prevOpacity;
  el.style.maxHeight = prevMaxH;
  el.style.overflow = prevOverflow;
}

/* Helper - get or open modal body element */
function getModalBody(modalId) {
  const modal = document.getElementById(modalId);
  if (!modal) return null;
  // Open modal temporarily if not open
  const wasOpen = modal.classList.contains('open');
  if (!wasOpen) modal.classList.add('open');
  const box = modal.querySelector('.modal-body');
  return { el: box, wasOpen, modal };
}

/* 1. TENDER DRAFT */
function downloadTenderDraft(btn) {
  const a = document.createElement('a');
  a.href = '/static/data/GT_Tender_Response_Grafham_WTW_UV_Upgrade_AMP8.pdf';
  a.download = 'GT_Tender_Response_Grafham_WTW_UV_Upgrade_AMP8.pdf';
  document.body.appendChild(a);
  a.click();
  setTimeout(() => a.remove(), 500);
  setBtnDownloadFeedback(btn, 'Downloaded');
}

/* 2. AGENT TRACE REPORT */
function downloadAgentTrace(btn) {
  const modal = document.getElementById('traceModal');
  const wasOpen = modal && modal.classList.contains('open');
  if (!wasOpen && modal) { modal.classList.add('open'); document.body.style.overflow = 'hidden'; }
  const el = document.querySelector('#traceModal .modal-body');
  exportToPdf(el, 'AgentTraceReport-AW-2025-IT-047.pdf', btn).then(() => {
    if (!wasOpen && modal) { modal.classList.remove('open'); document.body.style.overflow = ''; }
  });
}

/* 3. TENDER SUMMARY BRIEF */
function downloadTenderSummary(btn) {
  const a = document.createElement('a');
  a.href = '/static/data/Tender_Summary_Brief.docx';
  a.download = 'Tender_Summary_Brief.docx';
  document.body.appendChild(a);
  a.click();
  setTimeout(() => a.remove(), 500);
  setBtnDownloadFeedback(btn, 'Downloaded');
}

/* 4. RISK & CLARIFICATION LOG */
function downloadRiskLog(btn) {
  const a = document.createElement('a');
  a.href = '/static/data/Risk_Flags_Report.pdf';
  a.download = 'Risk_Flags_Report.pdf';
  document.body.appendChild(a);
  a.click();
  setTimeout(() => a.remove(), 500);
  setBtnDownloadFeedback(btn, 'Downloaded');
}

/* 5. INSPECT MODAL - smart router */
function downloadInspectReport(btn) {
  const activeTab = document.querySelector('.inspect-tab.active');
  const tabId = activeTab ? activeTab.dataset.itab : '';
  if (tabId === 'brief') { downloadTenderSummary(btn); return; }
  if (tabId === 'risk')  { downloadRiskLog(btn); return; }
  const el = document.querySelector('.inspect-pane.active');
  exportToPdf(el, 'AgentOutputReport-AW-2025-IT-047.pdf', btn);
}








/* ═══════════════════════════════════════════
   PDF UPLOAD — ILLUSION ENGINE
═══════════════════════════════════════════ */

let uploadedFile=null;
let trsExtractedData=null; /* Stores API extraction result — overrides hardcoded defaults */

function uploadFileSelected(e){
  const file=e.target.files[0];
  if(file)uploadSetFile(file);
}

function uploadDragOver(e){
  e.preventDefault();
  $('uploadZone').classList.add('drag-over');
}

function uploadDragLeave(e){
  $('uploadZone').classList.remove('drag-over');
}

function uploadDrop(e){
  e.preventDefault();
  $('uploadZone').classList.remove('drag-over');
  const file=e.dataTransfer.files[0];
  if(file)uploadSetFile(file);
}

function uploadSetFile(file){
  uploadedFile=file;
  trsExtractedData=null;
  /* Kick off risk engine after a short delay to let extraction run first */
  setTimeout(()=>runRiskEngine(), 1200);
  const zone=$('uploadZone');
  zone.classList.add('has-file');
  const nameEl=$('uploadFileName');
  if(nameEl)nameEl.textContent=file.name;
  const sizeEl=$('uploadFileSize');
  if(sizeEl){
    const kb=Math.round(file.size/1024);
    sizeEl.textContent=kb>1024?(Math.round(kb/102.4)/10)+'MB':kb+'KB';
  }
  const msg=$('uploadRequiredMsg');
  if(msg)msg.classList.remove('show');
  const title=$('launchTitle');
  if(title)title.textContent='Step 2 — Initiate the Agentic Workflow';
  setBtnLabel(' Analyse & Process');
  /* Kick off background extraction — non-blocking */
  trsExtractFile(file);
}

/* Send PDF to /api/extract-tender, store result in trsExtractedData */
function trsExtractFile(file){
  if(!file||!file.name.toLowerCase().endsWith('.pdf'))return;
  const fd=new FormData();
  fd.append('file',file);
  fetch('/api/extract-tender',{method:'POST',body:fd})
    .then(r=>r.json())
    .then(data=>{
      if(data&&!data.error){
        trsExtractedData=data;
        console.log('[TRS] Extraction complete:',data);
      }
    })
    .catch(e=>console.warn('[TRS] Extraction failed (non-blocking):',e));
}

/* Apply extracted fields to UI — call this at start of runFlow */
function trsApplyExtractedData(){
  if(!trsExtractedData)return;
  const d=trsExtractedData;
  const src=d.extraction_source||{};
  const get=(field)=>(src[field]==='extracted'&&d[field])?d[field]:null;

  const client   = get('client_name');
  const ref      = get('tender_ref');
  const deadline = get('bid_deadline');
  const value    = get('project_value');
  const title    = get('tender_title');
  const desc     = get('project_description');

  /* Tender modal header meta cards */
  const elClient=document.getElementById('trsDocClient');
  if(elClient&&client)elClient.textContent=client;
  const elRef=document.getElementById('trsDocRef');
  if(elRef&&ref)elRef.textContent=ref;
  const elDeadline=document.getElementById('trsDocDeadline');
  if(elDeadline&&deadline)elDeadline.textContent=deadline;
  const elValue=document.getElementById('trsDocValue');
  if(elValue&&value)elValue.textContent=value;

  /* Modal title and sub */
  const mt=document.getElementById('trsModalTitle');
  if(mt&&client)mt.textContent=client+' — Tender Response';
  const ms=document.getElementById('trsModalSub');
  if(ms&&ref)ms.textContent='Ref: '+ref+' | '+(title||'Tender Response')+' | Draft v1.0';

  /* Hero section */
  if(title){
    const heroT=document.querySelector('.sec-title');
    if(heroT)heroT.textContent='Galliford Try — '+title;
  }
  if(desc){
    const heroS=document.querySelector('.sec-sub');
    if(heroS)heroS.textContent=desc;
  }

  /* First doc textarea — Executive Summary */
  if(client||title||ref){
    const c=client||'the Client';
    const r=ref||'this tender';
    const t=title||'the project';
    const execTA=document.querySelector('#tenderModal .doc-editable');
    if(execTA){
      execTA.value='We are pleased to submit our response to '+c+
        ' Invitation to Tender for '+t+' (Ref: '+r+'). '+
        'Our proposed solution delivers measurable outcomes aligned to the specified requirements. '+
        'Galliford Try brings extensive sector experience and a proven delivery track record to this opportunity.';
    }
  }

  /* Log */
  const extracted=Object.entries(src).filter(([,v])=>v==='extracted').map(([k])=>k);
  console.log('[TRS] Applied '+extracted.length+' extracted fields: '+(extracted.join(', ')||'none'));
}

function uploadRemove(){
  uploadedFile=null;
  trsExtractedData=null;
  /* Hide risk console on file removal */
  const rc=$('riskConsole');
  if(rc){ rc.classList.remove('show'); }
  const sub=$('rcHeaderSub');
  if(sub) sub.textContent='Analysing uploaded ITT document\u2026';
  const gonogo=$('rcGoNogo');
  if(gonogo) gonogo.className='rc-gonogo scanning';
  const gonogoLabel=$('rcGoNogoLabel');
  if(gonogoLabel) gonogoLabel.textContent='Scanning\u2026';
  trsExtractedData=null;
  const zone=$('uploadZone');
  zone.classList.remove('has-file');
  /* Reset file input */
  const input=$('ittFileInput');
  if(input)input.value='';
  /* Reset button label */
  const btn=$('startBtn');
  setBtnLabel(' Initiate Process');
}

/* Called at workflow start — validates upload and runs illusion parsing sequence */
async function uploadStartIllusion(){
  if(!uploadedFile){
    const msg=$('uploadRequiredMsg');if(msg)msg.classList.add('show');
    const zone=$('uploadZone');
    zone.style.borderColor='var(--brand-red)';
    setTimeout(()=>{zone.style.borderColor='';},1800);
    return false;
  }
  const proc=$('uploadProcessing');if(proc)proc.classList.add('show');
  const bar=$('uploadProcessingBar');
  const label=$('uploadProcessingLabel');
  const stages=[
    {pct:'15%',  text:'Reading document structure...'},
    {pct:'32%',  text:'Extracting ITT requirements...'},
    {pct:'51%',  text:'Identifying evaluation criteria...'},
    {pct:'68%',  text:'Flagging commercial risk items...'},
    {pct:'84%',  text:'Mapping submission requirements...'},
    {pct:'100%', text:'Document parsed - ready for agent processing'}
  ];
  for(const stage of stages){
    if(bar)bar.style.width=stage.pct;
    if(label)label.textContent=stage.text;
    await sleep(520);
  }
  if(label){label.style.color='#155724';}
  if(proc){proc.style.background='rgba(0,168,134,.06)';proc.style.borderColor='rgba(0,168,134,.2)';}
  uploadApplyFilenameIllusion(uploadedFile.name);
  await sleep(400);
  return true;
}

function uploadApplyFilenameIllusion(filename){
  /* Strip extension for display */
  const baseName=filename.replace(/\.[^.]+$/,'');
  /* Update the orchestrator agent description to reference the file */
  const desc0=$('ad0');
  if(desc0&&desc0.textContent){
    desc0.textContent=desc0.textContent.replace(
      'Coordinates the end-to-end agentic workflow',
      'Coordinates the end-to-end agentic workflow for “'+baseName+'”'
    );
  }
  /* Update ITT intake agent description */
  const desc1=$('ad1');
  if(desc1&&desc1.textContent){
    desc1.textContent=desc1.textContent.replace(
      'Ingests ITT documentation',
      'Ingests “'+filename+'”'
    );
  }
  /* Update the trace modal sub-header to reference the file */
  const traceSub=document.querySelector('#traceModal .modal-sub');
  if(traceSub&&traceSub.textContent.includes('AW-2025-IT-047')){
    traceSub.textContent=traceSub.textContent+' · Source: '+filename;
  }
}
function openTenderModal(){openModal('tenderModal');}
function openTraceModal(){openModal('traceModal');}

document.querySelectorAll('.modal-overlay').forEach(ov=>{
  ov.addEventListener('click',e=>{if(e.target===ov)closeModal(ov.id);});
});
document.addEventListener('keydown',e=>{if(e.key==='Escape')document.querySelectorAll('.modal-overlay.open').forEach(ov=>closeModal(ov.id));});

window.addEventListener('DOMContentLoaded',()=>{
  buildHeroCard();
  $('traceGenTime').textContent=new Date().toLocaleString('en-GB');
});
document.getElementById('startBtn').onclick=runFlow;

/* ═══════════════════════════════════════════════════════
   RESPONSE DRAFTING AGENT — ITERATIVE FEEDBACK LOOP ENGINE
═══════════════════════════════════════════════════════ */

/* State */
let rdaFeedbackHistory=[];
let rdaRetriggerCount=0;
let rdaFeedbackResolver=null;

/* NLP intent classifier — parses natural language into structured intent */
function rdaClassifyIntent(text){
  const t=text.toLowerCase();
  if(/remove|delete|exclude|drop|omit|take out/.test(t))return{type:'remove',label:'Remove Section',chipClass:'chip-remove',icon:'✕'};
  if(/rephrase|rewrite|reword|refine|redraft|make.*concise|simplify|shorten|tighten/.test(t))return{type:'rephrase',label:'Rephrase',chipClass:'chip-rephrase',icon:'↺'};
  if(/add|include|insert|append|introduce|expand|detail/.test(t))return{type:'add',label:'Add Content',chipClass:'chip-add',icon:'+'};
  if(/move|reorder|restructure|swap|shift|reorganise|reorganize/.test(t))return{type:'reorder',label:'Reorder',chipClass:'chip-reorder',icon:'⇅'};
  return{type:'custom',label:'Custom Edit',chipClass:'chip-custom',icon:'✎'};
}

/* NLP processing steps per intent type */
const RDA_NLP_STEPS={
  remove:[
    'Parsing natural language instruction…',
    'Identifying target section reference…',
    'Validating section removal against ITT compliance…',
    'Re-running criteria alignment check on remaining sections…',
    'Regenerating document structure and cross-references…',
    'Applying version delta — section removed cleanly…'
  ],
  rephrase:[
    'Parsing natural language instruction…',
    'Identifying target passage and scope of change…',
    'Loading original passage into NLP refinement engine…',
    'Applying conciseness and tone constraints…',
    'Validating rephrased content against evaluation criteria…',
    'Integrating refined passage into document…'
  ],
  add:[
    'Parsing natural language instruction…',
    'Identifying insertion point and section context…',
    'Retrieving relevant content from bid library…',
    'Generating new paragraph aligned to ITT requirements…',
    'Checking coherence with adjacent sections…',
    'Inserting and cross-referencing new content…'
  ],
  reorder:[
    'Parsing natural language instruction…',
    'Mapping current document structure…',
    'Computing optimal reorder sequence…',
    'Validating flow and narrative coherence post-reorder…',
    'Updating section numbering and cross-references…',
    'Finalising restructured document…'
  ],
  custom:[
    'Parsing natural language instruction…',
    'Decomposing instruction into discrete edit operations…',
    'Loading relevant document sections…',
    'Applying instruction with context-aware NLP engine…',
    'Running full criteria alignment pass…',
    'Generating updated draft with changes applied…'
  ]
};

/* Suggested quick-action prompts shown in feedback panel */
const RDA_SUGGESTIONS=[
  {text:'Remove Section 3.3 as it is not needed',icon:'<svg viewBox="0 0 24 24"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>'},
  {text:'Rephrase the introduction to highlight cost savings',icon:'<svg viewBox="0 0 24 24"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-3.76"/></svg>'},
  {text:'Add sustainability paragraph to Section 4.1',icon:'<svg viewBox="0 0 24 24"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>'},
  {text:'Make the executive summary more concise',icon:'<svg viewBox="0 0 24 24"><line x1="21" y1="10" x2="3" y2="10"/><line x1="21" y1="6" x2="3" y2="6"/><line x1="21" y1="14" x2="3" y2="14"/></svg>'}
];

/* Render the feedback panel after agent 4 (Response Drafting) completes */
function renderRdaFeedbackPanel(){
  /* Remove any existing panel first */
  const existing=document.getElementById('rdaFeedbackRow');
  if(existing)existing.remove();

  const row=document.createElement('tr');
  row.className='rda-feedback-panel';
  row.id='rdaFeedbackRow';

  const suggestionsHtml=RDA_SUGGESTIONS.map(s=>
    `<button class="rda-suggestion-btn" onclick="rdaUseSuggestion(this,'${s.text.replace(/'/g,"&apos;")}')">` +
    s.icon+`<span>${s.text}</span></button>`
  ).join('');

  row.innerHTML=`<td colspan="3">
    <div class="rda-feedback-inner">
      <div class="rda-feedback-hdr">
        <div class="rda-feedback-hdr-icon"><svg viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg></div>
        <div>
          <div class="rda-feedback-eyebrow">&#9654; Response Drafting Agent &mdash; Iterative Refinement</div>
          <div class="rda-feedback-title">Provide feedback to re-trigger the drafting agent</div>
        </div>
        <div class="rda-feedback-badge" id="rdaRetriggerBadge"><span style="width:6px;height:6px;border-radius:50%;background:var(--cyan);display:inline-block;"></span>&nbsp;Ready for Instructions</div>
      </div>
      <div style="font-size:12.5px;color:#607080;margin-bottom:10px;line-height:1.6;">
        The agent has produced <strong style="color:#111">Draft v${rdaRetriggerCount===0?'1.0':(rdaRetriggerCount+1)+'.0'}</strong>. Enter natural language feedback below &mdash; the agent will <strong style="color:#111">intelligently parse your instruction</strong>, classify the edit type, and regenerate the relevant sections in real-time.
      </div>
      <!-- NLP Intent chips (populated on input) -->
      <div class="rda-intent-strip" id="rdaIntentStrip"></div>
      <!-- Feedback textarea -->
      <div class="rda-feedback-input-wrap">
        <textarea class="rda-feedback-textarea" id="rdaFeedbackInput"
          placeholder="e.g. Remove Section 3.3 as it is not needed &bull; Rephrase the introduction to highlight cost savings &bull; Add a sustainability paragraph to Section 4.1"
          oninput="rdaOnInput(this)"
          maxlength="500"
        ></textarea>
        <span class="rda-feedback-hint" id="rdaIntentHint"></span>
      </div>
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
        <div style="font-size:11px;color:#9eadba;">Try a quick action:</div>
        <div style="font-size:10px;color:#9eadba;"><span id="rdaCharCount">0</span> / 500</div>
      </div>
      <!-- Quick suggestions -->
      <div class="rda-suggestions" id="rdaSuggestions">${suggestionsHtml}</div>
      <!-- Action buttons -->
      <div class="rda-feedback-actions">
        <button class="rda-btn-retrigger" id="rdaRetriggerBtn" onclick="rdaSubmitFeedback()" disabled>
          <svg viewBox="0 0 24 24"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-3.76"/></svg>
          Re-trigger Drafting Agent
        </button>
        <button class="rda-btn-skip" onclick="rdaSkipFeedback()">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>
          Skip &mdash; Proceed to CP0
        </button>
        <span class="rda-char-count" id="rdaFeedbackStatus" style="font-size:11px;color:#9eadba;">Enter feedback to enable re-trigger</span>
      </div>
      <!-- Feedback history log -->
      <div class="rda-history-log" id="rdaHistoryLog" style="display:none;">
        <div class="rda-history-title">Refinement History</div>
        <div id="rdaHistoryEntries"></div>
      </div>
    </div>
  </td>`;

  $('workflowBody').appendChild(row);
  setTimeout(()=>row.scrollIntoView({behavior:'smooth',block:'nearest'}),200);
}

/* Live NLP intent detection as user types */
function rdaOnInput(ta){
  const val=ta.value.trim();
  const cc=$('rdaCharCount');if(cc)cc.textContent=ta.value.length;
  const btn=$('rdaRetriggerBtn');if(btn)btn.disabled=val.length<5;
  const strip=$('rdaIntentStrip');
  const hint=$('rdaIntentHint');
  const status=$('rdaFeedbackStatus');
  if(!val){if(strip)strip.innerHTML='';if(hint)hint.textContent='';if(status)status.textContent='Enter feedback to enable re-trigger';return;}
  const intent=rdaClassifyIntent(val);
  if(strip)strip.innerHTML=`<span class="rda-intent-chip ${intent.chipClass} active">${intent.icon} ${intent.label}</span><span style="font-size:11px;color:#607080;align-self:center;">Intent detected</span>`;
  if(hint)hint.textContent=intent.type.toUpperCase();
  if(status)status.textContent='Intent: '+intent.label+' — click Re-trigger to apply';
}

/* Inject suggestion text into textarea */
function rdaUseSuggestion(btn,text){
  const ta=$('rdaFeedbackInput');
  if(!ta)return;
  ta.value=text;
  rdaOnInput(ta);
  ta.focus();
  btn.style.borderColor='var(--cyan)';
  btn.style.color='#0c4a6e';
  setTimeout(()=>{btn.style.borderColor='';btn.style.color='';},1200);
}

/* Submit feedback — triggers the NLP retrigger sequence */
async function rdaSubmitFeedback(){
  const ta=$('rdaFeedbackInput');
  const feedback=ta?ta.value.trim():'';
  if(!feedback)return;
  const intent=rdaClassifyIntent(feedback);
  rdaFeedbackHistory.push({feedback,intent,time:ts(),version:'v'+(rdaRetriggerCount+1)+'.'+1});
  rdaRetriggerCount++;

  /* Disable input panel during processing */
  const feedbackRow=$('rdaFeedbackRow');
  if(feedbackRow)feedbackRow.style.pointerEvents='none';
  const btn=$('rdaRetriggerBtn');if(btn)btn.disabled=true;
  const badge=$('rdaRetriggerBadge');
  if(badge){badge.innerHTML='<span style="width:6px;height:6px;border-radius:50%;background:#f5a623;display:inline-block;animation:pulseDot 1s ease-in-out infinite;"></span>&nbsp;Processing Feedback';badge.style.background='rgba(245,166,35,.1)';badge.style.color='#856404';badge.style.borderColor='rgba(245,166,35,.3)';}

  /* Inject retrigger processing row */
  await rdaShowRetriggerSequence(feedback,intent);

  /* Log to history */
  rdaUpdateHistoryLog();

  /* Log to agent trace */
  rdaLogToTrace(feedback,intent);

  /* Re-enable for next round */
  if(ta)ta.value='';
  rdaOnInput(ta);
  if(feedbackRow)feedbackRow.style.pointerEvents='';
  const newBadge=$('rdaRetriggerBadge');
  if(newBadge){newBadge.innerHTML='<span style="width:6px;height:6px;border-radius:50%;background:#00a886;display:inline-block;"></span>&nbsp;Draft v1.'+rdaRetriggerCount+' Ready';newBadge.style.background='rgba(0,168,134,.1)';newBadge.style.color='#155724';newBadge.style.borderColor='rgba(0,168,134,.25)';}
}

/* Animated NLP retrigger sequence */
async function rdaShowRetriggerSequence(feedback,intent){
  /* Remove any previous retrigger row */
  const prev=document.getElementById('rdaRetriggerRow');
  if(prev){prev.style.opacity='0';await sleep(300);prev.remove();}

  const steps=RDA_NLP_STEPS[intent.type]||RDA_NLP_STEPS.custom;
  const row=document.createElement('tr');
  row.className='rda-retrigger-row';
  row.id='rdaRetriggerRow';

  const stepsHtml=steps.map((_,i)=>
    `<div class="rda-nlp-step" id="rdaNlpStep${i}">`+
    `<div class="rda-nlp-step-icon" id="rdaNlpStepIcon${i}">&#8203;</div>`+
    `<span id="rdaNlpStepText${i}">${_}</span>`+
    `</div>`
  ).join('');

  row.innerHTML=`<td colspan="3">
    <div class="rda-retrigger-inner">
      <div class="rda-retrigger-hdr">
        <div class="rda-retrigger-spinner"></div>
        <div>
          <div class="rda-retrigger-label">Response Drafting Agent &mdash; Re-triggered</div>
          <div class="rda-retrigger-sub">Processing: <em>&ldquo;${feedback}&rdquo;</em></div>
        </div>
        <span class="rda-intent-chip ${intent.chipClass}" style="margin-left:auto;">${intent.icon} ${intent.label}</span>
      </div>
      <div class="rda-nlp-steps">${stepsHtml}</div>
    </div>
  </td>`;

  /* Insert before feedback row */
  const feedbackRow=$('rdaFeedbackRow');
  $('workflowBody').insertBefore(row,feedbackRow);
  row.scrollIntoView({behavior:'smooth',block:'nearest'});

  /* Animate each step */
  for(let s=0;s<steps.length;s++){
    const stepEl=document.getElementById('rdaNlpStep'+s);
    const iconEl=document.getElementById('rdaNlpStepIcon'+s);
    if(stepEl){stepEl.classList.add('visible');stepEl.classList.add('processing');}
    if(iconEl)iconEl.classList.add('processing');
    await sleep(650);
    if(stepEl){stepEl.classList.remove('processing');stepEl.classList.add('done');}
    if(iconEl){iconEl.classList.remove('processing');iconEl.classList.add('done');iconEl.textContent='✓';}
  }

  /* Replace spinner with complete state */
  await sleep(400);
  const spinner=row.querySelector('.rda-retrigger-spinner');
  if(spinner){
    spinner.style.animation='none';
    spinner.style.borderColor='rgba(0,168,134,.3)';
    spinner.style.borderTopColor='#00a886';
    spinner.style.transform='none';
  }
  const label=row.querySelector('.rda-retrigger-label');
  if(label)label.textContent='Response Drafting Agent — Refinement Complete';
  const sub=row.querySelector('.rda-retrigger-sub');
  if(sub)sub.innerHTML='Draft updated &mdash; <strong style="color:#155724">'+rdaGetChangeDescription(intent,feedback)+'</strong>';

  /* Show complete banner */
  const completeBanner=document.createElement('div');
  completeBanner.className='rda-complete-banner';
  completeBanner.innerHTML=`<svg viewBox="0 0 24 24"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>Draft v1.${rdaRetriggerCount} generated &mdash; ${rdaGetChangeDescription(intent,feedback)}. Ready for review at CP0.`;
  row.querySelector('.rda-retrigger-inner').appendChild(completeBanner);
  await sleep(500);
}

/* Generate a human-readable description of what changed */
function rdaGetChangeDescription(intent,feedback){
  switch(intent.type){
    case 'remove':
      const secMatch=feedback.match(/section[\s]+([\d.]+)/i);
      return secMatch?'Section '+secMatch[1]+' removed and document restructured':'Specified content removed and document restructured';
    case 'rephrase':
      return 'Target passage rephrased with updated tone and emphasis';
    case 'add':
      const addMatch=feedback.match(/section[\s]+([\d.]+)/i);
      return addMatch?'New content added to Section '+addMatch[1]+', cross-references updated':'New content generated and integrated';
    case 'reorder':
      return 'Document sections reordered and narrative flow validated';
    default:
      return 'Custom edits applied and criteria alignment re-validated';
  }
}

/* Update the visible feedback history log */
function rdaUpdateHistoryLog(){
  const log=$('rdaHistoryLog');
  const entries=$('rdaHistoryEntries');
  if(!log||!entries)return;
  log.style.display='block';
  const last=rdaFeedbackHistory[rdaFeedbackHistory.length-1];
  const chipColors={remove:'background:#fee2e2;color:#7f1d1d;',rephrase:'background:#ede9fe;color:#5b21b6;',add:'background:#d4edda;color:#155724;',reorder:'background:#dbeafe;color:#0c4a6e;',custom:'background:var(--surface-3);color:#37474f;'};
  const style=chipColors[last.intent.type]||chipColors.custom;
  const entry=document.createElement('div');
  entry.className='rda-history-entry';
  entry.innerHTML=`<span class="rda-history-badge" style="${style}">${last.intent.label}</span><span class="rda-history-text">${last.feedback}</span><span class="rda-history-time">${last.time}</span>`;
  entries.insertBefore(entry,entries.firstChild);
}

/* Log feedback retrigger to the Agent Trace modal */
function rdaLogToTrace(feedback,intent){
  const tbody=$('traceHitlLog');
  if(!tbody)return;
  const tr=document.createElement('tr');
  tr.innerHTML=`<td>Drafting Agent Retrigger</td><td>${intent.label}</td><td>workflow-engine</td><td><span class="trace-pill trace-pill-amber">Retriggered</span></td><td>${ts()}</td><td>${feedback}</td>`;
  tbody.appendChild(tr);
  /* Also add gate card in trace modal */
  const gateList=document.querySelector('.hitl-gate-list');
  if(gateList){
    const div=document.createElement('div');
    div.className='hitl-gate-card hgc-awaiting';
    div.style.borderLeftColor='var(--cyan)';
    div.innerHTML=`<div class="hitl-gate-header">
      <div class="hgc-gate-label" style="background:rgba(0,194,224,.1);color:#0c4a6e;border-color:rgba(0,194,224,.25);">Drafting Retrigger #${rdaRetriggerCount}</div>
      <div class="hgc-info">
        <div class="hgc-name">Response Drafting Agent &mdash; Re-triggered</div>
        <div class="hgc-role"><em>${feedback}</em></div>
      </div>
      <span class="hgc-action-pill trace-pill trace-pill-amber">${intent.label}</span>
      <span style="font-size:11px;color:#9eadba;">${ts()}</span>
    </div>`;
    gateList.insertBefore(div,gateList.firstChild);
  }
}

/* Skip feedback — proceed directly to CP0 */

/* =================================================================
   CP1 & CP2 ENHANCED NLP INTELLIGENCE ENGINE
   Section-aware: re-review, notify lead, escalate, flag, highlight
   All actions dispatched inline and logged to Agent Trace
================================================================= */

const CP1_SECTION_LEADS = {
  'health':        { lead:'S. Patel',           role:'H&S Lead',           email:'s.patel@gallifordtry.com',     color:'#EC1B2E', initials:'SP' },
  'safety':        { lead:'S. Patel',           role:'H&S Lead',           email:'s.patel@gallifordtry.com',     color:'#EC1B2E', initials:'SP' },
  'h&s':           { lead:'S. Patel',           role:'H&S Lead',           email:'s.patel@gallifordtry.com',     color:'#EC1B2E', initials:'SP' },
  'sustainability':{ lead:'L. Ahmed',           role:'Sustainability Lead', email:'l.ahmed@gallifordtry.com',     color:'#00a886', initials:'LA' },
  'carbon':        { lead:'L. Ahmed',           role:'Sustainability Lead', email:'l.ahmed@gallifordtry.com',     color:'#00a886', initials:'LA' },
  'supply chain':  { lead:'R. Chen',            role:'Supply Chain Lead',  email:'r.chen@gallifordtry.com',      color:'#7c5cfc', initials:'RC' },
  'subcontract':   { lead:'R. Chen',            role:'Supply Chain Lead',  email:'r.chen@gallifordtry.com',      color:'#7c5cfc', initials:'RC' },
  'technical':     { lead:'J. Harrison',        role:'Technical Lead',     email:'j.harrison@gallifordtry.com',  color:'#1976d2', initials:'JH' },
  'methodology':   { lead:'J. Harrison',        role:'Technical Lead',     email:'j.harrison@gallifordtry.com',  color:'#1976d2', initials:'JH' },
  'programme':     { lead:'J. Harrison',        role:'Technical Lead',     email:'j.harrison@gallifordtry.com',  color:'#1976d2', initials:'JH' },
  'commercial':    { lead:'Commercial Manager', role:'Commercial Lead',    email:'commercial@gallifordtry.com',  color:'#f5a623', initials:'CM' },
  'pricing':       { lead:'Commercial Manager', role:'Commercial Lead',    email:'commercial@gallifordtry.com',  color:'#f5a623', initials:'CM' },
  'quality':       { lead:'Quality Manager',    role:'Quality Lead',       email:'quality@gallifordtry.com',     color:'#00c2e0', initials:'QM' },
  'social value':  { lead:'L. Ahmed',           role:'Sustainability Lead', email:'l.ahmed@gallifordtry.com',    color:'#00a886', initials:'LA' },
};

function cp_classifyAction(text){
  const t = text.toLowerCase();
  if(/re.?review|review.*section|check.*section|look.*at|revisit/.test(t))  return 'rereview';
  if(/notify|send.*to|alert|inform|contact|request.*review/.test(t))         return 'notify';
  if(/escalate|raise|flag.*director|escalation/.test(t))                      return 'escalate';
  if(/flag|highlight|mark|note|attention/.test(t))                            return 'flag';
  if(/remove|delete|drop|exclude/.test(t))                                    return 'remove';
  if(/rephrase|rewrite|update|revise|amend/.test(t))                          return 'rephrase';
  if(/add|include|insert/.test(t))                                            return 'add';
  return 'general';
}

function cp_detectSection(text){
  const t = text.toLowerCase();
  for(const key of Object.keys(CP1_SECTION_LEADS)){
    if(t.includes(key)) return { key, ...CP1_SECTION_LEADS[key] };
  }
  const secNum = t.match(/section\s+([\d]+(?:\.\d+)?)/);
  if(secNum){
    const n = parseFloat(secNum[1]);
    if(n===4)  return { key:'Section 4', ...CP1_SECTION_LEADS['health'] };
    if(n===5)  return { key:'Section 5', ...CP1_SECTION_LEADS['sustainability'] };
    if(n===6)  return { key:'Section 6', ...CP1_SECTION_LEADS['supply chain'] };
    if(n===7)  return { key:'Section 7', ...CP1_SECTION_LEADS['commercial'] };
    if(n===8)  return { key:'Section 8', ...CP1_SECTION_LEADS['quality'] };
    if(n===9)  return { key:'Section 9', ...CP1_SECTION_LEADS['social value'] };
    return { key:'Section '+secNum[1], ...CP1_SECTION_LEADS['technical'] };
  }
  return null;
}

const CP_ACTION_META = {
  rereview: { label:'Re-review Requested',     color:'#1976d2', bg:'rgba(25,118,210,.1)',  icon:'\u{1F504}' },
  notify:   { label:'Notification Dispatched', color:'#00a886', bg:'rgba(0,168,134,.1)',   icon:'\u{1F514}' },
  escalate: { label:'Escalation Raised',       color:'#EC1B2E', bg:'rgba(236,27,46,.1)',   icon:'\u25B2'    },
  flag:     { label:'Section Flagged',         color:'#d97706', bg:'rgba(245,166,35,.1)',  icon:'\u{1F6A9}' },
  remove:   { label:'Removal Requested',       color:'#EC1B2E', bg:'rgba(236,27,46,.1)',   icon:'\u2715'    },
  rephrase: { label:'Revision Requested',      color:'#7c5cfc', bg:'rgba(124,92,252,.1)',  icon:'\u270E'    },
  add:      { label:'Addition Requested',      color:'#00a886', bg:'rgba(0,168,134,.1)',   icon:'\u002B'    },
  general:  { label:'Feedback Logged',         color:'#607080', bg:'rgba(96,112,128,.1)',  icon:'\u{1F4AC}' },
};

function cp_buildNotificationCard(action, section, text, checkpoint, approver){
  const meta         = CP_ACTION_META[action] || CP_ACTION_META.general;
  const time         = ts();
  const sectionLabel = section ? section.key      : 'General feedback';
  const leadName     = section ? section.lead     : 'Bid Team';
  const leadRole     = section ? section.role     : '';
  const leadEmail    = section ? section.email    : '';
  const leadInitials = section ? section.initials : 'BT';
  const leadColor    = section ? section.color    : '#607080';
  const notifyRow    = section ? `
      <div class="cp-nlp-notify-row">
        <div class="cp-nlp-avatar" style="background:${leadColor};">${leadInitials}</div>
        <div class="cp-nlp-notify-info">
          <div class="cp-nlp-notify-name">${leadName} &mdash; ${leadRole}</div>
          <div class="cp-nlp-notify-email">Notification sent to ${leadEmail}</div>
        </div>
        <span class="cp-nlp-sent-badge">&#10003; Sent</span>
      </div>` : '';
  return `
  <div class="cp-nlp-card" style="border-left-color:${meta.color};">
    <div class="cp-nlp-card-hdr">
      <span class="cp-nlp-action-badge" style="background:${meta.bg};color:${meta.color};">${meta.icon} ${meta.label}</span>
      <span class="cp-nlp-ts">${time}</span>
    </div>
    <div class="cp-nlp-body">
      <div class="cp-nlp-section-row">
        <span class="cp-nlp-section-label">Section:</span>
        <span class="cp-nlp-section-val">${sectionLabel.charAt(0).toUpperCase()+sectionLabel.slice(1)}</span>
      </div>
      <div class="cp-nlp-feedback-text">&ldquo;${text}&rdquo;</div>
      ${notifyRow}
    </div>
    <div class="cp-nlp-card-ftr">
      <span>Logged to Agent Trace &nbsp;&middot;&nbsp; ${checkpoint} &nbsp;&middot;&nbsp; ${approver}</span>
    </div>
  </div>`;
}

async function cp1DispatchNlpAction(text){
  if(!text) return;
  const action  = cp_classifyAction(text);
  const section = cp_detectSection(text);
  let container = document.getElementById('cp1NlpActionsContainer');
  if(!container){
    container = document.createElement('div');
    container.id = 'cp1NlpActionsContainer';
    container.className = 'cp-nlp-actions-container';
    const notesWrap = document.getElementById('cp1NotesWrap');
    if(notesWrap) notesWrap.insertAdjacentElement('afterend', container);
  }
  const wrapper = document.createElement('div');
  wrapper.innerHTML = cp_buildNotificationCard(action, section, text, 'CP1', 'Bid Manager');
  const card = wrapper.firstElementChild;
  card.style.cssText += 'opacity:0;transform:translateY(6px);transition:opacity .35s ease,transform .35s ease;';
  container.appendChild(card);
  requestAnimationFrame(()=>requestAnimationFrame(()=>{ card.style.opacity='1'; card.style.transform='translateY(0)'; }));
  cp_logToTrace('CP1', action, section, text, 'Bid Manager');
  if(action==='rereview'||action==='notify'){
    await cp_showDispatchSequence('cp1NlpActionsContainer', section, text, action);
  }
}

async function cp2DispatchDirectorFeedback(directorIdx, text){
  if(!text) return;
  const dirNames = ['D. Patel (BU Director)','C. Wright (Commercial Director)'];
  const action   = cp_classifyAction(text);
  const section  = cp_detectSection(text);
  const approver = dirNames[directorIdx] || 'Director';
  const cid = 'cp2NlpContainer'+directorIdx;
  let container  = document.getElementById(cid);
  if(!container){
    container = document.createElement('div');
    container.id = cid;
    container.className = 'cp-nlp-actions-container';
    const apCard = document.getElementById('apCard'+directorIdx);
    if(apCard) apCard.insertAdjacentElement('afterend', container);
    else {
      const cp2Inner = document.querySelector('#cp2Row .hitl-inner');
      if(cp2Inner) cp2Inner.appendChild(container);
    }
  }
  const wrapper = document.createElement('div');
  wrapper.innerHTML = cp_buildNotificationCard(action, section, text, 'CP2', approver);
  const card = wrapper.firstElementChild;
  card.style.cssText += 'opacity:0;transform:translateY(6px);transition:opacity .35s ease,transform .35s ease;';
  container.appendChild(card);
  requestAnimationFrame(()=>requestAnimationFrame(()=>{ card.style.opacity='1'; card.style.transform='translateY(0)'; }));
  cp_logToTrace('CP2', action, section, text, approver);
  if(action==='rereview'||action==='notify'||action==='flag'){
    await cp_showDispatchSequence(cid, section, text, action);
  }
}

async function cp_showDispatchSequence(containerId, section, text, action){
  const seqId    = 'cpSeq_'+Date.now();
  const leadName = section ? section.lead     : 'Bid Team';
  const leadRole = section ? section.role     : 'Lead';
  const leadClr  = section ? section.color    : '#607080';
  const leadInit = section ? section.initials : 'BT';
  const secLbl   = section ? section.key      : 'the section';
  const aLabel   = action==='rereview' ? 're-review' : 'notification';
  const steps = [
    'Parsing instruction: '+aLabel+' request detected...',
    'Identifying responsible lead for \"'+secLbl+'\"...',
    'Composing notification to '+leadName+' ('+leadRole+')...',
    'Dispatching review request via workflow orchestrator...',
    'Notification delivered \u2014 '+leadName+' alerted \u2713',
  ];
  const stepsHtml = steps.map((_,i)=>
    '<div class="cp-dispatch-step" id="'+seqId+'_s'+i+'"><div class="cp-dispatch-step-icon" id="'+seqId+'_i'+i+'"></div><span>'+_+'</span></div>'
  ).join('');
  const seqHtml =
    '<div class="cp-dispatch-seq" id="'+seqId+'">'+
    '<div class="cp-dispatch-hdr">'+
    '<div class="cp-dispatch-spinner"></div>'+
    '<div style="flex:1;"><div class="cp-dispatch-title">Orchestrator &mdash; Dispatching Review Request</div>'+
    '<div class="cp-dispatch-sub">Processing: &ldquo;'+text.slice(0,80)+(text.length>80?'...':'')+'&rdquo;</div></div>'+
    '<div class="cp-dispatch-avatar" style="background:'+leadClr+';">'+leadInit+'</div></div>'+
    '<div class="cp-dispatch-steps">'+stepsHtml+'</div>'+
    '<div class="cp-dispatch-done" id="'+seqId+'_done">'+
    '<svg viewBox="0 0 24 24" fill="none" stroke="#00a886" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>'+
    'Review request sent to <strong>'+leadName+'</strong> &mdash; pending their confirmation</div></div>';
  const container = document.getElementById(containerId);
  if(container) container.insertAdjacentHTML('beforeend', seqHtml);
  const seqEl = document.getElementById(seqId);
  if(seqEl) seqEl.scrollIntoView({behavior:'smooth',block:'nearest'});
  for(let i=0;i<steps.length;i++){
    const sEl=document.getElementById(seqId+'_s'+i);
    const iEl=document.getElementById(seqId+'_i'+i);
    if(sEl) sEl.classList.add('visible','processing');
    if(iEl) iEl.className='cp-dispatch-step-icon processing';
    await sleep(480);
    if(sEl){ sEl.classList.remove('processing'); sEl.classList.add('done'); }
    if(iEl){ iEl.className='cp-dispatch-step-icon done'; iEl.textContent='\u2713'; }
  }
  const sp=seqEl?seqEl.querySelector('.cp-dispatch-spinner'):null;
  if(sp){ sp.style.animation='none'; sp.style.borderColor='rgba(0,168,134,.3)'; sp.style.borderTopColor='#00a886'; }
  const doneEl=document.getElementById(seqId+'_done');
  if(doneEl){ await sleep(300); doneEl.classList.add('show'); }
}

/* CP2 director notes — live NLP intent detection */
function cp2OnNotesInput(directorIdx, ta){
  const val = ta.value.trim();
  const btn  = document.getElementById('cp2DispatchBtn'+directorIdx);
  const strip= document.getElementById('cp2IntentStrip'+directorIdx);
  if(btn) btn.disabled = !val;
  if(!val){ if(strip) strip.innerHTML=''; return; }
  const action  = cp_classifyAction(val);
  const section = cp_detectSection(val);
  const meta    = CP_ACTION_META[action] || CP_ACTION_META.general;
  if(strip){
    const secLabel = section ? ' — '+section.key.charAt(0).toUpperCase()+section.key.slice(1) : '';
    const leadLabel= section ? ' \u2192 '+section.lead : '';
    strip.innerHTML = `<span style="display:inline-flex;align-items:center;gap:4px;padding:1px 8px;border-radius:999px;font-size:10px;font-weight:700;background:${meta.bg};color:${meta.color};">${meta.icon} ${meta.label}${secLabel}${leadLabel}</span>`;
  }
}

/* Called when Bid Manager clicks Send Feedback in CP1 */
async function cp1HandleDispatch(){
  const ta=$('cp1Notes');
  const val=ta?ta.value.trim():'';
  if(!val) return;
  const btn=$('cp1DispatchBtn');
  if(btn){ btn.disabled=true; btn.textContent='Sending...'; }
  await cp1DispatchNlpAction(val);
  if(btn){ btn.textContent='Sent \u2713'; btn.style.background='#d4edda'; btn.style.color='#155724'; }
}

/* Called when a CP2 director clicks Send Feedback */
async function cp2HandleDirectorDispatch(directorIdx){
  const ta=document.getElementById('cp2DirectorNotes'+directorIdx);
  const val=ta?ta.value.trim():'';
  if(!val) return;
  const btn=document.getElementById('cp2DispatchBtn'+directorIdx);
  if(btn){ btn.disabled=true; btn.textContent='Sending...'; }
  await cp2DispatchDirectorFeedback(directorIdx, val);
  if(btn){ btn.textContent='Sent \u2713'; btn.style.background='#d4edda'; btn.style.color='#155724'; }
}

function cp_logToTrace(checkpoint, action, section, text, approver){
  const meta    = CP_ACTION_META[action] || CP_ACTION_META.general;
  const tbody   = document.getElementById('traceHitlLog');
  const secLbl  = section ? section.key.charAt(0).toUpperCase()+section.key.slice(1) : 'General';
  const leadInf = section ? section.lead+' ('+section.role+')' : '\u2014';
  if(tbody){
    const tr = document.createElement('tr');
    tr.innerHTML =
      '<td>'+checkpoint+' NLP</td>'+
      '<td>'+approver+'</td>'+
      '<td>'+(section?section.email:'\u2014')+'</td>'+
      '<td><span class="trace-pill trace-pill-amber">'+meta.label+'</span></td>'+
      '<td>'+ts()+'</td>'+
      '<td>'+secLbl+' \u2014 '+text.slice(0,80)+(text.length>80?'...':'')+' | Notified: '+leadInf+'</td>';
    tbody.appendChild(tr);
  }
  const gateList = document.querySelector('.hitl-gate-list');
  if(gateList){
    const div = document.createElement('div');
    div.className = 'hitl-gate-card hgc-awaiting';
    div.innerHTML =
      '<div class="hitl-gate-header">'+
      '<div class="hgc-gate-label" style="background:'+meta.bg+';color:'+meta.color+';border-color:transparent;">'+checkpoint+' \u2014 '+meta.label+'</div>'+
      '<div class="hgc-info"><div class="hgc-name">'+approver+'</div>'+
      '<div class="hgc-role">'+secLbl+' &middot; <em>'+text.slice(0,60)+(text.length>60?'...':'')+'</em></div></div>'+
      '<span class="hgc-action-pill trace-pill trace-pill-amber">'+meta.label+'</span>'+
      '<span style="font-size:11px;color:#9eadba;">'+ts()+'</span></div>';
    gateList.insertBefore(div, gateList.firstChild);
  }
}

/* CP1 notes textarea — live NLP intent detection */
function cp1OnNotesInput(ta){
  const val=ta.value.trim();
  const cc=$('cp1CharCount');if(cc)cc.textContent=ta.value.length;
  const hint=$('cp1NlpHint');
  const strip=$('cp1IntentStrip');
  const dispatchBtn=$('cp1DispatchBtn');
  if(dispatchBtn) dispatchBtn.disabled=!val;
  if(!val){
    if(hint)hint.textContent='';
    if(strip)strip.innerHTML='';
    return;
  }
  /* Enhanced NLP detection using cp_classifyAction */
  const action  = cp_classifyAction(val);
  const section = cp_detectSection(val);
  const meta    = CP_ACTION_META[action]||CP_ACTION_META.general;
  if(hint) hint.textContent = meta.label;
  if(strip){
    const secLabel = section ? ' — '+section.key.charAt(0).toUpperCase()+section.key.slice(1) : '';
    const leadLabel= section ? ' → '+section.lead : '';
    strip.innerHTML = `<span style="display:inline-flex;align-items:center;gap:4px;padding:1px 8px;border-radius:999px;font-size:10px;font-weight:700;background:${meta.bg};color:${meta.color};">${meta.icon} ${meta.label}${secLabel}${leadLabel}</span>`;
  }
  const intent=rdaClassifyIntent(val);
  const intentColors={remove:'#fee2e2;color:#7f1d1d',rephrase:'#ede9fe;color:#5b21b6',add:'#d4edda;color:#155724',reorder:'#dbeafe;color:#0c4a6e',custom:'var(--surface-3);color:#37474f'};
  const c=intentColors[intent.type]||intentColors.custom;
  if(hint)hint.textContent='Intent detected: '+intent.label;
  if(strip)strip.innerHTML=`<span style="background:${c};border-radius:999px;padding:1px 7px;font-size:10px;font-weight:700;">${intent.icon} ${intent.label}</span>`;
}

function rdaSkipFeedback(){
  const row=$('rdaFeedbackRow');
  if(row){row.style.transition='opacity .3s ease';row.style.opacity='0';setTimeout(()=>row.remove(),320);}
  if(rdaFeedbackResolver)rdaFeedbackResolver();
}

/* Return a Promise that resolves when user skips or after a retrigger cycle */
function waitForRdaFeedback(){
  return new Promise(resolve=>{
    rdaFeedbackResolver=resolve;
  });
}

/* Reset RDA state on workflow reset */
function resetRdaState(){
  rdaFeedbackHistory=[];
  rdaRetriggerCount=0;
  rdaFeedbackResolver=null;
  const fp=$('rdaFeedbackRow');if(fp)fp.remove();
  const rr=$('rdaRetriggerRow');if(rr)rr.remove();
}

/* ═══════════════════════════════════════
   AGENT INSPECT MODAL — JS
═══════════════════════════════════════ */

/* Which agents have a dedicated inspect modal — keyed by agent index */
const INSPECT_AGENTS={1:true,3:true}; /* 1 = ITT intake & analysis agent, 3 = Governance pack agent */

function openAgentInspect(agentIndex){
    /* Governance pack agent (index 3) — open dedicated gov pack modal */
    if(agentIndex===3){ openGovPackModal(); return; }
    /* Set header branding to match agent colour */
    const m=META[agentIndex];
  const ag=AGENTS[agentIndex];
  const icon=document.getElementById('inspectModalIcon');
  const title=document.getElementById('inspectModalTitle');
  const sub=document.getElementById('inspectModalSub');
  if(icon)icon.style.background=m.bg;
  if(title)title.textContent=ag.AGENT_NAME+' — Output Inspector';
  if(sub)sub.textContent='Detailed outputs, analysis & data generated by this agent';
  /* Reset tabs to first */
  document.querySelectorAll('.inspect-tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.inspect-pane').forEach(p=>p.classList.remove('active'));
  const firstTab=document.querySelector('.inspect-tab[data-itab="brief"]');
  const firstPane=document.getElementById('ipane-brief');
  if(firstTab)firstTab.classList.add('active');
  if(firstPane)firstPane.classList.add('active');
    /* Animate criteria bars after short delay */
  setTimeout(animateTsbBars,350);
  openModal('agentInspectModal');
}

/* Open inspect modal directly on a specific tab — called from clickable outcome items */
function openAgentInspectTab(agentIndex,tabId){
  const m=META[agentIndex];
  const ag=AGENTS[agentIndex];
  const icon=document.getElementById('inspectModalIcon');
  const title=document.getElementById('inspectModalTitle');
  const sub=document.getElementById('inspectModalSub');
  if(icon){icon.style.background=m.bg;const svg=icon.querySelector('svg');if(svg)svg.setAttribute('stroke',m.color);}
  if(title)title.textContent=ag.AGENT_NAME+' — Output Inspector';
  if(sub)sub.textContent='Detailed outputs, analysis & data generated by this agent';
  /* Activate requested tab */
  document.querySelectorAll('.inspect-tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.inspect-pane').forEach(p=>p.classList.remove('active'));
  const targetTab=document.querySelector('.inspect-tab[data-itab="'+tabId+'"]');
  const targetPane=document.getElementById('ipane-'+tabId);
  if(targetTab)targetTab.classList.add('active');
  if(targetPane)targetPane.classList.add('active');
  /* Trigger matching animation */
  if(tabId==='brief')setTimeout(animateTsbBars,350);
  if(tabId==='risk')setTimeout(animateSpiderChart,400);
  openModal('agentInspectModal');
}

function animateSpiderChart(){
  const poly=document.getElementById('spiderDataPoly');
  if(poly)poly.style.opacity='1';
  document.querySelectorAll('.spider-dot').forEach(dot=>{
    dot.style.opacity='1';
  });
}

function animateTsbBars(){
  document.querySelectorAll('#ipane-brief .tsb-criteria-bar-fill').forEach((fill,i)=>{
    setTimeout(()=>{
      const pct=fill.style.getPropertyValue('--tsb-pct')||'0%';
      fill.style.width=pct;
    },i*100);
  });
}

function initInspectTabs(){
  document.querySelectorAll('.inspect-tab').forEach(tab=>{
    tab.addEventListener('click',()=>{
      document.querySelectorAll('.inspect-tab').forEach(t=>t.classList.remove('active'));
      document.querySelectorAll('.inspect-pane').forEach(p=>p.classList.remove('active'));
      tab.classList.add('active');
      const pane=document.getElementById('ipane-'+tab.dataset.itab);
      if(pane){pane.classList.add('active');}
      if(tab.dataset.itab==='brief')setTimeout(animateTsbBars,100);
      if(tab.dataset.itab==='risk')setTimeout(animateSpiderChart,200);
    });
  });
}

function initRclFilters(){
  document.querySelectorAll('.rcl-filter-btn').forEach(btn=>{
    btn.addEventListener('click',()=>{
      document.querySelectorAll('.rcl-filter-btn').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      const filter=btn.dataset.filter;
      document.querySelectorAll('#rclList .rcl-card').forEach(card=>{
        if(filter==='all'){
          card.style.display='';
        } else {
          card.style.display=card.dataset.riskLevel===filter?'':'none';
        }
      });
    });
  });
}

function filterCmtTable(){
  const q=document.getElementById('cmtSearchInput').value.toLowerCase();
  document.querySelectorAll('#cmtTableBody tr').forEach(row=>{
    row.style.display=row.textContent.toLowerCase().includes(q)?'':'none';
  });
}

let cmtSortCol=0,cmtSortAsc=true;
function sortCmtTable(col){
  if(cmtSortCol===col){cmtSortAsc=!cmtSortAsc;}else{cmtSortCol=col;cmtSortAsc=true;}
  document.querySelectorAll('.cmt-table thead th').forEach((th,i)=>{
    th.classList.toggle('sorted',i===col);
  });
  const tbody=document.getElementById('cmtTableBody');
  const rows=Array.from(tbody.querySelectorAll('tr'));
  rows.sort((a,b)=>{
    const aT=a.cells[col]?a.cells[col].textContent.trim():'';
    const bT=b.cells[col]?b.cells[col].textContent.trim():'';
    return cmtSortAsc?aT.localeCompare(bT):bT.localeCompare(aT);
  });
  rows.forEach(r=>tbody.appendChild(r));
}

/* Inject inspect button below agent badge after completion */
function injectInspectButton(agentIndex){
  if(!INSPECT_AGENTS[agentIndex])return;
  const badge=document.getElementById('ab'+agentIndex);
  if(!badge)return;
  const btn=document.createElement('button');
  btn.className='agent-inspect-btn';
  btn.innerHTML=`<svg viewBox="0 0 24 24" style="display:none"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>Inspect Output`;
  btn.onclick=()=>openAgentInspect(agentIndex);
  badge.insertAdjacentElement('afterend',btn);
}

/* ═══════════════════════════════════════
   TRACE MODAL — INTERACTIVE ENHANCEMENTS
═══════════════════════════════════════ */

/* ── Tab switching ── */
function initTraceTabs(){
  document.querySelectorAll('.trace-tab').forEach(tab=>{
    tab.addEventListener('click',()=>{
      const target=tab.dataset.tab;
      document.querySelectorAll('.trace-tab').forEach(t=>t.classList.remove('active'));
      document.querySelectorAll('.trace-pane').forEach(p=>p.classList.remove('active'));
      tab.classList.add('active');
      const pane=document.getElementById('pane-'+target);
      if(pane){
        pane.classList.add('active');
        if(target==='perf')animatePerfBars();
        if(target==='agents')animateExpandedBars();
      }
    });
  });
}

/* ── Expand/collapse agent cards ── */
function initAgentCards(){
  document.querySelectorAll('.agent-exec-card').forEach(card=>{
    card.addEventListener('click',()=>{
      const wasExpanded=card.classList.contains('expanded');
      document.querySelectorAll('.agent-exec-card').forEach(c=>c.classList.remove('expanded'));
      if(!wasExpanded){
        card.classList.add('expanded');
        /* Animate the confidence bar after expand transition */
        setTimeout(()=>{
          card.querySelectorAll('.aec-conf-fill').forEach(fill=>{
            const w=fill.style.getPropertyValue('--conf-width')||'100%';
            fill.style.width=w;
          });
        },120);
      }
    });
  });
}

/* ── Animate performance bars when tab opens ── */
function animatePerfBars(){
  document.querySelectorAll('.perf-metric-row').forEach((row,i)=>{
    setTimeout(()=>{
      row.classList.add('in-view');
    },i*120);
  });
}

/* ── Animate any open agent card bars ── */
function animateExpandedBars(){
  document.querySelectorAll('.agent-exec-card.expanded .aec-conf-fill').forEach(fill=>{
    const w=fill.style.getPropertyValue('--conf-width')||'100%';
    fill.style.width=w;
  });
}

/* ── Sync live agent status into trace modal cards + summary pills ── */
function syncTraceAgentStatus(agentIndex,status){
  /* Agent execution tab pills */
  const pill=document.getElementById('aec-pill-'+agentIndex);
  if(pill){
    if(status==='complete'){
      pill.className='trace-pill trace-pill-green';
      pill.textContent='Complete';
    } else if(status==='active'){
      pill.className='trace-pill trace-pill-blue';
      pill.innerHTML='<span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:#1976d2;animation:pulseDot 1s ease-in-out infinite;vertical-align:middle;margin-right:3px;"></span>Active';
    }
  }
  /* Agent execution card state */
  const card=document.querySelector('.agent-exec-card[data-aec="'+agentIndex+'"]');
  if(card){
    if(status==='complete'){card.classList.remove('aec-pending','aec-active');card.classList.add('aec-complete');}
    else if(status==='active'){card.classList.remove('aec-pending');card.classList.add('aec-active');}
  }
  /* Summary tab pills */
  const sumPill=document.getElementById('sum-pill-'+agentIndex);
  if(sumPill){
    if(status==='complete'){sumPill.className='trace-pill trace-pill-green';sumPill.textContent='Complete';}
    else if(status==='active'){sumPill.className='trace-pill trace-pill-blue';sumPill.innerHTML='<span style="display:inline-block;width:7px;height:7px;border-radius:50%;background:#1976d2;animation:pulseDot 1s ease-in-out infinite;vertical-align:middle;margin-right:3px;"></span>Active';}
  }
  /* Tab badge counter */
  const done=document.querySelectorAll('.agent-exec-card.aec-complete').length;
  const badge=document.getElementById('tabBadgeAgents');
  if(badge)badge.textContent=done+'/6';
}

/* ── Sync HitL gate status into trace modal ── */
function syncTraceHitlStatus(gateIndex,action,timestamp){
  /* Update visible gate cards */
  const actionEl=document.getElementById('hgc-action-'+gateIndex);
  const tsEl=document.getElementById('hgc-ts-'+gateIndex);
  const card=document.querySelectorAll('.hitl-gate-card')[gateIndex];
  if(actionEl){
    if(action==='Approved'){
      actionEl.className='hgc-action-pill trace-pill trace-pill-green';
      actionEl.textContent='Approved';
      if(card){card.classList.remove('hgc-awaiting');card.classList.add('hgc-approved');}
    } else if(action==='Rejected'){
      actionEl.className='hgc-action-pill trace-pill trace-pill-rose';
      actionEl.textContent='Rejected';
    } else {
      actionEl.className='hgc-action-pill trace-pill trace-pill-amber';
      actionEl.textContent=action;
    }
  }
  if(tsEl&&timestamp)tsEl.textContent=timestamp;
  /* Tab badge */
  const approved=document.querySelectorAll('.hitl-gate-card.hgc-approved').length;
  const badge=document.getElementById('tabBadgeHitl');
  if(badge)badge.textContent=approved+'/2';
  /* Keep hidden tbody in sync for legacy JS that reads it */
  const rows=document.querySelectorAll('#traceHitlLog tr');
  if(rows[gateIndex]){
    const cells=rows[gateIndex].querySelectorAll('td');
    const oldPill=cells[3]&&cells[3].querySelector('.trace-pill');
    if(oldPill){
      if(action==='Approved'){oldPill.className='trace-pill trace-pill-green';oldPill.textContent='Approved';}
      else if(action==='Rejected'){oldPill.className='trace-pill trace-pill-rose';oldPill.textContent='Rejected';}
      else{oldPill.className='trace-pill trace-pill-amber';oldPill.textContent=action;}
    }
    if(cells[4]&&timestamp)cells[4].textContent=timestamp;
  }
}

/* ── Open trace modal with tab reset ── */
const _origOpenTraceModal=openTraceModal;
openTraceModal=function(){
  _origOpenTraceModal();
  /* Switch to summary tab on open */
  document.querySelectorAll('.trace-tab').forEach(t=>t.classList.remove('active'));
  document.querySelectorAll('.trace-pane').forEach(p=>p.classList.remove('active'));
  const sumTab=document.querySelector('.trace-tab[data-tab="summary"]');
  const sumPane=document.getElementById('pane-summary');
  if(sumTab)sumTab.classList.add('active');
  if(sumPane)sumPane.classList.add('active');
};

/* ── Patch updateTraceHitl to also update new UI ── */
const _origUpdateTraceHitl=updateTraceHitl;
updateTraceHitl=function(rowIdx,action,time,notes){
  _origUpdateTraceHitl(rowIdx,action,time,notes);
  syncTraceHitlStatus(rowIdx,action,time);
};

/* ── Patch renderAgent to also sync trace cards ── */
const _origRenderAgent=renderAgent;
renderAgent=async function(i){
  syncTraceAgentStatus(i,'active');
  await _origRenderAgent(i);
  syncTraceAgentStatus(i,'complete');
  /* Record duration from elapsed clock */
  const durEl=document.getElementById('aec-dur-'+i);
  if(durEl&&kTime.textContent&&kTime.textContent!=='—')durEl.textContent=kTime.textContent;
};

/* ── Init on DOM ready ── */
window.addEventListener('DOMContentLoaded',()=>{
    initTraceTabs();
    initAgentCards();
    initInspectTabs();
    initRclFilters();
    initGovPackTabs();
});

/* Gov Pack modal tab switching */
function initGovPackTabs(){
    document.querySelectorAll('#govPackTabs .inspect-tab').forEach(tab=>{
      tab.addEventListener('click',()=>{
        const id=tab.dataset.gptab;
        document.querySelectorAll('#govPackTabs .inspect-tab').forEach(t=>t.classList.remove('active'));
        document.querySelectorAll('.gp-pane').forEach(p=>p.classList.remove('active'));
        tab.classList.add('active');
        const pane=document.getElementById('gppane-'+id);
        if(pane){
          pane.classList.add('active');
          /* Animate compliance bars when compliance tab is opened */
          if(id==='compliance'){
            setTimeout(()=>{
              pane.querySelectorAll('.gp-comp-bar-fill').forEach(bar=>{
                bar.style.width=(bar.dataset.pct||'0')+'%';
              });
            },300);
          }
        }
      });
    });
}

/* Reset gov pack modal state on close */
function closeGovPackModal(){
    closeModal('govPackModal');
    /* Reset to first tab */
    document.querySelectorAll('#govPackTabs .inspect-tab').forEach((t,i)=>t.classList.toggle('active',i===0));
    document.querySelectorAll('.gp-pane').forEach((p,i)=>p.classList.toggle('active',i===0));
    /* Hide sign-off banner */
    const banner=document.getElementById('gpSignOffBanner');
    if(banner)banner.classList.remove('show');
    /* Reset compliance bars */
    document.querySelectorAll('.gp-comp-bar-fill').forEach(b=>b.style.width='0%');
}

/* ═══════════════════════════════════════════
   RISK MITIGATION CONSOLE ENGINE
   Runs after file upload — calls /api/assess-risk
   with extracted tender data (or defaults)
═══════════════════════════════════════════ */

async function runRiskEngine(){
  const console_el = $('riskConsole');
  if(!console_el) return;

  /* Show the console */
  console_el.classList.add('show');

  /* Reset all step icons */
  for(let i=0;i<6;i++){
    const step  = $('rcStep'+i);
    const icon  = $('rcStepIcon'+i);
    if(step){ step.classList.remove('visible'); }
    if(icon){ icon.className='rc-step-icon'; icon.textContent=''; }
  }

  /* Hide result sections */
  const grid = $('rcGrid');
  const scoreWrap = $('rcScoreWrap');
  const flagsEl = $('rcFlags');
  const toggle = $('rcToggle');
  if(grid)      { grid.style.display='none'; }
  if(scoreWrap) { scoreWrap.style.display='none'; }
  if(flagsEl)   { flagsEl.style.display='none'; flagsEl.innerHTML=''; }
  if(toggle)    { toggle.style.display='none'; }

  /* Reset Go/No-Go badge to scanning */
  const gonogo = $('rcGoNogo');
  const gonogoLabel = $('rcGoNogoLabel');
  if(gonogo)     { gonogo.className='rc-gonogo scanning'; }
  if(gonogoLabel){ gonogoLabel.textContent='Scanning\u2026'; }

  /* Update sub-header */
  const sub = $('rcHeaderSub');
  if(sub) sub.textContent = 'Analysing uploaded ITT document\u2026';

  /* Show steps panel */
  const stepsEl = $('rcSteps');
  if(stepsEl) stepsEl.style.display='block';

  /* Animate steps one by one */
  const stepDelays = [0, 400, 850, 1300, 1750, 2200];
  for(let i=0;i<6;i++){
    await sleep(stepDelays[i]);
    const step = $('rcStep'+i);
    const icon = $('rcStepIcon'+i);
    if(step) step.classList.add('visible');
    if(icon) { icon.className='rc-step-icon processing'; }
    await sleep(350);
    if(icon) { icon.className='rc-step-icon done'; icon.textContent='\u2713'; }
  }

  /* Call the risk API */
  let riskData = null;
  try{
    const payload = trsExtractedData || {};
    const resp = await fetch('/api/assess-risk',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    });
    if(resp.ok){ riskData = await resp.json(); }
  }catch(e){
    console.warn('[Risk Engine] API call failed:', e);
  }

  if(!riskData || riskData.error){
    if(sub) sub.textContent = 'Risk assessment unavailable — using defaults.';
    return;
  }

  /* ── Render dimension grid ── */
  if(grid){
    grid.style.display='grid';
    const dimMap = {
      commercial:  { score:'rcScoreCommercial', bar:'rcBarCommercial', tag:'rcTagCommercial' },
      technical:   { score:'rcScoreTechnical',  bar:'rcBarTechnical',  tag:'rcTagTechnical'  },
      programme:   { score:'rcScoreProgramme',  bar:'rcBarProgramme',  tag:'rcTagProgramme'  },
      supply_chain:{ score:'rcScoreSupply',     bar:'rcBarSupply',     tag:'rcTagSupply'     },
      strategic:   { score:'rcScoreStrategic',  bar:'rcBarStrategic',  tag:'rcTagStrategic'  }
    };
    const dims = riskData.dimensions || {};
    Object.keys(dimMap).forEach(key=>{
      const d    = dims[key] || {};
      const ids  = dimMap[key];
      const scoreEl = $(ids.score);
      const barEl   = $(ids.bar);
      const tagEl   = $(ids.tag);
      const score   = d.score || 0;
      const label   = d.label || 'low';
      if(scoreEl){ scoreEl.textContent = score; scoreEl.className='rc-cell-score '+label; }
      if(barEl)  { barEl.className='rc-cell-bar '+label; requestAnimationFrame(()=>requestAnimationFrame(()=>{ barEl.style.width=Math.min(score,100)+'%'; })); }
      if(tagEl)  { tagEl.textContent = label.charAt(0).toUpperCase()+label.slice(1)+' risk'; }
    });
  }

  /* ── Render overall score ring ── */
  const overall = riskData.overall_score || 0;
  const overallLabel = riskData.overall_label || 'low';
  if(scoreWrap){
    scoreWrap.style.display='flex';
    const valEl  = $('rcOverallScore');
    const fillEl = $('rcRingFill');
    const titleEl= $('rcScoreTitle');
    const descEl = $('rcScoreDesc');
    if(valEl)  { valEl.textContent = overall; }
    if(titleEl){ titleEl.textContent = riskData.decision_label || 'Risk Assessment Complete'; }
    if(descEl) { descEl.textContent  = riskData.decision_desc  || ''; }
    /* Ring colour */
    const ringColors = { low:'#00a886', medium:'#d97706', high:'#EC1B2E' };
    const ringColor  = ringColors[overallLabel] || '#d97706';
    /* Animate dashoffset: circumference = 2*pi*26 ≈ 163.4 */
    const circ   = 163;
    const offset = circ - (overall / 100) * circ;
    if(fillEl){
      fillEl.style.stroke = ringColor;
      fillEl.style.strokeDashoffset = circ; /* start full */
      requestAnimationFrame(()=>requestAnimationFrame(()=>{
        fillEl.style.transition='stroke-dashoffset .9s cubic-bezier(.22,1,.36,1),stroke .3s ease';
        fillEl.style.strokeDashoffset = offset;
      }));
    }
  }

  /* ── Render Go/No-Go badge ── */
  const decision = riskData.decision || 'conditional';
  if(gonogo)     { gonogo.className='rc-gonogo '+decision; }
  if(gonogoLabel){ gonogoLabel.textContent = riskData.decision_label || decision.toUpperCase(); }

    /* ── Render risk flags with mitigation intelligence ── */
  const flags = riskData.flags || [];
  if(flagsEl && flags.length){
    flagsEl.style.display='flex';
    flagsEl.innerHTML = flags.slice(0,8).map((f,fi)=>{
      const level = f.level || 'medium';
      const steps = (f.mitigation_steps || []).map((s,si)=>`
        <div class="rc-mit-step">
          <div class="rc-mit-num">${si+1}</div>
          <span>${s}</span>
        </div>`).join('');
      const urgencyColor = f.urgency&&f.urgency.toLowerCase().includes('critical')?'#EC1B2E'
        :f.urgency&&f.urgency.toLowerCase().includes('cp1')?'#d97706':'#607080';
      return `
      <div class="rc-flag ${level}" id="rcFlag${fi}">
        <div class="rc-flag-header" onclick="rcToggleFlag(${fi})">
          <span class="rc-flag-badge">${level.toUpperCase()}</span>
          <div class="rc-flag-text">
            <div class="rc-flag-title">${f.title||''}</div>
            <div class="rc-flag-detail">${f.detail||''}</div>
          </div>
          <div class="rc-flag-meta">
            ${f.owner?`<span class="rc-flag-owner"><svg viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>${f.owner}</span>`:''}
            ${f.urgency?`<span class="rc-flag-urgency" style="color:${urgencyColor}">⏰ ${f.urgency}</span>`:''}
          </div>
          <div class="rc-flag-chevron" id="rcFlagChevron${fi}">
            <svg viewBox="0 0 24 24"><polyline points="6 9 12 15 18 9"/></svg>
          </div>
        </div>
        <div class="rc-flag-body" id="rcFlagBody${fi}">
          ${steps?`<div class="rc-mit-section">
            <div class="rc-mit-label">
              <svg viewBox="0 0 24 24"><polyline points="9 11 12 14 22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>
              Mitigation Steps
            </div>
            <div class="rc-mit-steps">${steps}</div>
          </div>`:''}
          ${f.forecast?`<div class="rc-forecast">
            <div class="rc-forecast-label">
              <svg viewBox="0 0 24 24"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
              Risk Forecast
            </div>
            <div class="rc-forecast-text">${f.forecast}</div>
          </div>`:''}
        </div>
      </div>`;
    }).join('');
  }

  /* ── Update sub-header ── */
  if(sub){
    const tenderTitle = riskData.tender_title || 'ITT Document';
    const clientName  = riskData.client_name  || '';
    sub.textContent   = `${tenderTitle}${clientName?' \u00b7 '+clientName:''} \u00b7 ${flags.length} risk flag${flags.length!==1?'s':''} identified`;
  }

  /* ── Show toggle ── */
  if(toggle) toggle.style.display='flex';

  /* ── Hide steps after result renders ── */
  await sleep(600);
  if(stepsEl) stepsEl.style.display='none';
}

/* ═══════════════════════════════════════════
   GOVERNANCE PACK MODAL — Agent 3 Output
   Opened from: Inspect Output button (agent row)
   Also launched from CP1 & CP2 approve buttons
═══════════════════════════════════════════ */

function openGovPackModal(){
  openModal('govPackModal');
  /* Animate compliance bars on open */
  setTimeout(()=>{
    document.querySelectorAll('.gp-comp-bar-fill').forEach(bar=>{
      const pct = bar.dataset.pct || '0';
      bar.style.width = pct + '%';
    });
  }, 350);
}

/* Called from CP1 approve button — open gov pack for director review before sign-off */
function cp1OpenGovPackAndApprove(){
  /* Show a prompt overlay inside the gov pack modal after open */
  openGovPackModal();
  /* After modal opens, show the sign-off banner */
  setTimeout(()=>{
    const banner = document.getElementById('gpSignOffBanner');
    if(banner) banner.classList.add('show');
  }, 600);
}

/* Toggle full console detail expand/collapse */
function rcToggleDetails(){
  const flagsEl  = $('rcFlags');
  const grid     = $('rcGrid');
  const iconEl   = $('rcToggleIcon');
  const labelEl  = $('rcToggleLabel');
  if(!flagsEl) return;
  const hidden = flagsEl.style.display==='none';
  if(grid)    grid.style.display    = hidden?'grid':'none';
  if(flagsEl) flagsEl.style.display = hidden?'flex':'none';
  if(iconEl)  iconEl.style.transform= hidden?'':'rotate(180deg)';
  if(labelEl) labelEl.textContent   = hidden?'Hide detail':'Show detail';
}

/* Toggle individual flag mitigation body */
function rcToggleFlag(fi){
  const body    = $('rcFlagBody'+fi);
  const chevron = $('rcFlagChevron'+fi);
  const flag    = $('rcFlag'+fi);
  if(!body) return;
  const isOpen = body.classList.contains('open');
  body.classList.toggle('open', !isOpen);
  if(chevron) chevron.classList.toggle('open', !isOpen);
  if(flag)    flag.classList.toggle('expanded', !isOpen);
}