/**
 * Phase 5: RCGCC Case Hub Wiring (FINAL)
 * - Uses /api/claims (real DB)
 * - Keeps RCGCC HTML/CSS untouched
 * - Disables old AMIS agentCycle (calls /api/messages/demo)
 */
(function () {
  if (typeof SentinelAPI === "undefined") {
    console.error("SentinelAPI not loaded.");
    return;
  }

  // Disable old agentCycle that calls /api/messages/demo (AMIS-specific endpoint)
  window.cycleRunning = true;
  window.nextTimer = null;
  window.scheduleNextCycle = function () { /* disabled */ };

  // DOM refs (these IDs exist in RCGCC.html)
  const tbody = document.getElementById("dataBody");
  const searchInput = document.getElementById("tableSearch");
  const statusFilter = document.getElementById("statusFilter");
  const rowsPerPageSelect = document.getElementById("rowsPerPage");
  const pageInfo = document.getElementById("pageInfo");
  const pagination = document.getElementById("pagination");
  const btnRefresh = document.getElementById("btnRefresh");

  let limit = Number(rowsPerPageSelect?.value || 10);
  let offset = 0;
  let total = 0;

  // Mapping helper: ClaimCase -> existing table row model
  function mapCaseToRow(c) {
    const identity = c.identity || {};
    const lifecycle = c.lifecycle || {};
    const intel = c.intelligence || {};

    const caseId = c.case_id || identity.case_id || "";
    const createdAt = c.created_at || (c.audit && c.audit.created_at) || new Date().toISOString();

    const score = (c.fraud_score ?? intel.fraud_score);
    const conf = (c.fraud_confidence ?? intel.fraud_confidence);
    const status = c.status || lifecycle.status || "INTAKE";

    return {
      case_id: caseId,
      received_at: createdAt,
      triage_confidence: conf != null ? Number(conf) : (score != null ? Math.min(0.99, Number(score) / 100) : 0.5),
      sla_due_at: new Date(new Date(createdAt).getTime() + 8 * 3600 * 1000).toISOString(),
      status: status,
      event_type: score != null ? `Fraud Score ${score}` : "Claim Created",
      subject: `${caseId} · ${(identity.claim_type || "—")} · ${(identity.jurisdiction || "—")}`
    };
  }

  function fmtLocal(iso) {
    try { return new Date(iso).toLocaleString(); } catch { return iso || "—"; }
  }

  function badgeClassConfidence(v) {
    v = Number(v || 0);
    if (v >= 0.8) return "badge-chip chip-green";
    if (v >= 0.6) return "badge-chip chip-yellow";
    return "badge-chip chip-red";
  }

  function badgeClassStatus(s) {
    s = (s || "").toUpperCase();
    if (s === "CLOSED") return "badge-chip chip-green";
    if (s === "HUMAN_REVIEW") return "badge-chip chip-yellow";
    if (s === "ESCALATED") return "badge-chip chip-red";
    return "badge-chip chip-grey";
  }

  function renderRows(rows) {
    if (!tbody) return;
    tbody.innerHTML = rows.map((r, i) => `
      <tr style="cursor:pointer" onclick="rcgccRowClick(${i})">
        <td>${fmtLocal(r.received_at)}</td>
        <td><span class="${badgeClassConfidence(r.triage_confidence)}">${Number(r.triage_confidence).toFixed(2)}</span></td>
        <td>${fmtLocal(r.sla_due_at)}</td>
        <td><span class="${badgeClassStatus(r.status)}">${r.status}</span></td>
        <td><span class="badge-chip chip-grey">${r.event_type}</span></td>
        <td class="text-truncate" style="max-width:420px">${r.subject}</td>
      </tr>
    `).join("");
  }

  function renderPagination() {
    if (!pagination) return;
    const pages = Math.max(1, Math.ceil(total / limit));
    const currentPage = Math.floor(offset / limit) + 1;

    pagination.innerHTML = `
      <li class="page-item ${currentPage === 1 ? "disabled" : ""}">
        <a class="page-link" href="#" data-page="${currentPage - 1}">Prev</a>
      </li>
      <li class="page-item disabled"><span class="page-link">${currentPage} / ${pages}</span></li>
      <li class="page-item ${currentPage === pages ? "disabled" : ""}">
        <a class="page-link" href="#" data-page="${currentPage + 1}">Next</a>
      </li>
    `;

    pagination.querySelectorAll("a[data-page]").forEach(a => {
      a.addEventListener("click", (e) => {
        e.preventDefault();
        const p = Number(a.dataset.page);
        if (p < 1) return;
        offset = (p - 1) * limit;
        load();
      });
    });
  }

  window.load = async function () {
    window.load = async  const q = (searchInput?.value || "").trim();
    const status = (statusFilter?.value || "").trim();

    try {
      const resp = await SentinelAPI.listClaims({
        limit,
        offset,
        status: status || null,
        q: q || null
      });

      const items = resp.items || [];
      total = resp.total || items.length;

      const rows = items.map(c => ({
        case_id: c.case_id,
        received_at: c.created_at,
        triage_confidence: c.fraud_confidence || 0.5,
        sla_due_at: c.sla_due_ts || c.created_at,
        status: c.status,
        event_type: c.fraud_score ? `Fraud Score ${c.fraud_score}` : "New Claim",
        subject: `${c.case_id} · ${c.claim_type || "—"} · ${c.jurisdiction || "—"}`
      }));

      window._rcgccRows = rows;
      renderRows(rows);

      if (pageInfo) {
        const shownTo = Math.min(offset + limit, total);
        pageInfo.textContent =
          total === 0
            ? "Showing 0 records"
            : `Showing ${offset + 1} to ${shownTo} of ${total}`;
      }

      renderPagination();

    } catch (e) {
      console.error(e);
      showError("Load failed: " + e.message);
    }
  };


  // Row click: navigate to studio with case_id
  window.rcgccRowClick = function (idx) {
    const row = (window._rcgccRows || [])[idx];
    if (!row || !row.case_id) return;
    sessionStorage.setItem("sentinel_case_id", row.case_id);
    window.location.href = "/tender-response-studio";
  };

  // Wire controls
  searchInput?.addEventListener("input", () => { offset = 0; load(); });
  statusFilter?.addEventListener("change", () => { offset = 0; load(); });
  rowsPerPageSelect?.addEventListener("change", () => {
    limit = Number(rowsPerPageSelect.value || 10);
    offset = 0;
    load();
  });

  // Run agent wave -> backend batch run -> refresh
  btnRefresh?.addEventListener("click", async () => {
    try {
      await SentinelAPI.runBatch(10);
      showSuccess("Agent wave executed");
      offset = 0;
      load();
    } catch (e) {
      console.error(e);
      showError("Agent wave failed: " + e.message);
    }
  });

  // Init
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", load);
  } else {
    load();
  }

  console.log("[RCGCC] Phase 5 Case Hub wiring active");
})();
// Auto-refresh: pull latest cases every 12 seconds
setInterval(() => {
  if (typeof window.load === "function") {
    window.load();
  }
}, 12000);
