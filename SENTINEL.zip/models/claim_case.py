"""
ClaimCase Model
===============
Core insurance claim record.

Separation of concerns:
  - Immutable identity (policy_id, claim_type, loss_date)
  - System intelligence (fraud_score, network_risk_flag)
  - Human authority (handler_decision, referred_unit)
  - Audit trail (created_at, updated_at, last_agent_run)
"""

from datetime import datetime
from . import db


class ClaimCase(db.Model):
    """
    Insurance claim case record.
    
    Invariants:
      - Agents generate intelligence; they never decide
      - Humans review, decide, and record decisions
      - System maintains explicit audit trail
    """
    __tablename__ = 'claim_cases'

    # ─────────────────────────────────────────────────────────────────
    # IDENTITY (immutable facts)
    # ─────────────────────────────────────────────────────────────────
    
    id = db.Column(db.Integer, primary_key=True)
    case_id = db.Column(db.String(50), unique=True, nullable=False, index=True)
    policy_id = db.Column(db.String(100), nullable=False, index=True)
    claimant_id = db.Column(db.String(100), nullable=False)
    claim_type = db.Column(db.String(50), nullable=False)  # e.g. 'Motor', 'Property', 'Health'
    coverage_type = db.Column(db.String(100), nullable=True)  # specific coverage under policy
    
    loss_date = db.Column(db.DateTime, nullable=False)
    reported_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    jurisdiction = db.Column(db.String(50), nullable=True)  # for multi-jurisdiction handling
    
    # ─────────────────────────────────────────────────────────────────
    # LIFECYCLE (workflow state, not decisions)
    # ─────────────────────────────────────────────────────────────────
    
    status = db.Column(
        db.String(50),
        nullable=False,
        default='INTAKE'
        # Allowed: INTAKE, INVESTIGATING, HUMAN_REVIEW, ESCALATED, CLOSED
    )
    current_stage = db.Column(db.String(100), nullable=True)  # e.g. 'initial_triage', 'agent_analysis'
    assigned_handler = db.Column(db.String(100), nullable=True)  # human assigned to review
    sla_start_ts = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    sla_due_ts = db.Column(db.DateTime, nullable=True)
    
    # ─────────────────────────────────────────────────────────────────
    # SYSTEM INTELLIGENCE (agent outputs, not final authority)
    # ─────────────────────────────────────────────────────────────────
    
    fraud_score = db.Column(db.Float, default=0.0)  # 0.0 – 100.0
    fraud_band = db.Column(db.String(20), default='LOW')  # LOW, REVIEW, HIGH
    fraud_confidence = db.Column(db.Float, default=0.0)  # 0.0 – 1.0 (model certainty)
    
    network_risk_flag = db.Column(db.Boolean, default=False)  # cross-policy / ring-fence risk
    ring_fence_indicator = db.Column(db.String(100), nullable=True)  # e.g. 'STAGED_CLAIMS', 'TIMING_PATTERN'
    
    triggered_indicators = db.Column(db.Text, nullable=True)  # JSON or comma-separated list
    reasoning_summary = db.Column(db.Text, nullable=True)  # short explanation of intelligence
    evidence_refs = db.Column(db.Text, nullable=True)  # references to evidence records
    source_filename = db.Column(db.String(255), nullable=True)
    source_text = db.Column(db.Text, nullable=True)
    ingestion = db.Column(db.JSON, nullable=True)
    
    # ─────────────────────────────────────────────────────────────────
    # SYSTEM RECOMMENDATION (what agents suggest)
    # ─────────────────────────────────────────────────────────────────
    
    recommended_referral = db.Column(db.String(100), nullable=True)
    # e.g. 'FRAUD_INVESTIGATION', 'POLICE_REFERRAL', 'MEDICAL_REVIEW', 'CLEAR'
    
    recommended_action = db.Column(db.Text, nullable=True)  # narrative recommendation
    
    # ─────────────────────────────────────────────────────────────────
    # HUMAN DECISION (immutable once recorded)
    # ─────────────────────────────────────────────────────────────────
    
    handler_decision = db.Column(db.String(50), nullable=True)
    # CLEAR, HOLD, REFER, REJECT
    
    referred_unit = db.Column(db.String(100), nullable=True)  # where did human send it?
    # e.g. 'SIU', 'MEDICAL_REVIEW', 'POLICE', 'CUSTOMER_SERVICE'
    
    handler_notes = db.Column(db.Text, nullable=True)  # human reasoning
    decision_ts = db.Column(db.DateTime, nullable=True)  # when human decided
    decision_version = db.Column(db.Integer, default=0)  # for tracking overwrites
    decided_by = db.Column(db.String(100), nullable=True)  # human username/ID
    
    # ─────────────────────────────────────────────────────────────────
    # EXPLAINABILITY (why this path was taken)
    # ─────────────────────────────────────────────────────────────────
    
    explainability_model = db.Column(db.String(50), nullable=True)  # which model ran? e.g. 'fraud_v1', 'network_v2'
    explainability_version = db.Column(db.String(20), nullable=True)  # model version
    
    # ─────────────────────────────────────────────────────────────────
    # CHECKPOINTS (Phase 4 human gate decisions)
    # ─────────────────────────────────────────────────────────────────
    
    cp0_state = db.Column(db.JSON, nullable=True)  # CP0 (intake) gate decision
    cp1_state = db.Column(db.JSON, nullable=True)  # CP1 (review) gate decision
    cp2_state = db.Column(db.JSON, nullable=True)  # CP2 (decision) gate decision
    
    # ─────────────────────────────────────────────────────────────────
    # AUDIT TRAIL (immutable, system-managed)
    # ─────────────────────────────────────────────────────────────────
    
    created_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, nullable=False, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_agent_run = db.Column(db.DateTime, nullable=True)  # when agents last touched this
    schema_version = db.Column(db.Integer, default=1)  # for migration tracking

    def to_dict(self):
        """
        Serialize to dictionary with explicit section separation.
        
        Returns 5 clear sections for API/UI consumption:
          1. identity - immutable claim facts
          2. lifecycle - workflow status
          3. intelligence - system analysis
          4. human_decision - handler authority
          5. audit - timestamps and metadata
        """
        return {
            'identity': {
                'case_id': self.case_id,
                'policy_id': self.policy_id,
                'claimant_id': self.claimant_id,
                'claim_type': self.claim_type,
                'coverage_type': self.coverage_type,
                'loss_date': self.loss_date.isoformat() if self.loss_date else None,
                'reported_date': self.reported_date.isoformat() if self.reported_date else None,
                'jurisdiction': self.jurisdiction,
            },
            'lifecycle': {
                'status': self.status,
                'current_stage': self.current_stage,
                'assigned_handler': self.assigned_handler,
                'sla_start_ts': self.sla_start_ts.isoformat() if self.sla_start_ts else None,
                'sla_due_ts': self.sla_due_ts.isoformat() if self.sla_due_ts else None,
            },
            'intelligence': {
                'fraud_score': self.fraud_score,
                'fraud_band': self.fraud_band,
                'fraud_confidence': self.fraud_confidence,
                'network_risk_flag': self.network_risk_flag,
                'ring_fence_indicator': self.ring_fence_indicator,
                'triggered_indicators': self.triggered_indicators,
                'reasoning_summary': self.reasoning_summary,
                'evidence_refs': self.evidence_refs,
                'source_filename': self.source_filename,
                'source_text': self.source_text,
                'ingestion': self.ingestion,
                'recommended_referral': self.recommended_referral,
                'recommended_action': self.recommended_action,
                'explainability_model': self.explainability_model,
                'explainability_version': self.explainability_version,
            },
            'human_decision': {
                'handler_decision': self.handler_decision,
                'referred_unit': self.referred_unit,
                'handler_notes': self.handler_notes,
                'decision_ts': self.decision_ts.isoformat() if self.decision_ts else None,
                'decision_version': self.decision_version,
                'decided_by': self.decided_by,
            },
            'audit': {
                'created_at': self.created_at.isoformat() if self.created_at else None,
                'updated_at': self.updated_at.isoformat() if self.updated_at else None,
                'last_agent_run': self.last_agent_run.isoformat() if self.last_agent_run else None,
                'schema_version': self.schema_version,
            }
        }

    def __repr__(self):
        return f'<ClaimCase {self.case_id}: {self.claim_type} ({self.status})>'
