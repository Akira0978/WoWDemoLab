""" generator (demo-grade)
- Generates 20–30 cases
- Produces synthetic 'source_text' that claim_parser will detect signals in
"""
from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime, timedelta
import random
from typing import List, Dict, Any

@dataclass
class DemoCase:
    policy_id: str
    claimant_id: str
    claimant_name: str
    claim_type: str
    jurisdiction: str
    amount: float
    scenario: str
    expected_band: str
    expected_score: int
    source_filename: str
    source_text: str

SCENARIOS = [
    dict(
        scenario="FRAUD_RING", jurisdiction="DE", claim_type="Motor",
        amount_range=(2500, 6000), score=87, band="HIGH",
        template=(
            "Claimant: {name}\nPolicy: {policy}\nRepairer: AutoFix GmbH\n"
            "Location: Frankfurt, Germany\n"
            "Narrative: Rear-end collision on A3 autobahn with whiplash injury. First-time claimant. "
            "Shared solicitor appears across 6 linked claims.\n"
            "Amount: €{amount}\n"
        )
    ),
    dict(
        scenario="SUSPICIOUS_CLUSTER", jurisdiction="FR", claim_type="Property",
        amount_range=(9000, 16000), score=64, band="REVIEW",
        template=(
            "Claimant: {name}\nPolicy: {policy}\nContractor: RénoPlus SARL\n"
            "Location: Lyon, France\n"
            "Narrative: Burst pipe water damage. 3rd claim in 18 months from same address.\n"
            "Amount: €{amount}\n"
        )
    ),
    dict(
        scenario="CLEAR_FASTTRACK", jurisdiction="UK", claim_type="Travel",
        amount_range=(200, 1200), score=8, band="LOW",
        template=(
            "Claimant: {name}\nPolicy: {policy}\nLocation: London, United Kingdom\n"
            "Narrative: Baggage loss claim after flight. Police report and airline letter attached.\n"
            "Amount: £{amount}\n"
        )
    )
]

NAMES = ["H. Müller","M. Dubois","J. Whitfield","P. Hoffmann","L. Weber","J. Schröder","A. Singh","S. Patel"]

def generate_cases(n: int = 30, seed: int | None = None) -> List[DemoCase]:
    rng = random.Random(seed)
    out: List[DemoCase] = []
    for i in range(n):
        sc = rng.choice(SCENARIOS)
        policy = f"POL-{rng.randint(100000,999999)}"
        claimant_id = f"CLM-{rng.randint(10000,99999)}"
        name = rng.choice(NAMES)
        amount = rng.randint(*sc["amount_range"])
        text = sc["template"].format(name=name, policy=policy, amount=amount)
        filename = f"{sc['scenario']}_{sc['jurisdiction']}_{i+1}.pdf"
        out.append(DemoCase(
            policy_id=policy, claimant_id=claimant_id, claimant_name=name,
            claim_type=sc["claim_type"], jurisdiction=sc["jurisdiction"],
            amount=float(amount), scenario=sc["scenario"],
            expected_band=sc["band"], expected_score=int(sc["score"]),
            source_filename=filename, source_text=text
        ))
    return out

def to_payload(dc: DemoCase) -> Dict[str, Any]:
    now = datetime.utcnow()
    return {
        "policy_id": dc.policy_id,
        "claimant_id": dc.claimant_id,
        "claim_type": dc.claim_type,
        "coverage_type": dc.claim_type,
        "loss_date": (now - timedelta(days=random.randint(1, 60))).date().isoformat(),
        "reported_date": now.date().isoformat(),
        "jurisdiction": dc.jurisdiction,
        "source_filename": dc.source_filename,
        "source_text": dc.source_text,
        "expected": {"scenario": dc.scenario, "fraud_band": dc.expected_band, "fraud_score": dc.expected_score}
    }
