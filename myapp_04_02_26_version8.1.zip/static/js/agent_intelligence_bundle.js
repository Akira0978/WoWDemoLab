(function(){

  function fire(agent, msg){
      if (window.agentSay) agentSay(agent, msg);
      if (window.IntelEvents) IntelEvents.pulse(agent);
  }

  // ---- FORECASTER AGENT ----
  window.ForecasterAI = {
    run: function(typeKey){
        const packs = {
            active_by_phase: {
                forecast: "Phase 2 share to drop 4% next quarter.",
                spark: "-3.8%",
                impact: { slowdown:"3–5%", risk:"+1.4", kpis:2 }
            },
            start_momentum: {
                forecast: "Momentum dip of 6–9% next month.",
                spark: "-7.1%",
                impact: { slowdown:"6–9%", risk:"+2.1", kpis:3 }
            },
            moa_distribution: {
                forecast: "GLP‑1 share softening by 4–6%.",
                spark: "-5.0%",
                impact: { slowdown:"4–6%", risk:"+1.8", kpis:1 }
            },
            geo_footprint: {
                forecast: "EU slowdown, NA/Asia +6% compensation.",
                spark: "+6%",
                impact: { slowdown:"7–10%", risk:"+2.4", kpis:4 }
            }
        };

        const p = packs[typeKey] || packs.start_momentum;

        fire("Forecast", `AI forecast: ${p.forecast}`);
        
        // Update dock impact
        IntelEvents.impact({
            recruitment_slowdown: p.impact.slowdown,
            risk_delta: p.impact.risk,
            kpis_impacted: p.impact.kpis,
            narrative: p.forecast
        });
    }
  };


  // ---- COMPETITOR ANALYST AGENT ----
  window.CompeteAI = {
    analyze: function(typeKey){
        const insights = {
            moa_distribution: "Lilly accelerating GLP‑1 trial starts +12% QoQ.",
            active_by_phase: "AZ Phase 3 output expected to soften.",
            start_momentum: "Pfizer momentum declining after failed indication.",
            geo_footprint: "Novo expanding Asian trial footprint (+8 sites)."
        };
        fire("Competitor", insights[typeKey] || "Competitor landscape shifting.");
    }
  };


  // ---- RISK BRAIN ----
  window.RiskAI = {
    project: function(typeKey){
        const risks = {
            start_momentum: "Scenario: 2–3 month delay risk emerging.",
            active_by_phase: "Phase 2 attrition risk +14%.",
            moa_distribution: "Safety-review induced MoA drift risk.",
            geo_footprint: "EU regulatory friction driving geo imbalance."
        };
        fire("Risk", risks[typeKey]);
    }
  };


  // ---- ENTERPRISE ADVISOR ----
  window.AdvisorAI = {
    recommend: function(typeKey){
        const recs = {
            start_momentum: "Mitigation: Activate backup sites in NA to offset slowdown.",
            active_by_phase: "Recommendation: Rebalance cohort allocation.",
            moa_distribution: "Prepare MoA diversification strategy.",
            geo_footprint: "Shift 12% enrollment capacity to Asia for stability."
        };
        fire("Advisor", recs[typeKey]);
    }
  };

})();
