// static/js/what_if_sim.js
(function(){
  const SIM_ID = 'whatif-panel';
  const DEFAULTS = { enrollmentPct: 0, sitesPct: 0, regionShift: 'none' };

  function injectStyles(){
    if (document.getElementById('whatif-styles')) return;
    const css = `
      .whatif-wrap{position:fixed;right:18px;bottom:90px;z-index:10001;
        background:#0f1115;color:#e8e8e8;border:1px solid #1f242d;border-radius:10px;
        box-shadow:0 10px 28px rgba(0,0,0,.55);width:min(360px,92vw);font:13px/1.4 'Segoe UI',Roboto,sans-serif}
      .whatif-hdr{display:flex;justify-content:space-between;align-items:center;
        padding:10px 12px;border-bottom:1px solid #1f242d}
      .whatif-body{padding:12px;display:grid;gap:10px}
      .whatif-row{display:grid;grid-template-columns:1fr auto;gap:10px;align-items:center}
      .whatif-row input[type=range]{width:180px}
      .whatif-btns{display:flex;gap:8px;justify-content:flex-end;padding:10px;border-top:1px solid #1f242d}
      .whatif-mini{position:fixed;right:18px;bottom:18px;z-index:10001}
      .whatif-mini button{background:#15181e;border:1px solid #262b35;color:#cfd6e6;border-radius:8px;padding:8px 12px;cursor:pointer}
      .whatif-mini button:hover{background:#1b2029}
    `;
    const s = document.createElement('style'); s.id='whatif-styles'; s.textContent=css; document.head.appendChild(s);
  }

  function buildPanel(){
    if (document.getElementById(SIM_ID)) return;
    injectStyles();
    const host = document.createElement('section');
    host.id = SIM_ID;
    host.className = 'whatif-wrap';
    host.innerHTML = [
      '<div class="whatif-hdr"><b>What‑If Simulator</b>',
      '<button id="wi-close" title="Close" style="background:none;border:0;color:#cfd6e6;cursor:pointer">✕</button></div>',
      '<div class="whatif-body">',
      '  <div class="whatif-row"><label>Enrollment Δ%</label><input id="wi-enroll" type="range" min="-20" max="40" value="0"><span id="wi-enroll-val">0%</span></div>',
      '  <div class="whatif-row"><label>Active Sites Δ%</label><input id="wi-sites" type="range" min="-10" max="40" value="0"><span id="wi-sites-val">0%</span></div>',
      '  <div class="whatif-row"><label>Region Shift</label>',
      '    <select id="wi-region"><option value="none">—</option><option value="eu_to_na">EU → NA</option><option value="eu_to_apac">EU → APAC</option></select>',
      '  </div>',
      '</div>',
      '<div class="whatif-btns">',
      '  <button id="wi-apply">Apply</button>',
      '  <button id="wi-reset">Reset</button>',
      '</div>'
    ].join('');
    document.body.appendChild(host);

    // mini launcher
    if (!document.getElementById('whatif-mini')) {
      const mini = document.createElement('div');
      mini.id = 'whatif-mini';
      mini.className = 'whatif-mini';
      mini.innerHTML = '<button id="wi-open">What‑If</button>';
      document.body.appendChild(mini);
      mini.querySelector('#wi-open').onclick = open;
    }

    // wire
    const elEnroll = host.querySelector('#wi-enroll');
    const elSites  = host.querySelector('#wi-sites');
    const elReg    = host.querySelector('#wi-region');
    const updateLbls = ()=> {
      host.querySelector('#wi-enroll-val').textContent = elEnroll.value + '%';
      host.querySelector('#wi-sites-val').textContent  = elSites.value  + '%';
    };
    elEnroll.oninput = elSites.oninput = updateLbls; updateLbls();

    host.querySelector('#wi-apply').onclick = ()=> apply({
      enrollmentPct: +elEnroll.value,
      sitesPct: +elSites.value,
      regionShift: elReg.value
    });
    host.querySelector('#wi-reset').onclick = reset;
    host.querySelector('#wi-close').onclick = close;
  }

  function open(){ buildPanel(); document.getElementById(SIM_ID).style.display='block'; }
  function close(){ const n=document.getElementById(SIM_ID); if(n) n.style.display='none'; }

  // ---- IMPACT FUNCTIONS (no backend) ----
  // Apply multipliers to currently clicked (or visible) chart.
  function apply(params){
    const last = window.__LAST_CLICKED_CHART__ || document.querySelector('.nnci-chart.is-ready'); // best effort
    if (!last) return;

    const chartId = last.id;
    const typeKey = last.getAttribute('data-chart-type');

    // 1) Forecast band into the chart
    addFanBand(chartId, typeKey, params);

    // 2) KPI / Impact to Dock
    pushScenarioIntelligence(typeKey, params);

    // 3) Competitor heatmap (demo)
    if (window.IntelDock && IntelDock.setCompetitorHeat){
      const heat = scenarioHeat(params);
      IntelDock.setCompetitorHeat(heat);
    }

    // 4) Agent chatter
    safeSay('Advisor', 'Applied What‑If scenario to ' + (typeKey||'chart'));
  }

  function reset(){
    // Simple reset = trigger a resize & rerender so lazy renderers refresh. (Or keep a backup Option snapshot.)
    window.dispatchEvent(new Event('resize'));
    if (window.IntelDock){ IntelDock.say('System','What‑If scenario cleared'); }
  }

  // ---- Chart fan band (confidence interval) ----
  function addFanBand(chartId, typeKey, {enrollmentPct=0, sitesPct=0}={}){
    if (typeof echarts==='undefined') return;
    const inst = echarts.getInstanceByDom(document.getElementById(chartId)); if (!inst) return;

    const opt = inst.getOption();
    const s0  = opt.series && opt.series[0]; if (!s0) return;

    // Build a simple confidence band based on the last value and scenario multipliers
    const data = s0.data.slice(); const last = +data[data.length-1]||0;
    const lift = 1 + (Math.max(enrollmentPct, sitesPct)/100);
    const f1 = +(last * (0.98*lift)).toFixed(1);
    const f2 = +(last * (1.02*lift)).toFixed(1);
    const f3 = +(last * (1.05*lift)).toFixed(1);
    const fanUpper = data.concat([f1*1.03, f2*1.06, f3*1.08]);
    const fanLower = data.concat([f1*0.97, f2*0.94, f3*0.92]);

    // add/replace two new series (upper/lower area)
    const bandColor = 'rgba(47,140,255,0.20)';
    opt.series = opt.series.filter(x=>x && x.name!=='AI Forecast (What‑If)' && x.name!=='AI Fan');
    opt.series.push(
      { name: 'AI Fan', type: 'line', data: fanUpper, lineStyle:{width:0}, showSymbol:false, areaStyle:{color:bandColor} },
      { name: 'AI Forecast (What‑If)', type: 'line', data: data.concat([f1,f2,f3]),
        lineStyle:{type:'dashed',width:2,color:'#2f8cff'}, symbol:'circle' }
    );
    inst.setOption(opt, false, true);

    if (window.IntelEvents){ IntelEvents.forecastBadge(chartId, 'What‑If Forecast', 6000); }
  }

  // ---- Dock impact & narrative ----
  function pushScenarioIntelligence(typeKey, {enrollmentPct=0, sitesPct=0, regionShift='none'}){
    const kpisImpacted = Math.max(1, Math.round((Math.abs(enrollmentPct)+Math.abs(sitesPct))/15));
    const riskDelta = '+' + (1 + (Math.abs(enrollmentPct)+Math.abs(sitesPct))/20).toFixed(1);

    const shiftText = regionShift==='eu_to_na' ? 'Shift EU → NA'
                    : regionShift==='eu_to_apac' ? 'Shift EU → APAC'
                    : 'No region shift';

    if (window.IntelEvents){
      IntelEvents.summary({ agents: 5, external_signals: 1, kpis_at_risk: kpisImpacted, forecast_badges: 1 });
      IntelEvents.impact({
        recruitment_slowdown: (enrollmentPct>=0? '+'+enrollmentPct : enrollmentPct) + '% (enrollment Δ)',
        risk_delta: riskDelta,
        kpis_impacted: kpisImpacted,
        narrative: `What‑If applied: Enrollment ${enrollmentPct}% · Sites ${sitesPct}% · ${shiftText}.` 
          + `AI estimates Novo’s relative share vs peers improves by ~${Math.round((enrollmentPct * 0.15 + sitesPct * 0.1))} pp over 30 days.`

      });
    }
    if (window.AgentFlow && AgentFlow.setReasoningTrace){
      AgentFlow.setReasoningTrace([
        `Scenario: ${enrollmentPct}% enrollment, ${sitesPct}% sites`,
        `Estimate: ${kpisImpacted} KPIs affected`,
        `Risk delta ${riskDelta}`,
        `Regional: ${shiftText}`
      ]);
    }
    if (window.AgentFlow && AgentFlow.setAutoActions){
      AgentFlow.setAutoActions([
        'Reprojected 30/60/90‑day forecast',
        'Updated competitive exposure',
        'Suggested regional reallocation',
        'Booked scenario for review'
      ]);
    }
  }

/*   function scenarioHeat({enrollmentPct=0, sitesPct=0}){
    // Demo heuristics for heatmap deltas
    const bump = (p)=> (p>0? '+'+p : p) + '%';
    const lilly = bump(Math.round(enrollmentPct*0.6 + sitesPct*0.3));
    const az    = bump(Math.round(-enrollmentPct*0.2 + sitesPct*0.4));
    const pf    = bump(Math.round(-enrollmentPct*0.7));
    return { lilly: `LLY ${lilly}`, az: `AZ ${az}`, pfizer: `PFE ${pf}` };
  } */

  // what_if_sim.js – replace scenarioHeat()
  function scenarioHeat({ enrollmentPct = 0, sitesPct = 0 }) {
    // If an ECharts instance is available on the last clicked chart,
    // compute scenario deltas relative to last point per series.
    try {
      const node = window.__LAST_CLICKED_CHART__ || document.querySelector('.nnci-chart.is-ready');
      if (!node || typeof echarts === 'undefined') throw 0;
      const inst = echarts.getInstanceByDom(node); if (!inst) throw 0;
      const opt = inst.getOption(); if (!opt || !opt.series) throw 0;

      // Collect latest values from the first 3 series (Novo + two peers ideally)
      const latest = (ser) => {
        const arr = ser && ser.data || [];
        return +arr[arr.length - 1] || 0;
      };

      const s0 = opt.series[0], s1 = opt.series[1], s2 = opt.series[2];
      const v0 = latest(s0), v1 = latest(s1), v2 = latest(s2);

      // Assume s0 ~ Novo Nordisk, s1 ~ Lilly, s2 ~ AZ in your CT demos.
      // Apply a simple “lift” to estimate new peer momentum under the scenario.
      const lift = 1 + (Math.max(enrollmentPct, sitesPct) / 100);
      const novoLift = lift;            // we’re simulating our own uplift
      const peerLift1 = 1 + (sitesPct * 0.2 / 100);  // small spillover to LLY
      const peerLift2 = 1 + (enrollmentPct * 0.1 / 100); // small spillover to AZ

      const novoNew = v0 * novoLift;
      const llyNew = v1 * peerLift1;
      const azNew = v2 * peerLift2;

      // Express as % change vs. current visible baseline
      const pct = (newV, oldV) => oldV ? Math.round((newV / oldV - 1) * 100) : 0;

      const novoDelta = pct(novoNew, v0); // we’ll convert this to a relative share line in narrative
      const llyDelta = pct(llyNew, v1);
      const azDelta = pct(azNew, v2);

      return {
        // Heatmap rows:
        lilly: (llyDelta >= 0 ? '+' : '') + llyDelta + '%',
        az: (azDelta >= 0 ? '+' : '') + azDelta + '%',
        pfizer: '—', // not visible on chart → keep neutral or compute from a 3rd/4th series when present
        // Also return a suggested pp impact for Novo vs peers (used in narrative)
        __novoRelPP__: Math.max(0, Math.round(novoDelta * 0.15)) // demo-grade conversion to “pp over 30 days”
      };
    } catch (_) {
      // fallback to earlier heuristic
      const bump = (p) => (p > 0 ? '+' + p : p) + '%';
      const lilly = bump(Math.round(enrollmentPct * 0.6 + sitesPct * 0.3));
      const az = bump(Math.round(-enrollmentPct * 0.2 + sitesPct * 0.4));
      const pf = bump(Math.round(-enrollmentPct * 0.7));
      return { lilly: `LLY ${lilly}`, az: `AZ ${az}`, pfizer: `PFE ${pf}`, __novoRelPP__: Math.max(0, Math.round((enrollmentPct * 0.15 + sitesPct * 0.1))) };
    }
  }
    function safeSay(agent,msg){ try{ if(window.agentSay) agentSay(agent,msg); else if(window.IntelDock) IntelDock.say(agent,msg); }catch(_){ } }

  // track last clicked chart id to target what‑if
  document.addEventListener('click', (ev)=>{
    const node = ev.target.closest('.nnci-chart'); if (!node) return;
    window.__LAST_CLICKED_CHART__ = node;
  });

  // auto inject launcher on DOM ready
  if (document.readyState==='loading') document.addEventListener('DOMContentLoaded', buildPanel, {once:true});
  else buildPanel();
})();