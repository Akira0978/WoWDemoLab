
// static/js/ct_diabetes.js
(function () {
  "use strict";
  // --- Utilities from global.js (exposed on window.NNCI) ---
  const fetchJSON = (url, opts) => window.NNCI.fetchJSON(url, opts);
  const qsFromFilters = (f) => window.NNCI.utils.buildQueryString(f);
  const mergeFilters = (a, b) => window.NNCI.utils.merge(a, b);

  // --- Base filter: therapy area from the page dataset ---
  const rootEl = document.getElementById("mainContentWrap");
  const pageTherapy = (rootEl && (rootEl.dataset.therapyArea || rootEl.getAttribute("data-therapy-area"))) || "diabetes";

  function getPageFilters() {
    const urlFilters = window.NNCI.utils.getUrlFilters();
    return mergeFilters({ therapy_area: pageTherapy }, urlFilters);
  }

  // --- KPI rendering (data-kpi="...") ---
  function setText(selector, value, fallback = "—") {
    const el = document.querySelector(selector);
    if (el) el.textContent = (value ?? fallback);
  }

  function buildDebugHtml({ filters, kpis, sampleTrials }) {
    const esc = (s) => String(s ?? '—').replace(/&/g,'&').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    const li = (obj) => Object.entries(obj).map(([k,v]) => `
<tr><th>${esc(k)}</th><td>${esc(v)}</td></tr>`).join("");
    const sampleRows = (sampleTrials || []).map(t => `
<tr><td>${esc(t.trial_id)}</td><td>${esc(t.sponsor)}</td><td>${esc(t.phase)}</td><td>${esc(t.status)}</td></tr>`).join("");
    return `
<h6>Filters</h6><table>${li(filters)}</table>
<h6>KPI payload</h6>
<table>
<tr><th>total_trials</th><td>${esc(kpis.total_trials)}</td></tr>
<tr><th>active_trials</th><td>${esc(kpis.active_trials)}</td></tr>
<tr><th>recruiting_trials</th><td>${esc(kpis.recruiting_trials)}</td></tr>
<tr><th>new_starts_12m</th><td>${esc(kpis.new_starts_12m)}</td></tr>
<tr><th>top_mechanism_active</th><td>${esc(kpis.top_mechanism_active)}</td></tr>
<tr><th>biggest_competitor_threat</th><td>${esc(kpis.biggest_competitor_threat)}</td></tr>
<tr><th>median_recruitment_velocity_n_per_month</th><td>${esc(kpis.median_recruitment_velocity_n_per_month)}</td></tr>
</table>
<h6>Sample /api/trials rows (3)</h6>
<table>
<tr><th>Trial</th><th>Sponsor</th><th>Phase</th><th>Status</th></tr>
${sampleRows || '<tr><td colspan="4">No rows</td></tr>'}
</table>`;
  }

  async function loadDebugPopover(filters, kpis) {
    const q = new URLSearchParams({ ...filters, limit: 3, offset: 0, sort_by: 'last_updated', desc: true });
    const trialsResp = await fetch(`/api/trials?${q.toString()}`, { headers: { "Accept": "application/json" } });
    let sampleTrials = [];
    if (trialsResp.ok) {
      const trialsJson = await trialsResp.json();
      sampleTrials = Array.isArray(trialsJson) ? trialsJson.slice(0,3) : (trialsJson.rows || []).slice(0,3);
    }
    const btn = document.getElementById('kpi-debug-btn');
    if (!btn) return;
    try {
      const contentHtml = buildDebugHtml({ filters, kpis, sampleTrials });
      new bootstrap.Popover(btn, { html: true, trigger: 'focus', content: contentHtml });
    } catch (e) { console.warn("Debug popover init failed:", e); }
  }

  function renderKpis(kpis) {
    setText('[data-kpi="total_trials"]', kpis.total_trials);
    setText('[data-kpi="active_trials"]', kpis.active_trials);
    setText('[data-kpi="recruiting_trials"]', kpis.recruiting_trials);
    setText('[data-kpi="new_starts_12m"]', kpis.new_starts_12m);
    setText('[data-kpi="top_mechanism_active"]', kpis.top_mechanism_active);
    setText('[data-kpi="biggest_competitor_threat"]', kpis.biggest_competitor_threat);
    let mv = kpis.median_recruitment_velocity_n_per_month;
    if (typeof mv === "number") mv = mv.toFixed(1);
    setText('[data-kpi="median_recruitment_velocity_n_per_month"]', mv);

    const listEl = document.querySelector('[data-kpi="next_readouts"]');
    if (listEl) {
      listEl.innerHTML = "";
      const items = Array.isArray(kpis.next_readouts) ? kpis.next_readouts.slice(0, 5) : [];
      if (!items.length) {
        listEl.innerHTML = '\n- No upcoming readouts \n';
      } else {
        items.forEach(r => {
          const title = r.title || r.trial_id || "Upcoming readout";
          const date = r.primary_completion_date || r.date || "";
          const li = document.createElement("li");
          li.innerHTML = `${title}${date ? ` (${date})` : ""}`;
          listEl.appendChild(li);
        });
      }
    }

    const meta = document.getElementById("meta");
    if (meta) {
      const parts = [];
      if (kpis.total_trials != null) parts.push(`Total: ${kpis.total_trials}`);
      if (kpis.active_trials != null) parts.push(`Active: ${kpis.active_trials}`);
      if (kpis.new_starts_12m != null) parts.push(`Starts (12m): ${kpis.new_starts_12m}`);
      meta.textContent = parts.join(" · ");
    }
  }

  async function loadKpis(filters) {
    const url = `/api/kpis?${qsFromFilters(filters)}`;
    const data = await fetchJSON(url);
    renderKpis(data);
  }

  function renderInsights(insights) {
    const panels = document.querySelectorAll('[data-insight-target]');
    if (!panels.length) return;

    const mkCard = (insight) => {
      const steps = Array.isArray(insight.next_steps) ? insight.next_steps : [];
      return `
<div class="ins-card">
  <div class="ins-title">${insight.title || "Insight"}</div>
  <div class="ins-body">${insight.why_it_matters || ""}</div>
  ${steps.length ? `<div class="ins-steps">${steps.slice(0,3).map(s => `\n- ${s} \n`).join("")}</div>` : ""}
</div>`;
    };

    panels.forEach(panel => {
      const slice = (insights || []).slice(0, 2);
      panel.innerHTML = slice.length ? slice.map(mkCard).join("") : `\nNo insights available.\n`;
    });

    const evHolders = [
      { id: "ev_active_by_phase", key: "top_sponsors_active_trials" },
      { id: "ev_start_momentum",  key: "starts_series" },
      { id: "ev_moa_distribution",key: "top_moa" },
      { id: "ev_geo_footprint",  key: "regions" }
    ];
    evHolders.forEach(({ id, key }) => {
      const evEl = document.getElementById(id);
      if (!evEl) return;
      const firstWithEvidence = (insights || []).find(i => i.evidence && i.evidence[key]);
      if (firstWithEvidence) {
        const ev = firstWithEvidence.evidence[key];
        if (Array.isArray(ev)) {
          evEl.innerHTML = `\n${ev.slice(0, 5).map(e => { if (typeof e === "object") { const k = Object.keys(e)[0]; const v = e[k]; return `${k}: **${v}**`; } return `${String(e)}`; }).join("")}\n`;
        } else if (typeof ev === "object") {
          evEl.innerHTML = `<pre>${JSON.stringify(ev, null, 2)}</pre>`;
        } else { evEl.textContent = String(ev); }
      } else {
        evEl.innerHTML = `No evidence available`;
      }
    });
  }

  async function loadInsights(filters) {
    const url = `/api/insights?${qsFromFilters(filters)}`;
    const data = await fetchJSON(url);
    const insights = Array.isArray(data.insights) ? data.insights : [];
    renderInsights(insights);
  }

  // --- Page boot ---
  document.addEventListener("DOMContentLoaded", async () => {
    window.NNCI.setBaseFilter({ therapy_area: pageTherapy });
    const filters = getPageFilters();

    try { await loadKpis(filters); } catch (e) { console.error("KPI load failed:", e); }
    try {
      const kpiData = await fetch(`/api/kpis?${qsFromFilters(filters)}`, { headers: { "Accept": "application/json" } }).then(r => r.json());
      await loadDebugPopover(filters, kpiData);
    } catch (e) { console.warn("Debug popover skipped:", e); }

    if (window.CTI && typeof window.CTI.refreshCharts === "function") { await window.CTI.refreshCharts(); }

    try { await loadInsights(filters); } catch (e) { console.error("Insights load failed:", e); }
  });

})();

// ---- DEBUG: manual trigger so PMs/demo can run without chatbot ----
window.debugAgent = function (text) {
  if (window.AgentFlow && typeof AgentFlow.handleChatCommand === 'function') {
    AgentFlow.handleChatCommand(text || "show active trials");
  } else { console.warn("AgentFlow not ready yet."); }
};

// === AOP (Art-of-Possible) demo: Satellite -> Brain -> Eyes -> Authorities ===
(function () {
  // Master toggle if needed
  window.DEMO_AOP_ENABLED = (typeof window.DEMO_AOP_ENABLED === 'boolean') ? window.DEMO_AOP_ENABLED : true;

  document.addEventListener('DOMContentLoaded', function () {
    if (!window.DEMO_AOP_ENABLED) return;
    const main = document.getElementById('mainContentWrap');
    if (!main) return;
    main.addEventListener('click', function (ev) {
      const node = ev.target.closest('.nnci-chart');
      if (!node) return;
      startSatelliteDemo(node);
    });
  });

  function startSatelliteDemo(node) {
    if (node.dataset.demoRunning === '1') return;
    node.dataset.demoRunning = '1';

    const chartId = node.id;
    const typeKey = node.getAttribute('data-chart-type');

    // Kick off the orchestrator mini-pipeline for this external signal
    if (window.AgentFlow && typeof AgentFlow.externalSignalFlow === 'function') {
      AgentFlow.externalSignalFlow(`External signal affecting ${prettyType(typeKey)}`);
    }

    // Right-rail feed sequence
    agentSay('Satellite', `Scanning external signals related to ${prettyType(typeKey)}…`);
    setTimeout(() => { agentSay('Satellite', 'Regulatory update detected: temporary hold on a Phase 2 Diabetes trial.'); }, 1200);

    // Brain: recalibrate, update UI
    setTimeout(() => {
      agentSay('Brain', 'Recalibrating KPIs & risk scores based on the new signal…');
      tweakChart(chartId, typeKey);
      highlightDelta(chartId, typeKey);
      addForecastOverlay(chartId, typeKey);
      tweakInsights(typeKey);

      // --- NEW: Predictive Intelligence injection (Mode A) ---
      try {
        IntelEvents.summary({
          agents: 4,
          external_signals: 1,
          kpis_at_risk: 3,
          forecast_badges: 1
        });

        IntelEvents.impact({
          recruitment_slowdown: "8–12%",
          risk_delta: "+2.1",
          kpis_impacted: 3,
          narrative: "AI models forecast enrollment headwinds in EU due to temporary regulatory friction. " +
            "Phase 2 cycles likely to extend by ~11 days. Reallocate recruitment to NA/Asia to offset slowdown."
        });

        // Forecast badge on the current chart
        IntelEvents.forecastBadge(chartId, "AI Forecast Applied", 6000);

        // Agent pulse for predictive model
        IntelEvents.pulse("Brain");

      } catch (e) { console.warn("Predictive AI block failed", e); }
      // Intelligence blocks
      if (window.AgentFlow && AgentFlow.setReasoningTrace) {
        AgentFlow.setReasoningTrace([
          'Signal suggests regulatory delay in key markets.',
          'Phase 2 cohort likely to be impacted.',
          'Predicted enrollment slowdown: 8–12%.',
          'Recommending KPI recalibration and forecast shifts.'
        ]);
      }
      if (window.AgentFlow && AgentFlow.setAutoActions) {
        AgentFlow.setAutoActions([
          'Drafted regulatory alert',
          'Recalibrated KPIs',
          'Adjusted next 30‑day forecast',
          'Updated risk exposure model'
        ]);
      }
      autoTuneUI(typeKey);
    }, 3200);

    
    setTimeout(() => {
      ForecasterAI.run(typeKey);
      CompeteAI.analyze(typeKey);
      RiskAI.project(typeKey);
      AdvisorAI.recommend(typeKey);
    }, 3600);


    // Notify authorities and offer report
    setTimeout(() => {
      agentSay('Radar', 'Authorities notified (EMA / FDA). Automated report prepared.');
      offerReportDownload(typeKey);
      // allow replay after short cooldown
      setTimeout(() => { node.dataset.demoRunning = ''; }, 8000);
    }, 5000);
  }

  function prettyType(typeKey) {
    const map = {
      'active_by_phase': 'Active by Phase',
      'start_momentum': 'Trial Start Momentum',
      'moa_distribution': 'MoA Distribution',
      'geo_footprint': 'Geographic Footprint'
    };
    return map[typeKey] || typeKey || 'this view';
  }

  // --- Live Feeds (right rail) ---
  function addFeed(source, title) {
    const root = document.getElementById('right-rail-feeds');
    const tpl = document.getElementById('live-feed-item-tpl');
    if (!root || !tpl) return;
    const frag = tpl.content.cloneNode(true);
    frag.querySelector('.feed-source').textContent = source;
    frag.querySelector('.feed-title').textContent = title;
    const timeEl = frag.querySelector('.feed-time');
    if (timeEl) {
      timeEl.textContent = new Date().toLocaleTimeString();
      timeEl.setAttribute('datetime', new Date().toISOString());
    }
    root.prepend(frag);
  }
  function agentSay(agent, message){ addFeed(agent, message); }

  // --- Chart nudge (Eyes) ---
  function tweakChart(chartId, typeKey) {
    const el = document.getElementById(chartId);
    if (!el || typeof echarts === 'undefined') return;
    const inst = echarts.getInstanceByDom(el);
    if (!inst) return;
    try {
      const opt = inst.getOption();
      if (typeKey === 'start_momentum') {
        const s0 = opt.series && opt.series[0] && opt.series[0].data;
        if (Array.isArray(s0) && s0.length) {
          s0[s0.length - 1] = +(((Number(s0[s0.length - 1]) || 0) * 1.08)).toFixed(1);
        }
      } else {
        (opt.series || []).forEach(ser => {
          if (Array.isArray(ser.data) && ser.data.length) {
            const v = Number(ser.data[0]) || 0;
            ser.data[0] = +(v * 0.92).toFixed(1);
          }
        });
      }
      inst.setOption(opt, false, true);
    } catch (e) { console.warn('tweakChart failed', e); }
  }

  // --- Delta highlight for the changed point/bar (2–3s) ---
  function highlightDelta(chartId, typeKey) {
    const el = document.getElementById(chartId);
    if (!el || typeof echarts === 'undefined') return;
    const inst = echarts.getInstanceByDom(el);
    if (!inst) return;

    try {
      const opt = inst.getOption();
      let idx, coord, seriesIdx = 0;

      if (typeKey === 'start_momentum') {
        const x = (opt.xAxis && opt.xAxis[0] && opt.xAxis[0].data) || [];
        const s0 = opt.series?.[0]?.data || [];
        idx = Math.max(0, s0.length - 1);
        coord = [x[idx], Number(s0[idx]) || 0];
        opt.series[seriesIdx].markPoint = {
          symbol: 'circle', symbolSize: 28,
          label: { show: true, formatter: 'Updated', color: '#0f1115', fontSize: 10 },
          itemStyle: { color: '#FFD166', shadowColor: 'rgba(255, 209, 102, 0.8)', shadowBlur: 18 },
          data: [{ coord }]
        };
      } else if (typeKey === 'geo_footprint') {
        const x = (opt.xAxis && opt.xAxis[0] && opt.xAxis[0].data) || [];
        idx = 0; const val = Number(opt.series?.[0]?.data?.[idx]) || 0; coord = [x[idx], val];
        opt.series[seriesIdx].markPoint = {
          symbol: 'rect', symbolSize: [30, 18],
          label: { show: true, formatter: 'Updated', color: '#0f1115', fontSize: 10 },
          itemStyle: { color: '#7AD1FF', shadowColor: 'rgba(122, 209, 255, 0.8)', shadowBlur: 18 },
          data: [{ coord }]
        };
      } else {
        const y = (opt.yAxis && opt.yAxis[0] && opt.yAxis[0].data) || [];
        idx = 0; const val = Number(opt.series?.[0]?.data?.[idx]) || 0; coord = [val, y[idx]];
        opt.series[seriesIdx].markPoint = {
          symbol: 'rect', symbolSize: [38, 18],
          label: { show: true, formatter: 'Updated', color: '#0f1115', fontSize: 10 },
          itemStyle: { color: '#A0E991', shadowColor: 'rgba(160, 233, 145, 0.8)', shadowBlur: 18 },
          data: [{ coord }]
        };
      }

      const anim = { animationDurationUpdate: 400, animationEasingUpdate: 'cubicOut' };
      inst.setOption(Object.assign({}, opt, anim), false, true);
      try { inst.dispatchAction({ type: 'showTip', seriesIndex: seriesIdx, dataIndex: idx }); setTimeout(() => inst.dispatchAction({ type: 'hideTip' }), 1800); } catch (_) {}
      setTimeout(() => { const cur = inst.getOption(); if (cur.series && cur.series[seriesIdx]) { cur.series[seriesIdx].markPoint = undefined; inst.setOption(cur, false, true); } }, 2200);
    } catch (e) { console.warn('highlightDelta failed', e); }
  }

  // --- Forecast overlay (line/continuous charts) ---
  function addForecastOverlay(chartId, typeKey) {
    const el = document.getElementById(chartId);
    if (!el || typeof echarts === 'undefined') return;
    const inst = echarts.getInstanceByDom(el);
    if (!inst) return;

    try {
      const opt = inst.getOption();
      if (typeKey !== 'start_momentum') return; // keep it simple for demo
      const series = opt.series && opt.series[0];
      if (!series) return;
      const data = Array.isArray(series.data) ? series.data.slice() : [];
      if (!data.length) return;
      const last = Number(data[data.length - 1]) || 0;
      const forecast = [last * 1.02, last * 1.05, last * 1.09].map(v => Number(v.toFixed(1)));
      series.data = data.concat(forecast);
      series.lineStyle = { type: 'dashed', width: 2 };
      opt.series[0] = series;
      inst.setOption(opt, false, true);
      setTimeout(() => { series.data = data; series.lineStyle = { type: 'solid' }; inst.setOption(opt, false, true); }, 6000);
    } catch (e) { console.warn('addForecastOverlay failed', e); }

    // --- append AI sparkline pseudo-forecast ---
    try {
      const inst = echarts.getInstanceByDom(document.getElementById(chartId));
      if (inst) {
        const opt = inst.getOption();
        if (opt.series && opt.series[0]) {
          const base = Number(opt.series[0].data.slice(-1)[0] || 0);
          const forecast = [base * 1.02, base * 1.05, base * 1.08];
          opt.series.push({
            name: "AI Forecast",
            type: "line",
            data: [null, null, ...forecast],
            lineStyle: { type: "dashed", color: "#2f8cff" },
            symbol: "circle"
          });
          inst.setOption(opt);
        }
      }
    } catch (_) { }
  }

  // --- Insight injection (Brain) ---
  function tweakInsights(typeKey) {
    const messages = {
      'active_by_phase': 'Rebalancing expected in Phase 2; monitor mid‑stage attrition risk.',
      'start_momentum': 'Starts momentum likely to dip next month due to temporary hold.',
      'moa_distribution': 'Slight, near‑term softening on GLP‑1 as safety review plays out.',
      'geo_footprint': 'Enrollment pressure in EU; consider routing capacity to NA/Asia.'
    };
    const id = 'ins_' + (typeKey || '').replace(/\-/g, '_');
    const panel = document.getElementById(id);
    if (!panel) return;
    const note = document.createElement('div');
    note.className = 'insight-chip';
    note.textContent = messages[typeKey] || 'System recalibrated KPIs based on latest external signal.';
    panel.prepend(note);
  }

  // --- Autonomic UI tweaks ---
  function autoTuneUI(typeKey){
    const cardIdMap = {
      'active_by_phase': 'card_active_by_phase',
      'start_momentum': 'card_start_momentum',
      'moa_distribution': 'card_moa',
      'geo_footprint': 'card_geo'
    };
    const cid = cardIdMap[typeKey];
    if (!cid) return;
    const card = document.getElementById(cid);
    if (!card) return;
    const badge = document.createElement('div');
    badge.className = 'auto-tune-badge';
    badge.textContent = 'Auto-tuned · External Signal';
    card.prepend(badge);
  }

  // --- Generate & offer a fake report.md (Authorities) ---
  function offerReportDownload(typeKey) {
    const md = [
      '# Regulatory Alert',
      '',
      '- **Detected**: Temporary hold on Phase 2 Diabetes trial',
      '- **Impact**: KPIs recalibrated; charts & insights updated',
      `- **Affected view**: ${prettyType(typeKey)}`,
      `- **Timestamp**: ${new Date().toISOString()}`
    ].join('\n');
    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'report.md'; a.className = 'orch-btn-close'; a.textContent = 'Download alert report';
    showToast('High‑priority alert generated', a);
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  }

  // --- Minimal toast (with wrapper) ---
  function showToast(title, actionEl) {
    let host = document.getElementById('nnci-toast');
    if (!host) { host = document.createElement('div'); host.id = 'nnci-toast'; host.className = 'nnci-toast'; document.body.appendChild(host); }
    host.innerHTML = `<div class="nnci-toast-card"><div class="t1">${title}</div></div>`;
    if (actionEl) host.querySelector('.nnci-toast-card').appendChild(actionEl);
    host.classList.add('show');
    setTimeout(() => host.classList.remove('show'), 5000);
  }
})();
