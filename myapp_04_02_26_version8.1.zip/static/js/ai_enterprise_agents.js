// ===============================
// ENTERPRISE AI AGENTS (ADD-ON)
// ===============================
(function(){

  function fire(agent, msg){
      if (window.agentSay) agentSay(agent, msg);
      if (window.IntelEvents) IntelEvents.pulse(agent);
  }

  // -------------------------------
  // 1. FORECASTER AGENT
  // -------------------------------
  window.ForecasterAI = {
    run(typeKey){
        const packs = {
            active_by_phase: {
                forecast: "Phase 2 share expected to decline by ~4% next quarter.",
                seriesDelta: [-2, -3, -4],
                impact: { slowdown:"3–5%", risk:"+1.4", kpis:2 },
                competitor: "Lilly increasing early-phase trials (+12%)."
            },
            start_momentum: {
                forecast: "Momentum projected to dip 6–9% next month.",
                seriesDelta: [-3, -5, -7],
                impact: { slowdown:"6–9%", risk:"+2.1", kpis:3 },
                competitor: "Pfizer experiencing slowed monthly output."
            },
            moa_distribution: {
                forecast: "GLP‑1 share softening by 4–6% in next review cycle.",
                seriesDelta: [-2, -4, -5],
                impact: { slowdown:"4–6%", risk:"+1.8", kpis:1 },
                competitor: "AZ MoA diversification into dual agonists."
            },
            geo_footprint: {
                forecast: "EU slowdown, NA/Asia compensating with +6% throughput.",
                seriesDelta: [2, 4, 6],
                impact: { slowdown:"7–10%", risk:"+2.4", kpis:4 },
                competitor: "Novo expanding sites in APAC region."
            }
        };

        const p = packs[typeKey] || packs.start_momentum;

        fire("Forecast", p.forecast);

        // Future Impact Intelligence
        IntelEvents.impact({
            recruitment_slowdown: p.impact.slowdown,
            risk_delta: p.impact.risk,
            kpis_impacted: p.impact.kpis,
            narrative: p.forecast + "\nCompetitors adjusting: " + p.competitor
        });

        // Summary enrichment
        IntelEvents.summary({
           agents: 5,
           external_signals: 1,
           kpis_at_risk: p.impact.kpis,
           forecast_badges: 1
        });

        return p;
    }
  };


  // -------------------------------
  // 2. COMPETITOR ANALYST AGENT
  // -------------------------------
  window.CompeteAI = {
    analyze(typeKey){
        const insights = {
            active_by_phase: "AZ Phase 3 pipeline softening; Lilly Ph1 accelerations detected.",
            start_momentum: "Pfizer down 14% MoM; Novo steady; Lilly rising momentum.",
            moa_distribution: "GLP‑1 dominance challenged; dual agonists gaining traction.",
            geo_footprint: "EU lagging; APAC expansion strong across competitors."
        };

        fire("Competitor", insights[typeKey] || "Competitive shift detected.");
        return insights[typeKey];
    }
  };


  // -------------------------------
  // 3. RISK & SCENARIO AGENT
  // -------------------------------
  window.RiskAI = {
    project(typeKey){
        const risks = {
            active_by_phase: "Phase distribution imbalance → risk of 2–3 month pipeline drift.",
            start_momentum: "Scenario: next-cycle delay risk (6–9%) emerging.",
            moa_distribution: "Safety review may cause MoA drift affecting GLP‑1.",
            geo_footprint: "EU regulatory friction → geo imbalance risk."
        };

        fire("Risk", risks[typeKey]);
        return risks[typeKey];
    }
  };


  // -------------------------------
  // 4. ENTERPRISE ADVISOR AGENT
  // -------------------------------
  window.AdvisorAI = {
    recommend(typeKey){
        const recs = {
            active_by_phase: "Rebalance Phase 2 cohort allocation across NA & Asia.",
            start_momentum: "Activate backup sites to offset momentum drop.",
            moa_distribution: "Prepare MoA diversification and safety review strategy.",
            geo_footprint: "Shift 12% site capacity to APAC to stabilize throughput."
        };
        
        fire("Advisor", recs[typeKey]);
        return recs[typeKey];
    }
  };


  // -------------------------------
  // 5. CONSENSUS ENGINE
  // -------------------------------
  window.ConsensusAI = {
    score(typeKey){
        // Multi-agent agreement score (0–100)
        const score = Math.round(70 + Math.random()*20);
        fire("Consensus", `Agent consensus: ${score}% confidence`);
        return score;
    }
  };

})();