import os
import json
import asyncio
import time
import hashlib
from datetime import datetime, timezone
from typing import List
from modules.ollama_helper import ask_llama
from modules.graph_summary import (
    render_classification_tables,
    summarize_with_llama,
    render_graph_with_summary,
    render_detailed_summary)
from collections import defaultdict
from flask import (
    Flask, jsonify, render_template, request,
    redirect, url_for, send_from_directory, session
)
import fitz  # PyMuPDF
from langdetect import detect
from werkzeug.utils import secure_filename

from neo4j import GraphDatabase
from modules.neo4j_handler import Neo4jHandler
from modules import metadata_extractors  # async enrich_text(text, page_count)
from modules.chatbot_backend import get_chatbot_response

# -----------------------------
# App config
# -----------------------------
app = Flask(__name__)
app.secret_key = "change-this-secret-key"

# Hardcoded paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
METADATA_DIR = os.path.join(BASE_DIR, "metadata")
SITEMAP_DIR = os.path.join(BASE_DIR, "sitemaps")
UPLOADS_DIR = os.path.join(BASE_DIR, "uploads")           # for admin uploads
USER_RFP_DIR = os.path.join(BASE_DIR, "user_rfp_uploads") # for user uploads

os.makedirs(METADATA_DIR, exist_ok=True)
os.makedirs(SITEMAP_DIR, exist_ok=True)
os.makedirs(UPLOADS_DIR, exist_ok=True)
os.makedirs(USER_RFP_DIR, exist_ok=True)

# Hardcoded Neo4j credentials
NEO4J_URI = "bolt://localhost:7687"
NEO4J_USER = "neo4j"
NEO4J_PASSWORD = "graph@123"

driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))
handler = Neo4jHandler(driver)

# -----------------------------
# Utility functions
# -----------------------------
def infer_tags(path: str):
    parts = path.replace("\\", "/").split("/")
    return {
        "domain": parts[0] if len(parts) > 0 else "Unknown",
        "region": parts[1] if len(parts) > 1 else "Unknown",
        "client": parts[2] if len(parts) > 2 else "Unknown"
    }

def file_hash(path: str) -> str:
    with open(path, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()

def detect_language(text: str) -> str:
    try:
        return detect(text)
    except Exception:
        return "unknown"

def generate_quick_overview(text: str, max_chars: int = 500) -> str:
    return text.strip().replace("\n", " ")[:max_chars]

# -----------------------------
# Sitemap builder
# -----------------------------
def build_sitemap(root_folder: str) -> List[dict]:
    entries = []
    for dirpath, _, filenames in os.walk(root_folder):
        print(f"Scanning: {dirpath}, found {len(filenames)} files")
        for fname in filenames:
            print(f"  -> {fname}")
            ext = os.path.splitext(fname)[1].lower()
            if ext != ".pdf":
                continue
            full_path = os.path.join(dirpath, fname)
            rel_path = os.path.relpath(full_path, root_folder)
            tags = infer_tags(rel_path)
            stat = os.stat(full_path)
            try:
                with fitz.open(full_path) as doc:
                    page_count = doc.page_count
                    text = doc[0].get_text("text") if page_count > 0 else ""
            except Exception:
                page_count = 0
                text = ""
            entries.append({
                "id": file_hash(full_path)[:12],
                "filename": fname,
                "absolute_path": full_path,
                "relative_path": rel_path,
                "extension": ext,
                "domain": tags["domain"],
                "region": tags["region"],
                "client": tags["client"],
                "file_size_bytes": stat.st_size,
                "last_modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                "page_count": page_count,
                "quick_overview": generate_quick_overview(text)
            })
    print(f"Total PDFs found: {len(entries)}")
    return entries

# -----------------------------
# PDF metadata extractor
# -----------------------------
def extract_pdf_text(file_path: str) -> str:
    text_chunks = []
    with fitz.open(file_path) as doc:
        for page in doc:
            text_chunks.append(page.get_text("text"))
    return "\n".join(text_chunks)

def extract_pdf_metadata(file_path: str) -> dict:
    props = {}
    try:
        stat = os.stat(file_path)
        props["file_size_bytes"] = stat.st_size
        props["created_time"] = datetime.fromtimestamp(stat.st_ctime).isoformat()
        props["modified_time"] = datetime.fromtimestamp(stat.st_mtime).isoformat()
    except Exception as e:
        props["fs_meta_error"] = str(e)

    try:
        with fitz.open(file_path) as doc:
            props["page_count"] = doc.page_count
            props["pdf_metadata"] = doc.metadata or {}
    except Exception as e:
        props["pdf_meta_error"] = str(e)

    return props

async def process_pdf(entry: dict, root_folder: str, preview_chars: int = 1500) -> dict:
    full_path = os.path.join(root_folder, entry["relative_path"])
    start = time.time()
    try:
        text = await asyncio.to_thread(extract_pdf_text, full_path)
        props = await asyncio.to_thread(extract_pdf_metadata, full_path)
        lang = detect_language(text)
        hash_val = file_hash(full_path)
        enrichment = await metadata_extractors.enrich_text(text, props.get("page_count", 0))
    except Exception as e:
        return {"error": str(e), "filename": entry.get("filename", "unknown")}

    elapsed = round(time.time() - start, 3)

    return {
        "id": hash_val[:12],
        "filename": entry["filename"],
        "relative_path": entry["relative_path"],
        "extension": entry["extension"],
        "tags": {
            "domain": entry["domain"],
            "region": entry["region"],
            "client": entry["client"]
        },
        "file_size_bytes": props.get("file_size_bytes"),
        "last_modified": props.get("modified_time"),
        "page_count": props.get("page_count"),
        "content_length": len(text),
        "pdf_metadata": props.get("pdf_metadata"),
        "hash": hash_val,
        "language": lang,
        "ingested_at": datetime.now(timezone.utc).isoformat(),
        "content_preview": text[:preview_chars],
        "overview_summary": enrichment["content_summary"]["summary"],
        "content_summary": enrichment["content_summary"],
        "classification": enrichment["classification"],
        "industry_tags": enrichment["industry_tags"],
        "entities": enrichment["entities"],
        "extraction_time_sec": elapsed
    }

async def process_all_pdfs(sitemap: List[dict], root_folder: str):
    tasks = [process_pdf(entry, root_folder) for entry in sitemap]
    return await asyncio.gather(*tasks)

# -----------------------------
# Auth (basic placeholder)
# -----------------------------
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "GET":
        return render_template("login.html")
    # POST
    username = request.form.get("username", "")
    password = request.form.get("password", "")
    # Very basic role routing (placeholder)
    if username.lower().startswith("admin"):
        session["role"] = "admin"
        return redirect(url_for("admin_panel"))
    else:
        session["role"] = "user"
        return redirect(url_for("user_panel"))


# -----------------------------
# Dashboard and panels
# -----------------------------
@app.route("/")
def home():
    # Use dashboard as the new home
    return render_template("dashboard.html")

@app.route("/admin", methods=["GET"])
def admin_panel():
    return render_template("admin.html")

@app.route("/user", methods=["GET"])
def user_panel():
    return render_template("user.html")

# -----------------------------
# Admin actions
# -----------------------------
@app.route("/ingest", methods=["GET"])
def ingest():
    sitemap = build_sitemap(UPLOADS_DIR)
    sitemap_path = os.path.join(SITEMAP_DIR, "sitemap.json")
    with open(sitemap_path, "w", encoding="utf-8") as f:
        json.dump(sitemap, f, indent=2, ensure_ascii=False)

    results = asyncio.run(process_all_pdfs(sitemap, UPLOADS_DIR))
    
     # Save each file’s metadata individually (no big metadata.json)
    metadatas = []
    for doc in results:
        if "id" in doc and "filename" in doc and "error" not in doc:
            # Save per-file JSON
            meta_path = os.path.join(METADATA_DIR, f"{doc['filename']}.json")
            with open(meta_path, "w", encoding="utf-8") as mf:
                json.dump(doc, mf, indent=2, ensure_ascii=False)

            # Push to Neo4j
            handler.create_document_graph(doc)

            metadatas.append(doc)

    preview = json.dumps(results[:1], indent=2, ensure_ascii=False)
    return render_template(
        "results.html",
        files_processed=len(results),
        sitemap_file=sitemap_path,
        metadata_file="(individual JSONs per file)",
        metadata_preview=preview
    )

@app.route("/view_sitemap", methods=["GET"])
def view_sitemap():
    path = os.path.join(SITEMAP_DIR, "sitemap.json")
    if not os.path.exists(path):
        return jsonify({"error": "No sitemap found. Run ingestion first."}), 404
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return jsonify(data)

@app.route("/view_metadata", methods=["GET"])
def view_metadata():
    path = os.path.join(METADATA_DIR, "metadata.json")
    if not os.path.exists(path):
        return jsonify({"error": "No metadata found. Run ingestion first."}), 404
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return jsonify(data)

@app.route("/view_graph", methods=["GET"])
def view_graph():
    with driver.session() as session_db:
        result = session_db.run("""
            MATCH (a)-[r]->(b)
            RETURN a, r, b LIMIT 200
        """)
        nodes, edges = [], []
        seen = set()

        def node_color(label):
            colors = {
                "Document": "#1f77b4",   # blue
                "Client": "#2ca02c",     # green
                "Region": "#ff7f0e",     # orange
                "Domain": "#9467bd",     # purple
                "Industry": "#8c564b",   # brown
                "Technology": "#17becf", # teal
                "Partner": "#d62728",    # red
                "Product": "#bcbd22"     # yellow-green
            }
            return colors.get(label, "#7f7f7f")  # default grey

        for record in result:
            a, r, b = record["a"], record["r"], record["b"]

            if a.id not in seen:
                label_a = list(a.labels)[0] if a.labels else "Node"
                nodes.append({
                    "id": a.id,
                    "label": label_a,
                    "title": dict(a),
                    "color": node_color(label_a)
                })
                seen.add(a.id)

            if b.id not in seen:
                label_b = list(b.labels)[0] if b.labels else "Node"
                nodes.append({
                    "id": b.id,
                    "label": label_b,
                    "title": dict(b),
                    "color": node_color(label_b)
                })
                seen.add(b.id)

            edges.append({
                "from": a.id,
                "to": b.id,
                "label": r.type
            })

    return render_template(
        "graph.html",
        nodes=json.dumps(nodes),
        edges=json.dumps(edges)
    )

def load_all_metadata():
    docs = []
    for fname in os.listdir(METADATA_DIR):
        if fname.endswith(".json") and fname != "metadata.json":  # skip the big file
            fpath = os.path.join(METADATA_DIR, fname)
            try:
                with open(fpath, "r", encoding="utf-8") as f:
                    docs.append(json.load(f))
            except Exception:
                continue
    return docs

from collections import defaultdict

def _render_classification_tables(docs):
    """
    Build relation summary + classification tables for:
      • Group Priority
      • Sector
      • Service Offering
    Then render graph_summary.html with that data.
    """
    # 1) Neo4j relation counts
    rel_summary = []
    with driver.session() as sess:
        result = sess.run("""
            MATCH ()-[r]->()
            RETURN type(r) AS rel_name, count(r) AS cnt
        """)
        rel_summary = [{"name": rec["rel_name"], "count": rec["cnt"]} for rec in result]

    # 2) Tally classifications + examples
    group_counts, sector_counts, service_counts = defaultdict(int), defaultdict(int), defaultdict(int)
    group_examples, sector_examples, service_examples = defaultdict(list), defaultdict(list), defaultdict(list)

    for d in docs:
        cls = d.get("classification", {}) or {}
        grp = cls.get("group_priority", "Unknown")
        sect = cls.get("sector", "Unknown")
        svcs = cls.get("service_offerings", [])
        if not isinstance(svcs, (list, tuple)):
            svcs = [svcs or "Unknown"]

        group_counts[grp] += 1
        sector_counts[sect] += 1
        for svc in svcs:
            service_counts[svc] += 1

        fname = d.get("filename", "(unknown)")
        group_examples[grp].append(fname)
        sector_examples[sect].append(fname)
        for svc in svcs:
            service_examples[svc].append(fname)

    total = len(docs) or 1

    def to_summary(counts, examples):
        return [
            {
                "name": k,
                "count": v,
                "percent": round(v * 100 / total, 1),
                "examples": examples.get(k, [])[:3]
            }
            for k, v in sorted(counts.items(), key=lambda x: -x[1])
        ]

    group_summary = to_summary(group_counts, group_examples)
    sector_summary = to_summary(sector_counts, sector_examples)
    service_summary = to_summary(service_counts, service_examples)

    # 3) Render template with all contexts
    return render_template(
        "graph_summary.html",
        rel_summary=rel_summary,
        group_summary=group_summary,
        sector_summary=sector_summary,
        service_summary=service_summary,
        total_docs=total
    )
@app.route("/graph_summary")
def graph_summary():
    docs = load_all_metadata()

    # check if we already have classification fields
    has_cls = all(
        isinstance(d.get("classification"), dict)
        and d["classification"].get("group_priority")
        for d in docs
    )

    if has_cls:
        return _render_classification_tables(docs)
    else:
        # fallback: build a prompt for Llama
        prompt = "Summarize the following documents by group priority, sector, and service offering. " \
                 "List each category and how many files belong:\n\n"
        for d in docs:
            prompt += f"- {d.get('filename','(unknown)')}: {d.get('overview_summary','')[:100]}...\n"
        prompt += "\nFormat your answer as:\n" \
                  "Group Priority:\n  High: X files\n  Medium: Y files\n" \
                  "Sector:\n  Insurance: A files\n  Manufacturing: B files\n" \
                  "Service Offering:\n  Consulting: M files\n  Implementation: N files\n"

        summary_text = ask_llama(prompt)
        return render_template("graph_summary_fallback.html", summary=summary_text)


@app.route("/graph_summary_combined")
def graph_summary_combined():
    docs = load_all_metadata()
    return render_graph_with_summary(docs, driver)


@app.route("/graph_summary_detailed")
def graph_summary_detailed():
    docs = load_all_metadata()
    return render_detailed_summary(docs, driver)


@app.route("/generate_graph_summary", methods=["POST"])
def generate_graph_summary():
    """
    Expects POSTed JSON with keys: docs, group_counts, sector_counts, service_counts,
    doc_type_counts, tech_counts, year_counts, customer_counts.
    Returns a JSON with LLM summary and chart data.
    """
    data = request.get_json(force=True)
    docs = data.get("docs", [])
    group_counts = data.get("group_counts", {})
    sector_counts = data.get("sector_counts", {})
    service_counts = data.get("service_counts", {})
    doc_type_counts = data.get("doc_type_counts", {})
    tech_counts = data.get("tech_counts", {})
    year_counts = data.get("year_counts", {})
    customer_counts = data.get("customer_counts", {})

    prompt = "Summarize the following classification data:\n"
    for d in docs:
        prompt += f"- {d.get('filename','(unknown)')}: {d.get('overview_summary','')[:100]}...\n"

    summary_text = ask_llama(prompt)

    chart_data = {
        "Group Priority": group_counts,
        "Sector": sector_counts,
        "Service Offering": service_counts,
        "Document Type": doc_type_counts,
        "Technology": tech_counts,
        "Year of Response": year_counts,
        "Customer": customer_counts
    }

    return jsonify({"summary": summary_text, "chart_data": chart_data})


@app.route("/graph_insights")
def graph_insights():
    meta_path = os.path.join(METADATA_DIR, "metadata.json")
    with open(meta_path, "r", encoding="utf-8") as f:
        docs = json.load(f)

    group_counts = defaultdict(int)
    sector_counts = defaultdict(int)
    service_counts = defaultdict(int)
    doc_type_counts = defaultdict(int)
    tech_counts = defaultdict(int)
    year_counts = defaultdict(int)
    customer_counts = defaultdict(int)

    for d in docs:
        cls = d.get("classification", {}) or {}
        grp      = cls.get("group_priority", "Unknown")
        sect     = cls.get("sector", "Unknown")
        svcs     = cls.get("service_offerings", [])
        doc_type = cls.get("document_type", "Unknown")
        techs    = cls.get("technology", [])
        year     = cls.get("year_of_response", "Unknown")
        customer = cls.get("customer", "Unknown")

        if not isinstance(svcs, (list, tuple)):
            svcs = [svcs or "Unknown"]
        if not isinstance(techs, (list, tuple)):
            techs = [techs or "Unknown"]

        group_counts[grp] += 1
        sector_counts[sect] += 1
        for svc in svcs:
            service_counts[svc] += 1
        doc_type_counts[doc_type] += 1
        for tech in techs:
            tech_counts[tech] += 1
        year_counts[year] += 1
        customer_counts[customer] += 1

    def summarize(counts):
        return [{"name": name, "count": cnt} for name, cnt in sorted(counts.items(), key=lambda x: -x[1])]

    prompt = "Summarize the following classification data:\n"
    for d in docs:
        prompt += f"- {d['filename']}: {d.get('overview_summary','')[:100]}...\n"

    summary_text = ask_llama(prompt)

    chart_data = {
        "Group Priority": summarize(group_counts),
        "Sector": summarize(sector_counts),
        "Service Offering": summarize(service_counts),
        "Document Type": summarize(doc_type_counts),
        "Technology": summarize(tech_counts),
        "Year of Response": summarize(year_counts),
        "Customer": summarize(customer_counts)
    }

    return render_template("graph_insights.html", summary=summary_text, chart_data=json.dumps(chart_data))

@app.route("/output_summary_from_llama")
def output_summary_from_llama():
    # Load metadata
    meta_path = os.path.join(METADATA_DIR, "metadata.json")
    with open(meta_path, "r", encoding="utf-8") as f:
        docs = json.load(f)

    prompt = "Summarize the following documents by group priority, sector, service offering, document type, technology, year of response, and customer. " \
             "List each category and how many files belong:\n\n"
    for d in docs:
        prompt += f"- {d['filename']}: {d.get('overview_summary','')[:100]}...\n"

    prompt += "\nFormat your answer as:\n" \
              "Group Priority:\n  High: X files\n  Medium: Y files\n" \
              "Sector:\n  Manufacturing: A files\n  Pharma: B files\n" \
              "Service Offering:\n  Consulting: M files\n  Implementation: N files\n" \
              "Document Type:\n  Case Study: P files\n  RFP: Q files\n" \
              "Technology:\n  Azure: R files\n  AWS: S files\n" \
              "Year of Response:\n  2025: T files\n  2024: U files\n" \
              "Customer:\n  P&G: V files\n  Toyota: W files\n"

    summary_text = ask_llama(prompt)

    return f"""
    <div style='font-family: Arial, sans-serif; background: #f9f9f9; padding: 30px;'>
      <h1 style='color: #e76f51; text-align: center;'>Graph Summary via Llama3.3</h1>
      <h2>LLM-Generated Summary</h2>
      <pre style='background: #fff; border: 1px solid #ddd; padding: 20px; white-space: pre-wrap; font-size: 16px; line-height: 1.5;'>{summary_text}</pre>
      <div style='text-align: center; margin-top: 30px;'>
        <a href='/' style='margin: 0 15px; color: #e76f51; text-decoration: none; font-weight: bold;'>Home</a>
        <a href='/view_graph' style='margin: 0 15px; color: #e76f51; text-decoration: none; font-weight: bold;'>View Graph</a>
        <a href='/chat' style='margin: 0 15px; color: #e76f51; text-decoration: none; font-weight: bold;'>Chat</a>
      </div>
    </div>
    """
@app.route("/upload_files", methods=["POST"])
def upload_files():
    files = request.files.getlist("files")
    category = request.form.get("category", "other")
    if not files:
        return jsonify({"status": "no_files"}), 400

    saved, skipped, metadatas = [], [], []
    for f in files:
        if not f.filename:
            continue
        ext = os.path.splitext(f.filename)[1].lower()
        if ext not in (".pdf", ".doc", ".docx", ".txt"):
            continue
        filename = secure_filename(f.filename)
        file_path = os.path.join(UPLOADS_DIR, filename)
        meta_path = os.path.join(METADATA_DIR, f"{filename}.json")

        if os.path.exists(file_path):
            skipped.append(filename)
            # Load existing metadata
            if os.path.exists(meta_path):
                with open(meta_path, "r", encoding="utf-8") as mf:
                    metadatas.append(json.load(mf))
            continue

        # Save file
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        f.save(file_path)
        # Build entry for process_pdf
        entry = {
            "filename": filename,
            "relative_path": filename,
            "extension": ext,
            "domain": "Admin",
            "region": "Unknown",
            "client": "Unknown",
            "category": category
        }
        # Process file
        result = asyncio.run(process_pdf(entry, UPLOADS_DIR))
        # Save metadata JSON
        with open(meta_path, "w", encoding="utf-8") as mf:
            json.dump(result, mf, indent=2, ensure_ascii=False)
        metadatas.append(result)
        saved.append(filename)

    return jsonify({
        "status": "success",
        "files_saved": saved,
        "files_skipped": skipped,
        "metadata": metadatas
    })
@app.route("/upload_rfp", methods=["POST"])
def upload_rfp():
    """
    Handles user RFP upload (single PDF).
    Processes it through the same metadata pipeline as admin docs.
    """
    file = request.files.get("rfp_file")
    if file is None or file.filename == "":
        return jsonify({"status": "no_file"}), 400

    filename = secure_filename(file.filename)
    if not filename.lower().endswith(".pdf"):
        return jsonify({"status": "invalid_type", "message": "Only PDF allowed"}), 400

    dest_path = os.path.join(USER_RFP_DIR, filename)
    file.save(dest_path)

    # Build a sitemap-like entry for this single file
    entry = {
        "filename": filename,
        "relative_path": filename,
        "extension": ".pdf",
        "domain": "User",
        "region": "Unknown",
        "client": "Unknown"
    }

    # Process PDF (extract text, metadata, enrichment)
    result = asyncio.run(process_pdf(entry, USER_RFP_DIR))

    # Save metadata JSON for this user doc (optional)
    user_meta_path = os.path.join(METADATA_DIR, f"user_{result['id']}.json")
    with open(user_meta_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    # Push into Neo4j graph
    handler.create_document_graph(result)

    # Track enriched doc in session
    session["current_doc"] = result
    session["chat_history"] = []  # reset chat history for new upload

    return jsonify({"status": "success", "saved_to": dest_path, "doc_id": result["id"]})
@app.route("/chatbot", methods=["POST"])
def chatbot():
    data = request.get_json(force=True)
    user_msg = (data.get("message") or "").strip()
    if not user_msg or len(user_msg) > 1000:
        return jsonify({"status": "error", "message": "Invalid input"}), 400

    answer, history = get_chatbot_response(
        user_msg,
        session,
        driver,
        METADATA_DIR,
        ask_llama,
        process_pdf
    )

    return jsonify({"status": "ok", "answer": answer, "history": history})

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))


# -----------------------------
# Static file serving convenience (optional)
# -----------------------------
@app.route("/static/<path:filename>")
def static_files(filename):
    return send_from_directory("static", filename)

# -----------------------------
# Run app
# -----------------------------

if __name__ == '__main__':
    app.run(debug=True,host='0.0.0.0',port=5000)
