from flask import Flask, render_template, redirect, url_for
import os

# Create Flask app
app = Flask(__name__, static_folder='static', template_folder='templates')

# Routes
@app.route('/')
def home():
    # Show dashboard summary page at root
    return render_template('dashboard-summary.html')


@app.route('/user')
def user_panel():
    return render_template('user.html')




@app.route('/dashboard')
def dashboard():
    # Show dashboard summary page
    return render_template('dashboard-summary.html')


# Create short-name aliases used by templates (some templates call url_for('admin') or url_for('user'))
# Ensure admin and user endpoints exist with the short names templates expect.

@app.route('/admin')
def admin_panel():
    # Render the admin panel with document processing and graph management
    return render_template('admin-panel.html')

# alias endpoints for templates that reference the short names
app.add_url_rule('/admin', endpoint='admin', view_func=admin_panel)
app.add_url_rule('/user', endpoint='user', view_func=user_panel)


@app.route('/logout')
def logout():
    # simple logout placeholder - redirect to home
    return redirect(url_for('home'))

# Optional: simple status endpoint
@app.route('/health')
def health():
    return {'status': 'ok'}

if __name__ == '__main__':
    # Allow running on 0.0.0.0 for external testing, default port 5001
    port = int(os.environ.get('PORT', 5001))
    app.run(host='0.0.0.0', port=port, debug=True)


