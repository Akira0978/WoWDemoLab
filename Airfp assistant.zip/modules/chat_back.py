import os
import json
from modules.ollama_helper import ask_llama
from modules.neo4j_handler import Neo4jHandler  # or import driver if you want to use raw driver

UPLOAD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "uploads")
META_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "metadata")

def get_or_create_metadata(filename: str, process_pdf):
    file_path = os.path.join(UPLOAD_DIR, filename)
    meta_path = os.path.join(META_DIR, f"{filename}.json")

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File {filename} not found in uploads/")

    if os.path.exists(meta_path):
        with open(meta_path, "r", encoding="utf-8") as f:
            return json.load(f)

    # If metadata missing, run extraction
    metadata = process_pdf(file_path)  # Pass your actual process_pdf function
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)
    return metadata

def query_related_docs(driver, user_query: str, limit=3):
    cypher = """
    MATCH (d:Document)
    WHERE d.summary CONTAINS $q OR d.filename CONTAINS $q
    RETURN d.filename AS filename, d.metadata_path AS metadata_path
    LIMIT $limit
    """
    with driver.session() as session:
        results = session.run(cypher, q=user_query, limit=limit)
        return [r.data() for r in results]

def build_context(user_query: str, process_pdf, driver):
    # Scenario 1: User just uploaded a file (detected by filename in query)
    if os.path.exists(os.path.join(UPLOAD_DIR, user_query)):
        metadata = get_or_create_metadata(user_query, process_pdf)
        return f"Document: {user_query}\nSummary: {metadata.get('overview_summary')}\nEntities: {metadata.get('entities')}"

    # Scenario 2: User asks about an existing doc
    related = query_related_docs(driver, user_query)
    contexts = []
    for doc in related:
        with open(doc["metadata_path"], "r", encoding="utf-8") as f:
            meta = json.load(f)
        contexts.append(f"{doc['filename']} → {meta.get('overview_summary')}")
    return "\n".join(contexts)

def answer_query(user_query: str, process_pdf, driver):
    context = build_context(user_query, process_pdf, driver)
    prompt = f"""
You are AiRFP Assistant. Use the following context to answer:

Context:
{context}

User Question: {user_query}
Answer:
"""
    return ask_llama(prompt)

def build_chat_context(user_msg, session, driver, metadata_dir):
    history = session.setdefault("chat_history", [])
    current_doc = session.get("current_doc")
    context = ""

    # Always include all available files in metadata/
    all_metadata = []
    for fname in os.listdir(metadata_dir):
        if fname.endswith(".json"):
            meta_path = os.path.join(metadata_dir, fname)
            try:
                with open(meta_path, "r", encoding="utf-8") as f:
                    meta = json.load(f)
                    all_metadata.append({
                        "filename": meta.get("filename", fname.replace(".json", "")),
                        "summary": meta.get("overview_summary", ""),
                        "entities": meta.get("entities", {}),
                        "id": meta.get("id", ""),
                    })
            except Exception:
                continue

    # Try to match user query to a file
    matched = []
    query_lower = user_msg.lower()
    for meta in all_metadata:
        if meta["filename"].lower() in query_lower or any(word in query_lower for word in meta["filename"].lower().split()):
            matched.append(meta)

    # If a match, include its summary/entities in context
    if matched:
        context += "Matched document(s):\n"
        for m in matched:
            context += f"- {m['filename']} (id: {m['id']}): {m['summary']}\n"
            if m["entities"]:
                context += f"  Entities: {m['entities']}\n"
    else:
        # If no match, list all available files
        context += "Available files:\n"
        for m in all_metadata:
            context += f"- {m['filename']}\n"

    # Add chat history
    hist_str = "\n".join([f"{t['role']}: {t['content']}" for t in history[-10:]])
    prompt = (
        f"SYSTEM:SYSTEM: You are AiRFP Assistant. Always ground your answers in the CONTEXT provided below. If the user asks about a document, use its overview_summary and entities from CONTEXT. Do not guess based only on the filename.\n"
        f"CONTEXT:\n{context}\n\n"
        f"HISTORY:\n{hist_str}\n\n"
        f"USER: {user_msg}\nASSISTANT:"
    )
    return prompt, history

def chatbot_answer(user_msg, session, driver, metadata_dir, ask_llama):
    prompt, history = build_chat_context(user_msg, session, driver, metadata_dir)
    answer = ask_llama(prompt)
    history.append({"role": "assistant", "content": answer})
    session["chat_history"] = history
    return answer, history

def get_chatbot_response(user_msg, session, driver, metadata_dir, ask_llama, process_pdf=None):
    history = session.setdefault("chat_history", [])
    current_doc = session.get("current_doc")
    context = ""
    matched = []

    # Load all metadata files
    all_metadata = []
    for fname in os.listdir(metadata_dir):
        if fname.endswith(".json"):
            meta_path = os.path.join(metadata_dir, fname)
            try:
                with open(meta_path, "r", encoding="utf-8") as f:
                    meta = json.load(f)
                    all_metadata.append({
                        "filename": meta.get("filename", fname.replace(".json", "")),
                        "summary": meta.get("overview_summary", ""),
                        "entities": meta.get("entities", {}),
                        "id": meta.get("id", ""),
                        "metadata_path": meta_path
                    })
            except Exception:
                continue

    # Try to match user query to a file (by filename or content)
    query_lower = user_msg.lower()
    for meta in all_metadata:
        if meta["filename"].lower() in query_lower or any(word in query_lower for word in meta["filename"].lower().split()):
            matched.append(meta)

    # If matched, use answer_query logic (document-centric)
    if matched:
        context += "Matched document(s):\n"
        for m in matched:
            context += f"- {m['filename']} (id: {m['id']}): {m['summary']}\n"
            if m["entities"]:
                context += f"  Entities: {m['entities']}\n"
    else:
        # If not matched, use chatbot_answer logic (general context)
        context += "Available files:\n"
        for m in all_metadata:
            context += f"- {m['filename']}\n"

    # Add chat history
    hist_str = "\n".join([f"{t['role']}: {t['content']}" for t in history[-10:]])
    prompt = (
        f"SYSTEM: You are AiRFP Assistant. Always ground your answers in the CONTEXT provided below. "
        f"If the user asks about a document, use its overview_summary and entities from CONTEXT. "
        f"Do not guess based only on the filename.\n"
        f"CONTEXT:\n{context}\n\n"
        f"HISTORY:\n{hist_str}\n\n"
        f"USER: {user_msg}\nASSISTANT:"
    )
    answer = ask_llama(prompt)
    history.append({"role": "assistant", "content": answer})
    session["chat_history"] = history
    return answer, history