import os
import json
from collections import defaultdict
from flask import render_template
from modules.ollama_helper import ask_llama

# -----------------------------
# Core classification summary
# -----------------------------
def render_classification_tables(docs, driver):
    # --- Relationship summary from Neo4j ---
    rel_summary = []
    with driver.session() as sess:
        result = sess.run(
            "MATCH ()-[r]->() RETURN type(r) AS rel_name, count(r) AS cnt ORDER BY cnt DESC"
        )
        rel_summary = [{"name": rec["rel_name"], "count": rec["cnt"]} for rec in result]

    # --- Classification counts ---
    group_counts, sector_counts, service_counts = defaultdict(int), defaultdict(int), defaultdict(int)
    group_examples, sector_examples, service_examples = defaultdict(list), defaultdict(list), defaultdict(list)

    for d in docs:
        cls = d.get("classification", {}) or {}
        grp = cls.get("group_priority", "Unknown")
        sect = cls.get("sector", "Unknown")
        svcs = cls.get("service_offerings", [])
        if not isinstance(svcs, (list, tuple)):
            svcs = [svcs or "Unknown"]

        group_counts[grp] += 1
        sector_counts[sect] += 1
        for svc in svcs:
            service_counts[svc] += 1

        fname = d.get("filename", "(unknown)")
        group_examples[grp].append(fname)
        sector_examples[sect].append(fname)
        for svc in svcs:
            service_examples[svc].append(fname)

    total = len(docs) or 1

    def to_summary(counts, examples):
        return [
            {
                "name": k,
                "count": v,
                "percent": round(v * 100 / total, 1),
                "examples": examples.get(k, [])[:3]
            }
            for k, v in sorted(counts.items(), key=lambda x: -x[1])
        ]

    group_summary = to_summary(group_counts, group_examples)
    sector_summary = to_summary(sector_counts, sector_examples)
    service_summary = to_summary(service_counts, service_examples)

    return render_template(
        "graph_summary.html",
        rel_summary=rel_summary,
        group_summary=group_summary,
        sector_summary=sector_summary,
        service_summary=service_summary,
        total_docs=total
    )

# -----------------------------
# Fallback summary with LLM
# -----------------------------
def summarize_with_llama(docs):
    prompt = "Summarize the following documents by group priority, sector, service offering, industries, and key entities:\n\n"
    for d in docs:
        cls = d.get("classification", {}) or {}
        prompt += f"- {d.get('filename','(unknown)')}:\n"
        prompt += f"  Summary: {d.get('overview_summary','')[:300]}...\n"
        prompt += f"  Group: {cls.get('group_priority','Unknown')}, Sector: {cls.get('sector','Unknown')}, Services: {cls.get('service_offerings',[])}\n"
        prompt += f"  Industries: {d.get('industry_tags',{}).get('industries',[])}\n"
        prompt += f"  Entities: {d.get('entities',{})}\n\n"
    return ask_llama(prompt)

# -----------------------------
# Combined summary + graph viz
# -----------------------------
def render_graph_with_summary(docs, driver):
    # Classification summary
    rel_summary = []
    with driver.session() as sess:
        result = sess.run("MATCH ()-[r]->() RETURN type(r) AS rel_name, count(r) AS cnt")
        rel_summary = [{"name": rec["rel_name"], "count": rec["cnt"]} for rec in result]

    group_counts, sector_counts, service_counts = defaultdict(int), defaultdict(int), defaultdict(int)
    for d in docs:
        cls = d.get("classification", {}) or {}
        grp = cls.get("group_priority", "Unknown")
        sect = cls.get("sector", "Unknown")
        svcs = cls.get("service_offerings", [])
        if not isinstance(svcs, (list, tuple)):
            svcs = [svcs or "Unknown"]

        group_counts[grp] += 1
        sector_counts[sect] += 1
        for svc in svcs:
            service_counts[svc] += 1

    group_summary = [{"name": k, "count": v} for k, v in sorted(group_counts.items(), key=lambda x: -x[1])]
    sector_summary = [{"name": k, "count": v} for k, v in sorted(sector_counts.items(), key=lambda x: -x[1])]
    service_summary = [{"name": k, "count": v} for k, v in sorted(service_counts.items(), key=lambda x: -x[1])]

    # Graph visualization nodes/edges
    nodes, edges, seen = [], [], set()

    def node_color(label):
        colors = {
            "Document": "#1f77b4", "Client": "#2ca02c", "Region": "#ff7f0e",
            "Domain": "#9467bd", "Industry": "#8c564b", "Technology": "#17becf",
            "Partner": "#d62728", "Product": "#bcbd22"
        }
        return colors.get(label, "#7f7f7f")

    with driver.session() as session_db:
        result = session_db.run("MATCH (a)-[r]->(b) RETURN a, r, b LIMIT 200")
        for record in result:
            a, r, b = record["a"], record["r"], record["b"]
            if a.id not in seen:
                label_a = list(a.labels)[0] if a.labels else "Node"
                nodes.append({"id": a.id, "label": label_a, "title": dict(a), "color": node_color(label_a)})
                seen.add(a.id)
            if b.id not in seen:
                label_b = list(b.labels)[0] if b.labels else "Node"
                nodes.append({"id": b.id, "label": label_b, "title": dict(b), "color": node_color(label_b)})
                seen.add(b.id)
            edges.append({"from": a.id, "to": b.id, "label": r.type})

    return render_template(
        "graphwithsummary.html",
        nodes=json.dumps(nodes),
        edges=json.dumps(edges),
        rel_summary=rel_summary,
        group_summary=group_summary,
        sector_summary=sector_summary,
        service_summary=service_summary
    )

# -----------------------------
# Detailed classification summary
# -----------------------------
def render_detailed_summary(docs, driver):
    rel_summary = []
    with driver.session() as sess:
        result = sess.run("MATCH ()-[r]->() RETURN type(r) AS rel_name, count(r) AS cnt")
        rel_summary = [{"name": rec["rel_name"], "count": rec["cnt"]} for rec in result]

    def summarize(counts):
        return [{"name": name, "count": cnt} for name, cnt in sorted(counts.items(), key=lambda x: -x[1])]

    group_counts, sector_counts, service_counts = defaultdict(int), defaultdict(int), defaultdict(int)
    doc_type_counts, tech_counts, year_counts, customer_counts = defaultdict(int), defaultdict(int), defaultdict(int), defaultdict(int)

    for d in docs:
        cls = d.get("classification", {}) or {}
        grp = cls.get("group_priority", "Unknown")
        sect = cls.get("sector", "Unknown")
        svcs = cls.get("service_offerings", [])
        doc_type = cls.get("document_type", cls.get("sub_type", "Unknown"))
        techs = cls.get("technology", [])
        year = cls.get("year_of_response", "Unknown")
        customer = cls.get("customer", "Unknown")

        if not isinstance(svcs, (list, tuple)):
            svcs = [svcs or "Unknown"]
        if not isinstance(techs, (list, tuple)):
            techs = [techs or "Unknown"]

        group_counts[grp] += 1
        sector_counts[sect] += 1
        for svc in svcs:
            service_counts[svc] += 1
        doc_type_counts[doc_type] += 1
        for tech in techs:
            tech_counts[tech] += 1
        year_counts[year] += 1
        customer_counts[customer] += 1

    return render_template(
        "graph_summary_detailed.html",
        rel_summary=rel_summary,
        group_summary=summarize(group_counts),
        sector_summary=summarize(sector_counts),
        service_summary=summarize(service_counts),
        doc_type_summary=summarize(doc_type_counts),
        tech_summary=summarize(tech_counts),
        year_summary=summarize(year_counts),
        customer_summary=summarize(customer_counts)
    )