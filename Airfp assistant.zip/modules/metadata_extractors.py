import re
import asyncio
from typing import List, Dict
import spacy
from modules.ollama_helper import ask_llama  # import your LLM client

# Load spaCy model once at module level
nlp = spacy.load("en_core_web_sm")

INDUSTRY_KEYWORDS = {
    "Finance": ["investment", "banking", "portfolio", "equity", "trading", "fintech"],
    "Healthcare": ["patient", "clinical", "diagnosis", "hospital", "biotech", "pharma"],
    "Education": ["curriculum", "learning", "pedagogy", "school", "university", "edtech"],
    "Manufacturing": ["supply chain", "factory", "production", "automation", "lean"],
    "Technology": ["AI", "machine learning", "cloud", "data", "software", "IoT"],
    "Retail": ["ecommerce", "inventory", "POS", "customer", "store", "shopping"],
    "Legal": ["compliance", "contract", "litigation", "regulation", "law", "jurisdiction"]
}

# -----------------------------
# Heuristic classifiers
# -----------------------------
def infer_document_type(text: str) -> str:
    t = text.lower()
    if "request for proposal" in t or "rfp" in t[:500]:
        return "RFP"
    if "case study" in t:
        return "Case Study"
    if "white paper" in t or "whitepaper" in t:
        return "Whitepaper"
    if "proposal" in t:
        return "Proposal"
    if "statement of work" in t or "sow" in t:
        return "SOW"
    return "Unknown"

def infer_sector(industries: List[str]) -> str:
    if not industries:
        return "General"
    return industries[0]

def infer_priority(text: str) -> str:
    t = text.lower()
    if "urgent" in t or "immediately" in t:
        return "High"
    if "recommendation" in t or "draft" in t:
        return "Medium"
    return "Low"

def infer_services(text: str) -> List[str]:
    services = []
    t = text.lower()
    if "consulting" in t:
        services.append("Consulting")
    if "implementation" in t or "deployment" in t:
        services.append("Implementation")
    if "support" in t or "maintenance" in t:
        services.append("Support")
    return services or ["General"]

# -----------------------------
# Async wrappers
# -----------------------------
async def extract_industry_keywords(text: str) -> List[str]:
    def _extract():
        text_lower = text.lower()
        found_keywords = set()
        for industry, keywords in INDUSTRY_KEYWORDS.items():
            for keyword in keywords:
                if re.search(rf"\b{re.escape(keyword.lower())}\b", text_lower):
                    found_keywords.add(industry)
                    break
        return list(found_keywords)
    return await asyncio.to_thread(_extract)

async def extract_entities(text: str) -> Dict[str, List[str]]:
    def _extract():
        doc = nlp(text)
        entities = {
            "clients": [],
            "products": [],
            "technologies": [],
            "partners": []
        }
        for ent in doc.ents:
            if ent.label_ in ["ORG", "PRODUCT"]:
                entities["clients"].append(ent.text)
                entities["partners"].append(ent.text)
                entities["products"].append(ent.text)
        for token in doc:
            if token.pos_ == "PROPN" and token.text.lower() in ["azure", "terraform", "kubernetes"]:
                entities["technologies"].append(token.text)
        # Deduplicate
        for key in entities:
            entities[key] = list(set(entities[key]))
        return entities
    return await asyncio.to_thread(_extract)

async def extract_domain_tags(text: str) -> List[str]:
    def _extract():
        doc = nlp(text)
        return list(set([chunk.text for chunk in doc.noun_chunks if len(chunk.text.split()) <= 3]))
    return await asyncio.to_thread(_extract)

# -----------------------------
# Main async enrichment with LLM fallback
# -----------------------------
async def enrich_text(text: str, page_count: int) -> Dict:
    industries, domains, entities = await asyncio.gather(
        extract_industry_keywords(text),
        extract_domain_tags(text),
        extract_entities(text)
    )
    word_count = len(text.split())

    # Heuristic classification
    doc_type = infer_document_type(text)
    sector = infer_sector(industries)
    priority = infer_priority(text)
    services = infer_services(text)

    # LLM fallback if heuristics are too generic
    if doc_type == "Unknown" or sector == "General":
        prompt = f"""Classify the following document into categories:
- Document type (RFP, Case Study, Proposal, Whitepaper, SOW, Other)
- Sector (Finance, Healthcare, Education, Manufacturing, Technology, Retail, Legal, General)
- Group priority (High, Medium, Low)
- Service offerings (Consulting, Implementation, Support, Other)

Document excerpt:
{text[:1000]}

Return the classification in JSON with keys: document_type, sector, group_priority, service_offerings.
"""
        try:
            ai_response = ask_llama(prompt)
            import json as pyjson
            parsed = pyjson.loads(ai_response.strip())
            doc_type = parsed.get("document_type", doc_type)
            sector = parsed.get("sector", sector)
            priority = parsed.get("group_priority", priority)
            services = parsed.get("service_offerings", services)
        except Exception:
            # fallback to heuristics only
            pass

    classification = {
        "document_type": doc_type,
        "group_priority": priority,
        "sector": sector,
        "service_offerings": services
    }

    return {
        "content_summary": {
            "summary": text[:300].replace("\n", " ") + "...",
            "word_count": word_count,
            "page_count": page_count
        },
        "classification": classification,
        "industry_tags": {
            "industries": industries,
            "domains": domains[:10]
        },
        "entities": entities
    }