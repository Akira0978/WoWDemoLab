import os
import json
from typing import Tuple, Callable, Optional
from modules.ollama_helper import ask_llama
from modules.neo4j_handler import Neo4jHandler
from neo4j import GraphDatabase# or import driver if you want to use raw driver

UPLOAD_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "uploads")
META_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "metadata")

def get_or_create_metadata(filename: str, process_pdf):
    file_path = os.path.join(UPLOAD_DIR, filename)
    meta_path = os.path.join(META_DIR, f"{filename}.json")

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"File {filename} not found in uploads/")

    if os.path.exists(meta_path):
        with open(meta_path, "r", encoding="utf-8") as f:
            return json.load(f)

    # If metadata missing, run extraction
    metadata = process_pdf(file_path)  # Pass your actual process_pdf function
    with open(meta_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, indent=2)
    return metadata

def query_related_docs(driver, user_query: str, limit=3):
    cypher = """
    MATCH (d:Document)
    WHERE d.summary CONTAINS $q OR d.filename CONTAINS $q
    RETURN d.filename AS filename, d.metadata_path AS metadata_path
    LIMIT $limit
    """
    with driver.session() as session:
        results = session.run(cypher, q=user_query, limit=limit)
        return [r.data() for r in results]

def build_context(user_query: str, process_pdf, driver):
    # Scenario 1: User just uploaded a file (detected by filename in query)
    if os.path.exists(os.path.join(UPLOAD_DIR, user_query)):
        metadata = get_or_create_metadata(user_query, process_pdf)
        return f"Document: {user_query}\nSummary: {metadata.get('overview_summary')}\nEntities: {metadata.get('entities')}"

    # Scenario 2: User asks about an existing doc
    related = query_related_docs(driver, user_query)
    contexts = []
    for doc in related:
        with open(doc["metadata_path"], "r", encoding="utf-8") as f:
            meta = json.load(f)
        contexts.append(f"{doc['filename']} → {meta.get('overview_summary')}")
    return "\n".join(contexts)

def answer_query(user_query: str, process_pdf, driver):
    context = build_context(user_query, process_pdf, driver)
    prompt = f"""
You are AiRFP Assistant. Use the following context to answer:

Context:
{context}

User Question: {user_query}
Answer:
"""
    return ask_llama(prompt)

def build_chat_context(user_msg, session, driver, metadata_dir):
    history = session.setdefault("chat_history", [])
    current_doc = session.get("current_doc")
    context = ""

    # Always include all available files in metadata/
    all_metadata = []
    for fname in os.listdir(metadata_dir):
        if fname.endswith(".json"):
            meta_path = os.path.join(metadata_dir, fname)
            try:
                with open(meta_path, "r", encoding="utf-8") as f:
                    meta = json.load(f)
                    all_metadata.append({
                        "filename": meta.get("filename", fname.replace(".json", "")),
                        "summary": meta.get("overview_summary", ""),
                        "entities": meta.get("entities", {}),
                        "id": meta.get("id", ""),
                    })
            except Exception:
                continue

    # Try to match user query to a file
    matched = []
    query_lower = user_msg.lower()
    for meta in all_metadata:
        if meta["filename"].lower() in query_lower or any(word in query_lower for word in meta["filename"].lower().split()):
            matched.append(meta)

    # If a match, include its summary/entities in context
    if matched:
        context += "Matched document(s):\n"
        for m in matched:
            context += f"- {m['filename']} (id: {m['id']}): {m['summary']}\n"
            if m["entities"]:
                context += f"  Entities: {m['entities']}\n"
    else:
        # If no match, list all available files
        context += "Available files:\n"
        for m in all_metadata:
            context += f"- {m['filename']}\n"

    # Add chat history
    hist_str = "\n".join([f"{t['role']}: {t['content']}" for t in history[-10:]])
    prompt = (
        f"SYSTEM:SYSTEM: You are AiRFP Assistant. Always ground your answers in the CONTEXT provided below. If the user asks about a document, use its overview_summary and entities from CONTEXT. Do not guess based only on the filename.\n"
        f"CONTEXT:\n{context}\n\n"
        f"HISTORY:\n{hist_str}\n\n"
        f"USER: {user_msg}\nASSISTANT:"
    )
    return prompt, history

def chatbot_answer(user_msg, session, driver, metadata_dir, ask_llama):
    prompt, history = build_chat_context(user_msg, session, driver, metadata_dir)
    answer = ask_llama(prompt)
    history.append({"role": "assistant", "content": answer})
    session["chat_history"] = history
    return answer, history

def get_chatbot_response(
    user_msg: str,
    session,
    driver: GraphDatabase,
    metadata_dir: str,
    ask_llama: Callable[[str], str],
    process_pdf: Optional[Callable] = None
) -> Tuple[str, list]:
    """
    Build a grounded prompt using:
      - session['current_doc'] (if present)
      - related documents from Neo4j
      - top corpus summaries from metadata.json
      - recent chat history from session['chat_history']

    Returns: (answer_text, history_list)
    """

    # ensure chat history exists
    history = session.setdefault("chat_history", [])

    # Build context from uploaded/current document
    context_parts = []
    current_doc = session.get("current_doc")
    if current_doc and isinstance(current_doc, dict):
        fname = current_doc.get("filename", "unknown")
        doc_id = current_doc.get("id", "")
        context_parts.append(f"Uploaded document: {fname} (id: {doc_id})")
        overview = current_doc.get("overview_summary") or current_doc.get("content_preview", "")[:400]
        if overview:
            context_parts.append(f"Document summary: {overview}")
        # industries
        inds = current_doc.get("industry_tags", {}).get("industries", [])
        if inds:
            context_parts.append("Industries: " + ", ".join(inds))
        # entities: show only top-level keys with up to 6 values each
        entities = current_doc.get("entities", {}) or {}
        if entities:
            ent_lines = []
            for k, v in entities.items():
                if not v:
                    continue
                vals = v[:6] if isinstance(v, (list, tuple)) else [v]
                ent_lines.append(f"{k}: {', '.join(vals)}")
            if ent_lines:
                context_parts.append("Key entities: " + " | ".join(ent_lines))

    # Pull related docs from Neo4j (if we have a current doc id)
    if current_doc and current_doc.get("id"):
        try:
            related = []
            with driver.session() as sess:
                q = """
                MATCH (d:Document {id:$doc_id})-[]->(x)<-[]-(other:Document)
                WHERE other.id <> $doc_id
                RETURN other.filename AS filename, labels(x)[0] AS via LIMIT 8
                """
                res = sess.run(q, doc_id=current_doc["id"])
                for r in res:
                    fn = r.get("filename")
                    via = r.get("via")
                    if fn:
                        related.append(f"{fn} (via {via})" if via else fn)
            if related:
                context_parts.append("Related documents: " + "; ".join(related))
        except Exception:
            # don't fail the whole flow on Neo4j errors
            pass

    # Add top N corpus summaries from metadata.json for grounding
    meta_path = os.path.join(metadata_dir, "metadata.json")
    if os.path.exists(meta_path):
        try:
            with open(meta_path, encoding="utf-8") as mf:
                docs = json.load(mf)
                snippets = []
                for d in docs[:3]:
                    name = d.get("filename", "unknown")
                    summ = d.get("overview_summary") or d.get("quick_overview") or ""
                    if summ:
                        snippets.append(f"{name}: {summ[:300]}")
                if snippets:
                    context_parts.append("Sample corpus summaries:\n" + "\n".join(snippets))
        except Exception:
            pass

    # Compose final context
    context = "\n\n".join(context_parts).strip()
    if not context:
        context = "No uploaded document context available."

    # Prepare history string (last 10 turns)
    hist_turns = history[-20:]  # keep some buffer (user+assistant entries)
    hist_lines = []
    for t in hist_turns:
        role = t.get("role", "user")
        content = t.get("content", "")
        hist_lines.append(f"{role.upper()}: {content}")

    hist_str = "\n".join(hist_lines)

    # Construct system + user prompt
    prompt = (
        "SYSTEM: You are AiRFP Assistant, an expert in RFP analysis and project estimation. "
        "Always use the CONTEXT below to answer the user's question. "
        "Structure your answer with clear sections and bullet points in the response "
        "If the user asks about project effort, estimate based on available deliverables, phases, and testing mentioned. "
        "Reference document sections and entities when relevant. "
        "If information is missing, suggest what the user can do next (e.g., review specific sections, upload more docs, or clarify their question). "
        "Be concise, friendly, and actionable.\n\n"
        f"CONTEXT:\n{context}\n\n"
        f"HISTORY:\n{hist_str}\n\n"
        f"USER QUESTION: {user_msg}\n"
        "ASSISTANT INSTRUCTIONS: Structure your answer with:\n"
        "- A direct summary addressing the user's question\n"
        "- Relevant details from the document(s)\n"
        "- Actionable next steps or suggestions\n"
        "ASSISTANT:"
    )

    # Call LLM
    try:
        answer = ask_llama(prompt)
    except Exception as e:
        answer = "Sorry, I couldn't produce an answer right now (LLM error)."

    # Update history and session
    history.append({"role": "user", "content": user_msg})
    history.append({"role": "assistant", "content": answer})
    # keep history length bounded
    session["chat_history"] = history[-200:]

    # If no current_doc and user asked about an uploaded file explicitly, try to locate by filename in metadata (optional)
    # (The caller can pass process_pdf if they want on-the-fly reprocessing; not used here by default.)

    return answer, session["chat_history"]
