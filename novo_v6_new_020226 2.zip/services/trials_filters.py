#Standardizes query parameters into a filter dict and applies them to trial rows.

# services/trials_filters.py
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Dict, Iterable, List, Optional, Tuple


DATE_FMT = "%Y-%m-%d"


def _parse_date(s: Optional[str]) -> Optional[datetime]:
    if not s:
        return None
    return datetime.strptime(s, DATE_FMT)


def _to_list(value: Optional[str]) -> Optional[List[str]]:
    """
    Accepts:
      - None
      - "A"
      - "A,B,C"
    Returns list[str] or None.
    """
    if value is None or value == "":
        return None
    parts = [p.strip() for p in value.split(",") if p.strip()]
    return parts or None


@dataclass
class TrialFilters:
    therapy_area: Optional[str] = None                 # diabetes|obesity|cardiovascular
    sponsor: Optional[List[str]] = None                # one or many
    drug_name: Optional[List[str]] = None              # one or many
    mechanism: Optional[List[str]] = None              # one or many
    indication: Optional[List[str]] = None             # one or many
    phase: Optional[List[int]] = None                  # one or many
    status: Optional[List[str]] = None                 # one or many
    region: Optional[List[str]] = None                 # US|EU|Asia|LatAm|Other
    country: Optional[List[str]] = None                # one or many
    start_from: Optional[datetime] = None
    start_to: Optional[datetime] = None
    completion_from: Optional[datetime] = None
    completion_to: Optional[datetime] = None
    updated_within_days: Optional[int] = None          # for "recent changes" later


def parse_filters(args: Dict[str, Any]) -> TrialFilters:
    """
    Parses Flask request.args (or any dict-like) into a TrialFilters object.
    """
    phase_raw = _to_list(args.get("phase"))
    phase = [int(p) for p in phase_raw] if phase_raw else None

    updated_within = args.get("updated_within_days")
    updated_within_days = int(updated_within) if updated_within else None

    return TrialFilters(
        therapy_area=args.get("therapy_area") or None,
        sponsor=_to_list(args.get("sponsor")),
        drug_name=_to_list(args.get("drug_name")),
        mechanism=_to_list(args.get("mechanism")),
        indication=_to_list(args.get("indication")),
        phase=phase,
        status=_to_list(args.get("status")),
        region=_to_list(args.get("region")),
        country=_to_list(args.get("country")),
        start_from=_parse_date(args.get("start_from")),
        start_to=_parse_date(args.get("start_to")),
        completion_from=_parse_date(args.get("completion_from")),
        completion_to=_parse_date(args.get("completion_to")),
        updated_within_days=updated_within_days,
    )


def apply_filters(trials: Iterable[Dict[str, Any]], f: TrialFilters) -> List[Dict[str, Any]]:
    """
    Filters are applied in Python to keep JS thin (as per project decision).
    """
    out: List[Dict[str, Any]] = []
    now = datetime.now()

    for t in trials:
        # Therapy area
        if f.therapy_area and t.get("therapy_area") != f.therapy_area:
            continue

        # Sponsor / drug / moa / indication / status
        if f.sponsor and t.get("sponsor") not in f.sponsor:
            continue
        if f.drug_name and t.get("drug_name") not in f.drug_name:
            continue
        if f.mechanism and t.get("mechanism") not in f.mechanism:
            continue
        if f.indication and t.get("indication") not in f.indication:
            continue
        if f.status and t.get("status") not in f.status:
            continue

        # Phase
        if f.phase and int(t.get("phase", -1)) not in f.phase:
            continue

        # Regions / countries
        if f.region:
            regions = t.get("regions") or []
            if not any(r in regions for r in f.region):
                continue
        if f.country:
            countries = t.get("countries") or []
            if not any(c in countries for c in f.country):
                continue

        # Date filters
        try:
            start_dt = datetime.strptime(t.get("start_date"), DATE_FMT)
            comp_dt = datetime.strptime(t.get("primary_completion_date"), DATE_FMT)
            upd_dt = datetime.strptime(t.get("last_updated"), DATE_FMT)
        except Exception:
            # If dates are malformed, skip (or you can keep them).
            continue

        if f.start_from and start_dt < f.start_from:
            continue
        if f.start_to and start_dt > f.start_to:
            continue
        if f.completion_from and comp_dt < f.completion_from:
            continue
        if f.completion_to and comp_dt > f.completion_to:
            continue

        if f.updated_within_days is not None:
            if (now - upd_dt).days > f.updated_within_days:
                continue

        out.append(t)

    return out