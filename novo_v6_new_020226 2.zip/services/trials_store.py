#Loads static/json/trials_master.json, caches it (mtime-aware), and provides a single access point.

# services/trials_store.py
from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional


@dataclass
class TrialsStoreConfig:
    """
    Configuration for where the trials master dataset lives.
    """
    project_root: str
    trials_master_relpath: str = os.path.join("static", "json", "trials_master.json")


class TrialsStore:
    """
    Loads and caches the trials master dataset.
    Cache invalidates automatically if the file changes on disk (mtime-based).
    """

    def __init__(self, config: TrialsStoreConfig):
        self.config = config
        self._cache: Optional[List[Dict[str, Any]]] = None
        self._cache_mtime: Optional[float] = None

    @property
    def trials_master_path(self) -> str:
        return os.path.join(self.config.project_root, self.config.trials_master_relpath)

    def _read_json(self, path: str) -> List[Dict[str, Any]]:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, list):
            raise ValueError("trials_master.json must be a JSON list of trial objects")
        return data

    def get_trials(self, force_reload: bool = False) -> List[Dict[str, Any]]:
        path = self.trials_master_path
        if not os.path.exists(path):
            raise FileNotFoundError(f"Trials master dataset not found at: {path}")

        mtime = os.path.getmtime(path)
        if force_reload or self._cache is None or self._cache_mtime != mtime:
            self._cache = self._read_json(path)
            self._cache_mtime = mtime
        return self._cache

    def invalidate(self) -> None:
        self._cache = None
        self._cache_mtime = None