#Computes KPI belt from the filtered slice — “decision-driving” metrics
# services/trials_kpis.py
from __future__ import annotations

from collections import Counter
from datetime import datetime, timedelta
from statistics import median
from typing import Any, Dict, List, Optional


DATE_FMT = "%Y-%m-%d"


ACTIVE_STATUSES = {
    "Recruiting",
    "Active (not recruiting)",
    "Not yet recruiting",
}
RECRUITING_STATUSES = {"Recruiting", "Not yet recruiting"}


def _safe_int(x, default=0) -> int:
    try:
        return int(x)
    except Exception:
        return default


def _safe_float(x, default=None) -> Optional[float]:
    try:
        return float(x)
    except Exception:
        return default


def compute_kpi_belt(trials: List[Dict[str, Any]], focal_company: str = "Novo Nordisk") -> Dict[str, Any]:
    """
    Returns a KPI belt dict that the UI can render directly.
    """
    total = len(trials)
    statuses = Counter([t.get("status") for t in trials if t.get("status")])
    sponsors = Counter([t.get("sponsor") for t in trials if t.get("sponsor")])
    phases = Counter([str(t.get("phase")) for t in trials if t.get("phase") is not None])

    active_trials = [t for t in trials if t.get("status") in ACTIVE_STATUSES]
    recruiting_trials = [t for t in trials if t.get("status") in RECRUITING_STATUSES]
    completed_trials = [t for t in trials if t.get("status") == "Completed"]

    # New starts: last 12 months by start_date
    now = datetime.now()
    last_12m = now - timedelta(days=365)
    starts_12m = 0
    for t in trials:
        try:
            sd = datetime.strptime(t.get("start_date"), DATE_FMT)
            if sd >= last_12m:
                starts_12m += 1
        except Exception:
            continue

    # Recruitment velocity summary
    velocities = []
    for t in recruiting_trials:
        v = _safe_float(t.get("recruitment_velocity_n_per_month"))
        if v is not None:
            velocities.append(v)
    med_velocity = median(velocities) if velocities else None

    # Top mechanism among active trials
    moas = Counter([t.get("mechanism") for t in active_trials if t.get("mechanism")])
    top_moa, top_moa_count = (moas.most_common(1)[0] if moas else (None, 0))

    # Biggest external sponsor threat (excluding focal)
    external_sponsors = Counter([t.get("sponsor") for t in active_trials if t.get("sponsor") and t.get("sponsor") != focal_company])
    threat_sponsor, threat_count = (external_sponsors.most_common(1)[0] if external_sponsors else (None, 0))

    # Enrollment summary
    enrollments = [_safe_int(t.get("enrollment")) for t in trials if t.get("enrollment") is not None]
    avg_enrollment = round(sum(enrollments) / len(enrollments), 1) if enrollments else None

    return {
        "total_trials": total,
        "active_trials": len(active_trials),
        "recruiting_trials": len(recruiting_trials),
        "completed_trials": len(completed_trials),
        "starts_last_12m": starts_12m,
        "median_recruitment_velocity": med_velocity,
        "top_mechanism": {"name": top_moa, "count": top_moa_count} if top_moa else None,
        "top_external_threat": {"sponsor": threat_sponsor, "active_trials": threat_count} if threat_sponsor else None,
        "avg_enrollment": avg_enrollment,
        # helpful for quick drilldowns:
        "distributions": {
            "status": dict(statuses),
            "phase": dict(phases),
            "sponsor": dict(sponsors),
        },
    }