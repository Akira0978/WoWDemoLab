"""
services/trials_charts.py

Clinical Trial Intelligence "brain":
- Loads and caches trials_master.json
- Applies canonical filters (therapy area, sponsor, phase, status, geo, time)
- Computes KPI belt
- Produces ECharts-ready chart payloads
- Generates actionable insights ("so what / next steps")

Designed to keep JS thin: JS only fetches JSON and renders ECharts. [1](https://capgemini-my.sharepoint.com/personal/aniruddh_ghosh_capgemini_com/Documents/Microsoft%20Copilot%20Chat%20Files/data_faker.py)
Dataset schema assumed to align with data_faker.py output. [1](https://capgemini-my.sharepoint.com/personal/aniruddh_ghosh_capgemini_com/Documents/Microsoft%20Copilot%20Chat%20Files/data_faker.py)
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import datetime, date
from functools import lru_cache
from typing import Any, Dict, Iterable, List, Optional, Tuple
from collections import Counter, defaultdict


# -------------------------
# Constants / Conventions
# -------------------------

ACTIVE_STATUSES = {
    "Recruiting",
    "Active (not recruiting)",
    "Not yet recruiting",
}

DEFAULT_DATA_PATH = os.path.join("static", "json", "trials_master.json")

PHASE_LABELS = {
    1: "Phase 1",
    2: "Phase 2",
    3: "Phase 3",
    4: "Phase 4",
}

REGION_ORDER = ["US", "EU", "Asia", "LatAm", "Other"]


# -------------------------
# Parsing helpers
# -------------------------

def _parse_date(value: Any) -> Optional[date]:
    """Parse YYYY-MM-DD safely into a date."""
    if not value:
        return None
    if isinstance(value, date) and not isinstance(value, datetime):
        return value
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, str):
        try:
            return datetime.strptime(value, "%Y-%m-%d").date()
        except ValueError:
            return None
    return None


def _to_int_list(value: Any) -> Optional[List[int]]:
    """Accept comma-separated '1,2,3' or repeated query params already in list."""
    if value is None:
        return None
    if isinstance(value, list):
        out = []
        for v in value:
            try:
                out.append(int(v))
            except Exception:
                pass
        return out or None
    if isinstance(value, str):
        parts = [p.strip() for p in value.split(",") if p.strip()]
        out = []
        for p in parts:
            try:
                out.append(int(p))
            except Exception:
                pass
        return out or None
    try:
        return [int(value)]
    except Exception:
        return None


def _to_str_list(value: Any) -> Optional[List[str]]:
    """Accept comma-separated 'a,b' or list."""
    if value is None:
        return None
    if isinstance(value, list):
        out = [str(v).strip() for v in value if str(v).strip()]
        return out or None
    if isinstance(value, str):
        out = [p.strip() for p in value.split(",") if p.strip()]
        return out or None
    out = [str(value).strip()]
    return out or None


def _month_key(d: date) -> str:
    """Return YYYY-MM for bucketing."""
    return f"{d.year:04d}-{d.month:02d}"


def _last_n_month_keys(end: date, n: int) -> List[str]:
    """Generate last n month keys ending at end month inclusive."""
    keys = []
    y, m = end.year, end.month
    for _ in range(n):
        keys.append(f"{y:04d}-{m:02d}")
        m -= 1
        if m == 0:
            m = 12
            y -= 1
    keys.reverse()
    return keys


# -------------------------
# Filters
# -------------------------

@dataclass(frozen=True)
class TrialFilters:
    therapy_area: Optional[str] = None                 # diabetes|obesity|cardiovascular
    sponsor: Optional[Tuple[str, ...]] = None
    drug_name: Optional[Tuple[str, ...]] = None
    mechanism: Optional[Tuple[str, ...]] = None
    indication: Optional[Tuple[str, ...]] = None

    phase: Optional[Tuple[int, ...]] = None
    status: Optional[Tuple[str, ...]] = None

    region: Optional[Tuple[str, ...]] = None
    country: Optional[Tuple[str, ...]] = None

    start_from: Optional[date] = None
    start_to: Optional[date] = None
    completion_from: Optional[date] = None
    completion_to: Optional[date] = None


def normalize_filters(raw: Dict[str, Any]) -> TrialFilters:
    """
    Normalize raw dict (typically from query params) into TrialFilters.
    """
    therapy_area = raw.get("therapy_area") or None

    sponsor = _to_str_list(raw.get("sponsor"))
    drug_name = _to_str_list(raw.get("drug_name"))
    mechanism = _to_str_list(raw.get("mechanism"))
    indication = _to_str_list(raw.get("indication"))

    phase = _to_int_list(raw.get("phase"))
    status = _to_str_list(raw.get("status"))

    region = _to_str_list(raw.get("region"))
    country = _to_str_list(raw.get("country"))

    start_from = _parse_date(raw.get("start_from"))
    start_to = _parse_date(raw.get("start_to"))
    completion_from = _parse_date(raw.get("completion_from"))
    completion_to = _parse_date(raw.get("completion_to"))

    return TrialFilters(
        therapy_area=therapy_area,
        sponsor=tuple(sponsor) if sponsor else None,
        drug_name=tuple(drug_name) if drug_name else None,
        mechanism=tuple(mechanism) if mechanism else None,
        indication=tuple(indication) if indication else None,
        phase=tuple(phase) if phase else None,
        status=tuple(status) if status else None,
        region=tuple(region) if region else None,
        country=tuple(country) if country else None,
        start_from=start_from,
        start_to=start_to,
        completion_from=completion_from,
        completion_to=completion_to,
    )


def apply_filters(trials: List[Dict[str, Any]], f: TrialFilters) -> List[Dict[str, Any]]:
    """Filter trials according to TrialFilters (server-side)."""
    out = []

    for t in trials:
        # therapy area
        if f.therapy_area and t.get("therapy_area") != f.therapy_area:
            continue

        # sponsor, drug, mechanism, indication
        if f.sponsor and t.get("sponsor") not in f.sponsor:
            continue
        if f.drug_name and t.get("drug_name") not in f.drug_name:
            continue
        if f.mechanism and t.get("mechanism") not in f.mechanism:
            continue
        if f.indication and t.get("indication") not in f.indication:
            continue

        # phase / status
        if f.phase and int(t.get("phase") or 0) not in f.phase:
            continue
        if f.status and t.get("status") not in f.status:
            continue

        # geo
        if f.region:
            regions = set(t.get("regions") or [])
            if not regions.intersection(set(f.region)):
                continue
        if f.country:
            countries = set(t.get("countries") or [])
            if not countries.intersection(set(f.country)):
                continue

        # date windows
        sd = _parse_date(t.get("start_date"))
        cd = _parse_date(t.get("primary_completion_date"))

        if f.start_from and (sd is None or sd < f.start_from):
            continue
        if f.start_to and (sd is None or sd > f.start_to):
            continue

        if f.completion_from and (cd is None or cd < f.completion_from):
            continue
        if f.completion_to and (cd is None or cd > f.completion_to):
            continue

        out.append(t)

    return out


# -------------------------
# Data loading / caching
# -------------------------

def _file_mtime(path: str) -> float:
    try:
        return os.path.getmtime(path)
    except Exception:
        return 0.0


@lru_cache(maxsize=4)
def _load_trials_cached(path: str, mtime: float) -> List[Dict[str, Any]]:
    """Cached loader keyed by file mtime."""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def get_trials(path: str = DEFAULT_DATA_PATH) -> List[Dict[str, Any]]:
    """Load trials_master.json with cache invalidation via file mtime."""
    return _load_trials_cached(path, _file_mtime(path))


# -------------------------
# KPI Belt
# -------------------------

def compute_kpis(trials: List[Dict[str, Any]], now: Optional[date] = None) -> Dict[str, Any]:
    """
    KPI belt designed for "decision-driving" summary:
    - total trials in scope
    - active trials
    - recruiting trials
    - new starts (last 12 months)
    - median recruitment velocity (recruiting)
    - top mechanism (active)
    - top competitor sponsor (active, excluding Novo Nordisk)
    """
    now = now or date.today()

    total = len(trials)

    active = [t for t in trials if (t.get("status") in ACTIVE_STATUSES)]
    recruiting = [t for t in trials if t.get("status") == "Recruiting"]

    # starts last 12 months
    start_cutoff = date(now.year - (1 if now.month <= 12 else 0), now.month, 1)
    # Simpler: use 365 days window
    start_cutoff = now.fromordinal(now.toordinal() - 365)

    starts_12m = 0
    for t in trials:
        sd = _parse_date(t.get("start_date"))
        if sd and sd >= start_cutoff:
            starts_12m += 1

    # median recruitment velocity among recruiting
    velocities = []
    for t in recruiting:
        v = t.get("recruitment_velocity_n_per_month")
        if isinstance(v, (int, float)):
            velocities.append(float(v))
    velocities.sort()
    if velocities:
        mid = len(velocities) // 2
        median_velocity = (velocities[mid] if len(velocities) % 2 == 1
                           else (velocities[mid - 1] + velocities[mid]) / 2.0)
        median_velocity = round(median_velocity, 1)
    else:
        median_velocity = None

    # top mechanism among active
    mech_counts = Counter([t.get("mechanism") for t in active if t.get("mechanism")])
    top_mechanism = mech_counts.most_common(1)[0][0] if mech_counts else None

    # top competitor sponsor among active (exclude Novo)
    sponsor_counts = Counter([t.get("sponsor") for t in active if t.get("sponsor")])
    sponsor_counts.pop("Novo Nordisk", None)
    top_competitor = sponsor_counts.most_common(1)[0][0] if sponsor_counts else None

    return {
        "total_trials": total,
        "active_trials": len(active),
        "recruiting_trials": len(recruiting),
        "new_starts_last_12m": starts_12m,
        "median_recruitment_velocity_n_per_month": median_velocity,
        "top_mechanism_active": top_mechanism,
        "top_competitor_active": top_competitor,
    }


# -------------------------
# Charts (ECharts-ready payloads)
# -------------------------

def chart_active_by_phase(
    trials: List[Dict[str, Any]],
    sponsors: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """
    Stacked bar: active trials by phase per sponsor.
    ECharts-ready:
      { categories: ["Phase 1","Phase 2","Phase 3","Phase 4"], series: [{name, data:[]}, ...] }
    """
    active = [t for t in trials if t.get("status") in ACTIVE_STATUSES]

    # Determine sponsors in scope
    sponsor_set = sorted(set(t.get("sponsor") for t in active if t.get("sponsor")))
    if sponsors:
        sponsor_set = [s for s in sponsors if s in sponsor_set]

    categories = [PHASE_LABELS[p] for p in (1, 2, 3, 4)]

    # build counts sponsor -> phase -> count
    counts = {s: {p: 0 for p in (1, 2, 3, 4)} for s in sponsor_set}
    for t in active:
        s = t.get("sponsor")
        p = int(t.get("phase") or 0)
        if s in counts and p in counts[s]:
            counts[s][p] += 1

    series = []
    for s in sponsor_set:
        series.append({
            "name": s,
            "data": [counts[s][p] for p in (1, 2, 3, 4)],
        })

    return {
        "categories": categories,
        "series": series,
        "meta": {
            "metric": "Active trials",
            "stacked": True,
        }
    }


def chart_start_momentum(
    trials: List[Dict[str, Any]],
    months: int = 24,
    now: Optional[date] = None,
    split_by: str = "sponsor",   # "sponsor" | "therapy_area"
    top_n: int = 6,
) -> Dict[str, Any]:
    """
    Line chart: trial start momentum by month.
    Returns:
      { x: [YYYY-MM...], series: [{name, data: [...]}, ...] }
    """
    now = now or date.today()
    x = _last_n_month_keys(now, months)

    # bucket starts within window
    window_set = set(x)
    bucket = defaultdict(lambda: Counter())  # group -> month -> count

    for t in trials:
        sd = _parse_date(t.get("start_date"))
        if not sd:
            continue
        mk = _month_key(sd)
        if mk not in window_set:
            continue
        group = t.get(split_by) if split_by in ("sponsor", "therapy_area") else "All"
        if not group:
            group = "Unknown"
        bucket[group][mk] += 1

    # choose top groups by total count
    totals = [(g, sum(c.values())) for g, c in bucket.items()]
    totals.sort(key=lambda x: x[1], reverse=True)
    keep = [g for g, _ in totals[:top_n]]

    series = []
    for g in keep:
        c = bucket[g]
        series.append({
            "name": g,
            "data": [c.get(m, 0) for m in x]
        })

    return {
        "x": x,
        "series": series,
        "meta": {
            "metric": "Trial starts",
            "months": months,
            "split_by": split_by,
            "top_n": top_n,
        }
    }


def chart_moa_distribution(
    trials: List[Dict[str, Any]],
    top_n: int = 10,
    active_only: bool = True,
) -> Dict[str, Any]:
    """
    Bar chart: Mechanism distribution (optionally active only).
    Returns:
      { categories: [moa...], values: [counts...] }
    """
    scope = [t for t in trials if (not active_only or t.get("status") in ACTIVE_STATUSES)]

    counts = Counter([t.get("mechanism") for t in scope if t.get("mechanism")])
    most = counts.most_common(top_n)

    categories = [m for m, _ in most]
    values = [v for _, v in most]

    return {
        "categories": categories,
        "values": values,
        "meta": {
            "metric": "Trials",
            "dimension": "Mechanism",
            "active_only": active_only,
            "top_n": top_n,
        }
    }


def chart_geo_footprint(
    trials: List[Dict[str, Any]],
    split_by: str = "sponsor",
    top_n: int = 6,
    active_only: bool = True,
) -> Dict[str, Any]:
    """
    Grouped/stacked bars: counts by region (US/EU/Asia/LatAm/Other) split by sponsor or therapy_area.
    Returns:
      { categories: ["US","EU","Asia","LatAm","Other"], series:[{name,data:[]},...] }
    """
    scope = [t for t in trials if (not active_only or t.get("status") in ACTIVE_STATUSES)]

    # count group -> region
    region_counts = defaultdict(lambda: Counter())
    for t in scope:
        group = t.get(split_by) if split_by in ("sponsor", "therapy_area") else "All"
        if not group:
            group = "Unknown"
        regions = t.get("regions") or []
        for r in regions:
            region_counts[group][r] += 1

    # pick top groups
    totals = [(g, sum(c.values())) for g, c in region_counts.items()]
    totals.sort(key=lambda x: x[1], reverse=True)
    keep = [g for g, _ in totals[:top_n]]

    categories = REGION_ORDER[:]
    series = []
    for g in keep:
        c = region_counts[g]
        series.append({
            "name": g,
            "data": [c.get(r, 0) for r in categories]
        })

    return {
        "categories": categories,
        "series": series,
        "meta": {
            "metric": "Trials (region presence)",
            "split_by": split_by,
            "active_only": active_only,
            "top_n": top_n,
        }
    }


def table_trials(
    trials: List[Dict[str, Any]],
    sort_by: str = "last_updated",
    sort_dir: str = "desc",
    limit: int = 50,
    offset: int = 0,
) -> Dict[str, Any]:
    """
    Tabular payload for UI.
    - sort_by supports: last_updated, start_date, primary_completion_date, enrollment, phase
    """
    def sort_key(t: Dict[str, Any]):
        if sort_by in ("last_updated", "start_date", "primary_completion_date"):
            return _parse_date(t.get(sort_by)) or date.min
        if sort_by in ("enrollment", "phase"):
            try:
                return float(t.get(sort_by) or 0)
            except Exception:
                return 0.0
        return str(t.get(sort_by) or "")

    reverse = (sort_dir.lower() != "asc")
    sorted_trials = sorted(trials, key=sort_key, reverse=reverse)

    page = sorted_trials[offset: offset + limit]

    # lightweight columns; UI can decide what to show
    rows = []
    for t in page:
        rows.append({
            "trial_id": t.get("trial_id"),
            "title": t.get("title"),
            "sponsor": t.get("sponsor"),
            "drug_name": t.get("drug_name"),
            "therapy_area": t.get("therapy_area"),
            "phase": t.get("phase"),
            "status": t.get("status"),
            "mechanism": t.get("mechanism"),
            "start_date": t.get("start_date"),
            "primary_completion_date": t.get("primary_completion_date"),
            "regions": t.get("regions"),
            "enrollment": t.get("enrollment"),
            "recruitment_velocity_n_per_month": t.get("recruitment_velocity_n_per_month"),
            "last_updated": t.get("last_updated"),
        })

    return {
        "total": len(trials),
        "offset": offset,
        "limit": limit,
        "rows": rows,
        "meta": {
            "sort_by": sort_by,
            "sort_dir": sort_dir,
        }
    }


# -------------------------
# Actionable Insights ("so what / next steps")
# -------------------------

def generate_insights(trials: List[Dict[str, Any]], kpis: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """
    Generate short, actionable intelligence from current scope.

    Output is designed for an 'Insights' panel:
      - key_findings: bullets
      - next_steps: bullets
      - watchlist: list of trials nearing completion
    """
    kpis = kpis or compute_kpis(trials)

    findings: List[str] = []
    next_steps: List[str] = []

    # 1) Competitive pressure
    top_comp = kpis.get("top_competitor_active")
    if top_comp:
        findings.append(f"Top competitor by active trials in current scope: {top_comp}.")
        next_steps.append(f"Review {top_comp}'s Phase 2/3 assets and compare mechanisms vs Novo Nordisk portfolio.")

    # 2) Momentum
    starts_12m = kpis.get("new_starts_last_12m")
    if isinstance(starts_12m, int):
        if starts_12m >= 10:
            findings.append(f"High start momentum: {starts_12m} trials started in the last 12 months.")
            next_steps.append("Investigate which sponsors are driving the start momentum and whether they overlap with priority indications.")
        elif starts_12m <= 2:
            findings.append(f"Low start momentum: only {starts_12m} trial starts in the last 12 months.")
            next_steps.append("Check whether the scope is too narrow (filters) or if competitive activity is truly slowing.")

    # 3) Mechanism concentration
    top_mech = kpis.get("top_mechanism_active")
    if top_mech:
        findings.append(f"Most common active mechanism: {top_mech}.")
        next_steps.append(f"Assess differentiation: if Novo is also concentrated in {top_mech}, explore adjacent MoAs or combination strategies.")

    # 4) Recruitment velocity signal
    med_vel = kpis.get("median_recruitment_velocity_n_per_month")
    if isinstance(med_vel, (int, float)):
        if med_vel >= 90:
            findings.append(f"Recruitment looks fast (median ~{med_vel} pts/month among recruiting trials).")
            next_steps.append("Prioritize monitoring near-term readouts from fast-recruiting programs (higher probability of earlier completion).")
        elif med_vel <= 30:
            findings.append(f"Recruitment looks slow (median ~{med_vel} pts/month among recruiting trials).")
            next_steps.append("Identify recruitment bottlenecks by region/indication; consider patient access strategies or site expansion risk signals.")

    # Watchlist: trials with primary completion within next 180 days
    today = date.today()
    watch = []
    for t in trials:
        cd = _parse_date(t.get("primary_completion_date"))
        if not cd:
            continue
        days = (cd - today).days
        if 0 <= days <= 180:
            watch.append((days, t))

    watch.sort(key=lambda x: x[0])
    watchlist = [{
        "trial_id": t.get("trial_id"),
        "title": t.get("title"),
        "sponsor": t.get("sponsor"),
        "therapy_area": t.get("therapy_area"),
        "phase": t.get("phase"),
        "primary_completion_date": t.get("primary_completion_date"),
        "days_to_completion": d,
    } for d, t in watch[:10]]

    # If we have no findings, provide a baseline guidance
    if not findings:
        findings.append("No strong signals detected in the current scope; adjust filters to widen view or focus on Phase 3 threats.")
        next_steps.append("Try viewing Active trials by Phase and Start Momentum for key competitors to identify emerging threats.")

    return {
        "key_findings": findings,
        "next_steps": next_steps,
        "watchlist": watchlist,
    }
