Clinical Trial Intelligence Dashboard — Project Notes (Novo Nordisk Demo)
(Documentation of the key points we agreed on so far — no bug fixes, no failed attempts, no code.)

1) Project Context & Objective
What Novo Nordisk wants
Novo Nordisk’s request — “we want to monitor what’s going on in clinical trials in the market and against competition” — translates into a Clinical Trial Intelligence (CI) layer that enables real-time-style monitoring and competitive benchmarking across key disease areas.
The product is not a trial listing tool; it’s a decision support cockpit built on clinical trial signals.
Core problem being solved

Trial intelligence is typically fragmented (registry browsing, internal trackers, scattered readouts).
NN wants a single place to see:

Where they stand vs competitors
What is changing
What matters next
Which programs represent near-term threats/opportunities




2) Demo Storyline (What the Demo Must Answer)
You defined a clear demo narrative that the UI must support:


What problem are we solving?

Identify the CI gap and the pain points the dashboard addresses.



How does the dashboard impact decisions?

Demonstrate how it speeds up decision-making across therapy areas, assets, trials, and competition.



What KPIs matter most to NN?

Focus only on “decision-driving” KPIs (not “everything possible”).



What do the charts actually reveal?
Every chart must explicitly communicate:

What it shows
Why it matters
What action or insight the stakeholder takes away



How will we navigate the demo?

A rehearsed flow from high-level landscape → drilldown → insights → decisions.



Additional high-value KPIs to include
You flagged these as particularly valuable to NN:

Company threat inclusion (direct competitors, emerging threats, “risk zones”)
Collision analysis

Internal collision: NN assets competing for the same patient segments
External collision: competitor trials overlapping with NN across indications/geographies


Patient recruitment intelligence

Protocol-level detail and recruitment velocity signals




3) What We Compare (Comparison Framework)
Comparison levels (3 layers)


Company vs Company

NN vs competitors on trial volume, phase distribution, MoA concentration, geographic footprint, trial-start momentum, etc.



Asset vs Asset

NN drug vs competitor drug within the same disease field / indication overlap.



Therapy Area vs Therapy Area

Comparisons across Diabetes, Obesity, and Cardiovascular because the same asset may span multiple areas.



Competitors selected (confirmed)
For the demo build, your confirmed competitor list is:

Eli Lilly
Pfizer
AstraZeneca
Sanofi
J&J


4) UI/UX Direction (“Look & Feel”)
Visual style target
You explicitly want the UI to move away from a dark/blue-heavy theme and into a white-first Novo Nordisk style:

Primary palette emphasis: True Blue + White
Simple, clear layouts
Novo Nordisk’s corporate design guidance emphasizes True Blue (#001965) and Snow White (#FFFFFF) as dominant colors and encourages clean white layouts. [slideplayer.fr]

Reference pages
You provided Novo Nordisk disease pages as the style target, and asked the app to match that general look and feel (white base, minimal clutter, clean hierarchy). [nnci-kpi-s...ds.compact | HTML], [slideplayer.fr]

5) Dashboard Page Structure (UI Composition)
Layout approach (standard enterprise pattern)

Left sidebar: navigation between therapy areas and pages
Top bar: title + filter button (company/drug/phase/etc.)
Main content: KPI belt + charts + tables
Optional later: right rail (live feed + chatbot)

Components strategy
You want the UI built with reusable partials:

Sidebar partial
KPI belt partial
Table partial
Chart partial(s)
Chatbot / live feed partial(s)

The sidebar you shared and integrated provides the switching structure across disease sections and pages. [NN_CT_diabetes | HTML]

6) Filters & Interaction Model
Filter requirement (confirmed)
A Filter UI (button + panel) should allow selecting:

Company/Sponsor
Drug/Asset
Therapy area (Diabetes / Obesity / CV)
Phase
Status
Geography
Time window

When filters change, KPIs + charts + tables should update to show the relevant subset.
Design principle

Python handles the logic and aggregation
JS remains thin (fetch chart-ready JSON + render ECharts)


7) Technical Architecture (Flask + Bootstrap + JSON)
You decided on:

Flask app to serve pages and APIs
Bootstrap for layout/design
Data pulled from JSON files (demo stage)
“Logic handling” in Python files, not JS
JS used mainly for:

requesting data from Flask endpoints
rendering ECharts charts



File organization approach (agreed direction)

One base layout used by all pages
Global CSS/JS (core theme + shared behavior)
Optional per-page CSS/JS when needed


8) Use of Legacy/Reference Clinical Trials Page
You shared an existing clinical trials HTML page as a reference for:

ECharts rendering style
How chart cards are structured
How “insights + provenance” panels sit beside charts

But you explicitly clarified:
✅ We will not copy its old logic/data; we will build new logic aligned to the new CI objectives. [NN_CT_diabetes | HTML]

9) Data Strategy (Key Decision)
Key decision: build a single master dataset
To support real filtering and comparisons, we agreed the system should revolve around a Trials Master dataset:
Trials Master concept: “one row per trial” with fields that allow:

sponsor comparisons
phase/status tracking
MoA breakdowns
geographic mapping
timelines/readouts
recruitment signals
collision analysis (later)

Synthetic data creation plan (agreed)
You asked Copilot to generate:

trials_master.json (100–200 trials)
via a faker generator script, seeded and controlled so the demo feels realistic

Anchoring on your real examples
The synthetic dataset will be patterned after the field types and characteristics you provided (companies, drugs, mechanisms, phases, enrollment, sites, countries, dates, outcomes).
This ensures the demo data produces believable competitive shapes and timelines.

10) Initial Therapy-Area Navigation Requirement
Default behavior (confirmed)

The app should open by default to Diabetes.
Sidebar must allow switching to:

Obesity
Cardiovascular



This aligns with your requirement that NN compares across multiple fields and that assets can span more than one disease area.

11) Next Build Steps (Planned Sequence)
Step 1 (Data foundation)

Generate trials_master.json (100–200 trial records) using a faker approach.
Ensure it supports:

filtering by sponsor, asset, phase, status, geography, therapy area
chart-ready aggregations via Python



Step 2 (Pages)

Diabetes page as default
Obesity and CV pages accessible via sidebar

Step 3 (New tables and charts with new logic)

Build tables powered by the new dataset
Then implement ECharts visualizations based on the new intelligence KPIs:

active trials by phase
trial-start momentum
MoA heatmap
geo footprint
timelines/readouts
collision (later phase)
12) Project Guardrails (Working Agreement)
To keep the work aligned with your expectations:

We only “copy” files verbatim when you explicitly instruct it.
Any legacy file is used only for UI/implementation pattern, not data/logic reuse. [NN_CT_diabetes | HTML]
When we change/add/edit anything, you want an explicit list of:

which files were updated
which files were added
which files need to be created




If you want, I can also format this into a short “Demo PRD” style doc (Objective → Users → Use cases → KPIs → Screens → Data model → Roadmap), still without code.