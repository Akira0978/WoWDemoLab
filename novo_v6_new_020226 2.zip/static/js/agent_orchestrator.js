// static/js/agent_orchestrator.js
(function () {
  // -------- Card map (IDs must match your ct_diabetes.html) --------
  var CARD_MAP = {
    'active_by_phase': { cardId: 'card_active_by_phase', chartId: 'ct_chart_active_by_phase' },
    'start_momentum':  { cardId: 'card_start_momentum',  chartId: 'ct_chart_start_momentum'  },
    'moa_distribution':{ cardId: 'card_moa',             chartId: 'ct_chart_moa_distribution'},
    'geo_footprint':   { cardId: 'card_geo',             chartId: 'ct_chart_geo_footprint'   }
  };

  // -------- Chat intent router (keywords -> show(typeKey)) --------
  function handleChatCommand(text) {
    if (!text) return;
    var t = String(text).toLowerCase();
    if (t.includes('active') && t.includes('trial')) return show('active_by_phase');
    if (t.includes('momentum')) return show('start_momentum');
    if (t.includes('moa') || t.includes('mechanism')) return show('moa_distribution');
    if (t.includes('geo') || t.includes('geographic') || t.includes('region')) return show('geo_footprint');
  }

  // -------- Overlay (Agentic thinking) --------
  var orchEl = null, barEl = null, stepEls = {};
  function ensureOverlay() {
    if (orchEl) return;
    orchEl = document.createElement('div');
    orchEl.className = 'agent-orch';
    orchEl.setAttribute('role','dialog');
    orchEl.setAttribute('aria-modal','true');
    orchEl.innerHTML = [
      '<div class="panel">',
        '<div class="panel-header">',
          '<div class="title">Agentic pipeline in progress…</div>',
          '<div class="badge"><span class="dot"></span> Working</div>',
        '</div>',
        '<div class="steps">',
          stepTpl('ingestor',  'The Ingester',  'Pulling registries & latest CT events'),
          stepTpl('brain',     'The Brain',     'Summarizing, ranking & planning'),
          stepTpl('eyes',      'The Eyes',      'Prepping visualization'),
          stepTpl('satellite', 'The Satellite', 'Scanning news & signals'),
          stepTpl('radar',     'The Radar',     'Checking risks & alerts'),
        '</div>',
        '<div class="panel-footer">',
          '<div class="progress"><div class="bar"></div></div>',
        '</div>',
      '</div>'
    ].join('');
    document.body.appendChild(orchEl);
    barEl = orchEl.querySelector('.bar');
    ['ingestor','brain','eyes','satellite','radar'].forEach(function(k){
      stepEls[k] = orchEl.querySelector('.step[data-agent="'+k+'"]');
    });
  }
  function stepTpl(key, name, desc) {
    return ''
      + '<div class="step pending" data-agent="'+key+'">'
      + '  <div class="name">'+name+'</div>'
      + '  <div class="desc">'+desc+'</div>'
      + '  <div class="badge"><span class="spinner"></span> Pending</div>'
      + '</div>';
  }
  function setStep(key, state, badgeHtml) {
    var el = stepEls[key]; if (!el) return;
    el.classList.remove('pending','running','done','error');
    el.classList.add(state);
    el.querySelector('.badge').innerHTML = badgeHtml;
  }
  function setProgress(pct){ if (barEl) barEl.style.width = Math.min(100, Math.max(0, pct)) + '%'; }
  function openOverlay(){ orchEl.classList.add('show'); orchEl.setAttribute('aria-busy','true'); }
  function closeOverlay(){ orchEl.classList.remove('show'); orchEl.removeAttribute('aria-busy'); }

  // -------- Right-rail activity chips (clean) --------
  function pushActivity(kind, text) { // kind: 'satellite' | 'radar'
    var root = document.getElementById('right-rail-feeds');
    if (!root) return;
    var last = root.querySelector('.rf-activity.' + kind);
    if (last && last.dataset.msg === text) {
      var t = last.querySelector('.time');
      if (t) t.textContent = new Date().toLocaleTimeString();
      return;
    }
    var el = document.createElement('div');
    el.className = 'rf-activity ' + kind;
    el.dataset.msg = text;
    el.innerHTML =
      '<span class="dot" aria-hidden="true"></span>'
      + '<span class="txt">'+text+'</span>'
      + '<span class="time">'+new Date().toLocaleTimeString()+'</span>';
    root.prepend(el);
  }

  // -------- Sequence driver --------
  function runSequence(finalizeCb) {
    Object.keys(stepEls).forEach(function(k){
      setStep(k, 'pending', '<span class="spinner"></span> Pending');
    });
    setProgress(0);
    openOverlay();

    var t0 = 250, t1 = 900, t2 = 1500, t3 = 2100, t4 = 2700;

    setTimeout(function(){
      setStep('ingestor','running','<span class="spinner"></span> Fetching sources');
      setProgress(12);
    }, t0);

    setTimeout(function(){
      setStep('ingestor','done','<span>✓</span> Sources ready');
      setStep('brain','running','<span class="spinner"></span> Summarizing signals');
      setProgress(36);
    }, t1);

    setTimeout(function(){
      setStep('brain','done','<span>✓</span> Plan ready');
      setStep('eyes','running','<span class="spinner"></span> Building visuals');
      setProgress(58);
    }, t2);

    setTimeout(function(){
      setStep('eyes','done','<span>✓</span> Visuals prepped');
      setStep('satellite','running','<span class="spinner"></span> News & filings sweep');
      pushActivity('satellite', 'Scanning news & filings for Diabetes CT…');
      setProgress(78);
    }, t3);

    setTimeout(function(){
      setStep('satellite','done','<span>✓</span> Signals queued');
      setStep('radar','running','<span class="spinner"></span> Alert checks');
      pushActivity('radar', 'Cross-checking conflicts & risk signals…');
      setProgress(90);
    }, t4);

    setTimeout(function(){
      setStep('radar','done','<span>✓</span> All clear');
      setProgress(100);
      finalizeCb && finalizeCb();
      setTimeout(closeOverlay, 250);
    }, t4 + 350);
  }

  // -------- Mode helpers (single vs. multi) --------
  function hideAllCards() {
    document.querySelectorAll('.ct-kpi-card').forEach(function(c){
      c.classList.add('is-hidden'); // modifier class; CSS handles display:none !important
    });
  }

  // -------- Core API --------
  function show(typeKey) {
    ensureOverlay();
    var cfg = CARD_MAP[typeKey];
    if (!cfg) return;

    // Pull mode from config (with default)
    var mode = (window.AgentFlow && window.AgentFlow.config && window.AgentFlow.config.mode) || 'single';

    runSequence(function(){
      if (mode === 'single') hideAllCards();

      var card = document.getElementById(cfg.cardId);
      if (card) {
        card.classList.remove('is-hidden');
        card.scrollIntoView({ behavior: 'smooth', block: 'start' });
        setTimeout(function(){ window.dispatchEvent(new Event('resize')); }, 200);
      }
    });
  }

  function setMode(next) {
    var current = window.AgentFlow && window.AgentFlow.config;
    if (!current) {
      // create config if missing
      window.AgentFlow = window.AgentFlow || {};
      window.AgentFlow.config = { mode: 'single' };
      current = window.AgentFlow.config;
    }
    if (next === 'single' || next === 'multi') current.mode = next;
    return current.mode;
  }

  // -------- SAFE EXPORT (idempotent, last line of the IIFE) --------
  (function safeExport(){
    var current = window.AgentFlow || {};
    var cfg = current.config || { mode: 'single' };
    window.AgentFlow = Object.assign({}, current, {
      handleChatCommand: current.handleChatCommand || handleChatCommand,
      show:              current.show              || show,
      setMode:           setMode,            // always (we want to guarantee it exists)
      config:            cfg
    });
    try { console.debug('[AgentFlow] ready; mode =', window.AgentFlow.config.mode); } catch(_) {}
  })();

})();
