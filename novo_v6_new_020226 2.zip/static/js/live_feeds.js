// static/js/live_feeds.js
(function () {
  "use strict";

  // Namespace
  window.NNCI = window.NNCI || {};
  const Feeds = {};
  window.NNCI.Feeds = Feeds;

  const MAX_ITEMS = 20;             // keep panel light
  const MIN_DELAY_MS = 2000;        // 2 seconds
  const MAX_DELAY_MS = 3200;        // ~3.2 seconds
  const ITEM_TEMPLATE_ID = "live-feed-item-tpl";
  const LIST_SELECTOR = "#live-feed-list";

  let running = false;
  let timeoutId = null;
  let listEl, tplEl;
  let therapyArea = "diabetes";     // default; try reading from page

  // --- Utilities -------------------------------------------------------------

  function randomFrom(arr) { return arr[Math.floor(Math.random() * arr.length)]; }
  function randomInt(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
  function nowISO() { return new Date().toISOString(); }
  function delay() {
    const ms = randomInt(MIN_DELAY_MS, MAX_DELAY_MS);
    return new Promise(resolve => { timeoutId = setTimeout(resolve, ms); });
  }
  function visible() { return document.visibilityState === "visible"; }

  // Read therapy_area from page container if present
  function getPageTherapyArea() {
    const root = document.getElementById("mainContentWrap");
    return (root && (root.dataset.therapyArea || root.getAttribute("data-therapy-area"))) || "diabetes";
  }

  // Format “relative” time label, client-side
  function timeAgo(dt) {
    const secs = Math.floor((Date.now() - dt.getTime()) / 1000);
    if (secs < 60) return `${secs}s ago`;
    const mins = Math.floor(secs / 60);
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    return `${hrs}h ago`;
  }

  // --- Synthetic “real-life” feed generator ---------------------------------

  function makeSyntheticFeed() {
    const sponsors = ["Novo Nordisk", "Eli Lilly", "Pfizer", "AstraZeneca", "Sanofi", "J&J"];
    const drugs = [
      "Semaglutide 2.4 mg", "Tirzepatide", "Dapagliflozin", "Ziltivekimab",
      "Amycretin", "MariTide", "Oral GLP‑1", "Dual GIP/GLP‑1"
    ];
    const areas = ["diabetes", "obesity", "cardiovascular"];
    const mechanisms = ["GLP‑1 RA", "SGLT2 inhibitor", "DPP‑4 inhibitor", "Amylin analog", "Dual GIP/GLP‑1"];

    const countries = ["USA", "Germany", "UK", "France", "Spain", "Japan", "Canada", "India", "Brazil", "Australia"];
    const statuses = [
      "site activated", "first patient in", "recruitment milestone hit",
      "protocol amendment posted", "DSMB: continue as planned",
      "primary endpoint met", "topline results shared",
      "new trial registered"
    ];

    // Bias items towards current therapy area
    const area = therapyArea || randomFrom(areas);
    const sponsor = randomFrom(sponsors);
    const drug = randomFrom(drugs);
    const mech = randomFrom(mechanisms);
    const country = randomFrom(countries);
    const status = randomFrom(statuses);
    const phase = randomFrom([1,2,3,3,3,4]); // skew toward late stage

    // Craft a human-readable message set
    let title;
    let meta;
    let source;

    switch (status) {
      case "new trial registered":
        source = "ClinicalTrials.gov";
        title = `New ${area} Phase ${phase} trial registered: ${drug}`;
        meta = `${sponsor} · Mechanism: ${mech} · ${country}`;
        break;
      case "first patient in":
        source = "Investigator update";
        title = `FPI achieved for ${drug} (${area}, Phase ${phase})`;
        meta = `${sponsor} · Site: ${country} · Mechanism: ${mech}`;
        break;
      case "site activated":
        source = "Site operations";
        title = `New site activated in ${country} · ${drug} (Phase ${phase})`;
        meta = `${sponsor} · ${area} · Mechanism: ${mech}`;
        break;
      case "recruitment milestone hit":
        source = "Study team";
        title = `${drug} hits recruitment milestone`;
        meta = `${sponsor} · ${area} · ${randomInt(100, 1000)} participants enrolled`;
        break;
      case "protocol amendment posted":
        source = "Registry update";
        title = `Protocol amendment posted for ${drug} (Phase ${phase})`;
        meta = `${sponsor} · ${area} · Endpoint clarifications`;
        break;
      case "DSMB: continue as planned":
        source = "DSMB note";
        title = `DSMB recommends study continuation (${drug})`;
        meta = `${sponsor} · ${area} · No safety concerns flagged`;
        break;
      case "primary endpoint met":
        source = "Press note";
        title = `${drug}: primary endpoint met (Phase ${phase})`;
        meta = `${sponsor} · ${area} · Mechanism: ${mech}`;
        break;
      case "topline results shared":
      default:
        source = "Press note";
        title = `Topline results shared for ${drug}`;
        meta = `${sponsor} · ${area} · Phase ${phase}`;
        break;
    }

    const ts = new Date();
    return {
      title,
      meta,
      source,
      tsISO: ts.toISOString(),
      tsLabel: timeAgo(ts)
    };
  }

  // --- Rendering -------------------------------------------------------------

  function renderFeedItem(item) {
    if (!tplEl || !listEl) return;
    const node = tplEl.content.firstElementChild.cloneNode(true);

    node.querySelector(".feed-source").textContent = item.source || "Update";
    node.querySelector(".feed-title").textContent = item.title || "";
    node.querySelector(".feed-meta").textContent = item.meta || "";
    const t = node.querySelector(".feed-time");
    t.textContent = item.tsLabel || "";
    t.setAttribute("datetime", item.tsISO || nowISO());

    // Insert at the top
    listEl.prepend(node);

    // Trim list
    const items = listEl.querySelectorAll(".feed-item");
    if (items.length > MAX_ITEMS) {
      listEl.removeChild(items[items.length - 1]);
    }
  }

  // --- Loop control ----------------------------------------------------------

  async function loop() {
    while (running) {
      try {
        // If tab is hidden, pause generation (saves CPU)
        if (!visible()) {
          await delay();
          continue;
        }
        const item = makeSyntheticFeed();
        renderFeedItem(item);
      } catch (err) {
        console.warn("[Feeds] render error:", err);
      }
      await delay();
    }
  }

  function start() {
    if (running) return;
    running = true;
    therapyArea = getPageTherapyArea();
    loop();
  }

  function stop() {
    running = false;
    if (timeoutId) clearTimeout(timeoutId);
    timeoutId = null;
  }

  // Pause on hover over the rail (optional nice touch)
  function bindHoverPause() {
    const rail = document.querySelector(".nnci-rightrail");
    if (!rail) return;
    rail.addEventListener("mouseenter", stop, { passive: true });
    rail.addEventListener("mouseleave", start, { passive: true });
  }

  // Public API
  Feeds.init = function () {
    listEl = document.querySelector(LIST_SELECTOR);
    tplEl  = document.getElementById(ITEM_TEMPLATE_ID);
    if (!listEl || !tplEl) {
      console.warn("[Feeds] container or template not found");
      return;
    }
    bindHoverPause();
    start();
    // Also handle page visibility
    document.addEventListener("visibilitychange", () => {
      if (document.visibilityState === "hidden") stop();
      else start();
    });
  };

  // Boot when DOM is ready
  document.addEventListener("DOMContentLoaded", () => {
    // Only init if the right-rail feed container is present on this page
    if (document.querySelector(LIST_SELECTOR)) {
      Feeds.init();
    }
// Update all feed item timestamps every 30 seconds
setInterval(() => {
  document.querySelectorAll(".feed-time").forEach(el => {
    const dt = new Date(el.getAttribute("datetime"));
    el.textContent = timeAgo(dt);
  });
}, 30000);

  });
})();