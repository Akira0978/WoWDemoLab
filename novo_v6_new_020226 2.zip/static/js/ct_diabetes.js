// static/js/ct_diabetes.js
(function () {
  "use strict";

  // --- Utilities from global.js (exposed on window.NNCI) ---
  const fetchJSON = (url, opts) => window.NNCI.fetchJSON(url, opts);
  const qsFromFilters = (f) => window.NNCI.utils.buildQueryString(f);
  const mergeFilters = (a, b) => window.NNCI.utils.merge(a, b);

  // --- Base filter: therapy area from the page dataset ---
  const rootEl = document.getElementById("mainContentWrap");
  const pageTherapy = (rootEl && (rootEl.dataset.therapyArea || rootEl.getAttribute("data-therapy-area"))) || "diabetes";

  // Any URL params win over defaults; we still force therapy_area = diabetes for this page
  function getPageFilters() {
    const urlFilters = window.NNCI.utils.getUrlFilters();
    return mergeFilters({ therapy_area: pageTherapy }, urlFilters);
  }

  // --- KPI rendering (data-kpi="...") ---
  function setText(selector, value, fallback = "—") {
    const el = document.querySelector(selector);
    if (el) el.textContent = (value ?? fallback);
  }

// Build small HTML table for the debug popover
function buildDebugHtml({ filters, kpis, sampleTrials }) {
  const esc = (s) => String(s ?? '—')
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  const li = (obj) => Object.entries(obj)
    .map(([k,v]) => `<tr><th class="text-muted pe-2">${esc(k)}</th><td>${esc(v)}</td></tr>`).join("");

  const sampleRows = (sampleTrials || []).map(t => `
    <tr><td>${esc(t.trial_id)}</td><td>${esc(t.sponsor)}</td><td>${esc(t.phase)}</td><td>${esc(t.status)}</td></tr>
  `).join("");

  return `
    <div class="small">
      <div class="fw-semibold mb-1">Filters</div>
      <table class="table table-sm mb-2"><tbody>${li(filters)}</tbody></table>

      <div class="fw-semibold mb-1">KPI payload</div>
      <table class="table table-sm mb-2">
        <tbody>
          <tr><th class="text-muted pe-2">total_trials</th><td>${esc(kpis.total_trials)}</td></tr>
          <tr><th class="text-muted pe-2">active_trials</th><td>${esc(kpis.active_trials)}</td></tr>
          <tr><th class="text-muted pe-2">recruiting_trials</th><td>${esc(kpis.recruiting_trials)}</td></tr>
          <tr><th class="text-muted pe-2">new_starts_12m</th><td>${esc(kpis.new_starts_12m)}</td></tr>
          <tr><th class="text-muted pe-2">top_mechanism_active</th><td>${esc(kpis.top_mechanism_active)}</td></tr>
          <tr><th class="text-muted pe-2">biggest_competitor_threat</th><td>${esc(kpis.biggest_competitor_threat)}</td></tr>
          <tr><th class="text-muted pe-2">median_recruitment_velocity_n_per_month</th><td>${esc(kpis.median_recruitment_velocity_n_per_month)}</td></tr>
        </tbody>
      </table>

      <div class="fw-semibold mb-1">Sample /api/trials rows (3)</div>
      <table class="table table-sm mb-0">
        <thead><tr><th>Trial</th><th>Sponsor</th><th>Phase</th><th>Status</th></tr></thead>
        <tbody>${sampleRows || '<tr><td colspan="4" class="text-muted">No rows</td></tr>'}</tbody>
      </table>
    </div>
  `;
} 

async function loadDebugPopover(filters, kpis) {
  // pull a tiny sample from /api/trials (contract per API_ENDPOINTS.md)
  // limit=3 keeps the popover lightweight
  const q = new URLSearchParams({ ...filters, limit: 3, offset: 0, sort_by: 'last_updated', desc: true });
  const trialsResp = await fetch(`/api/trials?${q.toString()}`, { headers: { "Accept": "application/json" } });
  let sampleTrials = [];
  if (trialsResp.ok) {
    const trialsJson = await trialsResp.json();
    // support both raw array or {rows:[]}
    sampleTrials = Array.isArray(trialsJson) ? trialsJson.slice(0,3) : (trialsJson.rows || []).slice(0,3);
  }

  const btn = document.getElementById('kpi-debug-btn');
  if (!btn) return;

  // Attach Bootstrap popover with dynamic content
  try {
    const contentHtml = buildDebugHtml({ filters, kpis, sampleTrials });
    new bootstrap.Popover(btn, {
      html: true,
      trigger: 'focus',
      content: contentHtml
    });
  } catch (e) {
    console.warn("Debug popover init failed:", e);
  }
}

//Debug popover--------------->END<---------------------

  function renderKpis(kpis) {
    // Map standard KPI keys from your API contract (see API_ENDPOINTS.md) → DOM
    // total_trials, active_trials, recruiting_trials, new_starts_12m,
    // top_mechanism_active, biggest_competitor_threat, median_recruitment_velocity_n_per_month, next_readouts
    setText('[data-kpi="total_trials"]', kpis.total_trials);
    setText('[data-kpi="active_trials"]', kpis.active_trials);
    setText('[data-kpi="recruiting_trials"]', kpis.recruiting_trials);
    setText('[data-kpi="new_starts_12m"]', kpis.new_starts_12m);

    setText('[data-kpi="top_mechanism_active"]', kpis.top_mechanism_active);
    setText('[data-kpi="biggest_competitor_threat"]', kpis.biggest_competitor_threat);

    // Format median velocity to 1 decimal if numeric
    let mv = kpis.median_recruitment_velocity_n_per_month;
    if (typeof mv === "number") mv = mv.toFixed(1);
    setText('[data-kpi="median_recruitment_velocity_n_per_month"]', mv);

    // Next readouts (expect an array of 3–5 objects)
    const listEl = document.querySelector('[data-kpi="next_readouts"]');
    if (listEl) {
      listEl.innerHTML = "";
      const items = Array.isArray(kpis.next_readouts) ? kpis.next_readouts.slice(0, 5) : [];
      if (!items.length) {
        listEl.innerHTML = '<li class="text-muted">No upcoming readouts</li>';
      } else {
        items.forEach(r => {
          const title = r.title || r.trial_id || "Upcoming readout";
          const date = r.primary_completion_date || r.date || "";
          const li = document.createElement("li");
          li.innerHTML = `<strong>${title}</strong>${date ? ` <span class="text-muted">(${date})</span>` : ""}`;
          listEl.appendChild(li);
        });
      }
    }

    // Optional: meta strip at the top
    const meta = document.getElementById("meta");
    if (meta) {
      const parts = [];
      if (kpis.total_trials != null) parts.push(`Total: ${kpis.total_trials}`);
      if (kpis.active_trials != null) parts.push(`Active: ${kpis.active_trials}`);
      if (kpis.new_starts_12m != null) parts.push(`Starts (12m): ${kpis.new_starts_12m}`);
      meta.textContent = parts.join(" · ");
    }
  }

  async function loadKpis(filters) {
    const url = `/api/kpis?${qsFromFilters(filters)}`;
    const data = await fetchJSON(url);
    renderKpis(data);
  }

  // --- Insights rendering (basic, page-friendly) ---
  function renderInsights(insights) {
    // We have multiple insight panels with data-insight-target attributes:
    // #ins_active_by_phase, #ins_start_momentum, #ins_moa_distribution, #ins_geo_footprint (from ct_diabetes.html)
    // The API doesn't enforce "topic" today; we will simply distribute 1–2 generic insights per panel.
    const panels = document.querySelectorAll('[data-insight-target]');
    if (!panels.length) return;

    // Helper to build a small insight card
    const mkCard = (insight) => {
      const steps = Array.isArray(insight.next_steps) ? insight.next_steps : [];
      return `
        <div class="mb-3">
          <div class="fw-semibold">${insight.title || "Insight"}</div>
          <div class="text-muted small">${insight.why_it_matters || ""}</div>
          ${steps.length ? `<ul class="small mt-2 mb-0">${steps.slice(0,3).map(s => `<li>${s}</li>`).join("")}</ul>` : ""}
        </div>
      `;
    };

    panels.forEach(panel => {
      const target = panel.getAttribute('data-insight-target');
      // naive split: rotate through insights so each panel gets something
      panel.innerHTML = "";
      const slice = insights.slice(0, 2);
      if (!slice.length) {
        panel.innerHTML = `<div class="text-muted small">No insights available.</div>`;
      } else {
        panel.innerHTML = slice.map(mkCard).join("");
      }
    });

    // Evidence panels (if present)
    const evHolders = [
      { id: "ev_active_by_phase", key: "top_sponsors_active_trials" },
      { id: "ev_start_momentum", key: "starts_series" },
      { id: "ev_moa_distribution", key: "top_moa" },
      { id: "ev_geo_footprint", key: "regions" }
    ];
    evHolders.forEach(({ id, key }) => {
      const evEl = document.getElementById(id);
      if (!evEl) return;
      const firstWithEvidence = insights.find(i => i.evidence && i.evidence[key]);
      if (firstWithEvidence) {
        const ev = firstWithEvidence.evidence[key];
        if (Array.isArray(ev)) {
          evEl.innerHTML = `<div>${ev.slice(0, 5).map(e => {
            if (typeof e === "object") {
              const k = Object.keys(e)[0];
              const v = e[k];
              return `<span class="me-3">${k}: <b>${v}</b></span>`;
            }
            return `<span class="me-3">${String(e)}</span>`;
          }).join("")}</div>`;
        } else if (typeof ev === "object") {
          evEl.innerHTML = `<pre class="small text-muted mb-0">${JSON.stringify(ev, null, 2)}</pre>`;
        } else {
          evEl.textContent = String(ev);
        }
      } else {
        evEl.innerHTML = `<span class="text-muted">No evidence available</span>`;
      }
    });
  }

  async function loadInsights(filters) {
    const url = `/api/insights?${qsFromFilters(filters)}`;
    const data = await fetchJSON(url);
    const insights = Array.isArray(data.insights) ? data.insights : [];
    renderInsights(insights);
  }

  // --- Page boot ---
  document.addEventListener("DOMContentLoaded", async () => {
    // Tell global loader the base filter for this page
    window.NNCI.setBaseFilter({ therapy_area: pageTherapy });

    const filters = getPageFilters();

    // KPIs (belt)
    try { await loadKpis(filters); } catch (e) { console.error("KPI load failed:", e); }

    // Initialize Debug popover (dev-only)
try {
  // reuse the KPIs you just fetched by asking loadKpis to return data, or re-fetch here:
  const kpiData = await fetch(`/api/kpis?${qsFromFilters(filters)}`, { headers: { "Accept": "application/json" } }).then(r => r.json());
  await loadDebugPopover(filters, kpiData);
} catch (e) {
  console.warn("Debug popover skipped:", e);
}

    // Charts: either rely on global auto-loader (already runs on DOMContentLoaded)
    // or force a refresh now so the base filter definitely applies.
    if (window.CTI && typeof window.CTI.refreshCharts === "function") {
      await window.CTI.refreshCharts();
    }

    // Insights
    try { await loadInsights(filters); } catch (e) { console.error("Insights load failed:", e); }
  });
})();

// ---- DEBUG: manual trigger so PMs/demo can run without chatbot ----
window.debugAgent = function (text) {
  if (window.AgentFlow && typeof AgentFlow.handleChatCommand === 'function') {
    AgentFlow.handleChatCommand(text || "show active trials");
  } else {
    console.warn("AgentFlow not ready yet.");
  }
};
