// static/js/lazy_charts.js
(function () {
  // Public entry
  window.initLazyCharts = initLazyCharts;

  // State
  var rendered = Object.create(null);   // id -> echarts instance
  var io = null, mo = null;

  // Utils
  function $(sel, root){ return (root||document).querySelector(sel); }
  function $all(sel, root){ return Array.prototype.slice.call((root||document).querySelectorAll(sel)); }
  function visible(el){ return !!(el && el.offsetParent !== null && el.offsetWidth && el.offsetHeight); }
  function ensure(id, fn){ if(!rendered[id]){ rendered[id] = fn(); } return rendered[id]; }
  function markReady(id){ var el = document.getElementById(id); if (el) el.classList.add('is-ready'); }
  function loadJson(path){ return fetch(path).then(function(r){ if(!r.ok) throw new Error(path); return r.json(); }); }

  // If page script accidentally exposed an eager init, noop it
  if (window.initCtCharts && typeof window.initCtCharts === 'function') {
    try { window.initCtCharts = function(){ /* lazy takes over */ }; } catch (_) {}
  }

  // Panels
  function fillPanelFor(containerId, json) {
    // We assume the insight and provenance element IDs follow: ins_<suffix>, ev_<suffix>
    // where containerId = ct_chart_<suffix>
    var suffix = containerId.replace(/^ct_chart_/, '');
    var insId = 'ins_' + suffix;
    var provId = 'ev_' + suffix;
    if (window.CIInsights && typeof CIInsights.render === 'function') {
      try { CIInsights.render(json.insights || [], json.provenance || [], insId, provId); } catch(_){}
    } else {
      // Fallback: minimal provenance list if present
      var prov = document.getElementById(provId);
      if (prov && Array.isArray(json.provenance)) {
        prov.innerHTML = json.provenance.map(function(s){
          var label = (s.url ? "<a class='link-info' target='_blank' href='"+s.url+"'>"+(s.name||s.url)+"</a>" : (s.name||''));
          return "<div>• " + label + "</div>";
        }).join('');
      }
    }
  }

  // ---- Renderers for CT ----
  function render_active_by_phase(id, json) {
    // Expect stacked bars per phase by sponsor or similar shape
    var el = echarts.init(document.getElementById(id), 'dark');

    var phases = (json.chart && json.chart.categories) || [];         // e.g., ['Phase 1','Phase 2',...]
    var entities = json.entities || [];                                // e.g., sponsors
    var byEntity = json.data && json.data.by_entity || [];             // [{name:..., Phase 1: n, Phase 2: n, ...}]

    var series = phases.map(function(p){
      return {
        name: p,
        type: 'bar',
        stack: 'total',
        data: entities.map(function(ent){
          var rec = byEntity.find(function(x){ return x.name === ent; }) || {};
          return +(rec[p] || 0);
        })
      };
    });

    el.setOption({
      tooltip: { trigger:'axis' },
      legend: { type:'scroll' },
      yAxis: { type:'category', data: entities },
      xAxis: { type:'value', name: (json.metadata && json.metadata.unit) || '' },
      series: series
    });
    markReady(id);
    return el;
  }

  function render_start_momentum(id, json) {
    // Expect a time-series line chart
    var el = echarts.init(document.getElementById(id), 'dark');
    var x = (json.data && json.data.series || []).map(function(r){ return r[(json.chart && json.chart.x_key) || 'month']; });
    var keys = (json.chart && json.chart.series_keys) || []; // e.g., ['Novo Nordisk', 'Eli Lilly']
    var s = keys.map(function(k){
      return { name:k, type:'line', smooth:true, data:(json.data.series || []).map(function(r){ return r[k]; }) };
    });
    el.setOption({
      tooltip:{ trigger:'axis' },
      legend:{ type:'scroll' },
      xAxis:{ type:'category', data:x },
      yAxis:{ type:'value', name:(json.metadata && json.metadata.unit) || '' },
      series:s
    });
    markReady(id);
    return el;
  }

  function render_moa_distribution(id, json) {
    // Expect top-N MoA as horizontal 100% stacked bars per company or single series bars
    var el = echarts.init(document.getElementById(id), 'dark');
    var cats = (json.chart && json.chart.categories) || []; // MoAs
    var entities = json.entities || []; // companies
    var byMoA = json.data && json.data.by_moa || []; // [{moa:'GLP-1', 'Novo Nordisk':0.4, 'Eli Lilly':0.3, ...}]

    var series = entities.map(function(ent){
      return {
        name: ent,
        type: 'bar',
        data: cats.map(function(m){
          var rec = byMoA.find(function(x){ return x.moa === m; }) || {};
          var v = (rec[ent] || 0) * 100;
          return +v.toFixed(1);
        })
      };
    });

    el.setOption({
      tooltip:{ trigger:'axis', valueFormatter:function(v){ return v + '%'; } },
      legend:{ type:'scroll' },
      yAxis:{ type:'category', data: cats },
      xAxis:{ type:'value', name:'Share %' },
      series: series,
      grid:{ left: 120 }
    });
    markReady(id);
    return el;
  }

  function render_geo_footprint(id, json) {
    // Expect region share by entity as grouped bars
    var el = echarts.init(document.getElementById(id), 'dark');
    var regions = (json.data && json.data.regions) || [];
    var entities = json.entities || [];
    var shares = json.data && json.data.share || []; // [{region:'NA', 'Novo Nordisk':0.3, ...}]

    var series = entities.map(function(ent){
      return {
        name: ent,
        type: 'bar',
        data: regions.map(function(r){
          var row = shares.find(function(x){ return x.region === r; }) || {};
          var v = (row[ent] || 0) * 100;
          return +v.toFixed(1);
        })
      };
    });

    el.setOption({
      tooltip:{ trigger:'axis', valueFormatter:function(v){ return v + '%'; } },
      legend:{ type:'scroll' },
      xAxis:{ type:'category', data: regions },
      yAxis:{ type:'value', name:'Share %' },
      series: series
    });
    markReady(id);
    return el;
  }

  // Map chart-type -> renderer
  var TYPE_TO_RENDER = {
    'active_by_phase': render_active_by_phase,
    'start_momentum':  render_start_momentum,
    'moa_distribution':render_moa_distribution,
    'geo_footprint':   render_geo_footprint
  };

  // Build per-container lazy render function
  function makeRenderer(node) {
    var id = node.id;
    var type = node.getAttribute('data-chart-type');
    var endpoint = node.getAttribute('data-endpoint');

    return function () {
      // fetch when visible
      return loadJson(endpoint)
        .then(function(json){
          var renderer = TYPE_TO_RENDER[type];
          if (!renderer) throw new Error('No renderer for type: ' + type);
          var inst = renderer(id, json);
          fillPanelFor(id, json);
          return inst;
        })
        .catch(function(err){
          console.error('Render failed for', id, err);
          var el = document.getElementById(id);
          if (el) {
            el.innerHTML = '<div class="text-danger small">Failed to load data.</div>';
            markReady(id);
          }
          return null;
        });
    };
  }

  // Orchestration
  function observeAndRender() {
    var nodes = $all('.nnci-chart[id]');
    var RENDER = Object.create(null);

    // register per node
    nodes.forEach(function(n){ RENDER[n.id] = makeRenderer(n); });

    try {
      io = new IntersectionObserver(function(entries){
        entries.forEach(function(ent){
          if (ent.isIntersecting) {
            var id = ent.target.id;
            if (RENDER[id] && !rendered[id]) {
              // ensure() can accept an async fn; we keep a promise so we don’t double-run
              rendered[id] = Promise.resolve(RENDERid);
            }
          }
        });
      }, { root:null, threshold:0.05 });

      nodes.forEach(function(node){ io.observe(node); });
    } catch(_) {
      // Fallback: instant render of visible ones
      nodes.forEach(function(node){
        if (visible(node) && !rendered[node.id]) {
          rendered[node.id] = Promise.resolve(RENDERnode.id);
        }
      });
    }

    // MutationObserver for reveal-on-interaction containers
    mo = new MutationObserver(function(){
      nodes.forEach(function(node){
        if (visible(node) && !rendered[node.id]) {
          rendered[node.id] = Promise.resolve(RENDERnode.id);
        }
      });
    });
    mo.observe(document.body, {
      attributes:true, childList:true, subtree:true,
      attributeFilter:['class','style','open','hidden','aria-hidden']
    });

    // Resize already rendered charts
    window.addEventListener('resize', function(){
      nodes.forEach(function(n){
        var inst = rendered[n.id];
        if (inst && typeof inst.then === 'function') {
          inst.then(function(e){ if (e && e.resize) try{ e.resize(); }catch(_){}; });
        } else if (inst && inst.resize) {
          try{ inst.resize(); }catch(_){}
        }
      });
    });
  }

  function initLazyCharts() {
    observeAndRender();
  }

  // Auto-init when DOM is ready (with defer this fires after parse)
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initLazyCharts, { once:true });
  } else {
    initLazyCharts();
  }
})();
