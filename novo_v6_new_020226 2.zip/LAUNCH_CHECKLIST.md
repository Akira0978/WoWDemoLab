# ✅ Pre-Launch Checklist

## Backend Status

### ✅ Flask App (app.py)
- [x] Routes refactored to new templates
- [x] Legacy inline `/api/trials` routes removed
- [x] Blueprint registered with explicit `url_prefix="/api"`
- [x] No syntax errors
- [x] 8 new routes verified registered:
  - `/clinical-trials/diabetes`
  - `/clinical-trials/obesity`
  - `/clinical-trials/cardiovascular`
  - `/dashboard` (legacy)
  - 8 × `/api/*` endpoints

### ✅ API Blueprint (services/api_trials.py)
- [x] 880+ lines of complete Python code
- [x] 8 endpoints implemented and documented
- [x] No syntax errors
- [x] Blueprint name: `api_trials`
- [x] URL prefix: `/api`
- [x] Imports correctly

### ✅ Data & Cache
- [ ] **TODO:** `static/json/trials_master.json` exists with trial data
  - Run: `python data_faker.py`
  - This file is **required** for API endpoints to return real data

---

## Frontend Status

### ✅ Templates
- [x] `base.html`: has `{% block topbar %}`, ECharts loaded, global.js loaded
- [x] `ct_diabetes.html`: placeholder divs for 4 charts + KPI belt + insights
- [ ] **TODO:** `ct_obesity.html` created and configured
- [ ] **TODO:** `ct_cardiovascular.html` created and configured

### ✅ JavaScript
- [ ] **TODO:** `static/js/global.js` is latest version with chart rendering logic
- [ ] **TODO:** `static/js/ct_diabetes.js` exists and handles API calls
- [ ] **TODO:** `static/js/ct_obesity.js` exists and handles API calls
- [ ] **TODO:** `static/js/ct_cardiovascular.js` exists and handles API calls

### ✅ CSS
- [ ] **TODO:** `static/css/ct_diabetes.css` exists (or styling in base.css)
- [ ] **TODO:** Novo Nordisk colors applied (True Blue #001965, Snow White #FFFFFF)
- [ ] **TODO:** Glass morphism topbar styled
- [ ] **TODO:** KPI belt cards styled
- [ ] **TODO:** Chart containers have proper height/spacing

---

## Test Sequence

### 1️⃣ Start Flask App
```bash
cd c:\Python\NovoNordisk\Clinical_trials\29-01-26
python app.py
```
Expected output:
```
WARNING: This is a development server. Do not use it in production.
 * Running on http://127.0.0.1:5000
```

### 2️⃣ Navigate to Page
Open browser: `http://localhost:5000/clinical-trials/diabetes`

Expected:
- ✅ Page loads without 404 errors
- ✅ Topbar shows: "CI Platform – Diabetes · Clinical Trials"
- ✅ Sidebar visible (if CSS/JS wired correctly)
- ✅ KPI belt container visible
- ✅ 4 chart containers visible

### 3️⃣ DevTools Verification (F12)

**Elements Tab:**
```js
// Count chart divs
document.querySelectorAll('.nnci-chart[data-endpoint]').length
// Expected: 4
```

**Network Tab:**
```
Filter: /api/
Expected calls:
  ✅ GET /api/kpis?therapy_area=diabetes (200)
  ✅ GET /api/charts/active-by-phase?therapy_area=diabetes (200)
  ✅ GET /api/charts/start-momentum?... (200)
  ✅ GET /api/charts/moa-distribution?... (200)
  ✅ GET /api/charts/geo-footprint?... (200)
  ✅ GET /api/insights?... (200)

Response should be JSON with data fields.
If 500 error: check Flask console for Python errors.
```

**Console Tab:**
```
❌ No red errors
❌ No "undefined function" messages
✅ Chart rendering messages (if logging enabled)
```

### 4️⃣ Visual Verification
- [ ] Topbar is sticky and doesn't scroll away
- [ ] KPI belt shows 9 metrics (not empty/NaN)
- [ ] Four charts render with data (not blank containers)
- [ ] Insight cards show actionable text (not empty)
- [ ] Color scheme matches Novo Nordisk (True Blue + white)
- [ ] Responsive on mobile (if needed)

---

## Common Issues & Fixes

### Issue: "404 Not Found" at `/clinical-trials/diabetes`
**Fix:** Ensure templates directory structure:
```
templates/
  ├─ base.html ✅
  ├─ ct_diabetes.html ✅
  ├─ ct_obesity.html (needed)
  ├─ ct_cardiovascular.html (needed)
  └─ partials/ (for includes)
```

### Issue: Charts show blank containers
**Causes:**
1. `static/json/trials_master.json` doesn't exist or is empty
   - **Fix:** Run `python data_faker.py`
2. API endpoints return 500 errors
   - **Fix:** Check Flask console for Python errors
3. JavaScript files not loading
   - **Fix:** DevTools → Network → check `/static/js/*.js` return 200
4. ECharts library not loaded
   - **Fix:** Ensure `<script src="https://cdn.jsdelivr.net/npm/echarts@5/dist/echarts.min.js"></script>` in base.html

### Issue: KPI metrics show as "NaN" or empty
**Causes:**
1. Data file missing/empty (see above)
2. API response format mismatch
   - **Fix:** Check `/api/kpis?therapy_area=diabetes` response in DevTools Network
3. JavaScript parsing error
   - **Fix:** DevTools Console → check for parse errors

### Issue: Sidebar collapse doesn't work
**Fix:** Check `global.js` selectors match your sidebar HTML IDs/classes

---

## File Checklist

### Must Exist
- [x] `app.py` ✅ (just updated)
- [x] `services/api_trials.py` ✅
- [x] `templates/base.html` ✅
- [ ] `templates/ct_diabetes.html` (you have it)
- [ ] `templates/ct_obesity.html` (needed)
- [ ] `templates/ct_cardiovascular.html` (needed)
- [ ] `static/js/global.js` (updated version)
- [ ] `static/js/ct_diabetes.js` (needed)
- [ ] `static/js/ct_obesity.js` (needed)
- [ ] `static/js/ct_cardiovascular.js` (needed)
- [ ] `static/json/trials_master.json` (from data_faker.py)

### Documentation
- [x] `API_ENDPOINTS.md` ✅ (already created)
- [x] `ROUTING_CHANGES.md` ✅ (just created)
- [x] `ARCHITECTURE.md` ✅ (just created)

---

## Next Immediate Steps

1. **Generate trial data:**
   ```bash
   python data_faker.py
   ```

2. **Verify data file was created:**
   ```bash
   ls -la static/json/trials_master.json
   # Should show file with non-zero size
   ```

3. **Start Flask app:**
   ```bash
   python app.py
   ```

4. **Test in browser:**
   - Navigate to `http://localhost:5000/clinical-trials/diabetes`
   - DevTools → Network → confirm `/api/*` calls return 200 + JSON
   - DevTools → Elements → confirm 4 charts render

5. **If charts don't render:**
   - Check Flask console for Python errors (500 responses)
   - Check Browser console for JavaScript errors
   - Verify `static/js/global.js` and `static/js/ct_diabetes.js` exist
   - Verify ECharts library loads (Network tab)

---

## Success Criteria

✅ You have successfully launched when:
- ✅ Page loads at `/clinical-trials/diabetes` without 404
- ✅ Topbar displays correctly
- ✅ KPI belt shows 9 metrics (numbers, not NaN)
- ✅ 4 charts render with data from `/api/charts/*`
- ✅ Insights cards show actionable text
- ✅ Network requests to `/api/*` all return 200 + valid JSON
- ✅ Browser console has no red errors
- ✅ Responsive design works (if tested)

