"""
Clinical Trials Master Data Generator
Generates synthetic but realistic trial data for NN CI Platform
"""
import json
import random
from datetime import datetime, timedelta
from typing import List, Dict, Any

class TrialsFaker:
    def __init__(self, seed: int = 42, total_trials: int = 150):
        random.seed(seed)
        self.total_trials = total_trials
        self.trial_counter = 1
        
        # Controlled vocabularies
        self.sponsors = [
            "Novo Nordisk", "Eli Lilly", "Pfizer", 
            "AstraZeneca", "Sanofi"
        ]
        
        self.mechanisms = {
            "diabetes": [
                "GLP-1 RA", "Oral GLP-1 RA", "GIP/GLP-1 dual agonist",
                "Triple agonist", "Amylin analog", "SGLT2 inhibitor",
                "DPP-4 inhibitor", "GCK activator"
            ],
            "obesity": [
                "GLP-1 RA", "Oral GLP-1 RA", "GIP/GLP-1 dual agonist",
                "Triple agonist", "Amylin analog", "Orexigenic antagonist",
                "Leptin analog", "Other"
            ],
            "cardiovascular": [
                "SGLT2 inhibitor", "GLP-1 RA", "IL-6 ligand mAb",
                "Aldosterone synthase inhibitor (ASI)", "ASI + SGLT2 combo",
                "DOAC / antithrombotic", "Other metabolic"
            ]
        }
        
        self.statuses = [
            "Recruiting", "Active (not recruiting)", "Completed",
            "Terminated", "Suspended", "Not yet recruiting"
        ]
        
        self.indications_by_area = {
            "diabetes": [
                "T2D", "T1D", "T2D + obesity", "T2D + CKD", 
                "T2D + CVD", "NASH"
            ],
            "obesity": [
                "Obesity", "Obesity + T2D", "Obesity + CVD",
                "Obesity + metabolic dysfunction", "Obesity + NASH"
            ],
            "cardiovascular": [
                "ASCVD", "CKD", "HFpEF", "HFrEF", "AMI post-MI",
                "MACE reduction", "PAD", "AF", "Angina"
            ]
        }
        
        self.countries_pool = {
            "US": ["USA"],
            "EU": ["Germany", "UK", "France", "Spain", "Italy", "Netherlands"],
            "Asia": ["Japan", "China", "South Korea", "India"],
            "LatAm": ["Mexico", "Brazil", "Argentina"],
            "Other": ["Canada", "Australia", "New Zealand"]
        }
        
        # Anchor trials (seeded, real-like)
        self.anchors = self._build_anchors()

    def _build_anchors(self) -> List[Dict[str, Any]]:
        """Build anchor trials from user-provided examples"""
        return [
            {
                "trial_id": "NCT05926401",
                "title": "ZEUS - Ziltivekimab Phase 3 CVOT",
                "sponsor": "Novo Nordisk",
                "drug_name": "Ziltivekimab",
                "mechanism": "IL-6 ligand mAb",
                "therapy_area": "cardiovascular",
                "indication": "ASCVD",
                "phase": 3,
                "status": "Active (not recruiting)",
                "fda_approved": False,
                "start_date": "2023-06-15",
                "primary_completion_date": "2026-12-31",
                "last_updated": "2026-01-15",
                "enrollment": 6200,
                "sites_count": 873,
                "countries": ["USA", "Germany", "UK", "France", "Spain", "Canada", "Australia"],
                "regions": ["US", "EU", "Other"],
                "primary_outcome_headline": "MACE reduction in ASCVD",
                "key_kpis": ["MACE", "CRP reduction", "CV safety"],
                "recruitment_velocity_n_per_month": 85.0,
                "expected_entry_year": 2026
            },
            {
                "trial_id": "NCT04527484",
                "title": "Prevent-HF - Baxdrostat + Dapagliflozin Phase 3",
                "sponsor": "Pfizer",
                "drug_name": "Baxdrostat + Dapagliflozin",
                "mechanism": "ASI + SGLT2 combo",
                "therapy_area": "cardiovascular",
                "indication": "HFpEF",
                "phase": 3,
                "status": "Active (not recruiting)",
                "fda_approved": False,
                "start_date": "2021-04-01",
                "primary_completion_date": "2029-06-30",
                "last_updated": "2026-01-10",
                "enrollment": 11300,
                "sites_count": 1153,
                "countries": ["USA", "UK", "Germany", "France", "Spain", "Japan", "Canada"],
                "regions": ["US", "EU", "Asia", "Other"],
                "primary_outcome_headline": "HF hospitalization reduction in HFpEF",
                "key_kpis": ["HF hospitalization", "CV death", "Symptoms"],
                "recruitment_velocity_n_per_month": 125.0,
                "expected_entry_year": 2029
            },
            {
                "trial_id": "NCT04839277",
                "title": "SELECT - Semaglutide 2.4 mg CVOT",
                "sponsor": "Novo Nordisk",
                "drug_name": "Semaglutide 2.4 mg",
                "mechanism": "GLP-1 RA",
                "therapy_area": "obesity",
                "indication": "Obesity + CVD",
                "phase": 3,
                "status": "Completed",
                "fda_approved": True,
                "start_date": "2018-10-15",
                "primary_completion_date": "2023-03-01",
                "last_updated": "2023-11-15",
                "enrollment": 17604,
                "sites_count": 1876,
                "countries": ["USA", "UK", "Germany", "Spain", "France", "Canada", "Australia"],
                "regions": ["US", "EU", "Other"],
                "primary_outcome_headline": "MACE reduction in obesity + CVD",
                "key_kpis": ["MACE", "Weight loss", "CV safety"],
                "recruitment_velocity_n_per_month": 140.0,
                "expected_entry_year": 2023
            },
            {
                "trial_id": "NCT03036150",
                "title": "DAPA-CKD - Dapagliflozin in CKD",
                "sponsor": "AstraZeneca",
                "drug_name": "Dapagliflozin",
                "mechanism": "SGLT2 inhibitor",
                "therapy_area": "cardiovascular",
                "indication": "CKD",
                "phase": 3,
                "status": "Completed",
                "fda_approved": True,
                "start_date": "2017-02-01",
                "primary_completion_date": "2020-06-30",
                "last_updated": "2021-04-15",
                "enrollment": 4304,
                "sites_count": 386,
                "countries": ["USA", "UK", "Germany", "Japan", "Australia"],
                "regions": ["US", "EU", "Asia", "Other"],
                "primary_outcome_headline": "CKD progression composite (renal & mortality)",
                "key_kpis": ["eGFR slope", "Mortality", "CKD progression"],
                "recruitment_velocity_n_per_month": 110.0,
                "expected_entry_year": 2020
            },
            {
                "trial_id": "NCT04881136",
                "title": "MariTide Phase 2/3 - T2D + Obesity",
                "sponsor": "Eli Lilly",
                "drug_name": "MariTide",
                "mechanism": "GIP/GLP-1 dual agonist",
                "therapy_area": "diabetes",
                "indication": "T2D + obesity",
                "phase": 3,
                "status": "Active (not recruiting)",
                "fda_approved": False,
                "start_date": "2021-08-01",
                "primary_completion_date": "2026-03-31",
                "last_updated": "2026-01-12",
                "enrollment": 4600,
                "sites_count": 520,
                "countries": ["USA", "UK", "Germany", "France", "Canada"],
                "regions": ["US", "EU", "Other"],
                "primary_outcome_headline": "HbA1c + weight reduction composite",
                "key_kpis": ["HbA1c", "Weight loss", "Glycemic control"],
                "recruitment_velocity_n_per_month": 95.0,
                "expected_entry_year": 2026
            },
            {
                "trial_id": "NCT05029999",
                "title": "Amycretin Phase 2 - Oral Amylin",
                "sponsor": "Novo Nordisk",
                "drug_name": "Amycretin (rAvPAC)",
                "mechanism": "Amylin analog",
                "therapy_area": "diabetes",
                "indication": "T2D",
                "phase": 2,
                "status": "Active (not recruiting)",
                "fda_approved": False,
                "start_date": "2022-03-15",
                "primary_completion_date": "2025-09-30",
                "last_updated": "2026-01-08",
                "enrollment": 280,
                "sites_count": 35,
                "countries": ["USA", "UK", "Germany"],
                "regions": ["US", "EU"],
                "primary_outcome_headline": "HbA1c + weight reduction in T2D",
                "key_kpis": ["HbA1c", "Weight loss", "GI tolerability"],
                "recruitment_velocity_n_per_month": 45.0,
                "expected_entry_year": 2025
            }
        ]

    def _generate_trial_id(self) -> str:
        """Generate NCT-style trial ID"""
        base_num = 5000000 + (self.trial_counter * 1000) + random.randint(1, 999)
        self.trial_counter += 1
        return f"NCT{base_num}"

    def _pick_sponsor(self, therapy_area: str) -> str:
        """Weighted sponsor selection"""
        weights = {
            "Novo Nordisk": 0.35,
            "Eli Lilly": 0.25,
            "Pfizer": 0.18,
            "AstraZeneca": 0.15,
            "Sanofi": 0.07
        }
        return random.choices(
            list(weights.keys()),
            weights=list(weights.values()),
            k=1
        )[0]

    def _pick_mechanism(self, therapy_area: str) -> str:
        """Pick mechanism based on therapy area"""
        return random.choice(self.mechanisms.get(therapy_area, ["Other"]))

    def _pick_phase(self) -> int:
        """Weighted phase distribution"""
        weights = {1: 0.20, 2: 0.40, 3: 0.30, 4: 0.10}
        return random.choices(
            list(weights.keys()),
            weights=list(weights.values()),
            k=1
        )[0]

    def _pick_status(self, phase: int) -> str:
        """Phase-aware status distribution"""
        if phase == 1:
            weights = {"Recruiting": 0.4, "Active (not recruiting)": 0.3, "Suspended": 0.2, "Terminated": 0.1}
        elif phase == 2:
            weights = {"Recruiting": 0.35, "Active (not recruiting)": 0.35, "Completed": 0.2, "Suspended": 0.1}
        else:  # Phase 3+
            weights = {"Active (not recruiting)": 0.5, "Recruiting": 0.2, "Completed": 0.25, "Suspended": 0.05}
        
        return random.choices(
            list(weights.keys()),
            weights=list(weights.values()),
            k=1
        )[0]

    def _pick_enrollment(self, phase: int) -> int:
        """Phase-aware enrollment sizes"""
        if phase == 1:
            return random.randint(20, 100)
        elif phase == 2:
            return random.randint(100, 1500)
        else:  # Phase 3+
            return random.randint(1000, 5000)

    def _pick_countries(self) -> List[str]:
        """Realistic country distribution"""
        num_countries = random.randint(3, 8)
        countries = []
        if random.random() < 0.85:  # Most trials include US
            countries.append("USA")
        
        # Add European countries
        if random.random() < 0.75:
            countries.extend(random.sample(self.countries_pool["EU"], k=random.randint(1, 3)))
        
        # Occasionally add others
        if random.random() < 0.4:
            countries.extend(random.sample(self.countries_pool["Asia"], k=random.randint(1, 2)))
        if random.random() < 0.2:
            countries.extend(random.sample(self.countries_pool["LatAm"], k=1))
        
        return list(set(countries))[:num_countries]

    def _derive_regions(self, countries: List[str]) -> List[str]:
        """Derive regions from countries"""
        regions = set()
        if "USA" in countries or "Canada" in countries:
            regions.add("US")
        if any(c in self.countries_pool["EU"] for c in countries):
            regions.add("EU")
        if any(c in self.countries_pool["Asia"] for c in countries):
            regions.add("Asia")
        if any(c in self.countries_pool["LatAm"] for c in countries):
            regions.add("LatAm")
        if any(c in self.countries_pool["Other"] for c in countries):
            regions.add("Other")
        return list(regions)

    def _pick_dates(self, phase: int) -> tuple:
        """Generate start and completion dates"""
        start_year = random.randint(2019, 2025)
        start_date = datetime(start_year, random.randint(1, 12), random.randint(1, 28))
        
        # Duration based on phase
        duration_months = {1: random.randint(6, 18), 2: random.randint(18, 36), 3: random.randint(24, 60), 4: random.randint(12, 24)}
        duration = duration_months.get(phase, 24)
        
        completion_date = start_date + timedelta(days=duration * 30)
        return start_date.strftime("%Y-%m-%d"), completion_date.strftime("%Y-%m-%d")

    def _derive_recruitment_velocity(self, enrollment: int, start_date: str, completion_date: str) -> float:
        """Derive recruitment velocity from enrollment and timeline"""
        start = datetime.strptime(start_date, "%Y-%m-%d")
        completion = datetime.strptime(completion_date, "%Y-%m-%d")
        total_months = (completion - start).days / 30.0
        recruitment_fraction = random.uniform(0.35, 0.55)  # Recruitment happens in first 35-55% of trial
        recruitment_months = max(3, total_months * recruitment_fraction)
        velocity = enrollment / recruitment_months
        return round(velocity, 1)

    def generate_trial(self, therapy_area: str, index: int) -> Dict[str, Any]:
        """Generate a single synthetic trial"""
        phase = self._pick_phase()
        enrollment = self._pick_enrollment(phase)
        start_date, completion_date = self._pick_dates(phase)
        countries = self._pick_countries()
        regions = self._derive_regions(countries)
        
        drug_name = f"Asset-{therapy_area[0].upper()}{index:03d}"
        mechanism = self._pick_mechanism(therapy_area)
        indication = random.choice(self.indications_by_area.get(therapy_area, ["Other"]))
        
        recruitment_velocity = self._derive_recruitment_velocity(enrollment, start_date, completion_date)
        sites_count = max(10, int(enrollment / (5 + random.randint(0, 15))))
        
        status = self._pick_status(phase)
        fda_approved = status == "Completed" and random.random() < 0.4
        
        return {
            "trial_id": self._generate_trial_id(),
            "title": f"{drug_name} Phase {phase} - {indication}",
            "sponsor": self._pick_sponsor(therapy_area),
            "drug_name": drug_name,
            "mechanism": mechanism,
            "therapy_area": therapy_area,
            "indication": indication,
            "phase": phase,
            "status": status,
            "fda_approved": fda_approved,
            "start_date": start_date,
            "primary_completion_date": completion_date,
            "last_updated": (datetime.now() - timedelta(days=random.randint(0, 60))).strftime("%Y-%m-%d"),
            "enrollment": enrollment,
            "sites_count": sites_count,
            "countries": countries,
            "regions": regions,
            "primary_outcome_headline": f"Primary outcome for {indication}",
            "key_kpis": random.sample(["HbA1c", "Weight loss", "MACE", "Safety", "eGFR", "Mortality"], k=random.randint(2, 4)),
            "recruitment_velocity_n_per_month": recruitment_velocity,
            "expected_entry_year": int(datetime.strptime(completion_date, "%Y-%m-%d").year)
        }

    def generate_all(self) -> List[Dict[str, Any]]:
        """Generate full trial dataset"""
        trials = self.anchors.copy()
        remaining = self.total_trials - len(trials)
        
        # Distribution: 40% diabetes, 30% obesity, 30% cardiovascular
        diabetes_count = int(remaining * 0.40)
        obesity_count = int(remaining * 0.30)
        cardiovascular_count = remaining - diabetes_count - obesity_count
        
        index = 1
        for _ in range(diabetes_count):
            trials.append(self.generate_trial("diabetes", index))
            index += 1
        for _ in range(obesity_count):
            trials.append(self.generate_trial("obesity", index))
            index += 1
        for _ in range(cardiovascular_count):
            trials.append(self.generate_trial("cardiovascular", index))
            index += 1
        
        return trials


def main():
    """Generate and save trials_master.json"""
    faker = TrialsFaker(seed=42, total_trials=150)
    trials = faker.generate_all()
    
    # Save to JSON
    output_path = "static/json/trials_master.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(trials, f, indent=2, ensure_ascii=False)
    
    print(f"✅ Generated {len(trials)} trials")
    print(f"📊 Breakdown by therapy area:")
    for area in ["diabetes", "obesity", "cardiovascular"]:
        count = sum(1 for t in trials if t["therapy_area"] == area)
        print(f"   - {area.capitalize()}: {count}")
    print(f"💾 Saved to: {output_path}")


if __name__ == "__main__":
    main()
