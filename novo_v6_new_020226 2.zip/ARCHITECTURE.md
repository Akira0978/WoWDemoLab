# 🎯 Traffic Flow Diagram (After Changes)

```
User Browser
    │
    ├─ GET / ──────────────────────────────> [home()]
    │                                          └─> redirect → /clinical-trials/diabetes
    │
    ├─ GET /clinical-trials/diabetes ──────> [ct_diabetes_page()]
    │                                          └─> render_template("ct_diabetes.html")
    │                                              ├─ Loads: ct_diabetes.js
    │                                              ├─ Calls: global.js
    │                                              └─ Renders: 4 chart divs + KPI belt
    │
    ├─ GET /clinical-trials/obesity ───────> [ct_obesity_page()]
    │                                          └─> render_template("ct_obesity.html")
    │
    ├─ GET /clinical-trials/cardiovascular ─> [ct_cv_page()]
    │                                          └─> render_template("ct_cardiovascular.html")
    │
    ├─ GET /api/kpis?therapy_area=... ────────────> [api_trials_bp → @api_trials_bp.route("/kpis")]
    │  GET /api/charts/* ─────────────────────────> Returns JSON (ECharts format)
    │  GET /api/insights?... ────────────────────> All routed through api_trials.py
    │  GET /api/filters ───────────────────────>
    │
    └─ GET /dashboard ────────────────────────> [dashboard()]
                                               └─> render_template("dashboard.html") [legacy]

```

---

## 🏗️ Architecture: Before vs After

### BEFORE (What Was Wrong)
```
/diabetes          ──> dashboard.html      ❌ Wrong template! (old layout)
/ct_diabetes       ──> dashboard.html      ❌ Wrong template!
/api/trials        ──> app.py @route()    ❌ Conflicts with blueprint
/api/trials/<area> ──> app.py @route()    ❌ Duplicated logic
```

### AFTER (What's Fixed)
```
/clinical-trials/diabetes      ──> ct_diabetes.html      ✅ New template!
/clinical-trials/obesity       ──> ct_obesity.html       ✅ New template!
/clinical-trials/cardiovascular ──> ct_cardiovascular.html ✅ New template!

/api/*                         ──> api_trials_bp        ✅ Single source of truth
                                  (url_prefix="/api")
                                  ├─ /api/kpis
                                  ├─ /api/charts/*
                                  ├─ /api/insights
                                  └─ /api/filters
```

---

## 🔄 Data Flow Example: Diabetes Clinical Trials Page

### 1️⃣ Page Load
```
Browser: GET /clinical-trials/diabetes
         └─> Flask: ct_diabetes_page()
         └─> Jinja: render ct_diabetes.html + base.html
         └─> Response: HTML with 4 chart divs (data-endpoint attributes)
         └─> Browser: Renders page + runs ct_diabetes.js
```

### 2️⃣ JavaScript Initialization (ct_diabetes.js)
```
Document Ready:
  └─> global.js: Initialize chart renderers
  └─> Scan page for .nnci-chart[data-endpoint]
  └─> Found 4 charts:
      ├─ data-endpoint="/api/charts/active-by-phase"
      ├─ data-endpoint="/api/charts/start-momentum"
      ├─ data-endpoint="/api/charts/moa-distribution"
      └─ data-endpoint="/api/charts/geo-footprint"
  └─> For each chart: fetch(endpoint) → call ECharts renderChart()
```

### 3️⃣ API Calls (from Browser JS)
```
ct_diabetes.js: 
  ├─ GET /api/kpis?therapy_area=diabetes
  │  └─ api_trials.py: compute_kpis() → return JSON (9 metrics)
  │  └─> JS: Render KPI belt
  │
  ├─ GET /api/charts/active-by-phase?therapy_area=diabetes
  │  └─ api_trials.py: chart_active_by_phase() → return ECharts-compatible JSON
  │  └─> JS: echarts.setOption() + render
  │
  ├─ GET /api/charts/start-momentum?months=24&therapy_area=diabetes
  │  └─ api_trials.py: chart_start_momentum() → monthly trend data
  │  └─> JS: Render line chart
  │
  ├─ GET /api/charts/moa-distribution?top_n=8&therapy_area=diabetes
  │  └─ api_trials.py: chart_moa_distribution() → top mechanisms
  │  └─> JS: Render bar chart
  │
  ├─ GET /api/charts/geo-footprint?therapy_area=diabetes
  │  └─ api_trials.py: chart_geo_footprint() → regional distribution
  │  └─> JS: Render geo/bubble chart
  │
  └─ GET /api/insights?therapy_area=diabetes
     └─ api_trials.py: generate_insights() → 4 insight types
     └─> JS: Render insight cards
```

### 4️⃣ Final Render
```
Page displays:
  ✅ Sticky topbar: "CI Platform – Diabetes · Clinical Trials"
  ✅ Sidebar: collapsible nav
  ✅ KPI Belt: 9 metrics (e.g., "42 Active Trials", "+8 New Starts Last 12m")
  ✅ Report Table: paginated trials list
  ✅ Chart 1: Stacked bar (active trials by phase)
  ✅ Chart 2: Line trend (trial starts momentum)
  ✅ Chart 3: Bar chart (top 8 MoAs)
  ✅ Chart 4: Bubble/geo chart (regions)
  ✅ Insights: "Pfizer dominating Phase 3", "GLP-1 still #1 mechanism", etc.
```

---

## 🔗 URL Routing Summary

| Method | URL | Handler | Template | API Calls |
|--------|-----|---------|----------|-----------|
| GET | `/` | `home()` | (none) | (redirect) |
| GET | `/clinical-trials/diabetes` | `ct_diabetes_page()` | `ct_diabetes.html` | `/api/*?therapy_area=diabetes` |
| GET | `/clinical-trials/obesity` | `ct_obesity_page()` | `ct_obesity.html` | `/api/*?therapy_area=obesity` |
| GET | `/clinical-trials/cardiovascular` | `ct_cv_page()` | `ct_cardiovascular.html` | `/api/*?therapy_area=cardiovascular` |
| GET | `/api/kpis` | `api_trials_bp` → `kpis()` | (JSON) | (no calls) |
| GET | `/api/charts/active-by-phase` | `api_trials_bp` → `chart_active_by_phase()` | (JSON) | (no calls) |
| GET | `/api/charts/start-momentum` | `api_trials_bp` → `chart_start_momentum()` | (JSON) | (no calls) |
| GET | `/api/charts/moa-distribution` | `api_trials_bp` → `chart_moa_distribution()` | (JSON) | (no calls) |
| GET | `/api/charts/geo-footprint` | `api_trials_bp` → `chart_geo_footprint()` | (JSON) | (no calls) |
| GET | `/api/insights` | `api_trials_bp` → `insights()` | (JSON) | (no calls) |
| GET | `/api/trials` | `api_trials_bp` → `trials()` | (JSON) | (no calls) |
| GET | `/api/filters` | `api_trials_bp` → `filters()` | (JSON) | (no calls) |
| GET | `/dashboard` | `dashboard()` | `dashboard.html` | (legacy) |

