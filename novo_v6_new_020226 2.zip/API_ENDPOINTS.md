# Clinical Trial Intelligence API Endpoints

All endpoints are available at `/api/` prefix and return JSON.

## Endpoints

### KPI Belt
```
GET /api/kpis
```
Returns decision-driving metrics:
- `total_trials`, `active_trials`, `recruiting_trials`
- `new_starts_12m` (last 12 months)
- `top_mechanism_active` (leading MoA)
- `biggest_competitor_threat` (sponsor)
- `median_recruitment_velocity_n_per_month`
- `next_readouts` (next 5 upcoming completions)

**Query parameters:**
- `therapy_area`: filter by disease area (diabetes|obesity|cardiovascular)
- `sponsor`: sponsor name (repeatable or comma-separated)
- `drug`: drug name (repeatable or comma-separated)
- `phase`: phase number (1|2|3|4, repeatable or comma-separated)
- `status`: trial status (repeatable or comma-separated)
- `region`: region (US|EU|Asia|LatAm|Other)
- `start_from`: start date (YYYY-MM-DD)
- `start_to`: start date (YYYY-MM-DD)
- `completion_from`: completion date (YYYY-MM-DD)
- `completion_to`: completion date (YYYY-MM-DD)

**Example:**
```
GET /api/kpis?therapy_area=diabetes&sponsor=Novo%20Nordisk&phase=3
```

---

### Charts

#### Active Trials by Phase
```
GET /api/charts/active-by-phase
```
Stacked bar chart: phases on x-axis, sponsors as series.

**Query parameters:** (same as KPIs above)

**Response:**
```json
{
  "categories": ["Phase 1", "Phase 2", "Phase 3", "Phase 4"],
  "series": [
    {"name": "Novo Nordisk", "type": "bar", "stack": "active_trials", "data": [5, 8, 12, 3]},
    {"name": "Pfizer", "type": "bar", "stack": "active_trials", "data": [3, 6, 10, 2]},
    ...
  ]
}
```

---

#### Trial Start Momentum
```
GET /api/charts/start-momentum?months=24
```
Line chart: monthly trial starts over time.

**Query parameters:**
- `months`: number of months to display (default: 24)
- (+ therapy_area, sponsor, etc.)

**Response:**
```json
{
  "categories": ["2024-02", "2024-03", ..., "2026-01"],
  "series": [
    {"name": "Total", "type": "line", "data": [5, 7, 8, ...]},
    {"name": "Novo Nordisk", "type": "line", "data": [2, 3, 4, ...]},
    {"name": "Competitors", "type": "line", "data": [3, 4, 4, ...]}
  ]
}
```

---

#### MoA Distribution
```
GET /api/charts/moa-distribution?top_n=8
```
Bar chart: top mechanisms of action among active trials.

**Query parameters:**
- `top_n`: number of top MoAs to return (default: 8)
- (+ therapy_area, sponsor, etc.)

**Response:**
```json
{
  "categories": ["GLP-1 agonist", "SGLT2 inhibitor", "DPP-4 inhibitor", ...],
  "series": [
    {"name": "Active trials", "type": "bar", "data": [45, 38, 22, ...]}
  ]
}
```

---

#### Geographic Footprint
```
GET /api/charts/geo-footprint
```
Stacked bar chart: regions on x-axis, sponsors as series (active trials only).

**Query parameters:** (therapy_area, sponsor, etc.)

**Response:**
```json
{
  "categories": ["US", "EU", "Asia", "LatAm", "Other"],
  "series": [
    {"name": "Novo Nordisk", "type": "bar", "stack": "geo", "data": [25, 18, 12, 8, 3]},
    {"name": "Pfizer", "type": "bar", "stack": "geo", "data": [22, 15, 10, 5, 2]},
    ...
  ]
}
```

---

### Trials Table
```
GET /api/trials?limit=50&offset=0&sort_by=last_updated&desc=true
```
Paginated trial data (filtered).

**Query parameters:**
- `limit`: number of rows per page (default: 50)
- `offset`: starting row index (default: 0)
- `sort_by`: sort column (trial_id|title|sponsor|drug_name|last_updated|etc.)
- `desc`: sort descending (true|false, default: true)
- (+ therapy_area, sponsor, phase, etc.)

**Response:**
```json
{
  "columns": ["trial_id", "title", "sponsor", "drug_name", "therapy_area", "indication", "phase", "status", ...],
  "rows": [
    {"trial_id": "NCT04123456", "title": "...", "sponsor": "Novo Nordisk", ...},
    {...}
  ],
  "total": 245  // total matching trials (for pagination)
}
```

---

### Actionable Insights
```
GET /api/insights
```
Human-readable intelligence signals and recommended next steps.

**Query parameters:** (therapy_area, sponsor, etc.)

**Response:**
```json
{
  "as_of": "2026-01-29",
  "insights": [
    {
      "title": "Trial activity concentration: Eli Lilly leads active trials",
      "why_it_matters": "High active-trial concentration signals where competitive attention and resources are being deployed.",
      "next_steps": [
        "Drill into Phase distribution for the leading sponsor...",
        "Compare mechanism mix vs Novo..."
      ],
      "evidence": {
        "top_sponsors_active_trials": [
          {"sponsor": "Eli Lilly", "active_trials": 28},
          {"sponsor": "Pfizer", "active_trials": 22},
          ...
        ]
      }
    },
    ...
  ]
}
```

---

### Filter Options
```
GET /api/filters
```
Get available filter values for populating UI dropdowns.

**Response:**
```json
{
  "sponsors": ["Novo Nordisk", "Eli Lilly", "Pfizer", "AstraZeneca", "Sanofi", ...],
  "drugs": ["semaglutide", "tirzepatide", "dulaglutide", ...],
  "mechanisms": ["GLP-1 agonist", "SGLT2 inhibitor", "DPP-4 inhibitor", ...],
  "phases": [1, 2, 3, 4],
  "statuses": ["Recruiting", "Active (not recruiting)", "Completed", ...],
  "regions": ["US", "EU", "Asia", "LatAm", "Other"],
  "therapy_areas": ["diabetes", "obesity", "cardiovascular"]
}
```

---

## Usage Examples

### Example 1: Get KPIs for Diabetes + Novo Nordisk
```
GET /api/kpis?therapy_area=diabetes&sponsor=Novo%20Nordisk
```

### Example 2: Get active trials by phase for Obesity
```
GET /api/charts/active-by-phase?therapy_area=obesity
```

### Example 3: Get start momentum over last 12 months for Phase 3 trials
```
GET /api/charts/start-momentum?months=12&phase=3
```

### Example 4: Get top 5 competitors in Cardiovascular
```
GET /api/trials?therapy_area=cardiovascular&limit=50&sort_by=sponsor
```

### Example 5: Get insights for high-recruitment trials
```
GET /api/insights?status=Recruiting
```

---

## Frontend Integration

All endpoints return JSON ready for ECharts visualization:

```javascript
// Example: Fetch KPIs and update UI
fetch('/api/kpis?therapy_area=diabetes')
  .then(r => r.json())
  .then(data => {
    document.getElementById('active-count').textContent = data.active_trials;
    document.getElementById('top-competitor').textContent = data.biggest_competitor_threat;
  });

// Example: Fetch and render chart
fetch('/api/charts/active-by-phase?therapy_area=diabetes')
  .then(r => r.json())
  .then(data => {
    myChart.setOption({
      xAxis: { type: 'category', data: data.categories },
      series: data.series
    });
  });
```

---

## Notes

- All date parameters use `YYYY-MM-DD` format
- All endpoints accept repeated query params or comma-separated values
- Filters are applied server-side (Python) to keep JS thin
- Dataset is cached with mtime-based invalidation
- Response times should be <100ms for typical datasets (100-500 trials)
