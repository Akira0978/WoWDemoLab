# 🎯 Quick Reference: Routes & Templates

## Current URL Map

```
ROOT ROUTES
├─ GET /                    → home() → REDIRECT to /clinical-trials/diabetes
│
├─ GET /clinical-trials/diabetes       → ct_diabetes_page()       → ct_diabetes.html
├─ GET /clinical-trials/obesity        → ct_obesity_page()        → ct_obesity.html
├─ GET /clinical-trials/cardiovascular → ct_cv_page()             → ct_cardiovascular.html
│
└─ GET /dashboard                      → dashboard()              → dashboard.html (legacy)

API ROUTES (via blueprint: url_prefix="/api")
├─ GET /api/kpis                       → kpis()                   → JSON (KPI belt data)
├─ GET /api/charts/active-by-phase     → chart_active_by_phase()  → JSON (stacked bar)
├─ GET /api/charts/start-momentum      → chart_start_momentum()   → JSON (line chart)
├─ GET /api/charts/moa-distribution    → chart_moa_distribution() → JSON (bar chart)
├─ GET /api/charts/geo-footprint       → chart_geo_footprint()    → JSON (geo chart)
├─ GET /api/insights                   → insights()               → JSON (insight cards)
├─ GET /api/trials                     → trials()                 → JSON (paginated table)
└─ GET /api/filters                    → filters()                → JSON (available options)

STATIC FILES
└─ GET /static/<path>                  → Static file serving
```

---

## Template Rendering Chain

### Example: Visit `/clinical-trials/diabetes`

```
1. Flask Routes
   @app.route("/clinical-trials/diabetes")
   def ct_diabetes_page():
       return render_template("ct_diabetes.html", ...)

2. Jinja Template Chain
   ct_diabetes.html
   ├─ {% extends "base.html" %}
   │  base.html
   │  ├─ Loads: Bootstrap, ECharts, global.js
   │  ├─ Renders: sidebar, topbar, main content
   │  └─ Injects: {% block content %} from child
   │
   └─ {% block content %}
      ├─ <div id="kpi-belt"> (filled by ct_diabetes.js)
      ├─ <div id="ct_chart_active_by_phase" data-endpoint="/api/charts/active-by-phase">
      ├─ <div id="ct_chart_start_momentum" data-endpoint="/api/charts/start-momentum">
      ├─ <div id="ct_chart_moa_distribution" data-endpoint="/api/charts/moa-distribution">
      ├─ <div id="ct_chart_geo_footprint" data-endpoint="/api/charts/geo-footprint">
      └─ Insight panels with data-insight-target attributes

3. JavaScript Execution
   ├─ Load: global.js
   │  ├─ Initializes chart renderer engine
   │  ├─ Provides helper functions
   │  └─ Listens for .nnci-chart elements
   │
   └─ Load: ct_diabetes.js
      ├─ On document ready:
      │  ├─ Fetch /api/kpis?therapy_area=diabetes
      │  ├─ Populate KPI belt from JSON response
      │  ├─ For each .nnci-chart[data-endpoint]:
      │  │  ├─ Extract therapy_area from URL param
      │  │  ├─ Fetch endpoint (e.g., /api/charts/active-by-phase?therapy_area=diabetes)
      │  │  ├─ Parse JSON response
      │  │  └─ Call ECharts to render chart
      │  ├─ Fetch /api/insights?therapy_area=diabetes
      │  └─ Populate insight cards from JSON
      │
      └─ On window load / interval:
         └─ Refresh charts if data updates

4. Final HTML Rendered to Browser
   ├─ Sticky topbar (CI Platform – Diabetes · Clinical Trials)
   ├─ Sidebar (collapsible nav)
   ├─ KPI belt (9 metric cards: Total Trials, Active, Recruiting, etc.)
   ├─ Report table (paginated trials)
   ├─ Chart 1: Active by Phase (stacked bar)
   ├─ Chart 2: Start Momentum (line chart)
   ├─ Chart 3: MoA Distribution (horizontal bar)
   ├─ Chart 4: Geo Footprint (bubble/scatter)
   └─ Insight cards (4 types: concentration, phase 3, dominance, readouts)
```

---

## Data Flow

```
User Request
    ↓
Browser GET /clinical-trials/diabetes
    ↓
Flask app.py routing table
    ├─ Matches: @app.route("/clinical-trials/diabetes")
    ├─ Calls: ct_diabetes_page()
    └─ Returns: render_template("ct_diabetes.html", ...)
    ↓
Jinja Template Rendering
    ├─ base.html (layout)
    └─ ct_diabetes.html (content)
    ↓
HTML Sent to Browser
    ├─ Includes: <script src="/static/js/global.js"></script>
    └─ Includes: <script src="/static/js/ct_diabetes.js"></script>
    ↓
Browser JavaScript Execution (ct_diabetes.js)
    ├─ On ready:
    │  ├─ FETCH /api/kpis?therapy_area=diabetes
    │  ├─ FETCH /api/charts/active-by-phase?therapy_area=diabetes
    │  ├─ FETCH /api/charts/start-momentum?therapy_area=diabetes
    │  ├─ FETCH /api/charts/moa-distribution?therapy_area=diabetes
    │  ├─ FETCH /api/charts/geo-footprint?therapy_area=diabetes
    │  └─ FETCH /api/insights?therapy_area=diabetes
    │
    └─ On responses:
       ├─ global.js helper: renderChart(container, data)
       │  └─ echarts.setOption() + echarts.resize()
       ├─ Fill KPI belt cards with metric values
       └─ Populate insight panels with text
    ↓
Fully Rendered Dashboard
    ├─ ✅ Charts show live data from API
    ├─ ✅ KPIs display current metrics
    ├─ ✅ Insights show actionable intelligence
    └─ ✅ User can interact (filters, drill-down if implemented)
```

---

## Comparison: Old vs New

### ❌ OLD Way (Why It Didn't Work)

```
GET /ct_diabetes
    ↓
@app.route("/ct_diabetes")
def ct_diabetes():
    return render_template("dashboard.html", ...)
    ↓
dashboard.html (old template)
    ├─ No chart divs
    ├─ No KPI belt
    ├─ Shows old sales/marketing layout
    └─ Never calls /api/...
    ↓
❌ User sees: Old dashboard, no charts, no data
```

### ✅ NEW Way (What We Just Fixed)

```
GET /clinical-trials/diabetes
    ↓
@app.route("/clinical-trials/diabetes")
def ct_diabetes_page():
    return render_template("ct_diabetes.html", ...)
    ↓
ct_diabetes.html (new template)
    ├─ 4 chart divs with data-endpoint attributes
    ├─ KPI belt container
    ├─ Includes ct_diabetes.js
    └─ Includes global.js
    ↓
JavaScript Execution
    ├─ Fetch /api/kpis → populate KPI belt
    ├─ Fetch /api/charts/* → render ECharts
    └─ Fetch /api/insights → populate cards
    ↓
✅ User sees: Full dashboard with charts, KPIs, insights
```

---

## Testing: Before You Launch

### Step 1: Verify Routes Exist
```bash
python -c "from app import app; print([r.rule for r in app.url_map.iter_rules() if '/clinical' in r.rule or '/api/' in r.rule])"
```

Expected output includes:
```
/clinical-trials/diabetes
/clinical-trials/obesity
/clinical-trials/cardiovascular
/api/kpis
/api/charts/active-by-phase
/api/charts/start-momentum
/api/charts/moa-distribution
/api/charts/geo-footprint
/api/insights
/api/trials
/api/filters
```

### Step 2: Start Flask App
```bash
python app.py
```

Expected:
```
WARNING: This is a development server. Do not use it in production.
 * Running on http://127.0.0.1:5000
```

### Step 3: Test in Browser

1. **Navigate:** `http://localhost:5000/clinical-trials/diabetes`
   - Expected: Page loads, topbar shows "CI Platform – Diabetes · Clinical Trials"

2. **DevTools → Network Tab:**
   - Filter: `/api/`
   - Expected: 6 calls all return 200 status + JSON

3. **DevTools → Elements Tab:**
   - Search: `.nnci-chart`
   - Expected: 4 elements found

4. **DevTools → Console:**
   - Expected: No red errors

---

## File Dependencies

```
app.py (just updated)
    ├─ imports from: services/api_trials.py
    └─ renders templates:
        ├─ templates/ct_diabetes.html
        ├─ templates/ct_obesity.html
        ├─ templates/ct_cardiovascular.html
        └─ templates/base.html

templates/ct_diabetes.html
    ├─ extends: templates/base.html
    ├─ includes JS: static/js/ct_diabetes.js
    └─ references API endpoints: /api/*

templates/base.html
    ├─ loads CSS: static/css/bootstrap.css, global.css
    ├─ loads JS: ECharts library
    ├─ loads JS: static/js/global.js
    └─ includes partial: partials/sidebar_nav.html

static/js/ct_diabetes.js (needed)
    ├─ imports from: global.js helpers
    ├─ calls: /api/kpis?therapy_area=diabetes
    ├─ calls: /api/charts/*?therapy_area=diabetes
    ├─ calls: /api/insights?therapy_area=diabetes
    └─ uses: ECharts to render

static/json/trials_master.json (needed)
    ├─ source: data_faker.py
    ├─ format: JSON array of trial objects
    └─ accessed by: services/api_trials.py

services/api_trials.py (complete)
    ├─ reads: static/json/trials_master.json
    ├─ implements: 8 API endpoints
    └─ returns: JSON responses for charts/KPIs/insights
```

---

## URL Naming Convention

### Page Routes
```
/clinical-trials/{therapy_area}
    - diabetes
    - obesity
    - cardiovascular
```

### API Routes
```
/api/{resource}
    - /api/kpis
    - /api/charts/{chart_type}
    - /api/insights
    - /api/trials
    - /api/filters

/api/charts/{chart_type}
    - /api/charts/active-by-phase
    - /api/charts/start-momentum
    - /api/charts/moa-distribution
    - /api/charts/geo-footprint
```

### Query Parameters
```
?therapy_area={therapy_area}    (all endpoints support this)
?months={n}                     (/api/charts/start-momentum)
?top_n={n}                      (/api/charts/moa-distribution)
?page={n}&per_page={n}          (/api/trials - for pagination)
?{filter_field}={value}         (filter endpoints)
```

