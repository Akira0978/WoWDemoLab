"""
JSON → SQLite Migration Script
Loads existing trials_master.json into SQLite database
Run once: python import_json_to_sqlite.py
"""
import json
import sqlite3
from pathlib import Path

DB_PATH = Path("data/trials.db")
JSON_PATH = Path("static/json/trials_master.json")

def main():
    print(f"Migrating from {JSON_PATH} → {DB_PATH}...")
    
    # Create data directory if it doesn't exist
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    
    # Create connection and initialize schema
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    
    # Read and execute schema
    schema_content = Path("schema.sql").read_text()
    cur.executescript(schema_content)
    
    # Helper to JSON-encode complex fields
    def j(x):
        return json.dumps(x) if isinstance(x, (list, dict)) else x
    
    # Load JSON data
    try:
        data = json.loads(JSON_PATH.read_text())
    except FileNotFoundError:
        print(f"❌ {JSON_PATH} not found!")
        return
    except json.JSONDecodeError as e:
        print(f"❌ JSON decode error: {e}")
        return
    
    if not isinstance(data, list):
        print(f"❌ JSON root must be an array, got {type(data)}")
        return
    
    # Build rows
    rows = []
    for t in data:
        rows.append((
            t.get("trial_id"),
            t.get("title"),
            t.get("sponsor"),
            t.get("drug_name"),
            t.get("mechanism"),
            t.get("therapy_area"),
            t.get("indication"),
            t.get("phase"),
            t.get("status"),
            t.get("fda_approved"),
            t.get("start_date"),
            t.get("primary_completion_date"),
            t.get("last_updated"),
            t.get("enrollment"),
            t.get("sites_count"),
            j(t.get("countries")),
            j(t.get("regions")),
            t.get("primary_outcome_headline"),
            j(t.get("key_kpis")),
            t.get("recruitment_velocity_n_per_month"),
            t.get("expected_entry_year"),
        ))
    
    # Insert all rows
    cur.executemany("""
        INSERT OR REPLACE INTO trials VALUES (
            ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?
        )
    """, rows)
    
    conn.commit()
    conn.close()
    
    print(f"✅ Migration complete: {len(rows)} trials imported to {DB_PATH}")

if __name__ == "__main__":
    main()
