from flask import Flask, render_template, redirect, url_for
import os

# Clinical Trial Intelligence API blueprint
from services.api_trials import api_trials_bp
from services.chatbot import chatbot_bp
from data_faker_sqlite import start_background_faker

app = Flask(__name__,
            static_folder='static',
            template_folder='templates')

# Mount API blueprint at /api/...
app.register_blueprint(api_trials_bp, url_prefix="/api")
app.register_blueprint(chatbot_bp, url_prefix="/api/chat")

# Start background data faker to continuously populate trials database
start_background_faker(app)

# ============================================
# Routes
# ============================================

@app.route("/")
def home():
    """Land on the new Clinical Trials Diabetes page"""
    return redirect(url_for("ct_diabetes_page"))


# ---- Clinical Trials views (new templates) ----

@app.route("/clinical-trials/diabetes")
def ct_diabetes_page():
    """Clinical Trials Intelligence — Diabetes"""
    return render_template(
        "ct_diabetes.html",
        page_title="Clinical Trials — Diabetes",
        active_page="diabetes-ct"
    )


@app.route("/clinical-trials/obesity")
def ct_obesity_page():
    """Clinical Trials Intelligence — Obesity"""
    return render_template(
        "ct_obesity.html",
        page_title="Clinical Trials — Obesity",
        active_page="obesity-ct"
    )


@app.route("/clinical-trials/cardiovascular")
def ct_cv_page():
    """Clinical Trials Intelligence — Cardiovascular"""
    return render_template(
        "ct_cardiovascular.html",
        page_title="Clinical Trials — Cardiovascular",
        active_page="cardiovascular-ct"
    )


# ---- Optional: legacy routes for backward compatibility ----

@app.route("/dashboard")
def dashboard():
    """Legacy dashboard view"""
    return render_template(
        "dashboard.html",
        page_title="Dashboard",
        active_page="dashboard"
    )

if __name__ == "__main__":
    app.run(debug=True)