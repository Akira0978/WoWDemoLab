# Database Path Fix & Data Faker Integration - Summary

## Changes Made

### 1. **New Helper Module: `services/db_config.py`**
- Created centralized database configuration with hardcoded relative paths
- `get_db_path()` - Returns absolute path to `data/trials.db`
- `get_db_folder()` - Returns path to data folder and creates it if needed
- Paths are calculated relative to the app root, ensuring they work anywhere

### 2. **Updated `app.py`**
- Added import: `from data_faker_sqlite import start_background_faker`
- Added line: `start_background_faker(app)` after blueprint registration
- Now automatically starts the background data generation thread on app startup

### 3. **Updated `services/api_trials.py`**
- Added import: `from services.db_config import get_db_path`
- Modified `get_db()` function to use: `get_db_path()` instead of config/env variables
- Ensures all API endpoints use the same hardcoded database path

### 4. **Updated `services/trials_store.py`**
- Refactored to read from SQLite database instead of JSON file
- Now uses `sqlite3` to load trials from database
- Added import: `from db_config import get_db_path`
- Implements automatic cache invalidation based on database mtime
- Returns empty list gracefully if database doesn't exist yet

### 5. **Updated `services/trials_charts.py`**
- Added import: `from db_config import get_db_path`
- Refactored `_load_trials_cached()` to read from SQLite instead of JSON
- Updated `get_trials()` to use database path instead of JSON file path
- Maintains cache invalidation via file mtime

### 6. **Updated `services/chatbot.py`**
- Simplified imports - removed fallback JSON reader logic
- Now directly reads from SQLite database using `get_db_path()`
- Implements robust database reading with error handling
- Parses JSON-encoded list fields (regions, countries, key_kpis)

### 7. **Updated `data_faker_sqlite.py`**
- Added import: `from services.db_config import get_db_path`
- Modified `resolve_db_path()` to use `get_db_path()` from db_config
- Now ignores app config and environment variables to ensure consistency
- Works reliably from any working directory

## Key Benefits

1. **Consistent Path Resolution**: All modules now use the same hardcoded relative path calculation, eliminating "file not found" errors
2. **Automatic Data Generation**: Background faker starts automatically when app starts (enabled by default, can be controlled via `INGEST_ENABLED` env var)
3. **SQLite Database**: All trial data now comes from `data/trials.db` instead of JSON files
4. **Centralized Configuration**: Single source of truth for database path in `db_config.py`
5. **Works Anywhere**: Paths are calculated relative to module location, so app works regardless of where it's launched from

## How It Works

1. When `app.py` starts, it imports and calls `start_background_faker(app)`
2. The faker thread begins inserting realistic trial data into `data/trials.db`
3. All API endpoints, filters, charts, and chatbot read from the same database
4. Path resolution uses relative paths from `services/db_config.py` to ensure consistency

## Environment Variable

- `INGEST_ENABLED=true` - Enables background data faker (default: false)
- Set to `true` before starting app if automatic data generation is desired
