# data_faker_sqlite.py  — Realistic calendar + priors + phase/status model
import os, sqlite3, json, random, uuid, time, threading
from datetime import datetime, date, timedelta
from pathlib import Path
from typing import Optional, Dict, Any, List
from services.db_config import get_db_path

# ------------------- Config -------------------
WINDOW_MONTHS = 24
INSERT_RECENT = 7     # of 10 per cycle: recent bias
INSERT_BACKFILL = 3   # backfill older months to keep history smooth
CYCLE_SLEEP_SEC = 5
DELETE_OLDEST = 5

# Per-therapy phase mix (approximate, tweak for your use-case)
PHASE_MIX = {
    "diabetes":        [0.15, 0.45, 0.35, 0.05],  # P1,P2,P3,P4
    "obesity":         [0.20, 0.45, 0.30, 0.05],
    "cardiovascular":  [0.10, 0.40, 0.45, 0.05],
}

# Approximate phase durations (months)
PHASE_DURATION = {1: (8, 16), 2: (14, 28), 3: (20, 40), 4: (12, 24)}  # min,max

# Sponsor shares per therapy area (keeps NN vs comps believable)
SPONSOR_SHARES = {
    "diabetes":        {"Novo Nordisk": 0.35, "Eli Lilly": 0.30, "Pfizer": 0.15, "AstraZeneca": 0.12, "Sanofi": 0.08},
    "obesity":         {"Novo Nordisk": 0.30, "Eli Lilly": 0.35, "Pfizer": 0.15, "AstraZeneca": 0.12, "Sanofi": 0.08},
    "cardiovascular":  {"Novo Nordisk": 0.20, "Eli Lilly": 0.20, "Pfizer": 0.25, "AstraZeneca": 0.25, "Sanofi": 0.10},
}

# Region priors per sponsor (used to stabilize Geo Footprint)
REGION_WEIGHTS = {
    "Novo Nordisk": {"US": 0.35, "EU": 0.40, "Asia": 0.18, "LatAm": 0.04, "Other": 0.03},
    "Eli Lilly":    {"US": 0.40, "EU": 0.35, "Asia": 0.20, "LatAm": 0.03, "Other": 0.02},
    "Pfizer":       {"US": 0.38, "EU": 0.34, "Asia": 0.20, "LatAm": 0.04, "Other": 0.04},
    "AstraZeneca":  {"US": 0.30, "EU": 0.42, "Asia": 0.22, "LatAm": 0.03, "Other": 0.03},
    "Sanofi":       {"US": 0.28, "EU": 0.45, "Asia": 0.20, "LatAm": 0.03, "Other": 0.04},
}

# Mechanisms per therapy area (stabilize MoA distribution)
MOA_BY_TA = {
    "diabetes":       ["GLP-1 RA", "GIP/GLP-1 dual agonist", "SGLT2 inhibitor", "DPP-4 inhibitor", "Amylin analog", "Triple agonist"],
    "obesity":        ["GLP-1 RA", "GIP/GLP-1 dual agonist", "Amylin analog", "Leptin pathway modulator", "Triple agonist"],
    "cardiovascular": ["SGLT2 inhibitor", "IL-6 ligand mAb", "DOAC", "Aldosterone synthase inhibitor (ASI)", "Novel anticoagulant"],
}

# Indications per TA
IND_BY_TA = {
    "diabetes":       ["T2D", "T1D", "T2D + obesity", "T2D + CKD"],
    "obesity":        ["Obesity", "Obesity + CVD", "Obesity + T2D"],
    "cardiovascular": ["ASCVD", "HFpEF", "HFrEF", "CKD", "AMI post-MI"],
}

COUNTRIES = ["USA","UK","Germany","France","Spain","Japan","Canada","Australia"]
REGIONS = ["US","EU","Asia","LatAm","Other"]

# ------------------- DB helpers -------------------
def resolve_db_path(app: Optional[object] = None) -> Path:
    """
    Return path to trials.db using hardcoded relative path.
    Ignores app config and env variables to ensure consistency.
    """
    return Path(get_db_path())

def conn(db_path: Path):
    c = sqlite3.connect(str(db_path))
    c.row_factory = sqlite3.Row
    return c

def execmany(db_path: Path, sql: str, rows: List[Dict[str, Any]]):
    c = conn(db_path)
    try:
        c.executemany(sql, rows)
        c.commit()
    finally:
        c.close()

def query_scalar(db_path: Path, sql: str, args: tuple = ()) -> Any:
    c = conn(db_path)
    try:
        cur = c.execute(sql, args)
        r = cur.fetchone()
        return r[0] if r else None
    finally:
        c.close()

# ------------------- Calendar helpers -------------------
def month_keys(now: date, months: int) -> List[str]:
    y, m = now.year, now.month
    out = []
    for _ in range(months):
        out.append(f"{y:04d}-{m:02d}")
        m -= 1
        if m == 0:
            m = 12; y -= 1
    return list(reversed(out))

def pick_month_key(now: date, recent_bias=True) -> str:
    keys = month_keys(now, WINDOW_MONTHS)
    # recency bias with shallow seasonality
    n = len(keys)
    weights = []
    for i, k in enumerate(keys):
        # lean toward recent months; gentle sinusoid to avoid flatness
        age = n - i
        base = 0.4 if recent_bias else 0.15
        w = base + (i / n) * (0.6 if recent_bias else 0.85)
        # micro-seasonality
        w *= (0.9 + 0.2 * random.random())
        weights.append(w)
    s = sum(weights)
    probs = [w/s for w in weights]
    return random.choices(keys, probs)[0]

def pick_date_in_month(ym: str) -> str:
    y, m = map(int, ym.split("-"))
    # choose a realistic day in month (avoid invalid days)
    day = random.choice([3,7,10,14,17,21,24,27])
    # clamp to end-of-month for short months
    if m == 2 and day > 28: day = 28
    return date(y, m, day).strftime("%Y-%m-%d")

# ------------------- Sampling helpers -------------------
def choice_weighted(d: Dict[str, float]) -> str:
    keys = list(d.keys()); vals = list(d.values()); s = sum(vals)
    probs = [v/s for v in vals]
    return random.choices(keys, probs)[0]

def sample_phase(ta: str) -> int:
    w = PHASE_MIX[ta]
    return random.choices([1,2,3,4], weights=w)[0]

def phase_duration_months(phase: int) -> int:
    lo, hi = PHASE_DURATION[phase]
    return random.randint(lo, hi)

def sponsor_for(ta: str) -> str:
    return choice_weighted(SPONSOR_SHARES[ta])

def regions_for(sponsor: str) -> List[str]:
    weights = REGION_WEIGHTS[sponsor]
    # choose 1–3 regions with weights (without replacement)
    picks = []
    for r in REGIONS:
        if random.random() < weights[r] * 0.9:  # tuned so ~2 regions common
            picks.append(r)
    if not picks:
        picks = [choice_weighted(weights)]
    return picks[:3]

def countries_for() -> List[str]:
    k = random.randint(1, 4)
    return random.sample(COUNTRIES, k=k)

def mechanism_for(ta: str) -> str:
    # bias towards 1–2 top mechanisms per TA
    top = MOA_BY_TA[ta][:2]
    rest = MOA_BY_TA[ta][2:]
    if random.random() < 0.6:
        return random.choice(top)
    return random.choice(rest) if rest else random.choice(top)

def indication_for(ta: str) -> str:
    return random.choice(IND_BY_TA[ta])

def enrollment_for(phase: int) -> int:
    if phase == 1: return random.randint(30, 150)
    if phase == 2: return random.randint(150, 1200)
    if phase == 3: return random.randint(800, 6000)
    return random.randint(200, 2000)

def sites_for(enrollment: int) -> int:
    return max(10, int(enrollment / random.uniform(15, 35)))

def status_for(age_months: int) -> str:
    # coarse state machine based on age since start
    if age_months <= 4:
        return random.choices(["Not yet recruiting","Recruiting"], weights=[0.5,0.5])[0]
    if age_months <= 18:
        return random.choices(["Recruiting","Active (not recruiting)"], weights=[0.65,0.35])[0]
    if age_months <= 30:
        return random.choices(["Active (not recruiting)","Completed","Suspended"], weights=[0.5,0.45,0.05])[0]
    return random.choices(["Completed","Terminated","Active (not recruiting)"], weights=[0.7,0.1,0.2])[0]

def velocity_for(enrollment: int, duration_months: int) -> float:
    v = enrollment / max(3.0, duration_months * random.uniform(0.35, 0.65))
    return round(v, 1)

def build_trial(now: date, recent: bool) -> Dict[str, Any]:
    ta = random.choice(["diabetes","obesity","cardiovascular"])
    sponsor = sponsor_for(ta)
    phase = sample_phase(ta)

    ym = pick_month_key(now, recent_bias=recent)
    start_dt = date.fromisoformat(pick_date_in_month(ym))
    dur_m = phase_duration_months(phase)
    completion_dt = start_dt + timedelta(days=int(dur_m * 30))

    age_m = max(0, (now - start_dt).days // 30)
    status = status_for(age_m)

    enr = enrollment_for(phase)
    rv = velocity_for(enr, dur_m)

    regions = regions_for(sponsor)
    countries = countries_for()

    return {
        "trial_id": "NCT" + str(uuid.uuid4())[:8].upper(),
        "title": f"{sponsor} {phase} — {ta.title()}",
        "sponsor": sponsor,
        "drug_name": f"Asset-{str(uuid.uuid4())[:4]}",
        "mechanism": mechanism_for(ta),
        "therapy_area": ta,
        "indication": indication_for(ta),
        "phase": phase,
        "status": status,
        "fda_approved": False if phase < 4 else random.random() < 0.3,
        "start_date": start_dt.strftime("%Y-%m-%d"),
        "primary_completion_date": completion_dt.strftime("%Y-%m-%d"),
        "last_updated": now.strftime("%Y-%m-%d"),   # API expects %Y-%m-%d
        "enrollment": enr,
        "sites_count": sites_for(enr),
        "countries": json.dumps(countries),
        "regions": json.dumps(regions),
        "primary_outcome_headline": "Primary outcome per protocol",
        "key_kpis": json.dumps(random.sample(["HbA1c","Weight loss","MACE","eGFR","CRP","Mortality"], k=3)),
        "recruitment_velocity_n_per_month": rv,
        "expected_entry_year": completion_dt.year,
    }

# ------------------- CRUD -------------------
def insert_trials(db_path: Path, trials: List[Dict[str, Any]]):
    sql = """
    INSERT OR REPLACE INTO trials VALUES (
        :trial_id,:title,:sponsor,:drug_name,:mechanism,:therapy_area,
        :indication,:phase,:status,:fda_approved,:start_date,
        :primary_completion_date,:last_updated,:enrollment,:sites_count,
        :countries,:regions,:primary_outcome_headline,:key_kpis,
        :recruitment_velocity_n_per_month,:expected_entry_year
    )
    """
    execmany(db_path, sql, trials)

def delete_oldest_by_startdate(db_path: Path, n: int):
    c = conn(db_path)
    try:
        cur = c.execute("SELECT trial_id FROM trials ORDER BY start_date ASC, rowid ASC LIMIT ?", (n,))
        ids = [r["trial_id"] for r in cur.fetchall()]
        if ids:
            c.executemany("DELETE FROM trials WHERE trial_id = ?", [(i,) for i in ids])
            c.commit()
    finally:
        c.close()

# ------------------- Background loop -------------------
_thread: Optional[threading.Thread] = None
_stop_evt = threading.Event()

def _worker(app):
    db_path = resolve_db_path(app)
    cycle = 0
    while not _stop_evt.is_set():
        cycle += 1
        now = date.today()
        new_trials = []

        # 7 recent-biased
        for _ in range(INSERT_RECENT):
            new_trials.append(build_trial(now, recent=True))
        # 3 backfill across 24 months
        for _ in range(INSERT_BACKFILL):
            new_trials.append(build_trial(now, recent=False))

        try:
            insert_trials(db_path, new_trials)
            delete_oldest_by_startdate(db_path, DELETE_OLDEST)
            total = query_scalar(db_path, "SELECT COUNT(*) FROM trials") or 0
            print(f"[faker] cyc={cycle:03d} +{len(new_trials)}/-{DELETE_OLDEST} total={total} db={db_path}")
        except Exception as e:
            print("[faker] non-fatal error:", e)

        for _ in range(CYCLE_SLEEP_SEC):
            if _stop_evt.is_set(): break
            time.sleep(1)

def start_background_faker(app):
    if os.environ.get("INGEST_ENABLED","true").lower() != "true":
        return
    global _thread
    if _thread and _thread.is_alive():
        return
    _thread = threading.Thread(target=_worker, args=(app,), daemon=True, name="sqlite_faker")
    _thread.start()

# Standalone test
if __name__ == "__main__":
    dbp = resolve_db_path(None)
    print("Realistic SQLite faker — standalone. DB =", dbp)
    while True:
        try:
            now = date.today()
            trials = [build_trial(now, True) for _ in range(INSERT_RECENT)]
            trials += [build_trial(now, False) for _ in range(INSERT_BACKFILL)]
            insert_trials(dbp, trials)
            delete_oldest_by_startdate(dbp, DELETE_OLDEST)
            print("total", query_scalar(dbp, "SELECT COUNT(*) FROM trials"))
        except Exception as e:
            print("error:", e)
        time.sleep(CYCLE_SLEEP_SEC)
