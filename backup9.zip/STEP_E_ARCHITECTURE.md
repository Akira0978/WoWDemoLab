# 📊 Step E Architecture & Flow Diagram

## System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    CLINICAL TRIALS PLATFORM                     │
│                                                                   │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │                      User Interface                         │ │
│  │  ┌──────────────────┐         ┌──────────────────────────┐ │ │
│  │  │   Main Content   │         │   Right-Rail (Dock)      │ │ │
│  │  │                  │         │                          │ │ │
│  │  │ ┌──────────────┐ │         │ ┌──────────────────────┐ │ │
│  │  │ │ Chart Card 1 │ │         │ │ AI Agent Messages    │ │ │
│  │  │ │ (Click Zone) │ │◄────────►│ │ • Forecaster (Blue) │ │ │
│  │  │ └──────────────┘ │         │ │ • Competitor (Teal) │ │ │
│  │  │                  │         │ │ • Risk (Red)        │ │ │
│  │  │ ┌──────────────┐ │         │ │ • Advisor (Green)   │ │ │
│  │  │ │ Chart Card 2 │ │         │ └──────────────────────┘ │ │
│  │  │ │ Chart Card 3 │ │         │                          │ │
│  │  │ │ Chart Card 4 │ │         │ ┌──────────────────────┐ │ │
│  │  │ └──────────────┘ │         │ │ Live Feeds           │ │ │
│  │  │                  │         │ │ • Satellite (Pulse)  │ │ │
│  │  └──────────────────┘         │ │ • Radar (Pulse)      │ │ │
│  │                               │ └──────────────────────┘ │ │
│  └────────────────────────────────────────────────────────────┘ │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Event Flow Diagram

```
User Clicks Chart Card
         │
         ▼
startSatelliteDemo(node)
         │
    ┌────┴────────────────────────────────────────┐
    │                                              │
    ▼                                              │
Orchestrator Pipeline Starts                       │
    │                                              │
    ├─ T+0s: showOverlay()                        │
    │         Display agent sequence               │
    │                                              │
    ├─ T+1.5s: addFeed("Satellite", "...")        │
    │           External signal notified           │
    │                                              │
    ├─ T+3.5s: tweakChart()                       │
    │         │                                    │
    │         ├─ Modify chart data (+8% or -8%)   │
    │         │                                    │
    │         └─► addForecastOverlay()             │
    │             │                                │
    │             ├─ Get ECharts instance         │
    │             ├─ Calculate forecast (2,5,8%)  │
    │             ├─ Add dashed blue line         │
    │             └─ Schedule removal @ T+6s      │
    │                                              │
    ├─ T+3.6s: 4 AI AGENTS FIRE ◄──────────────────┘
    │         │
    │         ├─► ForecasterAI.run(typeKey)
    │         │    └─► fire("Forecast", message)
    │         │         └─► agentSay() → Dock
    │         │         └─► IntelEvents.impact()
    │         │
    │         ├─► CompeteAI.analyze(typeKey)
    │         │    └─► fire("Competitor", message)
    │         │         └─► agentSay() → Dock
    │         │
    │         ├─► RiskAI.project(typeKey)
    │         │    └─► fire("Risk", message)
    │         │         └─► agentSay() → Dock
    │         │
    │         └─► AdvisorAI.recommend(typeKey)
    │              └─► fire("Advisor", message)
    │                   └─► agentSay() → Dock
    │
    ├─ T+5s: offerReportDownload()
    │         addFeed("Radar", "...")
    │
    ├─ T+6s: Forecast line auto-removed
    │         [ECharts instance cleanup]
    │
    └─ T+8s: closeOverlay()
             [Sequence complete]
```

---

## Data Flow: AI Agent Messages

```
┌─────────────────────────────────────────────────────────────────┐
│                    agent_intelligence_bundle.js                  │
│                                                                   │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │ ForecasterAI.run(typeKey)                                 │  │
│  │  • Lookup forecast template by typeKey                    │  │
│  │  • Extract: forecast text, spark, impact metrics          │  │
│  │  • Call: fire("Forecast", message)                        │  │
│  │  • Call: IntelEvents.impact({...})                        │  │
│  └───────────────────────────────────────────────────────────┘  │
│         │                                                          │
│         ▼                                                          │
│  ┌───────────────────────────────────────────────────────────┐  │
│  │ fire(agent, msg)                                          │  │
│  │  • if window.agentSay exists:                            │  │
│  │    └─► agentSay(agent, msg)  [→ Dock]                   │  │
│  │  • if window.IntelEvents exists:                         │  │
│  │    └─► IntelEvents.pulse(agent)  [→ Activity Chip]      │  │
│  └───────────────────────────────────────────────────────────┘  │
│         │                                                          │
│         ├────────────────────┬──────────────────────┐            │
│         │                    │                      │            │
│         ▼                    ▼                      ▼            │
│    Dock UI             Right-Rail             Browser           │
│  (Intelligence      (Live Feeds)            (Console)           │
│   Panel)                Chips                                    │
│                                                                   │
│  • Message card      • Pulsing dot        • console.log()       │
│  • Color-coded       • Timestamp          • For debugging       │
│  • Styled by agent   • Auto-layout        • Error tracking      │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Component Interaction Map

```
┌────────────────────────────────────────────────────────────┐
│                   ct_diabetes_030226.js                     │
│                                                              │
│  startSatelliteDemo(node)                                   │
│  ├─ tweakChart(chartId, typeKey)                           │
│  │  ├─ Get ECharts instance                                │
│  │  ├─ Modify data                                         │
│  │  └─ Call: addForecastOverlay(chartId, typeKey)          │
│  │                                                          │
│  └─ Call all 4 AI agents (T+3.6s)                          │
│     ├─ ForecasterAI.run(typeKey)  ─┐                       │
│     ├─ CompeteAI.analyze(typeKey)  │                       │
│     ├─ RiskAI.project(typeKey)     │─► agent_intelligence_ │
│     └─ AdvisorAI.recommend(typeKey)─┘    bundle.js        │
│                                                              │
├────────────────────────────────────────────────────────────┤
│                  agent_intelligence_bundle.js              │
│                                                              │
│  All agents use:                                            │
│  └─ fire(agent, msg)  ─────────────────┐                  │
│                                          │                  │
│                                    Sends to:              │
│                            ┌─────────────┴──────────────┐ │
│                            │                            │  │
│                       agentSay()              IntelEvents.│  │
│                     (Dock UI)            pulse() (Feeds) │  │
│                                                            │
└────────────────────────────────────────────────────────────┘
         │                              │
         ▼                              ▼
  ┌─────────────────┐          ┌──────────────────┐
  │  Dock (Right    │          │  Live Feeds      │
  │   Rail)         │          │  (Activity Chips)│
  │                 │          │                  │
  │ • Forecaster    │          │ • Satellite ping │
  │ • Competitor    │          │ • Radar ping     │
  │ • Risk          │          │ • Timestamps     │
  │ • Advisor       │          │ • Auto-scroll    │
  │                 │          │                  │
  └─────────────────┘          └──────────────────┘
```

---

## Forecast Overlay Mechanism

```
Chart Click
    │
    ▼
tweakChart(chartId, typeKey)
    │
    ▼
addForecastOverlay(chartId, typeKey)
    │
    ├─► document.getElementById(chartId)
    │
    ├─► echarts.getInstanceByDom(el)
    │
    ├─► inst.getOption()  [Get current config]
    │
    ├─► Get last data point
    │   lastVal = 100
    │
    ├─► Generate 3-point forecast
    │   forecast = [102, 105, 108]  (2%, 5%, 8%)
    │
    ├─► Create new series with dashed style
    │   {
    │     name: "AI Forecast",
    │     type: "line",
    │     data: [null, null, 102, 105, 108],
    │     lineStyle: { type: "dashed", color: "#2f8cff" },
    │     symbol: "circle",
    │     symbolSize: 6
    │   }
    │
    ├─► inst.setOption() [Apply changes]
    │
    └─► setTimeout(6000ms)
        └─► Remove forecast series
            └─► inst.setOption() [Revert]
```

---

## CSS Styling Cascade

```
global.css
│
├─ .ai-competitor
│  ├─ background: linear-gradient (blue)
│  ├─ color: #e0e6ef
│  └─ strong { color: #6aa2ff }
│
├─ .ai-risk
│  ├─ background: linear-gradient (red)
│  ├─ color: #ffb1b1
│  └─ strong { color: #ff6666 }
│
├─ .ai-advisor
│  ├─ background: linear-gradient (green)
│  ├─ color: #baffd6
│  └─ strong { color: #66ff99 }
│
├─ .ai-forecast-badge
│  ├─ background: rgba(47, 140, 255, 0.12)
│  ├─ border: 1px solid rgba(47, 140, 255, 0.35)
│  └─ color: #2f8cff
│
├─ .echarts-forecast-line
│  ├─ stroke-dasharray: 5, 3
│  ├─ stroke-width: 2px
│  └─ opacity: 0.85
│
├─ .rf-activity
│  ├─ .dot { animation: pulse 2s infinite }
│  ├─ .txt { flex: 1; color: var(--nnci-text) }
│  └─ .time { font-size: 11px; color: var(--nnci-muted) }
│
└─ @keyframes pulse
   └─ 0% → 50% → 100% (scale & opacity)
```

---

## Load Order Sequence

```
1. ct_diabetes.js
   ├─ Loads page logic
   ├─ Registers startSatelliteDemo()
   └─ Exposes addForecastOverlay()

2. lazy_charts.js
   └─ Auto-loads charts on visibility

3. agent_orchestrator.js
   └─ Handles chart click orchestration

4. agent_intelligence_bundle.js ◄── NEW
   ├─ Defines ForecasterAI
   ├─ Defines CompeteAI
   ├─ Defines RiskAI
   └─ Defines AdvisorAI

5. intelligence_dock.js
   └─ Sets up dock UI framework

6. ct_diabetes.dock.patch.js
   └─ Wires dock to page elements

7. intelligence_dock.autowire.js
   └─ Auto-wires remaining connections
```

---

## Data Structures

### Forecast Pack (per typeKey)
```javascript
{
  active_by_phase: {
    forecast: "Phase 2 share expected to soften by ~4%.",
    spark: "-3.8%",
    impact: {
      slowdown: "3–5%",
      risk: "+1.4",
      kpis: 2
    }
  },
  start_momentum: { ... },
  moa_distribution: { ... },
  geo_footprint: { ... }
}
```

### Activity Chip Structure
```javascript
{
  kind: "satellite" | "radar",
  text: "Message text",
  timestamp: "HH:MM:SS",
  dotColor: "#color",
  animation: "pulse 2s"
}
```

### Chart Option (ECharts)
```javascript
{
  series: [
    { /* original series */ },
    {
      name: "AI Forecast",
      type: "line",
      data: [null, null, 102, 105, 108],
      lineStyle: { type: "dashed", color: "#2f8cff" }
    }
  ]
}
```

---

## Browser Storage & Session

```
Session Storage (while page is open)
├─ Chart click state (demoRunning flag)
├─ Overlay visibility state
├─ Activity chips (transient)
└─ Message history (temp)

Local Storage (optional, not used)
└─ [Future: user preferences]

Memory
├─ ECharts instances (multiple)
├─ DOM references
├─ Event listeners
└─ Timeout references
```

---

## Performance Profile

```
Operation              Time    Memory    Impact
─────────────────────  ──────  ────────  ──────────
Chart click            < 1ms   ~1MB      Minimal
tweakChart()           < 5ms   ~2MB      Low
addForecastOverlay()   < 10ms  ~3MB      Low
AI agent calls         < 2ms   ~1MB      Minimal
agentSay() dispatch    < 5ms   ~1MB      Low
DOM updates            < 50ms  ~5MB      Medium
Total sequence         ~200ms  ~15MB     Acceptable

Forecast removal @ 6s  < 10ms  -3MB      Cleanup
```

---

**Architecture Complete & Ready for Implementation** ✅
