# services/chatbot.py
"""
Global Chatbot 'brain' for the CI demo.
- Intent detection (rule-based) mapped to on-page charts.
- Page-aware suggestions built from 'visible_charts' sent by the client.
- Site-bounded Q&A (KPIs) via the same dataset as /api endpoints.

Endpoints (mounted under /api/chat):
  POST /api/chat/query       -> main: parse user message, return reply + actions + suggestions
  GET  /api/chat/suggestions -> just suggestions based on visible charts (for initial buttons)
  GET  /api/chat/registry    -> chart registry (key -> label) used to name buttons
"""

from __future__ import annotations
from flask import Blueprint, request, jsonify, current_app
from typing import Dict, List, Any
from datetime import datetime
import re
import json
import sqlite3
from services.db_config import get_db_path

# --- Import the same dataset access your APIs use ---
def get_trials() -> List[Dict[str, Any]]:
    """Load trials from SQLite database"""
    try:
        db_path = get_db_path()
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        cur = conn.cursor()
        cur.execute("SELECT * FROM trials")
        rows = cur.fetchall()
        conn.close()
        
        trials = []
        for r in rows:
            trial_dict = dict(r)
            # Parse JSON-encoded list fields
            trial_dict["regions"] = json.loads(r["regions"]) if r["regions"] else []
            trial_dict["countries"] = json.loads(r["countries"]) if r["countries"] else []
            trial_dict["key_kpis"] = json.loads(r["key_kpis"]) if r["key_kpis"] else []
            trials.append(trial_dict)
        return trials
    except Exception:
        # Database doesn't exist yet or is empty
        return []

chatbot_bp = Blueprint("chatbot_bp", __name__)

# ---------------- Chart registry & intent rules (page-scoped keys) ----------------

# Known chart keys (must match your page 'data-chart-type' and the AgentFlow CARD_MAP).
# Keys pulled from your current pages: active_by_phase, start_momentum, moa_distribution, geo_footprint.
CHART_REGISTRY: Dict[str, Dict[str, str]] = {
    "active_by_phase":   {"label": "Active Trials by Phase"},
    "start_momentum":    {"label": "Trial Start Momentum"},
    "moa_distribution":  {"label": "MoA Distribution"},
    "geo_footprint":     {"label": "Geographic Footprint"},
}

# Simple keyword->intent mapping (lowercase matching)
INTENT_KEYWORDS: Dict[str, List[str]] = {
    "active_by_phase":  ["active", "phase", "by phase", "phases", "development stage"],
    "start_momentum":   ["momentum", "starts", "start", "monthly starts", "trend"],
    "moa_distribution": ["moa", "mechanism", "mechanisms"],
    "geo_footprint":    ["geo", "geographic", "region", "footprint", "regions"],
}

# ---------------- Helpers ----------------

def _lc(x: str) -> str:
    return (x or "").strip().lower()

def detect_chart_intent(message: str, visible_charts: List[str]) -> str | None:
    """
    Return the best chart key (from visible_charts if provided) inferred from message.
    Fallback to any known chart if no visible list provided.
    """
    t = _lc(message)
    keys_to_consider = visible_charts or list(CHART_REGISTRY.keys())
    # score by count of keyword hits
    best_key, best_score = None, 0
    for key in keys_to_consider:
        kws = INTENT_KEYWORDS.get(key, [])
        score = sum(1 for k in kws if k in t)
        if score > best_score:
            best_key, best_score = key, score
    return best_key

def build_suggestions(visible_charts: List[str]) -> List[Dict[str, Any]]:
    """
    Suggest buttons based on what's on the page.
    Always include 'Show all charts' and per-chart 'Show ...' for the visible set.
    """
    vis = visible_charts or list(CHART_REGISTRY.keys())
    suggestions: List[Dict[str, Any]] = [
        # 'Show all charts' = switch to multi mode
        {"label": "Show all charts", "action": {"type": "agentflow.setMode", "mode": "multi"}}
    ]
    for key in vis:
        if key in CHART_REGISTRY:
            suggestions.append({
                "label": f"Show {CHART_REGISTRY[key]['label']}",
                "action": {"type": "agentflow.show", "chart": key}
            })
    # Optional: add focused helpers
    suggestions.extend([
        {"label": "Focus on one chart", "action": {"type": "agentflow.setMode", "mode": "single"}},
    ])
    return suggestions

def _is_active(status: str) -> bool:
    return status in {"Recruiting", "Active (not recruiting)", "Not yet recruiting"}

def _compute_kpis(trials: List[Dict[str, Any]], therapy_area: str | None) -> Dict[str, Any]:
    """
    Lightweight KPI calc (aligns with your /api/kpis definition):
    - total_trials, active_trials, recruiting_trials, new_starts_12m (approx),
      top_mechanism_active (by count), biggest_competitor_threat (active trials, ex-NN),
      median_recruitment_velocity_n_per_month (rough median)
    This is intentionally simple; it keeps the chatbot self-sufficient.
    """
    from collections import Counter
    from statistics import median

    if therapy_area:
        trials = [t for t in trials if _lc(t.get("therapy_area")) == _lc(therapy_area)]

    total_trials = len(trials)
    active = [t for t in trials if _is_active(t.get("status", ""))]
    recruiting = [t for t in trials if _lc(t.get("status")) == "recruiting"]

    # New starts in last 12 months (approx using start_date)
    def _within_12m(dt_str: str) -> bool:
        try:
            dt = datetime.strptime(dt_str, "%Y-%m-%d")
            return (datetime.utcnow() - dt).days <= 365
        except Exception:
            return False
    new_starts_12m = sum(1 for t in trials if _within_12m(t.get("start_date", "")))

    # Top mechanism among active
    mech = Counter([t.get("mechanism") for t in active if t.get("mechanism")])
    top_mechanism_active = mech.most_common(1)[0][0] if mech else None

    # Biggest competitor threat (active trials, excluding Novo Nordisk)
    comp = Counter([t.get("sponsor") for t in active if t.get("sponsor") and t.get("sponsor") != "Novo Nordisk"])
    biggest_competitor_threat = comp.most_common(1)[0][0] if comp else None

    # Median recruitment velocity
    vel = [t.get("recruitment_velocity_n_per_month") for t in active if isinstance(t.get("recruitment_velocity_n_per_month"), (int, float))]
    mv = median(vel) if vel else None

    return {
        "total_trials": total_trials,
        "active_trials": len(active),
        "recruiting_trials": len(recruiting),
        "new_starts_12m": new_starts_12m,
        "top_mechanism_active": top_mechanism_active,
        "biggest_competitor_threat": biggest_competitor_threat,
        "median_recruitment_velocity_n_per_month": mv,
    }

def answer_smalltalk_or_kpi(message: str, therapy_area: str | None) -> str | None:
    """
    A tiny, deterministic responder for simple questions like:
    - "how many active trials" / "active trials count"
    - "total trials" / "recruiting"
    Returns a sentence or None if not applicable.
    """
    m = _lc(message)
    trials = get_trials()
    kpi = _compute_kpis(trials, therapy_area)

    if "active" in m and "trial" in m and "how" in m or "count" in m:
        return f"{kpi['active_trials']} active trials{f' in {therapy_area.capitalize()}' if therapy_area else ''}."
    if ("total" in m and "trial" in m) or re.search(r"\bhow many trials\b", m):
        return f"{kpi['total_trials']} total trials{f' in {therapy_area.capitalize()}' if therapy_area else ''}."
    if "recruiting" in m:
        return f"{kpi['recruiting_trials']} recruiting{f' in {therapy_area.capitalize()}' if therapy_area else ''}."
    if "top mechanism" in m or "top moa" in m or "mechanism" in m and "top" in m:
        tmoa = kpi.get("top_mechanism_active") or "not determined"
        return f"Top mechanism among active trials is {tmoa}."
    return None

# ---------------- Endpoints ----------------

@chatbot_bp.get("/registry")
def api_registry():
    """Return chart registry for clients to name buttons nicely."""
    return jsonify({"charts": {k: v["label"] for k, v in CHART_REGISTRY.items()}})

@chatbot_bp.get("/suggestions")
def api_suggestions():
    """
    Build suggestions from visible charts.
    Query params:
      visible: comma-separated chart keys (optional)
    """
    visible = request.args.get("visible", "").strip()
    vis_list = [v for v in visible.split(",") if v] if visible else []
    suggestions = build_suggestions(vis_list)
    return jsonify({"suggestions": suggestions})

@chatbot_bp.post("/query")
def api_query():
    """
    Main entry. Body JSON:
    {
      "message": "show momentum",
      "therapy_area": "diabetes",
      "visible_charts": ["active_by_phase","start_momentum","moa_distribution","geo_footprint"]
    }
    Response:
    {
      "reply": "…",
      "actions": [ {type:"agentflow.show", chart:"start_momentum"}, {type:"agentflow.setMode", mode:"single"} ],
      "suggestions": [ ...quick buttons... ]
    }
    """
    data = request.get_json(silent=True) or {}
    message = data.get("message", "")
    therapy_area = data.get("therapy_area")
    visible_charts = data.get("visible_charts") or []

    # 1) Rule-based smalltalk/KPI
    reply = answer_smalltalk_or_kpi(message, therapy_area)

    # 2) Try chart intent
    chart_key = detect_chart_intent(message, visible_charts)
    actions: List[Dict[str, Any]] = []

    if chart_key:
        # default: show in 'single' focus for dramatic effect
        actions.append({"type": "agentflow.setMode", "mode": "single"})
        actions.append({"type": "agentflow.show", "chart": chart_key})

        # If we didn't produce a reply sentence yet, synthesize a short one
        if not reply:
            label = CHART_REGISTRY.get(chart_key, {}).get("label", chart_key.replace("_", " ").title())
            reply = f"Focusing on **{label}**."

    # 3) Suggestions based on visible charts (for buttons under the chat)
    suggestions = build_suggestions(visible_charts)

    # Final response
    return jsonify({
        "reply": reply or "What would you like me to focus on?",
        "actions": actions,
        "suggestions": suggestions
    })