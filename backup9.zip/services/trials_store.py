#Loads trials from SQLite database (data/trials.db), caches it, and provides a single access point.

# services/trials_store.py
from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from typing import Any, Dict, List, Optional
from services.db_config import get_db_path


@dataclass
class TrialsStoreConfig:
    """
    Configuration for trials database.
    """
    db_path: str = None
    
    def __post_init__(self):
        if self.db_path is None:
            self.db_path = get_db_path()


class TrialsStore:
    """
    Loads and caches the trials dataset from SQLite database.
    Cache invalidates automatically based on database update time.
    """

    def __init__(self, config: Optional[TrialsStoreConfig] = None):
        if config is None:
            config = TrialsStoreConfig()
        self.config = config
        self._cache: Optional[List[Dict[str, Any]]] = None
        self._cache_mtime: Optional[float] = None

    @property
    def db_path(self) -> str:
        return self.config.db_path

    def _read_from_db(self) -> List[Dict[str, Any]]:
        """Read all trials from SQLite database"""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            cur = conn.cursor()
            cur.execute("SELECT * FROM trials")
            rows = cur.fetchall()
            
            trials = []
            for r in rows:
                trial_dict = dict(r)
                # Parse JSON-encoded list fields
                trial_dict["regions"] = json.loads(r["regions"]) if r["regions"] else []
                trial_dict["countries"] = json.loads(r["countries"]) if r["countries"] else []
                trial_dict["key_kpis"] = json.loads(r["key_kpis"]) if r["key_kpis"] else []
                trials.append(trial_dict)
            return trials
        except sqlite3.OperationalError:
            # Database doesn't exist yet or is empty
            return []
        finally:
            conn.close()

    def get_trials(self, force_reload: bool = False) -> List[Dict[str, Any]]:
        """Get trials from cache, reloading if needed"""
        import os
        
        path = self.db_path
        if not os.path.exists(path):
            return []

        mtime = os.path.getmtime(path)
        if force_reload or self._cache is None or self._cache_mtime != mtime:
            self._cache = self._read_from_db()
            self._cache_mtime = mtime
        return self._cache

    def invalidate(self) -> None:
        """Force cache invalidation"""
        self._cache = None
        self._cache_mtime = None
