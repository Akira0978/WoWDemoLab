# routes/api_trials.py
"""
Clinical Trial Intelligence API (Flask Blueprint)

Responsibilities:
- Load & cache trials_master.json (demo dataset)
- Apply filters (therapy_area, sponsor, phase, status, geography, time window)
- Provide KPI belt + chart-ready aggregations for ECharts
- Provide lightweight actionable intelligence ("insights" + next steps)

Design principle: Python handles logic/aggregation; JS stays thin (fetch JSON + render charts).
"""

from __future__ import annotations

import os
import json
import sqlite3
from dataclasses import dataclass
from datetime import datetime, date, timedelta
from functools import lru_cache
from typing import Any, Dict, List, Optional

from flask import Blueprint, current_app, jsonify, request
from services.db_config import get_db_path

api_trials_bp = Blueprint("api_trials", __name__, url_prefix="/api")


# ----------------------------
# Constants
# ----------------------------

DEFAULT_DATA_PATH = os.path.join("static", "json", "trials_master.json")
DATE_FMT = "%Y-%m-%d"

ACTIVE_STATUSES = {
    "Recruiting",
    "Active (not recruiting)",
    "Not yet recruiting",
}

DEFAULT_TOP_SPONSORS = ["Novo Nordisk", "Eli Lilly", "Pfizer", "AstraZeneca", "Sanofi"]


# ----------------------------
# Helper Functions
# ----------------------------

def _get_list_param(name: str) -> List[str]:
    """Get list parameter from query string (supports repeated params and CSV)"""
    raw = request.args.getlist(name)
    out: List[str] = []
    for item in raw:
        if not item:
            continue
        parts = [p.strip() for p in item.split(",") if p.strip()]
        out.extend(parts)
    # De-duplicate preserving order
    seen = set()
    deduped = []
    for x in out:
        if x not in seen:
            deduped.append(x)
            seen.add(x)
    return deduped


def _get_int_list_param(name: str) -> List[int]:
    values = _get_list_param(name)
    out = []
    for v in values:
        try:
            out.append(int(v))
        except ValueError:
            continue
    return out


def _get_int_param(name: str, default: Optional[int] = None) -> Optional[int]:
    v = request.args.get(name, None)
    if v is None or v == "":
        return default
    try:
        return int(v)
    except ValueError:
        return default


def _get_str_param(name: str, default: Optional[str] = None) -> Optional[str]:
    v = request.args.get(name, None)
    if v is None or v == "":
        return default
    return v


def _parse_date(s: Optional[str]) -> Optional[date]:
    if not s:
        return None
    try:
        return datetime.strptime(s, DATE_FMT).date()
    except ValueError:
        return None


def _safe_float(x: Any) -> Optional[float]:
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


@dataclass
class Filters:
    therapy_area: Optional[str] = None
    sponsors: List[str] = None
    drugs: List[str] = None
    phases: List[int] = None
    statuses: List[str] = None
    regions: List[str] = None
    countries: List[str] = None
    start_from: Optional[date] = None
    start_to: Optional[date] = None
    completion_from: Optional[date] = None
    completion_to: Optional[date] = None

    def __post_init__(self):
        self.sponsors = self.sponsors or []
        self.drugs = self.drugs or []
        self.phases = self.phases or []
        self.statuses = self.statuses or []
        self.regions = self.regions or []
        self.countries = self.countries or []


def _read_filters_from_query() -> Filters:
    return Filters(
        therapy_area=_get_str_param("therapy_area"),
        sponsors=_get_list_param("sponsor"),
        drugs=_get_list_param("drug"),
        phases=_get_int_list_param("phase"),
        statuses=_get_list_param("status"),
        regions=_get_list_param("region"),
        countries=_get_list_param("country"),
        start_from=_parse_date(_get_str_param("start_from")),
        start_to=_parse_date(_get_str_param("start_to")),
        completion_from=_parse_date(_get_str_param("completion_from")),
        completion_to=_parse_date(_get_str_param("completion_to")),
    )


# ----------------------------
# Data Loading (SQLite-backed)
# ----------------------------

def get_db():
    """Get SQLite connection with Row factory enabled"""
    db_path = get_db_path()
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def get_trials() -> List[Dict[str, Any]]:
    """Load all trials from SQLite database"""
    try:
        conn = get_db()
        cur = conn.cursor()
        cur.execute("SELECT * FROM trials")
        rows = cur.fetchall()
        conn.close()
        
        trials = []
        for r in rows:
            trial_dict = dict(r)
            # Parse JSON-encoded list fields
            trial_dict["regions"] = json.loads(r["regions"]) if r["regions"] else []
            trial_dict["countries"] = json.loads(r["countries"]) if r["countries"] else []
            trial_dict["key_kpis"] = json.loads(r["key_kpis"]) if r["key_kpis"] else []
            trials.append(trial_dict)
        return trials
    except sqlite3.OperationalError:
        # Database doesn't exist yet or is empty
        return []


# ----------------------------
# Filtering
# ----------------------------

def _trial_date(trial: Dict[str, Any], field: str) -> Optional[date]:
    v = trial.get(field)
    if not v:
        return None
    try:
        return datetime.strptime(v, DATE_FMT).date()
    except ValueError:
        return None


def apply_filters(trials: List[Dict[str, Any]], f: Filters) -> List[Dict[str, Any]]:
    out = []
    for t in trials:
        # therapy area
        if f.therapy_area and t.get("therapy_area") != f.therapy_area:
            continue

        # sponsor
        if f.sponsors and t.get("sponsor") not in f.sponsors:
            continue

        # drug
        if f.drugs and t.get("drug_name") not in f.drugs:
            continue

        # phase
        if f.phases:
            try:
                if int(t.get("phase")) not in f.phases:
                    continue
            except Exception:
                continue

        # status
        if f.statuses and t.get("status") not in f.statuses:
            continue

        # region
        if f.regions:
            regions = t.get("regions") or []
            if not any(r in regions for r in f.regions):
                continue

        # country
        if f.countries:
            countries = t.get("countries") or []
            if not any(c in countries for c in f.countries):
                continue

        # date windows
        start_d = _trial_date(t, "start_date")
        if f.start_from and (start_d is None or start_d < f.start_from):
            continue
        if f.start_to and (start_d is None or start_d > f.start_to):
            continue

        comp_d = _trial_date(t, "primary_completion_date")
        if f.completion_from and (comp_d is None or comp_d < f.completion_from):
            continue
        if f.completion_to and (comp_d is None or comp_d > f.completion_to):
            continue

        out.append(t)
    return out


# ----------------------------
# Reference "now" date
# ----------------------------

def _reference_now(trials: List[Dict[str, Any]]) -> date:
    """Use max(last_updated) as dataset anchor, fallback to today"""
    best: Optional[date] = None
    for t in trials:
        d = _trial_date(t, "last_updated")
        if d and (best is None or d > best):
            best = d
    return best or date.today()


# ----------------------------
# KPI Computations
# ----------------------------

def compute_kpis(trials: List[Dict[str, Any]]) -> Dict[str, Any]:
    now = _reference_now(trials)

    active = [t for t in trials if t.get("status") in ACTIVE_STATUSES]
    recruiting = [t for t in trials if t.get("status") in {"Recruiting", "Not yet recruiting"}]

    # New starts in last 12 months
    starts_12m = 0
    for t in trials:
        sd = _trial_date(t, "start_date")
        if sd and (now - sd).days <= 365:
            starts_12m += 1

    # Top mechanism among active trials
    moa_counts: Dict[str, int] = {}
    for t in active:
        moa = t.get("mechanism") or "Unknown"
        moa_counts[moa] = moa_counts.get(moa, 0) + 1
    top_moa = max(moa_counts.items(), key=lambda kv: kv[1])[0] if moa_counts else None

    # Biggest competitor threat (active trials excluding Novo)
    sponsor_counts: Dict[str, int] = {}
    for t in active:
        s = t.get("sponsor") or "Unknown"
        if s == "Novo Nordisk":
            continue
        sponsor_counts[s] = sponsor_counts.get(s, 0) + 1
    biggest_threat = max(sponsor_counts.items(), key=lambda kv: kv[1])[0] if sponsor_counts else None

    # Recruitment velocity stats
    velocities = []
    for t in recruiting:
        v = _safe_float(t.get("recruitment_velocity_n_per_month"))
        if v is not None:
            velocities.append(v)
    velocities.sort()
    median_velocity = None
    if velocities:
        mid = len(velocities) // 2
        median_velocity = velocities[mid] if len(velocities) % 2 == 1 else (velocities[mid - 1] + velocities[mid]) / 2.0
        median_velocity = round(median_velocity, 1)

    # Next readouts
    upcoming = []
    for t in trials:
        cd = _trial_date(t, "primary_completion_date")
        if cd and cd >= now:
            upcoming.append((cd, t))
    upcoming.sort(key=lambda x: x[0])

    next_readouts = []
    for cd, t in upcoming[:5]:
        next_readouts.append({
            "trial_id": t.get("trial_id"),
            "title": t.get("title"),
            "sponsor": t.get("sponsor"),
            "drug_name": t.get("drug_name"),
            "phase": t.get("phase"),
            "primary_completion_date": cd.strftime(DATE_FMT),
        })

    return {
        "as_of": now.strftime(DATE_FMT),
        "total_trials": len(trials),
        "active_trials": len(active),
        "recruiting_trials": len(recruiting),
        "new_starts_12m": starts_12m,
        "top_mechanism_active": top_moa,
        "biggest_competitor_threat": biggest_threat,
        "median_recruitment_velocity_n_per_month": median_velocity,
        "next_readouts": next_readouts,
    }


# ----------------------------
# Chart Aggregations
# ----------------------------

def chart_active_by_phase(trials: List[Dict[str, Any]], sponsors: Optional[List[str]] = None) -> Dict[str, Any]:
    sponsors = sponsors or DEFAULT_TOP_SPONSORS
    phases = [1, 2, 3, 4]
    phase_labels = [f"Phase {p}" for p in phases]

    active = [t for t in trials if t.get("status") in ACTIVE_STATUSES]
    counts: Dict[str, Dict[int, int]] = {s: {p: 0 for p in phases} for s in sponsors}

    for t in active:
        s = t.get("sponsor")
        if s not in counts:
            continue
        try:
            p = int(t.get("phase"))
        except Exception:
            continue
        if p not in phases:
            continue
        counts[s][p] += 1

    series = []
    for s in sponsors:
        series.append({
            "name": s,
            "type": "bar",
            "stack": "active_trials",
            "data": [counts[s][p] for p in phases],
        })

    return {"categories": phase_labels, "series": series}


def chart_start_momentum(trials: List[Dict[str, Any]], months: int = 24) -> Dict[str, Any]:
    """Monthly start counts for last N months"""
    now = _reference_now(trials)

    def ym(d: date) -> str:
        return f"{d.year:04d}-{d.month:02d}"

    # Generate list of last N months keys
    categories = []
    y, m = now.year, now.month
    for _ in range(months):
        categories.append(f"{y:04d}-{m:02d}")
        m -= 1
        if m == 0:
            m = 12
            y -= 1
    categories.reverse()

    # Initialize counts
    total = {k: 0 for k in categories}
    novo = {k: 0 for k in categories}
    competitors = {k: 0 for k in categories}

    for t in trials:
        sd = _trial_date(t, "start_date")
        if not sd:
            continue
        key = ym(sd)
        if key not in total:
            continue
        total[key] += 1
        if t.get("sponsor") == "Novo Nordisk":
            novo[key] += 1
        else:
            competitors[key] += 1

    return {
        "categories": categories,
        "series": [
            {"name": "Total", "type": "line", "data": [total[k] for k in categories]},
            {"name": "Novo Nordisk", "type": "line", "data": [novo[k] for k in categories]},
            {"name": "Competitors", "type": "line", "data": [competitors[k] for k in categories]},
        ],
    }


def chart_moa_distribution(trials: List[Dict[str, Any]], top_n: int = 8) -> Dict[str, Any]:
    """Top MoAs by active trials"""
    active = [t for t in trials if t.get("status") in ACTIVE_STATUSES]
    counts: Dict[str, int] = {}
    for t in active:
        moa = t.get("mechanism") or "Unknown"
        counts[moa] = counts.get(moa, 0) + 1

    items = sorted(counts.items(), key=lambda kv: kv[1], reverse=True)[:top_n]
    categories = [k for k, _ in items]
    values = [v for _, v in items]
    return {
        "categories": categories,
        "series": [{"name": "Active trials", "type": "bar", "data": values}],
    }


def chart_geo_footprint(trials: List[Dict[str, Any]], sponsors: Optional[List[str]] = None) -> Dict[str, Any]:
    """Sponsor vs Region counts (active trials)"""
    sponsors = sponsors or DEFAULT_TOP_SPONSORS
    regions = ["US", "EU", "Asia", "LatAm", "Other"]

    active = [t for t in trials if t.get("status") in ACTIVE_STATUSES]
    counts: Dict[str, Dict[str, int]] = {s: {r: 0 for r in regions} for s in sponsors}

    for t in active:
        s = t.get("sponsor")
        if s not in counts:
            continue
        rs = t.get("regions") or []
        for r in rs:
            if r in regions:
                counts[s][r] += 1

    series = []
    for s in sponsors:
        series.append({
            "name": s,
            "type": "bar",
            "stack": "geo",
            "data": [counts[s][r] for r in regions],
        })

    return {"categories": regions, "series": series}


# ----------------------------
# Insights
# ----------------------------

def generate_insights(trials: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Create human-readable insights derived from signals"""
    kpis = compute_kpis(trials)
    active = [t for t in trials if t.get("status") in ACTIVE_STATUSES]
    now = _reference_now(trials)

    # Sponsor active counts
    sponsor_active: Dict[str, int] = {}
    for t in active:
        s = t.get("sponsor") or "Unknown"
        sponsor_active[s] = sponsor_active.get(s, 0) + 1
    top_sponsors = sorted(sponsor_active.items(), key=lambda kv: kv[1], reverse=True)[:3]

    # Phase 3 competitor pressure
    phase3_comp: Dict[str, int] = {}
    for t in active:
        try:
            p = int(t.get("phase"))
        except Exception:
            continue
        if p != 3:
            continue
        s = t.get("sponsor") or "Unknown"
        if s == "Novo Nordisk":
            continue
        phase3_comp[s] = phase3_comp.get(s, 0) + 1
    phase3_leader = max(phase3_comp.items(), key=lambda kv: kv[1])[0] if phase3_comp else None

    # Upcoming readouts within 12 months
    readouts_12m = []
    for t in trials:
        cd = _trial_date(t, "primary_completion_date")
        if not cd:
            continue
        if 0 <= (cd - now).days <= 365:
            readouts_12m.append((cd, t))
    readouts_12m.sort(key=lambda x: x[0])

    insights = []

    if top_sponsors:
        title = f"Trial activity concentration: {top_sponsors[0][0]} leads active trials"
        insights.append({
            "title": title,
            "why_it_matters": "High active-trial concentration signals where competitive attention is being deployed most heavily.",
            "next_steps": [
                "Drill into Phase distribution for the leading sponsor to estimate near-term readout risk.",
                "Compare mechanism mix vs Novo to spot strategic crowding (MoA collision).",
            ],
            "evidence": {
                "top_sponsors_active_trials": [{"sponsor": s, "active_trials": c} for s, c in top_sponsors]
            }
        })

    if phase3_leader:
        insights.append({
            "title": f"Late-stage pressure: {phase3_leader} has the most active Phase 3 programs (excluding Novo)",
            "why_it_matters": "Phase 3 activity is a proxy for near-term competitive readouts and potential label-moving events.",
            "next_steps": [
                "Inspect upcoming primary completion dates for those Phase 3 trials to build a readout calendar.",
                "Validate overlap with Novo's indications and geographies (collision scan).",
            ],
            "evidence": {"phase3_competitor_counts": phase3_comp}
        })

    if kpis.get("top_mechanism_active"):
        insights.append({
            "title": f"Mechanism signal: '{kpis['top_mechanism_active']}' is the most active MoA in the current slice",
            "why_it_matters": "MoA dominance can indicate a crowded space or an emerging standard-of-care direction.",
            "next_steps": [
                "Compare sponsor-by-MoA distribution to identify who is betting most heavily on the dominant MoA.",
                "Use this to prioritize monitoring of readouts and recruitment acceleration signals.",
            ],
            "evidence": {"top_mechanism_active": kpis["top_mechanism_active"]}
        })

    if readouts_12m:
        next_items = []
        for cd, t in readouts_12m[:5]:
            next_items.append({
                "date": cd.strftime(DATE_FMT),
                "trial_id": t.get("trial_id"),
                "sponsor": t.get("sponsor"),
                "title": t.get("title"),
                "phase": t.get("phase"),
            })
        insights.append({
            "title": f"Near-term readouts: {len(readouts_12m)} primary completion(s) expected within 12 months",
            "why_it_matters": "Upcoming completions often precede results disclosures, competitive claims, or strategy shifts.",
            "next_steps": [
                "Create a watchlist for the next 3–5 completions and track last_updated changes weekly.",
                "Assess indication overlap vs Novo portfolio to prioritize medical and commercial readiness.",
            ],
            "evidence": {"upcoming_primary_completions_12m": next_items}
        })

    return {"as_of": now.strftime(DATE_FMT), "insights": insights}


# ----------------------------
# Flask API Endpoints
# ----------------------------

@api_trials_bp.route("/kpis", methods=["GET"])
def api_kpis():
    """KPI belt numbers (filtered)"""
    trials = get_trials()
    filters = _read_filters_from_query()
    filtered = apply_filters(trials, filters)
    return jsonify(compute_kpis(filtered))


@api_trials_bp.route("/charts/active-by-phase", methods=["GET"])
def api_chart_active_by_phase():
    trials = get_trials()
    filters = _read_filters_from_query()
    filtered = apply_filters(trials, filters)
    return jsonify(chart_active_by_phase(filtered))


@api_trials_bp.route("/charts/start-momentum", methods=["GET"])
def api_chart_start_momentum():
    months = _get_int_param("months", 24)
    trials = get_trials()
    filters = _read_filters_from_query()
    filtered = apply_filters(trials, filters)
    return jsonify(chart_start_momentum(filtered, months=months))


@api_trials_bp.route("/charts/moa-distribution", methods=["GET"])
def api_chart_moa_distribution():
    top_n = _get_int_param("top_n", 8)
    trials = get_trials()
    filters = _read_filters_from_query()
    filtered = apply_filters(trials, filters)
    return jsonify(chart_moa_distribution(filtered, top_n=top_n))


@api_trials_bp.route("/charts/geo-footprint", methods=["GET"])
def api_chart_geo_footprint():
    trials = get_trials()
    filters = _read_filters_from_query()
    filtered = apply_filters(trials, filters)
    return jsonify(chart_geo_footprint(filtered))


@api_trials_bp.route("/insights", methods=["GET"])
def api_insights():
    trials = get_trials()
    filters = _read_filters_from_query()
    filtered = apply_filters(trials, filters)
    return jsonify(generate_insights(filtered))


@api_trials_bp.route("/trials", methods=["GET"])
def api_trials_table():
    """
    Returns a paginated table of trials (filtered).
    Query params: limit, offset, sort_by, desc
    """
    limit = _get_int_param("limit", 50)
    offset = _get_int_param("offset", 0)
    sort_by = _get_str_param("sort_by", "last_updated")
    desc = request.args.get("desc", "true").lower() == "true"
    trials = get_trials()
    filters = _read_filters_from_query()
    filtered = apply_filters(trials, filters)
    
    def key_fn(t):
        if sort_by in ("start_date", "primary_completion_date", "last_updated"):
            d = _trial_date(t, sort_by)
            return d or datetime.min.date()
        return t.get(sort_by)
    
    sorted_trials = sorted(filtered, key=key_fn, reverse=desc)
    rows = sorted_trials[offset:offset+limit]
    columns = [
        "trial_id", "title", "sponsor", "drug_name", "therapy_area", "indication",
        "phase", "status", "start_date", "primary_completion_date", "last_updated",
        "mechanism", "enrollment", "sites_count", "regions"
    ]
    table = {
        "columns": columns,
        "rows": [{c: t.get(c) for c in columns} for t in rows],
        "total": len(filtered)
    }
    return jsonify(table)


@api_trials_bp.route("/filters", methods=["GET"])
def api_filter_options():
    """Return available filter options for UI dropdowns"""
    trials = get_trials()
    
    sponsors = sorted(set(t.get("sponsor") for t in trials if t.get("sponsor")))
    drugs = sorted(set(t.get("drug_name") for t in trials if t.get("drug_name")))
    mechanisms = sorted(set(t.get("mechanism") for t in trials if t.get("mechanism")))
    phases = sorted(set(int(t.get("phase", 0)) for t in trials if t.get("phase")))
    statuses = sorted(set(t.get("status") for t in trials if t.get("status")))
    regions = sorted(set(
        r for t in trials
        for r in (t.get("regions") or [])
    ))
    therapy_areas = sorted(set(t.get("therapy_area") for t in trials if t.get("therapy_area")))
    
    return jsonify({
        "sponsors": sponsors,
        "drugs": drugs,
        "mechanisms": mechanisms,
        "phases": phases,
        "statuses": statuses,
        "regions": regions,
        "therapy_areas": therapy_areas,
    })
