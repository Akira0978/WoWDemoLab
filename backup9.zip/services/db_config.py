# services/db_config.py
"""
Centralized database configuration with hardcoded relative paths.
This ensures the database path works consistently regardless of where the app is run.
"""

import os
from pathlib import Path


def get_db_path() -> str:
    """
    Returns the absolute path to trials.db using a hardcoded relative path.
    
    The path is calculated relative to the app.py root directory (2 levels up from services/).
    Returns: absolute path to data/trials.db
    """
    # Get the directory of this file (services/)
    services_dir = Path(__file__).parent.absolute()
    # Go up one level to the app root
    app_root = services_dir.parent
    # Construct path to data/trials.db
    db_path = app_root / "data" / "trials.db"
    return str(db_path)


def get_db_folder() -> str:
    """
    Returns the absolute path to the data folder.
    Creates the folder if it doesn't exist.
    """
    services_dir = Path(__file__).parent.absolute()
    app_root = services_dir.parent
    db_folder = app_root / "data"
    db_folder.mkdir(exist_ok=True)
    return str(db_folder)
