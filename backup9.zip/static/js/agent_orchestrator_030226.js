// static/js/agent_orchestrator.js
(function () {
  // -------- Card map (IDs must match your ct_diabetes.html) --------
  var CARD_MAP = {
    'active_by_phase': { cardId: 'card_active_by_phase', chartId: 'ct_chart_active_by_phase' },
    'start_momentum':  { cardId: 'card_start_momentum',  chartId: 'ct_chart_start_momentum'  },
    'moa_distribution':{ cardId: 'card_moa',             chartId: 'ct_chart_moa_distribution'},
    'geo_footprint':   { cardId: 'card_geo',             chartId: 'ct_chart_geo_footprint'   }
  };

  // -------- Chat intent router (keywords -> show(typeKey)) --------
  function handleChatCommand(text) {
    if (!text) return;
    var t = String(text).toLowerCase();
    if (t.includes('active') && t.includes('trial')) return show('active_by_phase');
    if (t.includes('momentum')) return show('start_momentum');
    if (t.includes('moa') || t.includes('mechanism')) return show('moa_distribution');
    if (t.includes('geo') || t.includes('geographic') || t.includes('region')) return show('geo_footprint');
  }

  // -------- Overlay (Agentic thinking) --------
  var orchEl = null, barEl = null, stepEls = {};
  function ensureOverlay() {
    if (orchEl) return;
    orchEl = document.createElement('div');
    orchEl.className = 'agent-orch';
    orchEl.setAttribute('role','dialog');
    orchEl.setAttribute('aria-modal','true');
    orchEl.innerHTML = [
      
'<div class="orch-header">',
     '<div class="orch-title">Enterprise Multi‑Agent Pipeline</div>',
     '<div class="orch-status"><span class="dot"></span> Working</div>',
  '</div>',

  '<div class="orch-section">',
     '<div class="orch-section-title">DATA FOUNDATION</div>',
     stepTpl("ingestor", "Data Ingestor", "Fetching & preparing CT.gov data"),
     stepTpl("kpi_engine", "KPI Engine", "Computing baseline KPIs"),
  '</div>',

  '<div class="orch-section">',
     '<div class="orch-section-title">REAL‑TIME ENGINE</div>',
     stepTpl("sim_engine", "Simulation Engine", "Generating real‑time demo activity"),
  '</div>',

  '<div class="orch-section">',
     '<div class="orch-section-title">USER INTELLIGENCE PIPELINE</div>',
     stepTpl("ingestor_refresh", "Ingestor Refresh", "Incremental sync on demand"),
     stepTpl("eyes", "Visualization (Eyes)", "Updating charts & dashboards"),
     stepTpl("brain", "Insight Agent (Brain)", "Summarizing insights & reasoning"),
  '</div>',

  '<div class="orch-section">',
     '<div class="orch-section-title">EXTERNAL INTELLIGENCE</div>',
     stepTpl("satellite", "Satellite Agent", "Monitoring news, filings & signals"),
     stepTpl("radar", "Radar Agent", "High‑impact event detection"),
  '</div>',

  '<div class="orch-progress"><div class="orch-progress-bar"></div></div>',
  '<div id="ai-reasoning-trace" class="ai-trace">',
    '<h4>Reasoning Trace</h4>',
    '<ul id="ai-trace-list"></ul>',
  '</div>',


    ].join('');
    document.body.appendChild(orchEl);
    barEl = orchEl.querySelector('.bar');
    ['ingestor','brain','eyes','satellite','radar'].forEach(function(k){
      stepEls[k] = orchEl.querySelector('.step[data-agent="'+k+'"]');
    });
  }
  function stepTpl(key, name, desc) {
    return ''
      + '<div class="step pending" data-agent="'+key+'">'
      + '  <div class="name">'+name+'</div>'
      + '  <div class="desc">'+desc+'</div>'
      + '  <div class="badge"><span class="spinner"></span> Pending</div>'
      + '</div>';
  }
  function setStep(key, state, badgeHtml) {
    var el = stepEls[key]; if (!el) return;
    el.classList.remove('pending','running','done','error');
    el.classList.add(state);
    el.querySelector('.badge').innerHTML = badgeHtml;
  }
  function setProgress(pct){ if (barEl) barEl.style.width = Math.min(100, Math.max(0, pct)) + '%'; }
  function openOverlay(){ orchEl.classList.add('show'); orchEl.setAttribute('aria-busy','true');document.getElementById('page-dimmer').style.display = 'block'; }
  function closeOverlay(){ orchEl.classList.remove('show'); orchEl.removeAttribute('aria-busy');document.getElementById('page-dimmer').style.display = 'none'; }

  // -------- Right-rail activity chips (clean) --------
  function pushActivity(kind, text) { // kind: 'satellite' | 'radar'
    var root = document.getElementById('right-rail-feeds');
    if (!root) return;
    var last = root.querySelector('.rf-activity.' + kind);
    if (last && last.dataset.msg === text) {
      var t = last.querySelector('.time');
      if (t) t.textContent = new Date().toLocaleTimeString();
      return;
    }
    var el = document.createElement('div');
    el.className = 'rf-activity ' + kind;
    el.dataset.msg = text;
    el.innerHTML =
      '<span class="dot" aria-hidden="true"></span>'
      + '<span class="txt">'+text+'</span>'
      + '<span class="time">'+new Date().toLocaleTimeString()+'</span>';
    root.prepend(el);
  }

  // -------- Sequence driver --------
  function runSequence(finalizeCb) {
    Object.keys(stepEls).forEach(function(k){
      setStep(k, 'pending', '<span class="spinner"></span> Pending');
    });
    setProgress(0);
    openOverlay();

    var t0 = 250, t1 = 900, t2 = 1500, t3 = 2100, t4 = 2700;

    setTimeout(function(){
      setStep('ingestor','running','<span class="spinner"></span> Fetching sources');
      setProgress(12);
    }, t0);

    setTimeout(function(){
      setStep('ingestor','done','<span>✓</span> Sources ready');
      setStep('brain','running','<span class="spinner"></span> Summarizing signals');
      setProgress(36);
    }, t1);

    setTimeout(function(){
      setStep('brain','done','<span>✓</span> Plan ready');
      setStep('eyes','running','<span class="spinner"></span> Building visuals');
      setProgress(58);
    }, t2);

    setTimeout(function(){
      setStep('eyes','done','<span>✓</span> Visuals prepped');
      setStep('satellite','running','<span class="spinner"></span> News & filings sweep');
      pushActivity('satellite', 'Scanning news & filings for Diabetes CT…');
      setProgress(78);
    }, t3);

    setTimeout(function(){
      setStep('satellite','done','<span>✓</span> Signals queued');
      setStep('radar','running','<span class="spinner"></span> Alert checks');
      pushActivity('radar', 'Cross-checking conflicts & risk signals…');
      setProgress(90);
    }, t4);

    setTimeout(function(){
      setStep('radar','done','<span>✓</span> All clear');
      setProgress(100);
      finalizeCb && finalizeCb();
      setTimeout(closeOverlay, 5000);
    }, t4 + 350);
  }
// External-signal mini-sequence: Satellite -> Brain -> Eyes -> Radar
function runExternalSignalSequence(label) {
  ensureOverlay();
  // Reset the known steps you actually render
  ['ingestor','brain','eyes','satellite','radar'].forEach(function (k) {
    setStep(k, 'pending', ' Pending');
  });
  setProgress(0);
  openOverlay();

  // T+0s: Satellite scanning
  setStep('satellite', 'running', ' Scanning external feeds');
  pushActivity('satellite', 'Scanning external feeds …');
  setProgress(20);

  // T+1.5s: Signal detected
  setTimeout(function () {
    setStep('satellite', 'done', ' ✓ Relevant signal captured');
    setStep('brain', 'running', ' Recalibrating KPIs & risks');
    pushActivity('satellite', (label || 'Regulatory update detected.'));
    setProgress(55);
  }, 1500);

  // T+3.5s: Brain done, Eyes updating charts
  setTimeout(function () {
    setStep('brain', 'done', ' ✓ KPIs updated');
    setStep('eyes', 'running', ' Refreshing visuals');
    setProgress(78);
  }, 3500);

  // T+5s: Radar notifies authorities
  setTimeout(function () {
    setStep('eyes', 'done', ' ✓ Visuals refreshed');
    setStep('radar', 'running', ' Notifying authorities');
    pushActivity('radar', 'Authorities notified. Report prepared.');
    setProgress(92);
  }, 5000);

  // T+6s: Wrap up
  setTimeout(function () {
    setStep('radar', 'done', ' ✓ Report dispatched');
    setProgress(100);
    // Keep open a bit; your global hold may also keep it
    setTimeout(closeOverlay, 2500);
  }, 6000);
}
  // -------- Mode helpers (single vs. multi) --------
  function hideAllCards() {
    document.querySelectorAll('.ct-kpi-card').forEach(function(c){
      c.classList.add('is-hidden'); // modifier class; CSS handles display:none !important
    });
  }

  // -------- Core API --------
  function show(typeKey) {
    ensureOverlay();
    var cfg = CARD_MAP[typeKey];
    if (!cfg) return;

    // Pull mode from config (with default)
    var mode = (window.AgentFlow && window.AgentFlow.config && window.AgentFlow.config.mode) || 'single';

    runSequence(function(){
      if (mode === 'single') hideAllCards();

      var card = document.getElementById(cfg.cardId);
      if (card) {
        card.classList.remove('is-hidden');
        card.scrollIntoView({ behavior: 'smooth', block: 'start' });
        setTimeout(function(){ window.dispatchEvent(new Event('resize')); }, 200);
      }
    });
  }

  function setMode(next) {
    var current = window.AgentFlow && window.AgentFlow.config;
    if (!current) {
      // create config if missing
      window.AgentFlow = window.AgentFlow || {};
      window.AgentFlow.config = { mode: 'single' };
      current = window.AgentFlow.config;
    }
    if (next === 'single' || next === 'multi') current.mode = next;
    return current.mode;
  }

  // -------- SAFE EXPORT (idempotent, last line of the IIFE) --------
  (function safeExport(){
    var current = window.AgentFlow || {};
    var cfg = current.config || { mode: 'single' };
    window.AgentFlow = Object.assign({}, current, {
      handleChatCommand: current.handleChatCommand || handleChatCommand,
      show:              current.show              || show,
      setMode:           setMode,            // always (we want to guarantee it exists)
      externalSignalFlow: runExternalSignalSequence,
      config:            cfg
    });
    try { console.debug('[AgentFlow] ready; mode =', window.AgentFlow.config.mode); } catch(_) {}
  })();

})();
function addForecastOverlay(chartId, typeKey) {
  const el = document.getElementById(chartId);
  const inst = echarts.getInstanceByDom(el);
  if (!inst) return;

  const opt = inst.getOption();
  const series = opt.series?.[0];
  if (!series) return;

  const data = [...series.data];
  const last = Number(data[data.length - 1]);

  // Fake 3-step forecast
  const forecast = [
    last * 1.02,
    last * 1.05,
    last * 1.09
  ].map(v => Number(v.toFixed(1)));

  // Append ghost future points
  series.data = [...data, ...forecast];

  // Add forecast styling
  series.lineStyle = { type: 'dashed', width: 2 };
  opt.series[0] = series;

  inst.setOption(opt, false, true);

  // Optional: remove forecast after 6 seconds
  setTimeout(() => {
    series.data = data;
    series.lineStyle = { type: 'solid' };
    inst.setOption(opt, false, true);
  }, 6000);
}

function addReasoningTrace(lines) {
  const list = document.getElementById('ai-trace-list');
  if (!list) return;
  list.innerHTML = '';
  lines.forEach(l => {
    const li = document.createElement('li');
    li.textContent = l;
    list.appendChild(li);
  });
}
