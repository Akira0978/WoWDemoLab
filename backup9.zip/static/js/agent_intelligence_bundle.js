// static/js/agent_intelligence_bundle.js
(function(){

    // Utility: uniform event trigger
    function fire(agent, msg){
        if(window.agentSay){
            agentSay(agent, msg);     // sends to Dock
        }
        if(window.IntelEvents){
            IntelEvents.pulse(agent); // triggers Dock pulse
        }
    }

    // ------------------------------
    //  FORECASTER AI
    // ------------------------------
    window.ForecasterAI = {
        run: function(typeKey){
            const packs = {
                active_by_phase: {
                    forecast: "Phase 2 share expected to soften by ~4%.",
                    spark: "-3.8%",
                    impact: { slowdown:"3–5%", risk:"+1.4", kpis:2 }
                },
                start_momentum: {
                    forecast: "Start momentum showing 6–9% projected dip next cycle.",
                    spark: "-7.1%",
                    impact: { slowdown:"6–9%", risk:"+2.1", kpis:3 }
                },
                moa_distribution: {
                    forecast: "GLP‑1 MoA trending -4–6% next quarter.",
                    spark: "-5.0%",
                    impact: { slowdown:"4–6%", risk:"+1.8", kpis:1 }
                },
                geo_footprint: {
                    forecast: "EU slowdown; Asia +6% offset expected.",
                    spark: "+6.0%",
                    impact: { slowdown:"7–10%", risk:"+2.4", kpis:4 }
                }
            };

            const p = packs[typeKey] || packs.start_momentum;

            fire("Forecast", `AI Forecast: ${p.forecast}`);

            if(window.IntelEvents){
                IntelEvents.impact({
                    recruitment_slowdown: p.impact.slowdown,
                    risk_delta: p.impact.risk,
                    kpis_impacted: p.impact.kpis,
                    narrative: p.forecast
                });
            }
        }
    };

    // ------------------------------
    //  COMPETITOR ANALYST
    // ------------------------------
    window.CompeteAI = {
        analyze: function(typeKey){
            const insights = {
                moa_distribution: "Lilly accelerating GLP‑1 trial starts (+12% QoQ).",
                active_by_phase: "AZ Phase 3 throughput expected to soften.",
                start_momentum: "Pfizer momentum declining after recent indication loss.",
                geo_footprint: "Novo expanding Asian footprint (+8 sites)."
            };
            fire("Competitor", insights[typeKey] || "Competitor landscape shifting.");
        }
    };

    // ------------------------------
    //   RISK / SCENARIO ENGINE
    // ------------------------------
    window.RiskAI = {
        project: function(typeKey){
            const risks = {
                start_momentum: "Scenario: 2–3 month operational delay emerging.",
                active_by_phase: "Phase 2 attrition risk +14%.",
                moa_distribution: "Safety‑review induced MoA drift risk.",
                geo_footprint: "EU regulatory friction driving geo imbalance."
            };
            fire("Risk", risks[typeKey]);
        }
    };

    // ------------------------------
    //   STRATEGY / ADVISOR AI
    // ------------------------------
    window.AdvisorAI = {
        recommend: function(typeKey){
            const recs = {
                start_momentum: "Mitigation: Activate backup NA/Asia sites for offset.",
                active_by_phase: "Recommendation: Rebalance cohort allocation.",
                moa_distribution: "Advisory: Prepare MoA diversification strategy.",
                geo_footprint: "Shift 12% enrollment capacity to Asia for stability."
            };
            fire("Advisor", recs[typeKey]);
        }
    };

})();