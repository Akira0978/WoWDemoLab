// static/js/global.js
(function () {
  "use strict";

  // ---------------- Bootstrap helpers (optional) ----------------
  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach((el) => {
      try { new bootstrap.Tooltip(el); } catch (_) {}
    });
  });

  // ---------------- Namespace ----------------
  window.NNCI = window.NNCI || {};

  // Simple JSON fetch
  window.NNCI.fetchJSON = async function (url, opts = {}) {
    const res = await fetch(url, { headers: { "Accept": "application/json" }, ...opts });
    if (!res.ok) throw new Error(`Fetch failed (${res.status}): ${url}`);
    return res.json();
  };

  // Keep an optional base filter that pages can set (e.g. therapy_area)
  let BASE_FILTER = {};
  window.NNCI.setBaseFilter = (f) => { BASE_FILTER = { ...(f || {}) }; };

  // ---------------- Utilities (exposed) ----------------
  function getUrlFilters() {
    const params = new URLSearchParams(window.location.search);
    return {
      therapy_area: params.get("therapy_area") || null,
      sponsor: params.getAll("sponsor"),
      drug: params.getAll("drug"),
      phase: params.getAll("phase"),
      status: params.getAll("status"),
      region: params.getAll("region"),
      start_from: params.get("start_from"),
      start_to: params.get("start_to"),
      completion_from: params.get("completion_from"),
      completion_to: params.get("completion_to"),
      months: params.get("months"),
      top_n: params.get("top_n")
    };
  }

  function merge(a = {}, b = {}) {
    const out = { ...a };
    Object.entries(b).forEach(([k, v]) => {
      if (v == null) return;
      if (Array.isArray(v)) {
        if (v.length) out[k] = v;
      } else if (typeof v === "string") {
        if (v !== "") out[k] = v;
      } else {
        out[k] = v;
      }
    });
    return out;
  }

  function getFilterState() {
    // Merge BASE_FILTER <- URL filters (URL wins unless empty)
    return merge(BASE_FILTER, getUrlFilters());
  }

  function buildQueryString(filterState) {
    const params = new URLSearchParams();
    Object.entries(filterState || {}).forEach(([key, value]) => {
      if (value == null) return;
      if (Array.isArray(value)) {
        value.forEach(v => { if (v) params.append(key, v); });
      } else if (value !== "") {
        params.set(key, value);
      }
    });
    return params.toString();
  }

  window.NNCI.utils = {
    getUrlFilters,
    getFilterState,
    buildQueryString,
    merge
  };

  // ---------------- ECharts option builders ----------------
  function optionActiveByPhase(apiData) {
    return {
      tooltip: { trigger: "axis" },
      legend: { top: 0 },
      grid: { left: 40, right: 20, top: 40, bottom: 40 },
      xAxis: { type: "category", data: apiData.categories || [] },
      yAxis: { type: "value" },
      series: (apiData.series || []).map(s => ({
        name: s.name,
        type: s.type || "bar",
        stack: s.stack || "active_trials",
        emphasis: { focus: "series" },
        data: s.data || []
      }))
    };
  }

  function optionStartMomentum(apiData) {
    // Supports either {categories, series:[lines]} or {months, counts}
    if (apiData.series) {
      return {
        tooltip: { trigger: "axis" },
        legend: { top: 0 },
        grid: { left: 40, right: 20, top: 40, bottom: 40 },
        xAxis: { type: "category", data: apiData.categories || [] },
        yAxis: { type: "value" },
        series: (apiData.series || []).map(s => ({
          name: s.name,
          type: s.type || "line",
          smooth: true,
          data: s.data || []
        }))
      };
    }
    return {
      tooltip: { trigger: "axis" },
      grid: { left: 40, right: 20, top: 20, bottom: 40 },
      xAxis: { type: "category", data: apiData.months || [] },
      yAxis: { type: "value" },
      series: [{
        name: "Starts",
        type: "line",
        smooth: true,
        data: apiData.counts || []
      }]
    };
  }

  function optionMoaDistribution(apiData) {
    if (apiData.series) {
      return {
        tooltip: { trigger: "axis" },
        grid: { left: 140, right: 20, top: 20, bottom: 20 },
        xAxis: { type: "value" },
        yAxis: { type: "category", data: apiData.categories || [] },
        series: (apiData.series || []).map(s => ({
          name: s.name,
          type: s.type || "bar",
          data: s.data || []
        }))
      };
    }
    return {
      tooltip: { trigger: "axis" },
      grid: { left: 160, right: 20, top: 20, bottom: 20 },
      xAxis: { type: "value" },
      yAxis: { type: "category", data: apiData.labels || [] },
      series: [{
        name: "Active Trials",
        type: "bar",
        data: apiData.values || []
      }]
    };
  }

  function optionGeoFootprint(apiData) {
    return {
      tooltip: { trigger: "axis" },
      legend: { top: 0 },
      grid: { left: 40, right: 20, top: 40, bottom: 40 },
      xAxis: { type: "category", data: apiData.categories || [] },
      yAxis: { type: "value" },
      series: (apiData.series || []).map(s => ({
        name: s.name,
        type: s.type || "bar",
        stack: s.stack || "geo",
        data: s.data || []
      }))
    };
  }

  function buildOption(chartType, apiData) {
    switch (chartType) {
      case "active_by_phase": return optionActiveByPhase(apiData);
      case "start_momentum": return optionStartMomentum(apiData);
      case "moa_distribution": return optionMoaDistribution(apiData);
      case "geo_footprint": return optionGeoFootprint(apiData);
      default:
        return { title: { text: "Unknown chart type" } };
    }
  }

  // ---------------- Loader ----------------
  async function loadSingleChart(el, filterState) {
    const endpoint = el.dataset.endpoint;
    const chartType = el.dataset.chartType;
    const height = el.dataset.height ? parseInt(el.dataset.height, 10) : null;
    if (height) el.style.height = `${height}px`;

    const qs = buildQueryString(filterState);
    const url = qs ? `${endpoint}?${qs}` : endpoint;

    const chart = echarts.init(el);
    el.__echart__ = chart;

    chart.showLoading({ text: "Loading…" });

    try {
      const resp = await fetch(url, { headers: { "Accept": "application/json" } });
      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const apiData = await resp.json();

      const option = buildOption(chartType, apiData);
      chart.setOption(option, true);
    } catch (err) {
      chart.setOption({
        title: { text: "Failed to load chart", left: "center", top: "center" },
        tooltip: {},
        series: []
      }, true);
      console.error("Chart load error:", endpoint, err);
    } finally {
      chart.hideLoading();
    }
  }

  async function loadAllCharts() {
    const filterState = getFilterState();
    // IMPORTANT: match your page HTML (ct_diabetes.html uses "nnci-chart")
    const chartEls = document.querySelectorAll(".nnci-chart[data-endpoint]");
    const tasks = Array.from(chartEls).map(el => loadSingleChart(el, filterState));
    await Promise.allSettled(tasks);
  }

  function bindResize() {
    window.addEventListener("resize", () => {
      document.querySelectorAll(".nnci-chart").forEach(el => {
        if (el.__echart__) el.__echart__.resize();
      });
    });
  }

  // Boot: auto-load charts once; pages may call refresh again after setting base filter
  document.addEventListener("DOMContentLoaded", () => {
    loadAllCharts();
    bindResize();
  });

  // Expose refresh hook for filter apply button or page controllers
  window.CTI = window.CTI || {};
  window.CTI.refreshCharts = loadAllCharts;
})();

//chart refresh
setInterval(() => {
  if (window.CTI?.refreshCharts) {
    window.CTI.refreshCharts()
  }
}, 8000);