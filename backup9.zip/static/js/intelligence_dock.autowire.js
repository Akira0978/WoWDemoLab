// static/js/intelligence_dock.autowire.js (ENHANCED · Mode A)
(function(){
  function when(cond, cb, tries){ tries = (typeof tries==='number'?tries:120); var t = setInterval(function(){ if(cond()){ clearInterval(t); try{ cb(); }catch(_){ } } else if(--tries<=0){ clearInterval(t); } }, 100); }
  var recent = [];
  function seen(k){ var now=Date.now(); for(var i=recent.length-1;i>=0;i--){ var r=recent[i]; if(now-r.t>12000) recent.splice(i,1); else if(r.k===k && now-r.t<4000) return true; } return false; }
  function push(k){ recent.push({k:k,t:Date.now()}); if(recent.length>80) recent.shift(); }
  function safeSay(agent, msg){ try{ if(window.IntelDock){ IntelDock.init(); IntelDock.show(); IntelDock.say(agent, msg); } }catch(_){ } }

  function wireFeeds(){
    if (typeof window.agentSay === 'function'){
      var oSay = window.agentSay;
      window.agentSay = function(agent, message){ var key = 'say:'+agent+'|'+message; if(!seen(key)){ safeSay(agent, message); push(key); } try{ return oSay.apply(this, arguments); }catch(_){ } }
    }
    if (typeof window.addFeed === 'function'){
      var oAdd = window.addFeed;
      window.addFeed = function(source, title){ var key = 'feed:'+source+'|'+title; if(!seen(key)){ safeSay(source, title); push(key); } try{ return oAdd.apply(this, arguments); }catch(_){ } }
    }
    var root = document.getElementById('right-rail-feeds');
    if(root && window.IntelDock){
      var mo = new MutationObserver(function(muts){
        muts.forEach(function(m){ (m.addedNodes||[]).forEach(function(n){ if(!(n instanceof HTMLElement)) return; var src = n.querySelector('.feed-source'); var ttl = n.querySelector('.feed-title'); if(src && ttl){ var s=src.textContent.trim(), t=ttl.textContent.trim(); var key='mo:'+s+'|'+t; if(!seen(key)){ safeSay(s,t); push(key);} } }); });
      });
      try{ mo.observe(root,{childList:true, subtree:false}); }catch(_){ }
    }
  }

  function wireAgentFlow(){
    if (!window.AgentFlow || !window.IntelDock) return; IntelDock.init(); var AF = window.AgentFlow;
    if (typeof AF.setReasoningTrace === 'function'){ var oRT = AF.setReasoningTrace; AF.setReasoningTrace = function(lines){ try{ IntelDock.show(); IntelDock.setReasoning(lines||[]); }catch(_){ } return oRT.apply(AF, arguments); } }
    if (typeof AF.setAutoActions === 'function'){ var oAA = AF.setAutoActions; AF.setAutoActions = function(list){ try{ IntelDock.show(); IntelDock.setActions(list||[]); }catch(_){ } return oAA.apply(AF, arguments); } }
  }

  function setupIntelEvents(){ if (window.IntelEvents) return; window.IntelEvents = { summary: function(kv){ try{ IntelDock.init(); IntelDock.setSummary(kv||{}); }catch(_){ } }, impact: function(data){ try{ IntelDock.init(); IntelDock.setImpact(data||{}); }catch(_){ } }, pulse: function(agent){ try{ IntelDock.init(); IntelDock.pulse(agent); }catch(_){ } }, forecastBadge: function(chartDomId, text, ttl){ try{ IntelDock.init(); IntelDock.addForecastBadge(chartDomId,text,ttl); }catch(_){ } } }; }

  function wireAutoShowTriggers(){ var mo = new MutationObserver(function(muts){ for (var i=0;i<muts.length;i++){ var m = muts[i]; if(!(m.addedNodes||[]).length) continue; for (var j=0;j<m.addedNodes.length;j++){ var n = m.addedNodes[j]; if (!(n instanceof HTMLElement)) continue; if (n.classList && n.classList.contains('insight-chip')){ try{ IntelDock.show(); IntelDock.pulse('Brain'); }catch(_){ } } if (n.classList && n.classList.contains('chart-badge')){ try{ IntelDock.show(); IntelDock.pulse('Eyes'); }catch(_){ } } } } }); try{ mo.observe(document.body, {childList:true, subtree:true}); }catch(_){ } }

  document.addEventListener('DOMContentLoaded', function(){
    when(function(){ return !!window.IntelDock; }, function(){ try{ IntelDock.init(); }catch(_){ } wireFeeds(); setupIntelEvents(); wireAutoShowTriggers(); when(function(){ return !!window.AgentFlow; }, wireAgentFlow, 120); try{ IntelEvents.summary({ agents:4, external_signals:0, kpis_at_risk:0, forecast_badges:0 }); }catch(_){ } });
  });
})();