
// static/js/agent_orchestrator.js
(function () {
  // ---------------- Card map (IDs must match your ct_diabetes.html) ----------------
  var CARD_MAP = {
    'active_by_phase': { cardId: 'card_active_by_phase', chartId: 'ct_chart_active_by_phase' },
    'start_momentum':  { cardId: 'card_start_momentum',  chartId: 'ct_chart_start_momentum'  },
    'moa_distribution':{ cardId: 'card_moa',             chartId: 'ct_chart_moa_distribution'},
    'geo_footprint':   { cardId: 'card_geo',             chartId: 'ct_chart_geo_footprint'   }
  };

  // ---------------- Chat intent router (keywords -> show(typeKey)) ----------------
  function handleChatCommand(text) {
    if (!text) return;
    var t = String(text).toLowerCase();
    if (t.includes('active') && t.includes('trial')) return show('active_by_phase');
    if (t.includes('momentum')) return show('start_momentum');
    if (t.includes('moa') || t.includes('mechanism')) return show('moa_distribution');
    if (t.includes('geo') || t.includes('geographic') || t.includes('region')) return show('geo_footprint');
  }

  // ---------------- Overlay (Agentic thinking) ----------------
  var orchEl = null, barEl = null, stepEls = {};

  function stepTpl(key, name, desc) {
    return ''
      + '<div class="step pending" data-agent="' + key + '">'
      +   '<div class="title">' + name + '</div>'
      +   '<div class="desc">' + desc + '</div>'
      +   '<div class="badge"> Pending</div>'
      + '</div>';
  }

  function ensureOverlay() {
    if (orchEl) return;
    orchEl = document.createElement('div');
    orchEl.className = 'agent-orch';
    orchEl.setAttribute('role','dialog');
    orchEl.setAttribute('aria-modal','true');

    orchEl.innerHTML = [
      '<div class="orch-header">',
      '  <div class="orch-title">Enterprise Multi‑Agent Pipeline</div>',
      '  <div class="orch-status"><span class="dot"></span> Working</div>',
      '</div>',

      '<div class="orch-section">',
      '  <div class="orch-section-title">DATA FOUNDATION</div>',
      stepTpl('ingestor', 'Data Ingestor', 'Fetching & preparing CT.gov data'),
      stepTpl('kpi_engine', 'KPI Engine', 'Computing baseline KPIs'),
      '</div>',

      '<div class="orch-section">',
      '  <div class="orch-section-title">REAL‑TIME ENGINE</div>',
      stepTpl('sim_engine', 'Simulation Engine', 'Generating real‑time demo activity'),
      '</div>',

      '<div class="orch-section">',
      '  <div class="orch-section-title">USER INTELLIGENCE PIPELINE</div>',
      stepTpl('ingestor_refresh', 'Ingestor Refresh', 'Incremental sync on demand'),
      stepTpl('eyes', 'Visualization (Eyes)', 'Updating charts & dashboards'),
      stepTpl('brain', 'Insight Agent (Brain)', 'Summarizing insights & reasoning'),
      '</div>',

      '<div class="orch-section">',
      '  <div class="orch-section-title">EXTERNAL INTELLIGENCE</div>',
      stepTpl('satellite', 'Satellite Agent', 'Monitoring news, filings & signals'),
      stepTpl('radar', 'Radar Agent', 'High‑impact event detection'),
      '</div>',

      '<div class="orch-section ai-blocks">',
      '  <div class="orch-section-title">INTELLIGENCE</div>',
      '  <div id="ai-reasoning-trace" class="ai-trace">',
      '    <h4>Reasoning Trace</h4>',
      '    <ul id="ai-trace-list"></ul>',
      '  </div>',
      '  <div id="auto-actions" class="auto-actions"></div>',
      '</div>',

      '<div class="orch-progress"><div class="orch-progress-bar bar"></div></div>',
      '<div class="orch-footer"><button class="orch-btn-close" onclick="window.AgentFlow && AgentFlow.closeNow && AgentFlow.closeNow()">OK</button></div>'
    ].join('');

    document.body.appendChild(orchEl);
    barEl = orchEl.querySelector('.bar');
    ['ingestor','brain','eyes','satellite','radar','kpi_engine','sim_engine','ingestor_refresh'].forEach(function(k){
      var el = orchEl.querySelector('.step[data-agent="'+k+'"]');
      if (el) stepEls[k] = el;
    });
  }

  function setStep(key, state, badgeHtml) {
    var el = stepEls[key];
    if (!el) return;
    el.classList.remove('pending','running','done','error');
    el.classList.add(state);
    var b = el.querySelector('.badge');
    if (b) b.innerHTML = badgeHtml;
  }

  function setProgress(pct){ if (barEl) barEl.style.width = Math.min(100, Math.max(0, pct)) + '%'; }

  function openOverlay(){ ensureOverlay(); orchEl.classList.add('show'); orchEl.setAttribute('aria-busy','true'); var d=document.getElementById('page-dimmer'); if (d) d.style.display='block'; }
  function closeOverlay(){ if (!orchEl) return; if (orchEl.getAttribute('data-force-open')) return; orchEl.classList.remove('show'); orchEl.removeAttribute('aria-busy'); var d=document.getElementById('page-dimmer'); if (d) d.style.display='none'; }

  // make available for button
  function closeNow(){ if (!orchEl) return; orchEl.removeAttribute('data-force-open'); closeOverlay(); }

  // ---------------- Right-rail activity chips (clean) ----------------
  function pushActivity(kind, text) { // kind: 'satellite' | 'radar'
    var root = document.getElementById('right-rail-feeds');
    if (!root) return;
    var last = root.querySelector('.rf-activity.' + kind);
    if (last && last.dataset.msg === text) {
      var t = last.querySelector('.time');
      if (t) t.textContent = new Date().toLocaleTimeString();
      return;
    }
    var el = document.createElement('div');
    el.className = 'rf-activity ' + kind;
    el.dataset.msg = text;
    el.innerHTML = '<div class="text">'+text+'</div><div class="time">'+new Date().toLocaleTimeString()+'</div>';
    root.prepend(el);
  }

  // ---------------- Sequence driver (initial pipeline) ----------------
  function runSequence(finalizeCb) {
    Object.keys(stepEls).forEach(function(k){ setStep(k, 'pending', ' Pending'); });
    setProgress(0);
    openOverlay();

    var t0 = 500, t1 = 1800, t2 = 3000, t3 = 4200, t4 = 5400;

    setTimeout(function(){ setStep('ingestor','running',' Fetching sources'); setProgress(12); }, t0);
    setTimeout(function(){ setStep('ingestor','done','✓ Sources ready'); setStep('brain','running',' Summarizing signals'); setProgress(36); }, t1);
    setTimeout(function(){ setStep('brain','done','✓ Plan ready'); setStep('eyes','running',' Building visuals'); setProgress(58); }, t2);
    setTimeout(function(){ setStep('eyes','done','✓ Visuals prepped'); setStep('satellite','running',' News & filings sweep'); pushActivity('satellite', 'Scanning news & filings for Diabetes CT…'); setProgress(78); }, t3);
    setTimeout(function(){ setStep('satellite','done','✓ Signals queued'); setStep('radar','running',' Alert checks'); pushActivity('radar', 'Cross-checking conflicts & risk signals…'); setProgress(90); }, t4);
    setTimeout(function(){ setStep('radar','done','✓ All clear'); setProgress(100); if (finalizeCb) finalizeCb(); setTimeout(closeOverlay, 2500); }, t4 + 350);
  }

  // ---------------- External-signal mini-sequence: Satellite -> Brain -> Eyes -> Radar ----------------
  function runExternalSignalSequence(label) {
    ensureOverlay();
    ['ingestor','brain','eyes','satellite','radar'].forEach(function (k) { setStep(k, 'pending', ' Pending'); });
    setProgress(0);
    openOverlay();

    // guarantee visibility for a few seconds
    orchEl.setAttribute('data-force-open','1');
    setTimeout(function(){ orchEl.removeAttribute('data-force-open'); }, 6000);

    // T+0s: Satellite scanning
    setStep('satellite', 'running', ' Scanning external feeds');
    pushActivity('satellite', 'Scanning external feeds …');
    setProgress(20);

    // T+1.5s: Signal detected
    setTimeout(function () {
      setStep('satellite', 'done', ' ✓ Relevant signal captured');
      setStep('brain', 'running', ' Recalibrating KPIs & risks');
      pushActivity('satellite', (label || 'Regulatory update detected.'));
      setProgress(55);
    }, 1500);

    // T+3.5s: Brain done, Eyes updating charts
    setTimeout(function () {
      setStep('brain', 'done', ' ✓ KPIs updated');
      setStep('eyes', 'running', ' Refreshing visuals');
      setProgress(78);
    }, 3500);

    // T+5s: Radar notifies authorities
    setTimeout(function () {
      setStep('eyes', 'done', ' ✓ Visuals refreshed');
      setStep('radar', 'running', ' Notifying authorities');
      pushActivity('radar', 'Authorities notified. Report prepared.');
      setProgress(92);
    }, 5000);

    // T+6s: Wrap up
    setTimeout(function () {
      setStep('radar', 'done', ' ✓ Report dispatched');
      setProgress(100);
      setTimeout(closeOverlay, 2200);
    }, 6000);
  }

  // ---------------- Small helpers for Intelligence blocks ----------------
  function setReasoningTrace(lines){
    var list = document.getElementById('ai-trace-list');
    if (!list) return;
    list.innerHTML = '';
    (lines||[]).forEach(function(l){ var li=document.createElement('li'); li.textContent=l; list.appendChild(li); });
  }
  function setAutoActions(actions){
    var el = document.getElementById('auto-actions');
    if (!el) return;
    el.innerHTML = (actions||[]).map(function(a){ return '<div>✔ '+a+'</div>'; }).join('');
  }

  // ---------------- Mode helpers (single vs. multi) ----------------
  function hideAllCards() {
    document.querySelectorAll('.ct-kpi-card').forEach(function(c){ c.classList.add('is-hidden'); });
  }

  // ---------------- Core API ----------------
  function show(typeKey) {
    ensureOverlay();
    var cfg = CARD_MAP[typeKey];
    if (!cfg) return;
    var mode = (window.AgentFlow && window.AgentFlow.config && window.AgentFlow.config.mode) || 'single';
    runSequence(function(){
      if (mode === 'single') hideAllCards();
      var card = document.getElementById(cfg.cardId);
      if (card) {
        card.classList.remove('is-hidden');
        card.scrollIntoView({ behavior: 'smooth', block: 'start' });
        setTimeout(function(){ window.dispatchEvent(new Event('resize')); }, 200);
      }
    });
  }

  function setMode(next) {
    var current = window.AgentFlow && window.AgentFlow.config;
    if (!current) { window.AgentFlow = window.AgentFlow || {}; window.AgentFlow.config = { mode: 'single' }; current = window.AgentFlow.config; }
    if (next === 'single' || next === 'multi') current.mode = next;
    return current.mode;
  }

  // ---------------- SAFE EXPORT (idempotent) ----------------
  (function safeExport(){
    var current = window.AgentFlow || {};
    var cfg = current.config || { mode: 'single' };
    window.AgentFlow = Object.assign({}, current, {
      handleChatCommand: current.handleChatCommand || handleChatCommand,
      show: current.show || show,
      setMode: setMode,
      //externalSignalFlow: runExternalSignalSequence,
      closeNow: closeNow,
      setReasoningTrace: setReasoningTrace,
      setAutoActions: setAutoActions,
      config: cfg
    });
    try { console.debug('[AgentFlow] ready; mode =', window.AgentFlow.config.mode); } catch(_) {}
  })();
})();
