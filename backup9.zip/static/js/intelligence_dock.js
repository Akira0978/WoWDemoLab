// static/js/intelligence_dock.js (ENHANCED · Mode A ready)
(function(){
  var root, hdr, conv, actions, traceList, summaryBox, impactBox,
      collapsed=false, hiddenByOverlay=false;

  var RECENT_MAX = 50; // for dedupe if needed by consumers
  var recentMsgs = [];

  var agentStyles = {
    "Satellite": {color:'#9ec7ff', tagBg:'#0e62ff20', glow:'#2f8cff'},
    "Brain":     {color:'#f9e285', tagBg:'#f6c90e22', glow:'#f6c90e'},
    "Eyes":      {color:'#A0E991', tagBg:'#5ad27a22', glow:'#5ad27a'},
    "Radar":     {color:'#9df3e0', tagBg:'#11c5a922', glow:'#11c5a9'},
    "System":    {color:'#cfd6e6', tagBg:'#cfd6e620', glow:'#8894a8'}
  };

  function injectStyles(){
    if (document.getElementById('intel-dock-styles')) return;
    var css = ''+
    '.intel-dock{position:fixed;left:50%;transform:translateX(-50%);bottom:20px;width:min(980px,92vw);z-index:99998;background:#0f1115;border:1px solid #1f242d;border-radius:12px;box-shadow:0 10px 28px rgba(0,0,0,.55),0 0 0 1px rgba(255,255,255,.03);color:#e8e8e8;font-family:\'Segoe UI\', Roboto, sans-serif;backdrop-filter:none;}'+
    '.intel-dock.hidden{display:none}'+
    '.intel-dock.sleep{opacity:.0;pointer-events:none;transform:translate(-50%, 24px);transition:opacity .18s ease, transform .18s ease}'+
    '.intel-dock .hdr{display:flex;align-items:center;justify-content:space-between;padding:10px 14px;border-bottom:1px solid #1f242d}'+
    '.intel-dock .ttl{font-size:14px;font-weight:600}'+
    '.intel-dock .status-dot{width:8px;height:8px;border-radius:50%;background:#3da5ff;box-shadow:0 0 8px #3da5ff;margin-right:8px;display:inline-block}'+
    '.intel-dock .btns{display:flex;gap:8px}'+
    '.intel-dock button.min, .intel-dock button.cls, .intel-dock button.clr{background:#15181e;border:1px solid #262b35;color:#cfd6e6;border-radius:6px;padding:6px 10px;font-size:12px;cursor:pointer}'+
    '.intel-dock button.min:hover, .intel-dock button.cls:hover, .intel-dock button.clr:hover{background:#1b2029}'+
    '.intel-dock .body{display:grid;grid-template-columns:1fr 1fr;gap:12px;padding:12px}'+
    '@media(max-width:900px){.intel-dock .body{grid-template-columns:1fr}}'+
    '.ai-summary,.ai-box{background:#12151b;border:1px solid #1f242d;border-radius:10px;padding:10px}'+
    '.ai-summary .kvs{display:flex;flex-wrap:wrap;gap:10px;margin-top:6px}'+
    '.ai-summary .kv{background:#151a22;border:1px solid #222835;border-radius:6px;padding:6px 8px;font-size:12px;color:#cfd6e6}'+
    '.ai-conv{background:#12151b;border:1px solid #1f242d;border-radius:10px;padding:10px;max-height:240px;overflow:auto}'+
    '.ai-conv-title{font-size:13px;font-weight:600;margin-bottom:6px}'+
    '.ai-conv-empty{color:#7f8796;font-size:12px;padding:6px 4px}'+
    '.ai-row{display:grid;grid-template-columns:auto 1fr auto;gap:10px;padding:6px 4px;border-bottom:1px dashed rgba(255,255,255,0.08)}'+
    '.ai-row:last-child{border-bottom:0}'+
    '.ai-row .tag{color:#9ec7ff;border:1px solid #2f8cff;background:#0e62ff20;border-radius:4px;padding:2px 6px;font-size:11px;white-space:nowrap}'+
    '.ai-row .msg{color:#e8e8e8;font-size:13px}'+
    '.ai-row time{color:#8b94a7;font-size:11px}'+
    'details.ai-reasoning summary{list-style:none;cursor:pointer;position:relative;padding-right:18px;font-size:13px;font-weight:600;color:#cfd6e6}'+
    'details.ai-reasoning summary::-webkit-details-marker{display:none}'+
    'details.ai-reasoning summary:after{content:"\\25be";position:absolute;right:0;top:0;color:#7f8796;transition:transform .2s ease}'+
    'details.ai-reasoning[open] summary:after{transform:rotate(180deg)}'+
    '#ai-trace{margin:6px 0 0 0;padding-left:16px}'+
    '#ai-trace li{color:#cdd6e4;margin:6px 0;font-size:13px}'+
    '.impact-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:8px}'+
    '@media(max-width:560px){.impact-grid{grid-template-columns:1fr}}'+
    '.impact-item{background:#151a22;border:1px solid #222835;border-radius:8px;padding:8px}'+
    '.impact-item .val{font-weight:700;color:#e8e8e8;font-size:18px}'+
    '.impact-item .lbl{color:#9aa2b2;font-size:12px}'+
    '.pulse{position:absolute;right:14px;top:12px;display:flex;gap:6px}'+
    '.pulse .p{width:8px;height:8px;border-radius:50%;opacity:.8;box-shadow:0 0 10px currentColor;animation:pulseBlink 1.2s ease infinite}'+
    '@keyframes pulseBlink{0%{transform:scale(.9);opacity:.6}50%{transform:scale(1.15);opacity:1}100%{transform:scale(.9);opacity:.6}}'+
    '.chart-badge{position:absolute;right:10px;top:10px;background:#12151b;color:#e8e8e8;border:1px solid #2f8cff;border-radius:6px;padding:3px 8px;font-size:11px;z-index:5;box-shadow:0 6px 14px rgba(0,0,0,.35)}'+
    '.slide-in{animation:slideIn .18s ease-out}';
    css += '@keyframes slideIn{from{transform:translate(-50%,8px)}to{transform:translate(-50%,0)}}';
    var s = document.createElement('style'); s.id='intel-dock-styles'; s.textContent = css; document.head.appendChild(s);
  }

  function build(){
    if (root) return;
    injectStyles();
    root = document.createElement('section');
    root.id = 'intel-dock';
    root.className = 'intel-dock slide-in';
    root.innerHTML = [
      '<div class="hdr">',
      ' <div class="ttl"><span class="status-dot" aria-hidden="true"></span>Intelligence Dock</div>',
      ' <div class="btns">',
      '   <button class="clr" title="Clear">Clear</button>',
      '   <button class="min" title="Minimize">Minimize</button>',
      '   <button class="cls" title="Close">Close</button>',
      ' </div>',
      '</div>',
      '<div class="body">',
      ' <div class="col left">',
      '   <div class="ai-summary">',
      '     <div class="ai-box-title" style="font-weight:600;margin-bottom:6px">AI System Summary</div>',
      '     <div id="ai-summary-kvs" class="kvs"></div>',
      '     <div class="pulse" aria-hidden="true">',
      '       <span class="p" id="pulse-satellite" style="color:'+agentStyles.Satellite.glow+';display:none"></span>',
      '       <span class="p" id="pulse-brain" style="color:'+agentStyles.Brain.glow+';display:none"></span>',
      '       <span class="p" id="pulse-eyes" style="color:'+agentStyles.Eyes.glow+';display:none"></span>',
      '       <span class="p" id="pulse-radar" style="color:'+agentStyles.Radar.glow+';display:none"></span>',
      '     </div>',
      '   </div>',
      '   <div style="height:10px"></div>',
      '   <div class="ai-conv">',
      '     <div class="ai-conv-title">Agent Conversation</div>',
      '     <div id="ai-conv"><div class="ai-conv-empty">Agents will post their internal updates here during the simulation.</div></div>',
      '   </div>',
      ' </div>',
      ' <div class="col right">',
      '   <div class="ai-box">',
      '     <div class="ai-box-title" style="font-weight:600">Automated Actions</div>',
      '     <div id="ai-actions" class="auto-actions"></div>',
      '   </div>',
      '   <div class="ai-box" style="margin-top:10px">',
      '     <details class="ai-reasoning" open>',
      '       <summary>Reasoning Trace</summary>',
      '       <ul id="ai-trace"></ul>',
      '     </details>',
      '   </div>',
      '   <div class="ai-box" style="margin-top:10px">',
      '     <div class="ai-box-title" style="font-weight:600">Future Impact</div>',
      '     <div id="ai-impact" class="impact-grid"></div>',
      '   </div>',
      ' </div>',
      '</div>'
    ].join('');
    document.body.appendChild(root);

    hdr = root.querySelector('.hdr');
    conv = root.querySelector('#ai-conv');
    actions = root.querySelector('#ai-actions');
    traceList = root.querySelector('#ai-trace');
    summaryBox = root.querySelector('#ai-summary-kvs');
    impactBox = root.querySelector('#ai-impact');

    root.querySelector('button.min').addEventListener('click', function(){
      collapsed = !collapsed;
      root.querySelector('.body').style.display = collapsed ? 'none' : 'grid';
      this.textContent = collapsed ? 'Expand' : 'Minimize';
    });
    root.querySelector('button.cls').addEventListener('click', hide);
    root.querySelector('button.clr').addEventListener('click', clearAll);

    // stick-to-bottom auto-scroll unless user scrolled up
    conv.addEventListener('scroll', function(){
      conv._userScrolledUp = (conv.scrollTop > 10);
    });
  }

  function show(){ build(); root.classList.remove('hidden'); }
  function hide(){ if (!root) return; root.classList.add('hidden'); }
  function sleep(on){ if (!root) return; if (on) root.classList.add('sleep'); else root.classList.remove('sleep'); }

  function clearAll(){
    if (conv){ conv.innerHTML = '<div class="ai-conv-empty">Agents will post their internal updates here during the simulation.</div>'; }
    if (actions){ actions.innerHTML = ''; }
    if (traceList){ traceList.innerHTML = ''; }
    if (summaryBox){ summaryBox.innerHTML = ''; }
    if (impactBox){ impactBox.innerHTML = ''; }
    recentMsgs.length = 0;
  }

  function dedupeKey(agent, message){ return (agent||'')+'|'+(message||''); }
  function pushRecent(key){
    recentMsgs.push({k:key, t:Date.now()});
    if (recentMsgs.length > RECENT_MAX) recentMsgs.shift();
  }
  function seenRecently(key){
    var now = Date.now();
    for (var i=recentMsgs.length-1; i>=0; i--) {
      var r = recentMsgs[i];
      if (r.k === key && (now - r.t) < 4000) return true; // 4s window
      if ((now - r.t) > 12000) { recentMsgs.splice(i,1); }
    }
    return false;
  }

  function ensureConvPlaceholderRemoved(){
    var empty = conv.querySelector('.ai-conv-empty'); if (empty) empty.remove();
  }

  function pulse(agent){
    var id = (agent||'').toLowerCase();
    var el = root && root.querySelector('#pulse-'+id);
    if(!el) return;
    el.style.display = 'inline-block';
    setTimeout(function(){ if (el) el.style.display = 'none'; }, 1400);
  }

  function say(agent, message){
    build();
    var key = dedupeKey(agent, message);
    if (seenRecently(key)) return; // prevent flood
    pushRecent(key);
    ensureConvPlaceholderRemoved();

    var st = agentStyles[agent]||agentStyles.System;

    var row = document.createElement('div');
    row.className = 'ai-row';
    row.innerHTML = '<span class="tag" style="color:'+st.color+';border-color:'+st.glow+';background:'+st.tagBg+'">'+agent+'</span>'+
                    '<span class="msg">'+String(message||'')+'</span>'+
                    '<time>'+new Date().toLocaleTimeString()+'</time>';
    conv.prepend(row);

    // smart autoscroll
    if (!conv._userScrolledUp) {
      conv.scrollTop = 0; // because we prepend
    }
    show();
    pulse(agent);
  }

  function setReasoning(lines){
    build(); traceList.innerHTML='';
    (lines||[]).forEach(function(l){ var li=document.createElement('li'); li.textContent=l; traceList.appendChild(li); });
    show();
  }

  function setActions(list){
    build(); actions.innerHTML=(list||[]).map(function(a){ return '<div>\u2714 '+a+'</div>'; }).join('');
    show();
  }

  function setSummary(kv){
    build();
    // kv can be object {agents:4, external_signals:1, kpis_at_risk:3, forecast_badges:1}
    var items = [];
    for (var k in kv){ if (!Object.prototype.hasOwnProperty.call(kv,k)) continue; items.push({k:k, v:kv[k]}); }
    summaryBox.innerHTML = items.map(function(p){
      var label = String(p.k).replace(/_/g,' ');
      return '<div class="kv"><b>'+p.v+'</b> '+label+'</div>';
    }).join('');
    show();
  }

  function setImpact(data){
    build();
    // data: {recruitment_slowdown:'8–12%', risk_delta:'+2.1', kpis_impacted:3, narrative:'...'}
    var html = ''+
      '<div class="impact-item"><div class="val">'+(data.recruitment_slowdown||'—')+'</div><div class="lbl">Predicted enrollment slowdown (next 30d)</div></div>'+
      '<div class="impact-item"><div class="val">'+(data.risk_delta||'—')+'</div><div class="lbl">Model risk delta</div></div>'+
      '<div class="impact-item"><div class="val">'+(data.kpis_impacted||'—')+'</div><div class="lbl">KPIs likely impacted</div></div>'+
      '<div class="impact-item" style="grid-column:1/-1"><div class="lbl" style="margin-bottom:4px">Narrative</div><div>'+ (data.narrative||'—') +'</div></div>';
    impactBox.innerHTML = html;
    show();
  }

  function addForecastBadge(chartDomId, text, ttlMs){
    try{
      var host = document.getElementById(chartDomId);
      if (!host) return;
      var badge = document.createElement('div');
      badge.className = 'chart-badge';
      badge.textContent = String(text||'Forecast applied');
      host.style.position = host.style.position || 'relative';
      host.appendChild(badge);
      setTimeout(function(){ if (badge && badge.parentNode) badge.parentNode.removeChild(badge); }, ttlMs||6000);
    }catch(_){ }
  }

  // Overlay coordination: auto sleep dock when orchestrator overlay/dimmer is active
  function watchOverlay(){
    var dim = document.getElementById('page-dimmer');
    var orch = document.querySelector('.agent-orch.show, .agent-orch.show *'); // legacy/new
    if (!dim && !orch) return;
    var mo = new MutationObserver(function(){
      var dimOn = dim && (dim.style.display === 'block' || dim.classList.contains('show'));
      var anyOrch = !!document.querySelector('.agent-orch.show');
      var on = dimOn || anyOrch;
      if (on && !hiddenByOverlay){ sleep(true); hiddenByOverlay = true; }
      else if (!on && hiddenByOverlay){ sleep(false); hiddenByOverlay = false; }
    });
    try{
      if (dim) mo.observe(dim, {attributes:true, attributeFilter:['style','class']});
      var orchHost = document.body; mo.observe(orchHost, {subtree:true, childList:true, attributes:true, attributeFilter:['class']});
    }catch(_){ }
  }

  // Public API
  window.IntelDock = {
    init: function(){ build(); watchOverlay(); },
    show: show,
    hide: hide,
    clear: clearAll,
    say: say,
    setReasoning: setReasoning,
    setActions: setActions,
    setSummary: setSummary,
    setImpact: setImpact,
    pulse: pulse,
    addForecastBadge: addForecastBadge
  };
})();