
// === BEGIN: Intelligence Dock integration (floating, decoupled) ===
(function(){
  var RR_FEED_ENABLED = false; // set true if you still want right-rail duplication

  // override/extend the small agentSay used by the AOP demo
  if (typeof agentSay === 'function') {
    var _origSay = agentSay;
    window.agentSay = function(agent, message){
      if (window.IntelDock){ IntelDock.init(); IntelDock.show(); IntelDock.say(agent, message); }
      if (RR_FEED_ENABLED) { try { _origSay(agent, message); } catch(_){} }
    }
  }

  // expose helpers for the AOP block to set intelligence
  window.__Intel = {
    setReasoning: function(lines){ if (window.IntelDock){ IntelDock.init(); IntelDock.show(); IntelDock.setReasoning(lines); } },
    setActions: function(list){ if (window.IntelDock){ IntelDock.init(); IntelDock.show(); IntelDock.setActions(list); } }
  };
})();
// === END: Intelligence Dock integration ===
