// static/js/chatbot_widget.js
(function () {
  "use strict";

  // ---- Small helpers --------------------------------------------------------
  function $(sel, root = document) { return root.querySelector(sel); }
  function $all(sel, root = document) { return Array.from(root.querySelectorAll(sel)); }
  function escapeHtml(s) {
    return String(s ?? '').replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  }
  function mdLite(s) {
    // very small markdown: **bold**
    return escapeHtml(s).replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
  }

  // ---- Global executor (exposed) -------------------------------------------
  window.NNCI = window.NNCI || {};
  NNCI.ChatExec = {
    runActions(actions = []) {
      for (const a of actions) {
        try {
          switch (a.type) {
            case "agentflow.setMode":
              if (window.AgentFlow?.setMode) AgentFlow.setMode(a.mode);
              break;
            case "agentflow.show":
              if (window.AgentFlow?.show) AgentFlow.show(a.chart);
              break;
            default:
              console.warn("[ChatExec] Unknown action:", a);
          }
        } catch (err) {
          console.error("[ChatExec] Failed action", a, err);
        }
      }
    }
  };

  // ---- Widget Controller ----------------------------------------------------
  const Chat = {
    els: {},
    state: {
      therapyArea: "diabetes",
      visibleCharts: [],
    },

    init() {
      this.els.wrap = $("#chatbot-widget");
      if (!this.els.wrap) return false;

      this.els.msgs   = $("#chat-messages");
      this.els.input  = $("#chat-input");
      this.els.send   = $("#chat-send");
      this.els.suggest= $("#chat-suggest-bar");

      // page context
      const root = document.getElementById("mainContentWrap");
      this.state.therapyArea = (root && (root.dataset.therapyArea || root.getAttribute("data-therapy-area"))) || "diabetes";
      this.discoverCharts();

      // Wire events
      this.els.send.addEventListener("click", () => this.send());
      this.els.input.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); this.send(); }
      });

      // Mode buttons
      $all('[data-chat-mode]').forEach(btn => {
        btn.addEventListener("click", () => {
          const mode = btn.getAttribute("data-chat-mode");
          if (mode && window.AgentFlow?.setMode) AgentFlow.setMode(mode);
        });
      });

      // Load suggestions
      this.loadSuggestions();
      // Optionally refresh suggestions if charts DOM changes
      this.observeChartMounts();

      return true;
    },

    discoverCharts() {
      this.state.visibleCharts = $all('.nnci-chart[data-chart-type]').map(el => el.dataset.chartType);
    },

    async loadSuggestions() {
      const vis = this.state.visibleCharts.join(',');
      try {
        const res = await fetch(`/api/chat/suggestions?visible=${encodeURIComponent(vis)}`, { headers:{Accept:'application/json'} });
        const data = await res.json();
        this.renderSuggestions(data.suggestions || []);
      } catch (err) {
        console.warn("[Chat] suggestions failed", err);
      }
    },

    renderSuggestions(suggestions = []) {
      if (!this.els.suggest) return;
      this.els.suggest.innerHTML = "";
      suggestions.forEach(s => {
        const btn = document.createElement("button");
        btn.className = "btn btn-sm btn-outline-primary me-2 mb-2";
        btn.textContent = s.label;
        btn.addEventListener("click", () => {
          // Suggestions may carry a single action or an object
          const actions = Array.isArray(s.action) ? s.action : [s.action];
          NNCI.ChatExec.runActions(actions);
        });
        this.els.suggest.appendChild(btn);
      });
    },

    appendUser(text) {
      if (!this.els.msgs) return;
      const row = document.createElement("div");
      row.className = "chat-msg user";
      row.innerHTML = `<div class="bubble">${escapeHtml(text)}</div>`;
      this.els.msgs.appendChild(row);
      this.els.msgs.scrollTop = this.els.msgs.scrollHeight;
    },

    appendBot(html) {
      if (!this.els.msgs) return;
      const row = document.createElement("div");
      row.className = "chat-msg bot";
      row.innerHTML = `<div class="bubble">${html}</div>`;
      this.els.msgs.appendChild(row);
      this.els.msgs.scrollTop = this.els.msgs.scrollHeight;
    },

    async send() {
      const text = (this.els.input.value || "").trim();
      if (!text) return;
      this.appendUser(text);
      this.els.input.value = "";

      // (Re)discover charts (if user navigated tabs or DOM changed)
      this.discoverCharts();

      const payload = {
        message: text,
        therapy_area: this.state.therapyArea,
        visible_charts: this.state.visibleCharts
      };

      try {
        const res = await fetch('/api/chat/query', {
          method: 'POST',
          headers: {'Content-Type':'application/json'},
          body: JSON.stringify(payload)
        });
        const data = await res.json();

        // render reply
        this.appendBot(mdLite(data.reply || "Okay."));

        // render latest suggestions
        if (Array.isArray(data.suggestions)) this.renderSuggestions(data.suggestions);

        // execute actions (focus charts via agent flow)
        if (Array.isArray(data.actions)) NNCI.ChatExec.runActions(data.actions);

      } catch (err) {
        console.error("[Chat] query failed", err);
        this.appendBot("Sorry—there was an error. Please try again.");
      }
    },

    observeChartMounts() {
      // If chart containers are added/removed later, update the suggestion bar
      const obs = new MutationObserver(() => {
        const before = this.state.visibleCharts.join(',');
        this.discoverCharts();
        const after = this.state.visibleCharts.join(',');
        if (before !== after) this.loadSuggestions();
      });
      obs.observe(document.body, { childList: true, subtree: true });
    }
  };

  document.addEventListener("DOMContentLoaded", () => { Chat.init(); });
})();