import json, sqlite3
from pathlib import Path

DB_PATH = Path("data/trials.db")
JSON_PATH = Path("static/json/trials_master.json")

conn = sqlite3.connect(DB_PATH)
cur = conn.cursor()

cur.executescript(open("schema.sql").read())

def j(x): return json.dumps(x) if isinstance(x, (list, dict)) else x

data = json.loads(JSON_PATH.read_text())

rows = []
for t in data:
    rows.append((
        t.get("trial_id"),
        t.get("title"),
        t.get("sponsor"),
        t.get("drug_name"),
        t.get("mechanism"),
        t.get("therapy_area"),
        t.get("indication"),
        t.get("phase"),
        t.get("status"),
        t.get("fda_approved"),
        t.get("start_date"),
        t.get("primary_completion_date"),
        t.get("last_updated"),
        t.get("enrollment"),
        t.get("sites_count"),
        j(t.get("countries")),
        j(t.get("regions")),
        t.get("primary_outcome_headline"),
        j(t.get("key_kpis")),
        t.get("recruitment_velocity_n_per_month"),
        t.get("expected_entry_year"),
    ))

cur.executemany("""
INSERT OR REPLACE INTO trials VALUES (
?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?
)
""", rows)

conn.commit()
conn.close()
print("JSON → SQLite migration done.")