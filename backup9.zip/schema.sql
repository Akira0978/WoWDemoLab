CREATE TABLE IF NOT EXISTS trials (
    trial_id TEXT PRIMARY KEY,
    title TEXT,
    sponsor TEXT,
    drug_name TEXT,
    mechanism TEXT,
    therapy_area TEXT,
    indication TEXT,
    phase INTEGER,
    status TEXT,
    fda_approved BOOLEAN,
    start_date TEXT,
    primary_completion_date TEXT,
    last_updated TEXT,
    enrollment INTEGER,
    sites_count INTEGER,
    countries TEXT,        -- JSON encoded list
    regions TEXT,          -- JSON encoded list
    primary_outcome_headline TEXT,
    key_kpis TEXT,         -- JSON encoded list
    recruitment_velocity_n_per_month REAL,
    expected_entry_year INTEGER
);
